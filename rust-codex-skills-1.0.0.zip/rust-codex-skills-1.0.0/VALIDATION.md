# Validation — standalone Rust skills 1.0.0

## Result and subject

The standalone folders, optional installer and helpers pass the local checks below.
The core Rust examples pass their declared checks. **Tokio and Serde runtime checks,
a live Codex session, and comparative agent trials did not run.** This is not a claim
that every inherited rule or code fence is fully qualified.

The installable subject is the exact file set in `skills-manifest.json`. Its digest and
actual check commands appear in [evidence/validation.json](evidence/validation.json).
The final ZIP receives a detached checksum and a separate archive-validation record;
that record tests extraction and installation from the actual delivered archive.
No recursive/self-hashing manifest is required.

## Checks completed

| Check | Observation | Scope |
| --- | --- | --- |
| Python regression suite | PASS — 57 tests | Metadata, references, generated views, selection, workspace impact, command separation, installer integrity/overwrite/backup/rollback, and example-oracle failure handling. |
| Rust core examples | PASS — 41 check-and-edition executions | Rust 1.97.1, Linux x86_64; editions 2021 and 2024 as declared. Compilation, expected compiler rejection/warnings, native assertions, real bounded C memcpy, and a separate downstream API crate. |
| Generated indexes and common review contract | PASS | Canonical source and generated views agree. |
| Installable file inventory | PASS | Exact per-skill files and SHA-256 digests agree. |
| Python syntax | PASS | All bundled Python files parsed without writing execution caches. |
| YAML parsing | PASS | Independent PyYAML parse of 14 skill headers and 14 Codex metadata files. PyYAML is not an installation dependency. |
| Evaluation fixture compilation | PASS — six core fixtures | Starting fixtures compile. Unsafe fixtures were not run. This does not mean their behavior is correct or that any agent evaluated them. |
| Source preservation and targeted diff | PASS | Original archive remains unchanged; 16 revised rule files match the declared change inventory. |

The corpus retains **265 rules**, with **1,091 Rust fences** in the revised files.
**21 named fences** feed **27 declared check definitions**, some of which run in two
editions. The other **1,070 fences remain illustrative and unqualified**. Sixteen rule
bodies received targeted changes; 249 remain inherited. New retrieval metadata does
not promote those inherited examples to checked implementations.

Core runtime assertions cover safe slice bounds/overflow, valid raw-pointer callers,
FFI length mismatch with no writes, empty copies, revision correctness/staleness/ABA,
competing commits, exhaustion without mutation, error precedence, external API use,
and independent thread-local storage. Compiler checks cover raw-pointer caller
obligations, invalid safe inputs, Cell/Send/Sync, future Send bounds, unsafe operation
and mutable-static lint levels, exported attributes, storage syntax, and downstream
non-exhaustive restrictions. Passing compilation alone is not a soundness proof.

## Checks not completed

The four Tokio/Serde check definitions would produce eight edition runs. Cargo's offline
resolution failed because the required crates were not available. Those results remain
`NOT_RUN`, with the resolver errors retained. The supplied test sources cover controlled
stale-fetch interleaving, justified async serialization, EOF and partial frames, stop
priority and retained progress, channel closure, watch updates, task detachment, and
isolated Serde unknown/missing/defaulted field behavior. No mock runtime replaced them.

No live Codex skill discovery, model-based implementation or review, independent model
review, or no-skill/original/revised agent comparison ran. The eight-task trial kit is
usable input for that comparison, not evidence of improved model performance. No
native Windows or macOS install/runtime check, multi-version MSRV check, Miri, Loom,
sanitizer, fuzz or load test ran. The code and instructions support ordinary Windows
paths, but Linux tests do not establish Windows reparse or filesystem behavior.

The project inspector is a static manifest reader, not Cargo's feature resolver.
It includes declared local reverse dependencies and widens shared or unknown changes,
but callers must qualify actual build inputs, feature matrices, target policy, recipes
and external workspaces before relying on a minimum check scope.

## Evidence and repaired authoring failures

[Python results](evidence/python-tests.log), [Rust results](evidence/rust-example-results.json),
[fixture compilation](evidence/trial-fixture-compiles.json), and
[toolchain input identity](evidence/toolchain-inputs.json) retain actual observations.
The Rust result has an overall `INCOMPLETE` label when all suites are requested because
eight optional dependency-backed runs did not execute; its 41 completed core cases pass.

[Repair history](evidence/repair-history.md) and the initial logs preserve the two early
harness issues: overly specific wording for a genuine compiler type rejection, and
Markdown-link validation that included inline syntax examples. The final checks use
the same intended safety/type boundary and validate real links. No invalid-pointer
fixture was executed and no product acceptance expectation was weakened.

No source toolchain, credentials, dependency cache, build output or original BBK runtime
ships in the archive. The installer modifies only the selected local skill folders and
its staging/backup locations when the user invokes it. This task did not install into
the user's real Codex environment or publish anything.
