---
name: rust-unsafe-ffi-assurance
description: "Review Rust unsafe, raw pointers, Send/Sync, pinning, initialization, callbacks, and foreign ABIs. Establish safety obligations before selecting evidence."
---

# Rust Unsafe, FFI, and ABI Assurance

Use only when the changed scope or assertion includes unsafe Rust, a foreign boundary, ABI/layout claims, raw pointers, manual thread-safety traits, custom allocation, or generated bindings.

## Contract inventory

For every boundary, identify:

- caller and callee language, target, calling convention, symbol, and ownership;
- value layout, alignment, validity, discriminants, nullability, provenance, and lifetime;
- allocation/deallocation authority and compatible allocator;
- mutation, aliasing, thread affinity, reentrancy, unwind, and callback behavior;
- error representation, cancellation, shutdown, and partial initialization;
- generated binding source, version, command, and drift policy.

## Unsafe invariants

Inspect:

- each `unsafe fn` caller obligation and each unsafe operation's local justification;
- raw-pointer creation, offset, dereference, integer conversion, and provenance assumptions;
- `Pin`, projection, self-reference, and `Unpin` behavior;
- `MaybeUninit`, `ManuallyDrop`, partial initialization, panic paths, and drop order;
- manual `Send`/`Sync` and field changes that could invalidate the proof;
- `repr(C)`, `repr(transparent)`, `repr(packed)`, unions, enum layout, and niche assumptions;
- exported names, `unsafe extern` declarations, calling conventions, and panic/unwind boundaries;
- callbacks retained after return, cross-thread invocation, and teardown races;
- handles, buffers, strings, slices, lengths, and ownership transfer across the boundary.

Missing `// SAFETY:` or `# Safety` text is a reviewability defect. It is not by itself evidence of unsoundness. Establish the false invariant or invalid safe call and its consequences before reporting a soundness defect.

## Evidence selection

Use the cheapest adequate combination:

- static review and small layout/ABI assertions;
- C/Rust or host/guest compile-and-call fixtures;
- generated-binding diff and regeneration receipt;
- targeted Miri where supported;
- sanitizer builds on qualified targets;
- fuzzing for untrusted boundary inputs;
- Loom or deterministic concurrency tests for callback/shared-state ordering;
- fault tests for partial initialization, panic, cancellation, unload, and double-free paths.

A passing dynamic tool is evidence, not proof. Unsupported tool behavior is an unavailable or inconclusive check, not evidence of a candidate defect.

## Required return

For each assigned assertion, return the exact boundary, invariant, evidence, failure scenario, consequence, confidence, remediation, regression test, and disposition. Do not broaden into a general crate review.

## Safety boundary checks

A length or index check does not establish raw-pointer validity, alignment, lifetime,
initialization, or aliasing. A safe wrapper must enforce the complete contract for all
safe callers, usually through references, slices, owned handles, or checked construction.
Otherwise keep the unsafe caller obligation explicit. Shrinking a block is not a reason
to remove `unsafe fn`. Check offsets, arithmetic and zero-length cases as well.

Distinguish Send (ownership transfer) from Sync (shared-reference access). Cell<T> is
Send when T is Send but not Sync; Rc<T> does not become Send by cloning it. Auto traits
are not compiler review of a hand-written unsafe impl. A caller's customary Mutex is
not a universal justification for the type's manual thread-safety contract.

Rust 2024's unsafe_op_in_unsafe_fn lint warns by default; the project's lint policy may
deny it. Unsafe extern blocks and unsafe attributes have separate edition requirements.
Check compiler syntax support, generated declarations, C headers and real linking;
syntax-only tests do not validate a foreign ABI.

<!-- BEGIN GENERATED REVIEW CONTRACT -->
## Findings and evidence

Review only the assigned subject. State the revision or changed files, inspected scope,
assumptions, and important omissions once. A review does not grant permission to edit,
change a public contract, add a dependency, publish, or deploy.

For each supported finding, give the exact path and symbol; the governing requirement
or invariant; a concrete input, failure trace, or interleaving; evidence and its limits;
consequence; the smallest permitted fix; and a regression check. Mark compatibility
impact and unresolved assumptions. Use the project's report format when it captures
these facts; do not create another mandatory report.

Classify evidence as **reproduced defect**, **source-proved defect**, **conditional
hypothesis**, **assurance gap**, or **optional improvement**. Source-proved means the
code and stated preconditions establish the failure without an untested material
assumption. Compilation alone does not prove soundness, behavior, or installed use.
Missing tests, comments, or optional tools do not by themselves prove a product defect.
Derive severity from consequence, reachability, exposure, and the actual obligation,
not the topic name. Keep uncertainty separate from severity.

Return **No supported findings** when appropriate. Recommend no fixed number of tests,
controls, refactors, or reviewers. Preserve correct counterexamples and explain any
important rebuttal. Do not call self-review independent review or treat an unrun check
as passing. Keep existing acceptance conditions intact; report a conflict rather than
quietly weakening them.
<!-- END GENERATED REVIEW CONTRACT -->
