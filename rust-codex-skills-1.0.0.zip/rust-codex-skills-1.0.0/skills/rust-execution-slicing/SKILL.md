---
name: rust-execution-slicing
description: "Plan coherent Rust implementation increments with early consumer tests. Use for multi-step changes, not routine private edits or arbitrary file quotas."
---

# Rust implementation increments

Start from the assigned outcome and its existing design. Keep routine work in one
coherent change. Split only when a boundary reduces reasoning difficulty, separates
real ownership, or produces useful integration evidence sooner.

For each increment, name the concrete result, required code/contracts/inputs, changed
owners and interfaces, the real consumer that will exercise it, checks and expected
outcomes, prerequisites, and recovery or rollback where needed. Plain task notes are
sufficient. Do not require framework-specific objects or metadata.

A useful increment may deliver a CLI operation, API exchange, downstream crate use,
protocol trace, packaged artifact, migration, or measured hot-path change. A foundational
increment needs its own check and named first integrated consumer. Avoid building all
layers before testing the boundary between them.

Complete shared semantics before parallel work. Parallelize independent ready work
only; keep one writer per mutable area or use isolated branches with an integration
owner. Record which outputs actually exist rather than treating plans as prerequisites.

Keep temporary mocks, flags, adapters, and generated inputs visible. State what they
prove, the real counterpart they cannot replace, and when they will be removed. Verify
the integrated candidate after merging; component tests alone do not establish the
combined result. Preserve unfinished work and a concise continuation record when needed.
