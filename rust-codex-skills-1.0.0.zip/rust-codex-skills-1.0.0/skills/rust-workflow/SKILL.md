---
name: rust-workflow
description: "Implement, debug, refactor, or review Rust with repository-aware checks and selected guidance. Start here for Rust work; do not load every reviewer."
---

# Rust workflow

## Establish the task

Read the task and applicable repository instructions before editing. Locate the Cargo
workspace, affected code and consumers, current changes, toolchain pin, editions,
minimum supported Rust version (MSRV), target, feature configurations, and dependency
policy. A compiler version is not the MSRV. Preserve unrelated work. For a new project,
state what does not yet exist and choose only the details the assignment delegates.

Find the project's actual format, lint, build, test, and packaging commands in its
configuration and CI. Inspect recipe bodies; names such as `fmt` or `check` do not
establish effects or coverage. No command is automatically authorized by this skill.
Build scripts, procedural macros, tests, and Cargo configuration can execute code.

For a quick read-only inventory and conservative proposed checks, run:

```sh
python /path/to/rust-workflow/scripts/inspect_project.py --repo /path/to/repo --changed crates/core/src/lib.rs
```

Resolve the script relative to this SKILL.md, not the repository's current directory.
The script reads manifests and recipes; it does not run Cargo or project code. Treat
its static dependency graph as conservative, not a complete feature resolver. Unknown
shared scope means inspect or test more, never an empty affected set. See
[project checks](references/project-checks.md) for its exact limits.

## Select only useful guidance

For routine private work, inspect the changed behavior, implement the smallest correct
change, and run the relevant checks. Do not create a design packet or a review team.
When installed, the sibling `rust-skills` directory supplies a searchable rule library;
read its SKILL.md and select specific rules, not the full catalog. Its helper returns
reasons, limits, and unresolved compatibility, not a code approval.

Use the following installed sibling skills only when their scope matters. Each is
optional and independently usable; absent siblings do not block ordinary Rust work.

| Need | Skill |
| --- | --- |
| Concrete failure or async/state bug | `rust-correctness-failure-review` |
| Unsafe implementation or foreign ABI | `rust-unsafe-ffi-assurance` |
| Public types, traits, features, downstream compatibility | `rust-api-crate-boundary-review` |
| Security, hostile inputs, build/dependency risks | `rust-security-supply-chain-review` |
| Regression evidence and missing test coverage | `rust-test-strategy-review` |
| Deployment, recovery, operational limits | `rust-operational-readiness-review` |
| Requested broad architecture/refactoring review | `comprehensive-analysis-rust` |
| Material implementation design or design conformance | `rust-implementation-structure`, `rust-implementation-structure-review` |
| Multi-step work needing early integration | `rust-execution-slicing` |
| Reproducer, flaky result, benchmark or fault evidence | `rust-evidence-reproducer` |
| Shipped crate, binary, installer, or archive | `rust-package-release-gates` |

A request for review does not permit a rewrite. A description of a technique does not
require adding its crate or tool. Use existing conventions unless they conflict with
a real obligation. Do not narrow public visibility from local usage alone.

## Implement and check

Preserve the invariant while fixing the implementation. A smaller unsafe block cannot
replace an unsafe caller contract. An async lock may deliberately span an await;
releasing it must not allow a stale read/compute/write commit. Cloning does not by
itself make a future Send. Keep task cancellation, shutdown, EOF and closure explicit.

Use the repository's supported package/target/feature configurations. Avoid assuming
`--all-features` is a valid or sufficient matrix. Begin with cheap relevant checks;
complete required checks before claiming success. Distinguish a source-format check
from a formatter that edits files. Recheck the changed candidate after edits.

Use Miri, Loom, fuzzing, sanitizers, mutation tests, and benchmarks only for a named
risk or a binding project requirement. Record missing optional evidence honestly;
do not silently install a toolchain, change dependencies, or waive required evidence.
For shipped artifacts, exercise the actual package outside the workspace.

## Return

State what changed, the exact commands and results, important assumptions, unsupported
checks, and remaining defects. For reviews, include location, failure trace, evidence
class, consequence, permitted fix, and regression check; allow no findings. A small
change needs a small report. Do not claim Codex execution, independent review, or
runtime validation merely from passing helper tests.
