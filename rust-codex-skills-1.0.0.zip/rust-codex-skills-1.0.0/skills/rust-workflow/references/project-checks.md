# Project inspection and proposed checks

`inspect_project.py` requires Python 3.11+ and an explicit Cargo root. It reads TOML
and recipe files, writes JSON only to stdout, and never invokes Cargo, a shell, a
project script, rustup, or a network request. It does not discover changes from Git;
provide all relevant paths, including old and new paths for moves and deleted paths.
No supplied scope selects all inventoried packages, not zero tests.

The helper lists declared workspace members, package editions, inherited MSRVs,
features and local path dependencies. It follows reverse local dependency edges,
including optional, build, development, renamed, inherited and target-specific edges.
It does not implement Cargo resolution. Implicit members, external path roots,
generated includes, build-script reads, custom harnesses and cfg-dependent behavior
need inspection or a properly scoped Cargo metadata result. Missing member manifests
and unknown shared paths widen scope and remain explicit issues.

Workspace manifests, lockfiles, toolchain pins, Cargo configuration, shared recipes,
and CI changes select the whole inventoried workspace. Do not treat that static set
as complete when unresolved external or implicit packages exist. Do not weaken an
existing broader CI requirement because the helper finds a smaller set.

Repository recipes remain unqualified candidates. In particular, `just fmt`, `make
format`, and any `*-check` name are not evidence that a recipe avoids source edits.
Read the body and invoked tools, arguments, features, target, shell, environment and
expected test selection. The helper never substitutes a recipe by name.

The proposed `cargo fmt --all -- --check` disables rustfmt's normal source rewrite.
That is not a claim that arbitrary tool lookup/configuration has no other effects.
Cargo lint/test commands can run build scripts, macros, tests and external code, write
build state, or resolve dependencies; `--locked` prevents lockfile changes but is not
an offline or no-execution guarantee. Apply the task's permissions and actual project
policy. Use `--offline` when required and supported; a missing cache is not a pass.

The proposed checks use default features because the helper has not qualified any
feature matrix. Confirm the required default, no-default, optional, target and release
variants. `--all-features` can be invalid and cannot prove every supported combination.
These are check plans, never check results. Record commands, selected cases and skips,
then bind results to the actual changed candidate.
