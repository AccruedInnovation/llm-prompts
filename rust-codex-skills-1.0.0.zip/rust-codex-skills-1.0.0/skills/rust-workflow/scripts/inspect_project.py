#!/usr/bin/env python3
"""Read Cargo manifests; propose conservative checks without executing project code."""
from __future__ import annotations
import argparse
import fnmatch
import hashlib
import json
import re
import sys
import tomllib
from pathlib import Path, PurePosixPath, PureWindowsPath
from typing import Any

MAX_BYTES = 2_000_000


def read_manifest(path: Path) -> dict[str, Any]:
    if path.stat().st_size > MAX_BYTES:
        raise ValueError(f"manifest too large: {path}")
    return tomllib.loads(path.read_text(encoding="utf-8"))


def relative_input(value: str) -> str:
    value = value.replace("\\", "/")
    p = PurePosixPath(value)
    if p.is_absolute() or PureWindowsPath(value).drive or ".." in p.parts:
        raise ValueError(f"changed path must be repository-relative: {value!r}")
    return p.as_posix()


def dependency_tables(manifest: dict[str, Any]):
    for section in ("dependencies", "build-dependencies", "dev-dependencies"):
        yield manifest.get(section, {})
    for target in manifest.get("target", {}).values():
        for section in ("dependencies", "build-dependencies", "dev-dependencies"):
            yield target.get(section, {})


def inspect_project(repo: Path, changed: list[str] | None = None) -> dict[str, Any]:
    root = repo.resolve(strict=True)
    manifest_path = root / "Cargo.toml"
    top = read_manifest(manifest_path)
    workspace = top.get("workspace", {})
    issues: list[str] = []
    paths: set[Path] = set()
    if "package" in top:
        paths.add(manifest_path)
    patterns = workspace.get("members", [])
    excluded = workspace.get("exclude", [])
    for pattern in patterns:
        normalized = relative_input(pattern)
        found = []
        for member in root.glob(normalized):
            if any(fnmatch.fnmatch(member.relative_to(root).as_posix(), e) for e in excluded):
                continue
            candidate = (member / "Cargo.toml").resolve()
            if not candidate.is_relative_to(root):
                issues.append(f"member outside inspected root: {pattern}")
                continue
            if candidate.is_file():
                found.append(candidate)
                paths.add(candidate)
        if not found:
            issues.append(f"member pattern has no readable manifest: {pattern}")
    if not paths:
        raise ValueError("no package manifests found; pass the Cargo workspace/package root")

    manifests: dict[Path, dict[str, Any]] = {}
    by_dir: dict[Path, str] = {}
    packages: dict[str, dict[str, Any]] = {}
    inherited = workspace.get("package", {})
    # A static declared-member inventory: implicit members and external path roots
    # remain limitations, never silent claims of a full Cargo-resolved graph.
    for path in sorted(paths):
        try:
            m = read_manifest(path)
            pkg = m["package"]
            name = pkg["name"]
            if name in packages:
                raise ValueError(f"duplicate package name: {name}")
            manifests[path] = m
            by_dir[path.parent] = name
            def value(key: str, default=None):
                v = pkg.get(key, default)
                return inherited.get(key) if isinstance(v, dict) and v.get("workspace") else v
            packages[name] = {
                "manifest": path.relative_to(root).as_posix(),
                "directory": path.parent.relative_to(root).as_posix(),
                "edition": value("edition", "2015"),
                "rust_version": value("rust-version"),
                "features": sorted(m.get("features", {})),
                "local_dependencies": [],
            }
        except (OSError, KeyError, ValueError, TypeError) as exc:
            issues.append(f"cannot fully inspect {path.relative_to(root)}: {exc}")
    if not packages:
        raise ValueError("no valid package records")
    for path, m in manifests.items():
        name = m["package"]["name"]
        deps = set()
        for table in dependency_tables(m):
            for alias, spec in table.items():
                if not isinstance(spec, dict):
                    continue
                base = path.parent
                if spec.get("workspace"):
                    spec = workspace.get("dependencies", {}).get(alias)
                    base = root
                    if spec is None:
                        issues.append(f"unresolved workspace dependency: {name}/{alias}")
                        continue
                    if not isinstance(spec, dict):
                        continue
                if "path" in spec:
                    location = (base / spec["path"]).resolve()
                    if location in by_dir:
                        deps.add(by_dir[location])
                    else:
                        issues.append(f"path dependency outside declared inventory: {name}/{alias}")
        packages[name]["local_dependencies"] = sorted(deps)

    normalized = [relative_input(p) for p in changed] if changed is not None else []
    all_names = set(packages)
    affected: set[str] = set()
    reasons: list[str] = []
    conservative = bool(issues)
    shared_files = {"Cargo.toml", "Cargo.lock", "rust-toolchain", "rust-toolchain.toml", "build.rs", "Justfile", "justfile", "Makefile", "mise.toml", ".mise.toml", "rustfmt.toml", ".rustfmt.toml", "clippy.toml", ".clippy.toml"}
    for file in normalized:
        if file in shared_files or file.startswith((".cargo/", ".github/", ".config/")):
            conservative = True
            reasons.append(f"shared configuration or workspace input changed: {file}")
            continue
        owners = [name for name, p in packages.items() if p["directory"] != "." and (file == p["directory"] or file.startswith(p["directory"] + "/"))]
        if not owners and "package" in top:
            owners = [top["package"]["name"]]
        if owners:
            owner = max(owners, key=lambda n: len(packages[n]["directory"]))
            affected.add(owner)
            reasons.append(f"path owner: {file} -> {owner}")
        else:
            conservative = True
            reasons.append(f"unknown shared impact; do not assume no packages: {file}")
    if not normalized:
        conservative = True
        reasons.append("no changed-path scope supplied; consider all inventoried packages")
    # Include reverse local dependencies, even optional/build/dev/target-specific ones.
    while True:
        previous = affected.copy()
        for name, pkg in packages.items():
            if set(pkg["local_dependencies"]) & affected:
                affected.add(name)
        if affected == previous:
            break
    if conservative:
        affected = all_names
        reasons.extend(issues)
    selection = ["--workspace"] if conservative else [arg for name in sorted(affected) for arg in ("-p", name)]
    check_plan = [
        {"id": "format-check", "argv": ["cargo", "fmt", "--all", "--", "--check"], "source_rewrite": False, "coverage": "workspace Rust formatting, not behavior"},
        {"id": "lint", "argv": ["cargo", "clippy", *selection, "--all-targets", "--locked"], "source_rewrite": False, "coverage": "selected packages, default features; inspect repository lint policy"},
        {"id": "tests", "argv": ["cargo", "test", *selection, "--locked"], "source_rewrite": False, "coverage": "selected packages, default features; verify actual selected test cases"},
    ]
    for check in check_plan:
        check.update({"status": "PROPOSED_NOT_RUN", "cwd": str(root), "feature_target_qualification": "REQUIRED", "effects_note": "Cargo/tool lookup, configuration, build scripts, macros and tests may execute code or write build state; source_rewrite is not a sandbox guarantee"})
    candidates = []
    for name in ("Justfile", "justfile", "Makefile", "mise.toml", ".mise.toml", "Taskfile.yml", "Taskfile.yaml"):
        p = root / name
        if p.is_file():
            if p.stat().st_size > MAX_BYTES:
                issues.append(f"recipe file too large: {name}")
                continue
            text = p.read_text(encoding="utf-8", errors="replace")
            candidates.append({"path": name, "sha256": hashlib.sha256(p.read_bytes()).hexdigest(), "status": "UNQUALIFIED_INSPECT_BODY", "possible_entry_points": [line.strip() for line in text.splitlines() if re.match(r"^[A-Za-z_][\w-]*\s*:", line)][:40], "automatic_substitution": False})
    toolchain = None
    pin = root / "rust-toolchain.toml"
    if pin.is_file():
        try:
            toolchain = read_manifest(pin).get("toolchain", {})
        except (OSError, ValueError) as exc:
            issues.append(f"toolchain not parsed: {exc}")
    elif (root / "rust-toolchain").is_file():
        toolchain = {"channel": (root / "rust-toolchain").read_text().strip()}
    return {"schema": "rust-project-inspection.v1", "repo": str(root), "toolchain_pin": toolchain, "packages": packages, "default_members": workspace.get("default-members"), "changed_paths": normalized, "affected_packages": sorted(affected), "scope": "CONSERVATIVE_ALL" if conservative else "DECLARED_LOCAL_DEPENDENTS", "scope_reasons": reasons, "issues": issues, "project_command_candidates": candidates, "proposed_checks": check_plan, "executed_commands": [], "limitations": ["Static declared Cargo members only; no cargo metadata or feature resolver was run.", "Path dependencies, generated inputs, build scripts and includes can create additional edges; resolve those before relying on a minimal scope.", "All optional, dev, build and target-specific local edges are included conservatively. Unknown edges widen scope; all means all inventoried packages, not external workspaces.", "No network, Cargo, project recipe, rustup or subprocess execution."]}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--changed", action="append", default=None, help="repository-relative path; repeat for each changed path")
    args = parser.parse_args()
    try:
        print(json.dumps(inspect_project(args.repo, args.changed), indent=2))
    except (OSError, ValueError, TypeError, KeyError) as exc:
        print(json.dumps({"status": "ERROR", "error": str(exc), "executed_commands": []}), file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
