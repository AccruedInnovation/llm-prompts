---
name: rust-implementation-structure-review
description: "Compare Rust implementation with its supplied design and contracts. Distinguish broken shared obligations from permitted private implementation choices."
---

# Rust implementation structure review

Bind the exact code revision and supplied requirements or design. No special schema,
workflow engine, or separate inventory file is required. When no design exists, state
that limit rather than inventing historical decisions.

Trace each material obligation through its actual owner and consumer: crate/module
responsibility, dependency direction, public types/traits/functions/macros, features,
wire formats, state ownership, locks and tasks, error and recovery behavior, persistence,
unsafe/ABI boundaries, packaging, and required verification.

Classify differences as **conforms**, **within delegated freedom**, **material
divergence**, or **not assessed**. Missing or stale evidence is not conformance. A
material divergence must cite the fixed behavior or shared contract it changes.
A private module tree, helper name, or local representation may differ freely unless
an actual binding requirement specifies it. Similar file trees do not prove correctness.

Propose the smallest fix or controlling-design correction; do not authorize your own
change to a protected contract. Recheck only affected obligations with adequate scope.

<!-- BEGIN GENERATED REVIEW CONTRACT -->
## Findings and evidence

Review only the assigned subject. State the revision or changed files, inspected scope,
assumptions, and important omissions once. A review does not grant permission to edit,
change a public contract, add a dependency, publish, or deploy.

For each supported finding, give the exact path and symbol; the governing requirement
or invariant; a concrete input, failure trace, or interleaving; evidence and its limits;
consequence; the smallest permitted fix; and a regression check. Mark compatibility
impact and unresolved assumptions. Use the project's report format when it captures
these facts; do not create another mandatory report.

Classify evidence as **reproduced defect**, **source-proved defect**, **conditional
hypothesis**, **assurance gap**, or **optional improvement**. Source-proved means the
code and stated preconditions establish the failure without an untested material
assumption. Compilation alone does not prove soundness, behavior, or installed use.
Missing tests, comments, or optional tools do not by themselves prove a product defect.
Derive severity from consequence, reachability, exposure, and the actual obligation,
not the topic name. Keep uncertainty separate from severity.

Return **No supported findings** when appropriate. Recommend no fixed number of tests,
controls, refactors, or reviewers. Preserve correct counterexamples and explain any
important rebuttal. Do not call self-review independent review or treat an unrun check
as passing. Keep existing acceptance conditions intact; report a conflict rather than
quietly weakening them.
<!-- END GENERATED REVIEW CONTRACT -->
