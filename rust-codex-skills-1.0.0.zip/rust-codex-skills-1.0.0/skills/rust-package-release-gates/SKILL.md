---
name: rust-package-release-gates
description: "Check Rust crate or binary delivery through the actual package, installation, startup, shutdown, and consumer path. Packaging checks do not grant publishing authority."
---

# Rust packaging and delivery checks

Use when the task ships a crate, binary, native library, archive, installer, or container.
Read the release contract and repository policy. Building, packaging, publishing,
deploying, and accepting a release are separate actions with separate permissions.

## Crates

Inspect declared include/exclude rules and, when permitted, `cargo package --list`.
Run the repository's locked packaging command under its supported toolchain. Inspect
actual archive contents, manifest, license, README, examples, generated bindings and
native build inputs. Cargo package verification is not a replacement for all tests.

Extract the exact package into a clean disposable directory outside the workspace.
Exercise a downstream consumer and the supported feature/target configurations. Check
for missing path dependencies, workspace leakage, excluded schemas, generated files,
or environment-dependent build inputs. Do not publish or fetch dependencies implicitly.

## Binaries and services

Verify the actual shipped bytes, architecture, native dependencies, configuration and
data discovery. Exercise supported install/startup/shutdown/error paths under normal
permissions. Check diagnostics, redaction, migration, partial install, rollback, and
removal where the delivery contract requires them. Do not infer Windows, macOS, hardware,
container, or offline support from a Linux workspace test.

## Scope and result

Respect the real feature matrix; `--all-features` is neither universally valid nor a
replacement for default/no-default/selected configurations. Treat panic strategy, LTO,
linking, stripping, codegen, CPU features, and ABI as project decisions, not universal
presets. Record package hash, source identity, toolchain, commands, checks, and limits.
Rebuild and retest the affected delivery path after changing package contents. An
extraction check proves extraction, not runtime behavior or reproducible builds.
