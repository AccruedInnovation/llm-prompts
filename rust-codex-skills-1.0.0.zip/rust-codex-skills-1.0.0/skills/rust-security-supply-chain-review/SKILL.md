---
name: rust-security-supply-chain-review
description: "Review Rust trust boundaries, hostile inputs, permissions, unsafe code, dependencies, build scripts, and release integrity against a stated threat model."
---

# Rust Security Supply Chain Review

## Procedure

Establish the assigned change or revision, relevant contracts, allowed effects, and
current evidence. Stay read-only unless the task also requests repairs. Review input trust, authorization, secrets, resource limits, native boundaries, build execution, and release integrity. Start from the real input-to-consumer path and the changed boundaries.

Use [the focused guide](references/review-guide.md) for depth. Skim its headings,
then read only the sections implicated by the code, obligation, or failure. Do not
turn its broad questions into a checklist of mandatory changes. For a large subject,
state what you covered; do not imply complete coverage from a sample.

For a suspected issue, attempt to disprove it with existing guards, call sites, tests,
feature settings, and supported operating limits. Where authorized, make a small
reproducer rather than a broad rewrite. Recheck fixes against the same obligation.
Repository conventions outrank stylistic preferences; no new crate or external tool
is mandatory merely because the guide mentions it.

Separate an observed vulnerability from an unreviewed dependency or a missing policy.
Establish the threat model and reachable inputs. No finding does not certify release
security; report evidence gaps and the limited claim. A release decision needs its
actual required checks and authority. Never execute an untrusted build to inspect it
without the permitted containment and effects.

Use separate agents only when actually available, permitted, and useful. One model's
successive passes are self-review. Preserve source attribution, deduplicate findings,
and avoid another review of the same scope without a distinct question.

<!-- BEGIN GENERATED REVIEW CONTRACT -->
## Findings and evidence

Review only the assigned subject. State the revision or changed files, inspected scope,
assumptions, and important omissions once. A review does not grant permission to edit,
change a public contract, add a dependency, publish, or deploy.

For each supported finding, give the exact path and symbol; the governing requirement
or invariant; a concrete input, failure trace, or interleaving; evidence and its limits;
consequence; the smallest permitted fix; and a regression check. Mark compatibility
impact and unresolved assumptions. Use the project's report format when it captures
these facts; do not create another mandatory report.

Classify evidence as **reproduced defect**, **source-proved defect**, **conditional
hypothesis**, **assurance gap**, or **optional improvement**. Source-proved means the
code and stated preconditions establish the failure without an untested material
assumption. Compilation alone does not prove soundness, behavior, or installed use.
Missing tests, comments, or optional tools do not by themselves prove a product defect.
Derive severity from consequence, reachability, exposure, and the actual obligation,
not the topic name. Keep uncertainty separate from severity.

Return **No supported findings** when appropriate. Recommend no fixed number of tests,
controls, refactors, or reviewers. Preserve correct counterexamples and explain any
important rebuttal. Do not call self-review independent review or treat an unrun check
as passing. Keep existing acceptance conditions intact; report a conflict rather than
quietly weakening them.
<!-- END GENERATED REVIEW CONTRACT -->
