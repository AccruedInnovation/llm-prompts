# Focused review guide

Use only the sections relevant to the assignment. The evidence and scope rules in
SKILL.md govern how to report findings. This guide supplies questions, not proof that
a defect exists or permission to impose a new requirement. Preserve correct code.


**Core Architectural Philosophy:** 
Evaluate the code through the lens of **Deep Module Architecture**: simple public APIs hiding meaningful implementation complexity. Flag shallow abstractions that add indirection without reducing cognitive load. Do not recommend additional layers unless they materially improve testability, changeability, or domain isolation. **Testability** must be treated as a first-class citizen, driving decoupling and interface design.

**Analysis Dimensions:**
Analyze the codebase across the following categories. Be concise, objective, and pragmatic.
1. **Maintainability & Complexity:** Identify unnecessary coupling, high cyclomatic complexity, and anti-patterns. Identify APIs requiring callers to invoke methods in a specific order for correctness (e.g., Initialize → Validate → Execute → Cleanup) when ordering is not enforced by the type system or API design. Suggest simplifications.
2. **Change Amplification & Evolution:** Identify concepts whose modification requires coordinated changes across unrelated modules. Highlight opportunities to localize change around a single domain concept.
3. **Architecture & Modularity:** Evaluate domain boundaries. Are upper-level APIs deep enough? Are lower-level primitives appropriately scoped? 
4. **Pattern Drift:** Identify areas where multiple architectural styles coexist for the same concern (e.g., some features use repositories, others query the database directly; some handlers return fragments, others return JSON). Recommend convergence when inconsistency increases cognitive load.
5. **Cognitive Load:** Identify areas where understanding a feature requires traversing excessive files, abstractions, configuration, or framework indirection.
6. **Dependency Direction:** Assess whether dependencies point inward toward stable domain concepts. Identify infrastructure leakage into business logic, circular dependencies, and violations of architectural layering.
7. **Domain Model Integrity:** Are business invariants enforced in the correct layer? Are domain concepts represented explicitly or leaking as primitive types, stringly-typed identifiers, magic constants, or duplicated validation rules?
8. **Invariant Duplication:** Flag business rules implemented in multiple layers (handlers, services, repositories, frontend validation, database constraints). Give the rule one authoritative definition; allow validation at separate trust boundaries and database constraints where they protect distinct failure paths.
9. **Dead Code & Unused Artifacts:** Unreachable branches, unused exports, stale feature flags, orphaned database migrations, commented-out code, or hard-coded values where they should be dynamic.
10. **Testability:** Highlight hard-to-test code (e.g., hidden side-effects, tight coupling to I/O or global state). Suggest dependency injection boundaries or pure function refactors.
11. **Test Suite Health & Coverage Gaps** Are there untested critical paths, brittle integration tests, missing error-path coverage, or tests that don’t validate behaviour realistically? Identify over-reliance on mocks where integration tests are needed.
12. **Performance & Efficiency:** Spot algorithmic bottlenecks, inefficient memory/allocation patterns, and over-fetching or N+1 issues.
13. **Data Access & Persistence:** Evaluate repository design, transaction boundaries, query efficiency, consistency guarantees, caching strategy, and separation between domain and persistence concerns.
14. **Robustness & Error Handling:** Assess how the system handles failure. Evaluate whether errors have consistent semantics, propagation rules, wrapping conventions, retry behavior, and user-facing representations. Suggest improvements for graceful degradation, fail-fast mechanisms, and exhaustive error handling.
15. **Observability & Durability:** Identify blind spots in logging, metrics, and distributed tracing. Check traceability and durability for the state and outcomes the operating contract requires; logging does not make state durable.
16. **Concurrency & State Management:** Spot potential race conditions, deadlocks, unguarded shared state, or inefficient async/threading paradigms. Also assess transaction usage, lack of idempotency keys for external calls, and safe state rollback mechanisms.
17. **Security (Zero-Trust):** Identify missing input validation, improper state exposure, or vulnerability to common injection/XSS vectors (especially at backend/frontend boundaries).
18. **Rust and Project Conventions:** Check ownership, errors, async APIs, standard-library choices, and the project's conventions. Recommend a change only for a stated benefit or violated contract.
19. **Documentation & Onboarding:** Missing documentation that impedes onboarding or future maintenance (complex algorithms, domain assumptions).
20. **Consumer Contract Alignment:** Check each declared consumer, representation, and compatibility promise. Do not prefer HTML, JSON, or a frontend framework without the project's selected contract.
21. **Operational Readiness:** Assess deployment safety, migration strategy, configuration management, backward compatibility, feature flag usage, and rollback capability.
22. **Configuration Complexity:** Flag configuration spread across environment variables, config files, feature flags, database values, and runtime overrides where effective behavior becomes difficult to reason about. Identify configuration that leaks deep into business logic rather than being resolved at application boundaries.
23. **Abstraction ROI:** For every abstraction (trait, interface, repository, service, middleware, package, helper, wrapper, generic type, macro), evaluate whether it meaningfully reduces cognitive load, isolates volatility, or improves testability. Flag abstractions whose maintenance cost exceeds their architectural benefit.

**Rust-Specific Heuristics:**
When analyzing the code, apply the following language-specific lenses:

* **Ownership & Lifetimes:** Flag excessive use of `.clone()`, `Rc`, or `Arc<Mutex<T>>` used purely to escape the borrow checker. Identify opportunities to simplify ownership through better data modeling or by moving allocations up the call stack.
* **Shared Ownership Audit:** Flag pervasive `Arc<T>`, `Arc<RwLock<T>>`, or `Arc<Mutex<T>>` usage where ownership boundaries are unclear. Excessive shared ownership often indicates weak domain decomposition.
* **Async/Tokio Hazards:** Identify blocking I/O or CPU-bound work inside async functions that could starve the reactor. Flag `std::sync::Mutex` being held across `.await` points.
* **Type-State Pattern & Invariants:** Evaluate if the type system is being fully utilized to make invalid states unrepresentable (e.g., using Enums for state machines rather than structs with optional/nullable fields).
 - **Error Handling Strategy:** Follow the repository error strategy. Strongly typed domain errors and contextual application errors are useful patterns; `thiserror` and `anyhow` are options, not mandatory dependencies. Flag `unwrap()` or `expect()` outside of tests unless justified by an invariant comment; flag only _unjustified_ unwraps.
 - **Error Boundary Discipline:** Ensure infrastructure errors are translated into domain/application errors at appropriate boundaries. Flag leakage of database, HTTP, or serialization errors into domain APIs.
 - **Lost Errors:** Flag `let _ = fallible()` or discarded `Result` values without an explicit comment explaining why the error is intentionally ignored.
* **Trait Bloat:** Flag dynamic dispatch (`Box<dyn Trait>`) that adds indirection without enabling runtime polymorphism, testability, or boundary isolation.
* **Unsafe Code Audit:** Flag any `unsafe` block that lacks a `// SAFETY:` explanation or any public `unsafe fn` without caller obligations. Missing documentation is a reviewability defect; classify severity from a supported failure and exposure, not merely because a comment is missing.
- **Build & Feature Bloat:** Identify overly complex Cargo feature flags (combinatorial explosion, dead features, mutually exclusive flags) that increase compile time and cognitive load.
- **Visibility Discipline:** Establish the effective exported API, documented support policy, and downstream consumers. Local non-use does not prove a public item is unused. Narrow visibility only when it preserves compatibility or an authorized breaking change permits it.
- **Macro Abstraction Cost:** Flag derives or proc macros that obscure invariants, generate significant hidden behavior, or materially increase compile time without reducing cognitive load.
- **Cancellation Safety:** Evaluate whether async operations leave state partially mutated when futures are cancelled. Flag lock acquisition, transaction handling, or state mutation patterns that are not cancellation-safe.

## Do Not Recommend

* Introducing abstractions without a named invariant, complexity reduction, or useful test seam; one implementation alone is not evidence of waste.
* Splitting modules solely for size.
* Replacing straightforward code with patterns/frameworks absent a clear benefit.
* Dependency injection frameworks where constructor injection suffices.
* Microservices decomposition unless strong evidence exists.
* Additional interfaces that do not improve testing or reduce coupling.
