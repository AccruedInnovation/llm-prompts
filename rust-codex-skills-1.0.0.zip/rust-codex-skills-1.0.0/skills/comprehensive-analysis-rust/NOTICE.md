# Attribution

Adapted from the user-supplied `bbk-profile-rust-0.1.0-alpha.3` archive.
The supplied package carries the MIT license retained in LICENSE. Its rule corpus
identifies leonardomso as author and declares MIT. Focused review prompts came from
the user's supplied material; no further original licensing provenance was supplied.
This adaptation changes instructions and packaging; it does not bundle or require
the source package's runtime. Rust, Cargo, third-party crates, and referenced tools
are not included. No broader third-party rights are asserted.
