---
name: rust-skills
description: "Retrieve specific Rust rules for ownership, errors, APIs, unsafe code, async work, tests, and performance. Reference guidance, not mandatory project policy."
---

# Rust rule reference

Use this reference for a concrete Rust question. The task, repository contracts,
compatibility promises, and allowed effects control the work. Rules guide reasoning;
they do not mandate a crate, toolchain, architecture, or blanket refactor.

## Read a bounded set

Start from the changed behavior and relevant risk. Resolve paths relative to this
skill directory. With Python 3.11 or later:

```sh
python /path/to/rust-skills/scripts/select_rules.py --topic unsafe --msrv 1.82 --edition 2021 --limit 6
python /path/to/rust-skills/scripts/select_rules.py --query "cancel read EOF" --topic async --limit 6
```

The selector returns rule IDs, paths, reasons, exclusions, code-use constraints, and
any truncation. It does not read a repository, execute Rust, download dependencies,
or prove applicability. Keep all named risks covered even when a reading budget
truncates results. Read the chosen rule bodies before acting on their summaries.

Without Python, use the [category index](references/categories.md), then the relevant
category page. These pages and `rules-index.json` are generated from each rule's first
blockquote and `references/rule-metadata.json`; do not edit generated summaries.

## Applicability and versions

Establish the project's MSRV, edition, compiler pin, crate versions/features, platform,
and target. Unknown compatibility is **not established**, not supported by default.
Explicit example constraints take priority over broad advice. Reading a soundness
principle on an older compiler does not authorize copying newer syntax. A low-MSRV
exclusion should prompt a compatible expression of the invariant, not dropping it.

Optimization needs a relevant workload or resource constraint and measurement where
needed. Library choices follow existing policy. Miri and other specialized tools are
conditional unless the project requires them. Diagnose lock lifetime and state
consistency together; do not mechanically remove async serialization or clone data.

## Evidence scope

Most inherited examples are illustrations, not independently runnable or qualified
fixtures. `examples/catalog.json` records every Rust code fence and its content hash.
Only examples named in `examples/checks.json` have an executable expectation; inspect
the actual result record before claiming they passed. A compile-pass does not prove
soundness or runtime behavior; a compile-fail must fail for its intended reason.

The optional check harness executes only declared examples, in temporary directories:

```sh
python /path/to/rust-skills/scripts/check_examples.py --rustc /path/to/rustc --suite core --output results.json
```

Tokio and Serde suites additionally need Cargo and their pinned dependencies. The
harness defaults to offline resolution; do not grant network access implicitly. See
[example checks](examples/README.md) for commands, effects, and coverage limits.

For a review, distinguish reproduced or source-proved defects from conditional
hypotheses, assurance gaps, and optional improvements. Return no supported findings
when the code meets its contract. Do not use untested examples as acceptance oracles.
