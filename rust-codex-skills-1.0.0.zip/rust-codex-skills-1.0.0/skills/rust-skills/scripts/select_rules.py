#!/usr/bin/env python3
"""Return bounded rule references with reasons and explicit compatibility limits."""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any

SKILL = Path(__file__).resolve().parents[1]
ROUTINE = ['err-result-over-panic', 'own-borrow-over-clone', 'type-newtype-ids', 'test-arrange-act-assert']
PRIORITY = ['unsafe-minimize-scope', 'unsafe-send-sync-manual', 'unsafe-extern-block', 'unsafe-no-mangle-unsafe', 'unsafe-miri-ci', 'async-cancel-safety', 'async-no-lock-await', 'async-clone-before-await', 'async-watch-latest', 'async-select-racing', 'api-non-exhaustive', 'serde-deny-unknown-fields']


def version(value: str | None) -> tuple[int, int, int] | None:
    if value is None:
        return None
    if not re.fullmatch(r'\d+\.\d+(?:\.\d+)?', value):
        raise ValueError(f'invalid stable Rust version: {value!r}; use major.minor[.patch]')
    numbers = [int(s) for s in value.split('.')]
    return tuple(numbers + [0] * (3 - len(numbers)))


def select_rules(*, topics: list[str] | None = None, query: str = '', rule_ids: list[str] | None = None, msrv: str | None = None, rust_version: str | None = None, edition: str | None = None, channel: str = 'stable', limit: int = 6, byte_budget: int = 24000) -> dict[str, Any]:
    if not 1 <= limit <= 50 or not 256 <= byte_budget <= 1_000_000:
        raise ValueError('limit must be 1..50; byte budget must be 256..1000000')
    minimum = version(msrv)
    current = version(rust_version)
    if minimum and current and current < minimum:
        raise ValueError('active compiler is below the declared MSRV')
    if edition not in (None, '2015', '2018', '2021', '2024'):
        raise ValueError('unknown Rust edition')
    edition_min = {'2015': (1,0,0), '2018': (1,31,0), '2021': (1,56,0), '2024': (1,85,0)}
    if edition:
        for label, number in [('MSRV', minimum), ('compiler', current)]:
            if number and number < edition_min[edition]:
                raise ValueError(f'{label} does not support edition {edition}')
    index = json.loads((SKILL / 'rules-index.json').read_text())
    rules = index['rules']
    by_id = {r['id']: r for r in rules}
    topics = topics or []
    rule_ids = rule_ids or []
    known_topics = {t for r in rules for t in r['topics']}
    if set(topics) - known_topics:
        raise ValueError(f'unknown topic(s): {sorted(set(topics)-known_topics)}; available: {sorted(known_topics)}')
    if set(rule_ids) - set(by_id):
        raise ValueError(f'unknown rule IDs: {sorted(set(rule_ids)-set(by_id))}')
    tokens = set(re.findall(r'[a-z0-9]+', query.lower()))
    candidates = []
    for r in rules:
        reasons = []
        hits = set(topics) & set(r['topics'])
        haystack = set(re.findall(r'[a-z0-9]+', (r['id']+' '+r['summary']).lower()))
        text_hits = tokens & haystack
        if r['id'] in rule_ids:
            reasons.append('explicit rule request')
        if hits:
            reasons.append('topic: '+', '.join(sorted(hits)))
        if text_hits:
            reasons.append('query terms: '+', '.join(sorted(text_hits)))
        if not topics and not tokens and not rule_ids and r['id'] in ROUTINE:
            reasons.append('small routine-work reading set')
        if not reasons:
            continue
        score = (1000 if r['id'] in rule_ids else 0) + len(hits)*100 + len(text_hits)*10 + (20 - PRIORITY.index(r['id']) if r['id'] in PRIORITY else 0)
        candidates.append((score, r, reasons))
    candidates.sort(key=lambda v: (-v[0], v[1]['id']))
    selected = []
    excluded = []
    deferred = []
    total = 0
    for _, r, reasons in candidates:
        c = r['compatibility']
        need = version(c['minimum_rust'])
        blocked = []
        if need and minimum and minimum < need:
            blocked.append(f'example syntax needs Rust {c["minimum_rust"]}; project MSRV is {msrv}')
        if need and current and current < need:
            blocked.append('active compiler does not support declared example syntax')
        if edition and c['editions'] and edition not in c['editions']:
            blocked.append('edition outside declared example support')
        if c['channel'] == 'nightly-tool' and channel != 'nightly':
            blocked.append('technique requires separately qualified nightly tooling; not a reason to change project MSRV')
        if blocked:
            excluded.append({'id': r['id'], 'reasons': blocked, 'invariant_note': 'Preserve any applicable underlying invariant; use compatible syntax or another justified check.'})
            continue
        if len(selected) >= limit or total + r['bytes'] > byte_budget:
            deferred.append(r['id'])
            continue
        path = SKILL / r['path']
        if hashlib.sha256(path.read_bytes()).hexdigest() != r['sha256']:
            raise ValueError(f'stale rule index for {r["id"]}; regenerate before selection')
        total += r['bytes']
        compatibility = 'DECLARED_CONSTRAINTS_MATCH' if need and minimum and edition and c['editions'] and c['channel'] == 'stable' else 'NOT_ESTABLISHED'
        selected.append({'id': r['id'], 'path': r['path'], 'summary': r['summary'], 'reasons': reasons, 'bytes': r['bytes'], 'sha256': r['sha256'], 'applicability': r['applicability'], 'compatibility': compatibility, 'constraints': c, 'review_state': r['review_state'], 'code_use': 'VERIFY_SELECTED_EXAMPLE_AND_PROJECT_CONTRACT'})
    return {'schema': 'rust-rule-selection.v1', 'selected': selected, 'excluded': excluded, 'deferred_count': len(deferred), 'deferred_sample': deferred[:10], 'selected_rule_bytes': total, 'limit': limit, 'byte_budget': byte_budget, 'coverage_warning': 'Selection is retrieval, not risk-coverage proof. Follow unresolved cross-references and expand a truncated set when obligations require it.', 'unknown_policy': 'Missing version, dependency, platform, or qualification evidence is not compatibility or correctness.', 'known_topics': sorted(known_topics)}


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--topic', action='append', default=[])
    p.add_argument('--query', default='')
    p.add_argument('--rule', action='append', default=[])
    p.add_argument('--msrv')
    p.add_argument('--rust-version')
    p.add_argument('--edition', choices=['2015','2018','2021','2024'])
    p.add_argument('--channel', choices=['stable','nightly'], default='stable')
    p.add_argument('--limit', type=int, default=6)
    p.add_argument('--byte-budget', type=int, default=24000)
    a = p.parse_args()
    try:
        print(json.dumps(select_rules(topics=a.topic, query=a.query, rule_ids=a.rule, msrv=a.msrv, rust_version=a.rust_version, edition=a.edition, channel=a.channel, limit=a.limit, byte_budget=a.byte_budget), indent=2))
    except (OSError, ValueError, KeyError) as exc:
        print(json.dumps({'status':'ERROR','error':str(exc)}),file=sys.stderr)
        return 2
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
