#!/usr/bin/env python3
"""Compile/test declared rule examples. Offline by default; never execute rejection cases."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

SKILL = Path(__file__).resolve().parents[1]


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def command(argv: list[str], cwd: Path, env: dict[str, str], timeout: int) -> dict[str, Any]:
    try:
        r = subprocess.run(argv, cwd=cwd, env=env, text=True, encoding="utf-8", errors="replace", capture_output=True, timeout=timeout, check=False)
        return {"argv": argv, "cwd": str(cwd), "exit_code": r.returncode, "stdout": r.stdout, "stderr": r.stderr, "timed_out": False}
    except subprocess.TimeoutExpired as exc:
        def text(v): return v.decode("utf-8", "replace") if isinstance(v, bytes) else (v or "")
        return {"argv": argv, "cwd": str(cwd), "exit_code": None, "stdout": text(exc.stdout), "stderr": text(exc.stderr), "timed_out": True}
    except OSError as exc:
        return {"argv": argv, "cwd": str(cwd), "exit_code": None, "stdout": "", "stderr": str(exc), "unavailable": True, "timed_out": False}


def extract_examples(skill: Path) -> dict[str, str]:
    examples = {}
    # Only explicitly named examples can be executed. Unmarked inherited fences
    # remain inventory, not an implicit permission to compile or run arbitrary text.
    for path in sorted((skill / "rules").glob("*.md")):
        text = path.read_text(encoding="utf-8")
        pattern = r"<!-- example: ([a-z0-9-]+) -->[ \t]*\n```rust[^\n]*\n(.*?)^```[ \t]*$"
        for m in re.finditer(pattern, text, re.M | re.S):
            if m[1] in examples:
                raise ValueError(f"duplicate named example: {m[1]}")
            examples[m[1]] = m[2]
    catalog = json.loads((skill / "examples/catalog.json").read_text(encoding="utf-8"))
    for entry in catalog["examples"]:
        if entry["id"] in examples and digest(examples[entry["id"]].encode()) != entry["sha256"]:
            raise ValueError(f"example changed after catalog generation: {entry['id']}")
    declared = {entry["id"] for entry in catalog["examples"]}
    if set(examples) - declared:
        raise ValueError("named examples missing from generated catalog")
    return examples


def assess(kind: str, result: dict[str, Any], expected: list[str], count: int | None = None) -> tuple[str, str]:
    if result.get("unavailable"):
        return "NOT_RUN", "executable unavailable"
    if result.get("timed_out"):
        return "INCONCLUSIVE", "command timed out"
    combined = result["stdout"] + "\n" + result["stderr"]
    if kind == "compile-fail":
        if result["exit_code"] == 0:
            return "FAIL", "intended compiler rejection did not occur"
        if not all(s in combined for s in expected):
            return "FAIL", "compiler failed without all intended diagnostics"
        # Missing symbols, imports and syntax errors must not mask the intended guard.
        if re.search(r"\bE(?:0425|0432|0433|0412|0658)\b", combined):
            return "FAIL", "unrelated compiler error invalidates the negative fixture"
        return "PASS", "intended compiler rejection; no executable run"
    if result["exit_code"] != 0:
        return "FAIL", "unexpected command failure"
    if kind == "compile-warning":
        if not all(s in combined for s in expected) or not re.search(r"(?m)^warning(?:\[|:)", combined):
            return "FAIL", "expected warning not observed"
    if kind == "run-pass":
        summaries = re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; .*?(\d+) filtered out", combined)
        if not summaries or sum(int(s[0]) for s in summaries) != count or any(int(v) for s in summaries for v in s[1:]):
            return "FAIL", "expected test count or full execution not established"
    return "PASS", "declared expectation met"


def manifest_text(dependencies: dict, edition: str) -> str:
    text = f'[package]\nname = "rust-skill-examples"\nversion = "0.0.0"\nedition = "{edition}"\n\n[workspace]\n\n[dependencies]\n'
    for name, spec in dependencies.items():
        fields = ['version = ' + json.dumps(spec["version"])]
        if spec.get("features"):
            fields.append("features = " + json.dumps(spec["features"]))
        text += f'{name} = {{ ' + ", ".join(fields) + " }\n"
    return text


def run_checks(skill: Path, suites: list[str], rustc: str, cargo: str, allow_network: bool, timeout: int, ids: list[str] | None = None) -> dict:
    manifest = json.loads((skill / "examples/checks.json").read_text(encoding="utf-8"))
    examples = extract_examples(skill)
    unknown = set(suites) - set(manifest["suites"])
    if unknown:
        raise ValueError(f"unknown suites: {sorted(unknown)}")
    if ids and set(ids) - {c["id"] for c in manifest["checks"]}:
        raise ValueError("unknown check id")
    checks = [c for c in manifest["checks"] if c["suite"] in suites and (not ids or c["id"] in ids)]
    if not checks:
        raise ValueError("selection contains no checks")
    env = os.environ.copy()
    rustc_path = shutil.which(rustc)
    if rustc_path:
        env["PATH"] = str(Path(rustc_path).resolve().parent) + os.pathsep + env.get("PATH", "")
        env["RUSTC"] = rustc_path
    if not allow_network:
        env["CARGO_NET_OFFLINE"] = "true"
    results = []
    suite_records = {}
    with tempfile.TemporaryDirectory(prefix="rust-skill-examples-") as tmp:
        work = Path(tmp)
        env["CARGO_TARGET_DIR"] = str(work / "target")
        version = command([rustc, "--version", "--verbose"], work, env, timeout)
        for suite in suites:
            deps = manifest["suites"][suite]["dependencies"]
            if not deps:
                continue
            probe = work / ("resolve-" + suite)
            (probe / "src").mkdir(parents=True)
            (probe / "src/lib.rs").write_text("", encoding="utf-8")
            (probe / "Cargo.toml").write_text(manifest_text(deps, "2021"), encoding="utf-8")
            args = [cargo, "generate-lockfile"] + ([] if allow_network else ["--offline"])
            result = command(args, probe, env, timeout)
            resolved = result["exit_code"] == 0
            suite_records[suite] = {"resolved": resolved, "command": result, "dependencies": deps}
            if resolved:
                lock = (probe / "Cargo.lock").read_bytes()
                suite_records[suite].update(lock_sha256=digest(lock), lock_content=lock.decode())
        for check in checks:
            for edition in check["editions"]:
                rec = {"id": check["id"], "suite": check["suite"], "kind": check["kind"], "edition": edition, "commands": []}
                rec["source_sha256"] = {n: digest(examples[n].encode()) for n in check["examples"] + check.get("library_examples", [])}
                if version["exit_code"] != 0:
                    rec.update(status="NOT_RUN", reason="Rust compiler unavailable")
                    results.append(rec); continue
                if check.get("platform") and check["platform"] != sys.platform:
                    rec.update(status="NOT_RUN", reason="example requires declared platform: " + check["platform"])
                    results.append(rec); continue
                if check["suite"] in suite_records and not suite_records[check["suite"]]["resolved"]:
                    rec.update(status="NOT_RUN", reason="declared dependencies not resolved; see suite command")
                    results.append(rec); continue
                case = work / (check["id"] + "-" + edition)
                case.mkdir()
                text = "\n".join(examples[n] for n in check["examples"])
                if check.get("harness"):
                    hp = (skill / check["harness"]).resolve()
                    if not hp.is_relative_to(skill.resolve()):
                        raise ValueError("harness path outside skill")
                    data = hp.read_bytes()
                    rec["harness_sha256"] = digest(data)
                    text += "\n" + data.decode("utf-8")
                source = case / "example.rs"
                source.write_text(text, encoding="utf-8")
                rec["assembled_source_sha256"] = digest(source.read_bytes())
                libs = []
                if check.get("library_examples"):
                    lp = case / "library.rs"
                    lp.write_text("\n".join(examples[n] for n in check["library_examples"]), encoding="utf-8")
                    lib = case / "libexample_api.rlib"
                    result = command([rustc, f"--edition={edition}", "--crate-name", "example_api", "--crate-type", "rlib", str(lp), "-o", str(lib)], case, env, timeout)
                    rec["commands"].append(result)
                    if result["exit_code"] != 0:
                        rec.update(status="FAIL", reason="prerequisite library did not compile")
                        results.append(rec); continue
                    libs = ["--extern", f"example_api={lib}"]
                kind = check["kind"]
                if check["suite"] != "core":
                    (case / "src").mkdir()
                    shutil.copyfile(source, case / "src/lib.rs")
                    deps = manifest["suites"][check["suite"]]["dependencies"]
                    (case / "Cargo.toml").write_text(manifest_text(deps, edition), encoding="utf-8")
                    (case / "Cargo.lock").write_text(suite_records[check["suite"]]["lock_content"], encoding="utf-8")
                    args = [cargo, "test", "--lib", "--locked"] + ([] if allow_network else ["--offline"]) + ["--", "--test-threads=1"]
                    result = command(args, case, env, timeout)
                    rec["commands"].append(result)
                else:
                    exe = case / ("example-tests.exe" if sys.platform == "win32" else "example-tests")
                    args = [rustc, f"--edition={edition}", "--crate-name", "rule_example", str(source), *libs, *check.get("rustc_flags", [])]
                    args += ["--test", "-o", str(exe)] if kind == "run-pass" else ["--crate-type", "lib", "--emit=metadata", "-o", str(case / "example.rmeta")]
                    result = command(args, case, env, timeout)
                    rec["commands"].append(result)
                    if kind == "run-pass":
                        if result["exit_code"] != 0:
                            rec.update(status="FAIL" if not result.get("timed_out") else "INCONCLUSIVE", reason="test program did not compile")
                            results.append(rec); continue
                        result = command([str(exe), "--test-threads=1"], case, env, timeout)
                        rec["commands"].append(result)
                status, reason = assess(kind, result, check.get("expected_diagnostics", []), check.get("test_count"))
                rec.update(status=status, reason=reason)
                if kind == "run-pass":
                    rec["expected_tests"] = check["test_count"]
                results.append(rec)
    counts = {s: sum(r["status"] == s for r in results) for s in ("PASS", "FAIL", "NOT_RUN", "INCONCLUSIVE")}
    overall = "FAIL" if counts["FAIL"] else "INCOMPLETE" if counts["NOT_RUN"] or counts["INCONCLUSIVE"] else "PASS"
    return {"schema": "rust-example-results.v1", "status": overall, "scope": suites, "network_allowed": allow_network, "host": platform.platform(), "compiler": version, "checks_manifest_sha256": digest((skill / "examples/checks.json").read_bytes()), "suite_resolution": suite_records, "counts": counts, "results": results, "limits": ["Only selected named examples were checked; inherited fences remain unqualified.", "Expected rejection proves the stated compiler boundary, not all memory safety.", "Runtime tests bind to this compiler, configuration and host, not every target or toolchain.", "No Miri or agent-comparison run is implied."]}


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--suite", action="append", choices=["core", "tokio", "serde", "all"])
    p.add_argument("--check", action="append", dest="ids")
    p.add_argument("--rustc", default="rustc")
    p.add_argument("--cargo", default="cargo")
    p.add_argument("--allow-network", action="store_true")
    p.add_argument("--timeout", type=int, default=60)
    p.add_argument("--output", type=Path)
    a = p.parse_args()
    if a.timeout < 1:
        p.error("--timeout must be positive")
    suites = a.suite or ["core"]
    if "all" in suites:
        suites = ["core", "tokio", "serde"]
    try:
        report = run_checks(SKILL, list(dict.fromkeys(suites)), a.rustc, a.cargo, a.allow_network, a.timeout, a.ids)
    except (OSError, ValueError, KeyError) as exc:
        print(json.dumps({"status": "ERROR", "error": str(exc)}), file=sys.stderr)
        return 2
    text = json.dumps(report, indent=2) + "\n"
    if a.output:
        a.output.parent.mkdir(parents=True, exist_ok=True)
        a.output.write_text(text, encoding="utf-8")
        print(json.dumps({"status": report["status"], "counts": report["counts"], "output": str(a.output)}))
    else:
        print(text)
    return 1 if report["status"] == "FAIL" else 2 if report["status"] == "INCOMPLETE" else 0


if __name__ == "__main__":
    raise SystemExit(main())
