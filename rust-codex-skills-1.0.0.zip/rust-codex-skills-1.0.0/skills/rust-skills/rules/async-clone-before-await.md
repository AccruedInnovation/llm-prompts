# async-clone-before-await

> Own or borrow data across await according to its lifetime and Send requirements; cloning is not a general fix for suspension or thread safety.

A future may hold references across await. A shared reference to T can be Send when
T is Sync; lifetime validity and thread transfer are separate requirements. Keeping
an owned Arc alive often lets a future borrow its contents without copying them.
Cloning Rc does not make it Send. Arc<T> itself needs the appropriate T bounds; it
does not make an arbitrary interior type safe to share across threads.

## Borrowing from an owned Arc can be Send

<!-- example: borrowed-arc-future -->
```rust
use std::sync::Arc;

pub async fn borrowed_len(data: Arc<Vec<u8>>) -> usize {
    let slice = &data[..];
    std::future::ready(()).await;
    slice.len()
}

fn requires_send<T: Send>(_: T) {}

pub fn check_future() {
    requires_send(borrowed_len(Arc::new(vec![1, 2, 3])));
}
```

## An Rc held across await still is not Send

This compiler-only negative fixture must fail at the Send bound.

<!-- example: rc-future-not-send -->
```rust
async fn holds_rc() -> u32 {
    let value = std::rc::Rc::new(7_u32);
    std::future::pending::<()>().await;
    *value
}
fn requires_send<T: Send>(_: T) {}
fn check_not_send() {
    requires_send(holds_rc());
}
```

When spawning a task, check the spawn API's actual Send and lifetime bounds. Move
owned data or clone a handle when the task needs independent ownership. For intentionally
local non-Send work, use the runtime's supported local-task mechanism when the project
allows it. Do not add clones that merely retain the same unsatisfied bounds.

Cloning shared state under a lock creates a snapshot. A later result must not overwrite
newer state without its required identity/revision check. See
[lock and commit semantics](async-no-lock-await.md). If an operation must use current
state through completion, independent ownership is not a substitute for that contract.

## References

- [Send and Sync](https://doc.rust-lang.org/nomicon/send-and-sync.html)
- [Arc thread safety](https://doc.rust-lang.org/std/sync/struct.Arc.html)
- [Tokio spawn bounds](https://docs.rs/tokio/latest/tokio/task/fn.spawn.html)
