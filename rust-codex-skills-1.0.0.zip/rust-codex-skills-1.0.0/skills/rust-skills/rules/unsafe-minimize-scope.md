# unsafe-minimize-scope

> Preserve the caller's safety contract; use small unsafe blocks only after establishing every operation's preconditions.

## Why it matters

`unsafe fn` declares obligations on callers. An `unsafe` block asserts that the
implementation has met the obligations of an operation. These are different jobs.
A short block does not make a raw-pointer API safe. A check that `index < len` proves
nothing about the pointer's allocation, alignment, initialized contents, lifetime,
or whether another access may conflict.

Prefer a safe reference- or slice-based interface when it represents the input.
Keep arithmetic behavior explicit too; this example reports an invalid index or
addition overflow as `None` rather than making the result build-profile dependent.

## Safe interface

<!-- example: unsafe-slice-sum -->
```rust
pub fn sum_at(values: &[i32], index: usize) -> Option<i32> {
    values.get(index)?.checked_add(1)
}
```

A safe caller cannot forge the slice's validity with safe Rust. This does not grant
permission to change an existing API's error or overflow contract; adapt the example
to the assigned contract.

## When a raw-pointer interface is required

<!-- example: unsafe-raw-sum -->
```rust
/// Read element `index` and add one, returning None on addition overflow.
///
/// # Panics
/// Panics when index is not less than len.
///
/// # Safety
/// For an in-range index, ptr must point to the first of len initialized i32
/// values in one live allocation. The range must be properly aligned and
/// valid for shared reads for this call. No concurrent or conflicting write
/// may access the element. The allocation and offset must satisfy ptr.add.
pub unsafe fn sum_at_raw(ptr: *const i32, len: usize, index: usize) -> Option<i32> {
    assert!(index < len, "index out of bounds");
    // SAFETY: the caller supplies a live, aligned, initialized readable range;
    // the check establishes that index is inside that range.
    let value = unsafe { *ptr.add(index) };
    value.checked_add(1)
}
```

Do not turn this into a safe function accepting arbitrary pointers. A comment that
simply assumes callers passed valid pointers cannot enforce a safe public contract.
The empty case fails the index check before pointer arithmetic or dereference.

## Edition and lint distinction

Rust 2024 makes `unsafe_op_in_unsafe_fn` warn by default, not a language hard error.
A project can promote the lint to an error. An explicit block around an unsafe
operation inside an unsafe function keeps the two responsibilities visible.

The following compiler-only fixture intentionally triggers that warning. Do not
execute it with an invalid pointer.

<!-- example: unsafe-lint-warning -->
```rust
pub unsafe fn read_one(ptr: *const u8) -> u8 {
    *ptr
}
```

Keep blocks small enough to audit, but do not fragment one coherent safety argument
into repetitive comments. Review the complete abstraction and all safe callers,
constructors, mutation paths, and destruction paths, not only the block's line count.

## References

- [Pointer read safety](https://doc.rust-lang.org/std/ptr/fn.read.html)
- [Rust 2024 unsafe operation lint](https://doc.rust-lang.org/edition-guide/rust-2024/unsafe-op-in-unsafe-fn.html)
- [Safety comments](unsafe-safety-comment.md)
- [Foreign declarations](unsafe-extern-block.md)
