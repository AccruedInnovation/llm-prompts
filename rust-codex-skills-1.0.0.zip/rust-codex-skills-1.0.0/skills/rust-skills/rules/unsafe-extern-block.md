# unsafe-extern-block

> Match the real foreign ABI and preserve caller obligations; use unsafe extern syntax when the compiler and edition support or require it.

## Declaration and call safety

Rust 1.82 introduced `unsafe extern` and explicit item safety annotations in all
editions. Rust 2024 requires the unsafe block marker. Functions default to unsafe
unless explicitly declared safe; there is no need to annotate every unsafe item.
Only declare an item safe when every safe call is valid under its actual contract.
A correct keyword does not prove a correct signature, ABI, symbol, or lifetime.

## Bounded C example

This example targets a conventional C `memcpy` ABI with `size_t` matching Rust's
`usize`, as on the tested Linux host. Validate the real target's headers and linking
rather than assuming this declaration works on every platform. For ordinary Rust
copies, prefer `copy_from_slice` instead of introducing an FFI call.

<!-- example: ffi-slice-copy -->
```rust
use std::ffi::c_void;

unsafe extern "C" {
    fn memcpy(dst: *mut c_void, src: *const c_void, count: usize) -> *mut c_void;
}

#[derive(Debug, PartialEq, Eq)]
pub struct LengthMismatch;

pub fn copy_bytes(dst: &mut [u8], src: &[u8]) -> Result<(), LengthMismatch> {
    if dst.len() != src.len() {
        return Err(LengthMismatch);
    }
    if src.is_empty() {
        return Ok(());
    }
    // SAFETY: the slices supply live initialized readable bytes and writable
    // storage for the checked length. Safe references prevent overlapping
    // access to these nonempty regions; u8 has alignment 1. The declaration
    // matches the C memcpy ABI on this example's declared target.
    unsafe {
        memcpy(dst.as_mut_ptr().cast(), src.as_ptr().cast(), src.len());
    }
    Ok(())
}
```

The slice interface and checks justify the call; the comment alone does not. A raw
pointer alternative must remain unsafe unless construction enforces its full
contract. A safe function taking arbitrary `*mut u8`, `*const u8`, and a length and
then calling `memcpy` is unsound even with a small block and an optimistic comment.

Do not declare `errno` as an ordinary external static without checking the platform:
its access may use thread-local storage or a function-like macro. Do not invent a
safe foreign symbol to make an example link. Binding generators and their settings
must match the actual compiler, edition, headers, and target; review generated output.

`cargo fix --edition` edits code and cannot verify foreign declarations. Use it only
when the assignment permits migration, then review signatures and call contracts.
A metadata-only compile test does not establish linking or foreign runtime behavior.

## References

- [Rust unsafe extern guide](https://doc.rust-lang.org/edition-guide/rust-2024/unsafe-extern.html)
- [Non-overlapping copy safety](https://doc.rust-lang.org/std/ptr/fn.copy_nonoverlapping.html)
- [Safety boundaries](unsafe-minimize-scope.md)
- [Unsafe exported attributes](unsafe-no-mangle-unsafe.md)
