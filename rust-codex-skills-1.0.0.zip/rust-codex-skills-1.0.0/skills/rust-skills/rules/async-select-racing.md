# async-select-racing

> Use select for an explicit race policy, preserving losing-operation state, fixed deadlines, and closed-channel behavior.

`tokio::select!` polls branches concurrently on one task; it is not parallel execution.
A blocking branch can prevent other branches from progressing. A branch guard controls
polling, not evaluation of the expression that creates the future. Avoid side effects
in future construction when a disabled branch must do nothing.

Read [async-cancel-safety](async-cancel-safety.md) before introducing a race around I/O,
locks, transactions, or spawned tasks. Losing branch-owned futures are dropped, not
rolled back. An externally retained future borrowed through `&mut` can survive. A
future is dropped when its owner drops it, not by waiting for a future await point.
Cancellation safety is about the resulting state and progress, not faster cancellation.

## Channel closure is a real branch result

This example treats either a stop message or stop-sender closure as shutdown. Closing
the command channel also terminates the loop. The callback must be brief and synchronous;
a long or async handler needs a separate stated cancellation and work-ownership policy.

<!-- example: select-command-loop -->
```rust
pub async fn command_loop<F>(
    commands: &mut tokio::sync::mpsc::Receiver<u8>,
    stop: &mut tokio::sync::oneshot::Receiver<()>,
    mut process: F,
) where F: FnMut(u8) {
    loop {
        tokio::select! {
            biased;
            _ = &mut *stop => break,
            command = commands.recv() => match command {
                Some(value) => process(value),
                None => break,
            },
        }
    }
}
```

A `Some(command) = recv()` pattern disables its branch for that invocation when the
channel closes. An `else` branch does not run while another enabled shutdown future
remains pending. Match `None` explicitly when closure itself should terminate.

Biased selection gives a ready stop branch first polling priority here. It is not a
global scheduling or real-time guarantee. An always-ready earlier branch can starve
later work; state the priority and fairness contract. Default randomized polling is
not an equal-service or bounded-wait guarantee.

For timeout policies, retain an absolute deadline or a timer outside a loop; recreating
a relative sleep after each event can indefinitely extend the operation. A sequential
fallback may be correct when the primary must fail before the fallback starts. Do not
replace it with a race unless parallel effects and cancellation satisfy the contract.

## References

- [Tokio select](https://docs.rs/tokio/latest/tokio/macro.select.html)
- [Cancellation and task ownership](async-cancel-safety.md)
