# serde-deny-unknown-fields

> Choose unknown-field handling from the wire or configuration contract; distinguish ignored extra keys from missing required fields.

In formats such as JSON, Serde's derived struct deserializer normally ignores unknown
fields. It still reports a missing required field unless a default, optional type, or
custom deserializer permits the omission. A misspelled required `timeout_secs` does
not silently become zero merely because an unknown key was ignored.

Use `deny_unknown_fields` when extra keys are forbidden by the contract, such as a
strict user configuration where typos must be caught. Tolerating extra fields may be
part of forward compatibility. Adding strict rejection can break existing consumers;
do not impose it on every request or response.

<!-- example: serde-unknown-contract -->
```rust
use serde::Deserialize;

#[derive(Debug, Deserialize, PartialEq)]
pub struct TolerantConfig {
    pub timeout_secs: u64,
}

#[derive(Debug, Deserialize, PartialEq)]
#[serde(deny_unknown_fields)]
pub struct StrictConfig {
    pub timeout_secs: u64,
}

#[derive(Debug, Deserialize, PartialEq)]
pub struct DefaultedConfig {
    #[serde(default)]
    pub timeout_secs: u64,
}
```

For `{"timeout_secs":30,"extra":1}`, TolerantConfig accepts the known value while
StrictConfig rejects the extra field. For `{"timout_secs":30}`, TolerantConfig reports
a missing timeout_secs; DefaultedConfig permits the missing field and supplies zero.
Those cases isolate different guards. A negative fixture with a missing required
field does not, by its failure alone, prove unknown-field rejection.

Serde documents that flatten and deny_unknown_fields cannot be combined in the
flattened arrangement. Do not assume deserializing into a generic Value preserves all
syntax-level facts: duplicate keys or other information may already have been lost.
Choose a parser and validation path that preserve every fact the contract checks.

## References

- [Serde container attributes](https://serde.rs/container-attrs.html)
- [Serde field attributes](https://serde.rs/field-attrs.html)
- [Flatten](serde-flatten.md)
