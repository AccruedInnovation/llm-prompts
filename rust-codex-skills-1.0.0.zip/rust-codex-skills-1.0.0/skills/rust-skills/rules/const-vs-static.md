# const-vs-static

> Choose const for a value and static for a shared storage identity; measure storage costs instead of assuming inlining or duplication.

## Why It Matters

A `const` denotes a value, not one guaranteed storage identity. Its uses may create
values or references to promoted storage; it is not a promise of zero storage, automatic
copying, or one machine-code layout. A `static` denotes a program-lifetime allocation;
use it when a shared identity or one storage owner matters. A zero-sized object need
not have a unique address. Large-table placement depends on actual uses and optimization,
so measure binary and runtime costs instead of calling every large const a defect.

A `&'static T` does not always require a static item: literals and eligible constant
promotion can also supply it. For global mutable state, use the synchronization or
initialization abstraction that fits the contract. Atomics do not make compound
invariants atomic; OnceLock and LazyLock establish initialization, not arbitrary future
mutation. Check target atomic support and toolchain versions.

The Rust 2024 `static_mut_refs` lint is deny-by-default for references to mutable statics,
including implicit references. Declaring a mutable static is not itself a language error;
by-value access and raw pointers have their own unsafe obligations. Lowering the lint
never establishes safety.

## Choices to review

```rust
// A const value: placement and duplication depend on its uses and optimization.
const LOOKUP: [u8; 256] = [0u8; 256];

// A mutable-static declaration is permitted; access needs a sound unsafe contract.
static mut COUNTER: u64 = 0;

// A small static can be appropriate when a shared identity is required.
static TIMEOUT_MS: u64 = 5000;
```

## Alternatives for the stated purpose

<!-- example: const-storage-example -->
```rust
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{LazyLock, OnceLock};

// Named values without a shared-storage requirement.
const MAX_RETRIES: u32 = 3;
const TIMEOUT_MS: u64 = 5_000;
const FLAG_MASK: u8 = 0b0000_1111;

// Shared static storage for this table.
static LOOKUP: [u8; 256] = [0u8; 256];

fn process(byte: u8) -> u8 {
    LOOKUP[byte as usize]
}

// A named static referencing a string literal; a const reference could also work.
static APP_NAME: &str = "my-app";

// mutable global state — use atomics, not `static mut`
static REQUEST_COUNT: AtomicU64 = AtomicU64::new(0);

fn record_request() {
    REQUEST_COUNT.fetch_add(1, Ordering::Relaxed);
}

// lazily initialized global — `LazyLock` (stable since 1.80)
static CONFIG_PATH: LazyLock<String> = LazyLock::new(|| {
    std::env::var("CONFIG_PATH").unwrap_or_else(|_| "/etc/app/config.toml".to_owned())
});

// single-assignment global — `OnceLock`
static GREETING: OnceLock<String> = OnceLock::new();

fn set_greeting(name: &str) {
    let _ = GREETING.set(format!("hello, {name}"));
}
```

## When to Prefer Which

| Situation | Use |
|-----------|-----|
| Small constant (number, bool, tiny array) | `const` |
| String literal | `const` or `static` (both work; prefer `const`) |
| Table needing one storage identity | `static`; measure actual layout |
| Need `&'static T` | Static storage, literals, or eligible promotion |
| Mutable counter / flag | `static AtomicXxx` |
| Lazily initialized value | `static LazyLock<T>` |
| Single-writer initialization | `static OnceLock<T>` |

## See Also

- [name-consts-screaming](name-consts-screaming.md) - naming `SCREAMING_SNAKE_CASE` for `const` and `static`
- [own-mutex-interior](own-mutex-interior.md) - use `Mutex<T>` for interior mutability in multi-threaded code

## References

- [Constant items and promoted references](https://doc.rust-lang.org/reference/items/constant-items.html)
- [Mutable static reference lint](https://doc.rust-lang.org/edition-guide/rust-2024/static-mut-references.html)
