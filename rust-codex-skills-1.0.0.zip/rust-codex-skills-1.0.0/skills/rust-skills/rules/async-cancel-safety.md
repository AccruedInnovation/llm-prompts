# async-cancel-safety

> Define progress, ownership, deadlines, and terminal states before racing futures; cancellation safety depends on the operation and how the future is retained.

## What dropping a branch means

`tokio::select!` stops polling losing branches and drops branch-owned futures when
the invocation finishes. A branch borrowing an externally retained future drops the
borrow, not that underlying future. Cancellation can discard a future's progress
state even when its external buffer still exists. Moving just the buffer outside the
future does not make `read_exact` restartable: the next call does not know how much the
previous call consumed.

Tokio documents `read` and `mpsc::Receiver::recv` as cancellation-safe in this racing
sense. `read_exact` and `read_to_end` are not general restartable substitutes. Cancelling
`Mutex::lock` loses queue position; that is a fairness/progress issue, not proof that
protected data was corrupted. Recreating a relative sleep can extend a deadline
indefinitely under frequent other events; retain a fixed deadline when that is the rule.

An owned oneshot receiver dropped with a branch can discard your access to the reply;
retain and poll `&mut` to preserve it. Distinguish a live oneshot sender from cancellation.
Awaiting `&mut JoinHandle` can preserve the result when another branch wins. Dropping
the owned handle detaches the task; it does not cancel or join it. Keep a task owner,
choose finish/abort/reconcile policy, and observe completion. Abort is not rollback,
and a started `spawn_blocking` task cannot generally be aborted.

## Framed input with explicit terminal states

This illustrative protocol has fixed four-byte frames. Channel messages are a stop
request; channel closure disables that branch and leaves the read active. Clean EOF
ends successfully; EOF inside a frame is an error. Stop returns the pending bytes to
the caller rather than silently losing them. Processing a completed frame is a
synchronous callback so the reader does not hide a second cancellation boundary.

<!-- example: cancel-frame-reader -->
```rust
use std::io;
use tokio::io::{AsyncRead, AsyncReadExt};
use tokio::sync::mpsc;

#[derive(Debug, PartialEq, Eq)]
pub enum ReadEnd {
    Eof,
    Stopped(Vec<u8>),
}

pub async fn read_frames<R, F>(
    reader: &mut R,
    stop: &mut mpsc::Receiver<()>,
    mut on_frame: F,
) -> io::Result<ReadEnd>
where
    R: AsyncRead + Unpin,
    F: FnMut([u8; 4]),
{
    let mut buffer = [0_u8; 4];
    let mut filled = 0;
    let mut stop_open = true;
    loop {
        tokio::select! {
            biased;
            message = stop.recv(), if stop_open => {
                match message {
                    Some(()) => return Ok(ReadEnd::Stopped(buffer[..filled].to_vec())),
                    None => stop_open = false,
                }
            }
            result = reader.read(&mut buffer[filled..]) => {
                let count = result?;
                if count == 0 {
                    return if filled == 0 {
                        Ok(ReadEnd::Eof)
                    } else {
                        Err(io::Error::new(io::ErrorKind::UnexpectedEof, "partial frame"))
                    };
                }
                filled += count;
                if filled == buffer.len() {
                    on_frame(buffer);
                    filled = 0;
                }
            }
        }
    }
}
```

The biased order intentionally gives an already-ready stop request priority. It does
not claim that a stop arriving later prevents every read. A closed stop channel is
checked once and disabled, preventing a permanently-ready branch from spinning.
The buffer is never read through an empty remaining slice: a full frame resets filled.

This function preserves progress when a select branch loses, not when its *entire*
future is dropped. Whole-task abort, a read error, or a callback panic needs the
caller's declared connection/discard/recovery policy. Put parser progress in a
longer-lived owner when arbitrary cancellation must allow resumption. The callback
must not block for long or perform unbounded work; asynchronous effects require an
explicit separate owner and acknowledgement contract.

Retaining a pinned future can preserve internal progress between select iterations,
but it must continue to be polled and must not hold a permit needed by an awaited
branch handler. Do not poll a completed future again. Pinning alone neither drives
work nor prevents whole-owner cancellation.

## References

- [Tokio select and cancellation](https://docs.rs/tokio/latest/tokio/macro.select.html)
- [Tokio Mutex queue behavior](https://docs.rs/tokio/latest/tokio/sync/struct.Mutex.html)
- [JoinHandle ownership](https://docs.rs/tokio/latest/tokio/task/struct.JoinHandle.html)
- [State and locks](async-no-lock-await.md)
