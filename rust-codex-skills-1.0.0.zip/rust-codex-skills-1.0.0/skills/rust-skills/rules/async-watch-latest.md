# async-watch-latest

> Use watch for replaceable latest state, not event history; define initial delivery, seen revisions, and sender closure.

A Tokio watch channel retains the latest value. Slow receivers can skip intermediate
updates. That is useful for replaceable configuration or status, but not for commands,
audit history, or workflows requiring every transition. A watch snapshot does not
establish an external system's current state or supply a durable log.

## Consume the initial and subsequent latest values

This observer applies the initial value, then changes, and exits when the channel
closes after its last unseen value. `borrow_and_update` marks the value actually read
as seen. Using `changed` followed by `borrow` can process the same update twice when
another send occurs between those operations.

<!-- example: watch-observer -->
```rust
pub async fn observe_latest<T, F>(
    mut receiver: tokio::sync::watch::Receiver<T>,
    mut apply: F,
) where
    T: Clone,
    F: FnMut(T),
{
    loop {
        let value = { receiver.borrow_and_update().clone() };
        apply(value);
        if receiver.changed().await.is_err() {
            break;
        }
    }
}
```

Drop the watch borrow guard before await or potentially blocking/reentrant work.
Cloning is one way to retain a snapshot; cloning an Arc can avoid copying large state.
The clone does not mean the value remains the latest during later work. Tie dependent
commits to the version required by their contract.

Handle `changed()` errors explicitly inside select loops. Ignoring a closed channel's
immediate error can create a busy loop. Define whether losing all senders means stop,
retain a last-known value marked stale, or report failure. Do not invent one policy for
all callers. `send_if_modified` relies on the closure accurately reporting mutation;
check whether sending without receivers must retain a value for future subscribers.

For every-event delivery, choose a different mechanism with the required retention
and backpressure. Broadcast can report lag and drop messages for slow receivers; a
bounded work queue does not by itself provide durability or processing acknowledgement.

## References

- [Tokio watch](https://docs.rs/tokio/latest/tokio/sync/watch/index.html)
- [Select terminal states](async-select-racing.md)
