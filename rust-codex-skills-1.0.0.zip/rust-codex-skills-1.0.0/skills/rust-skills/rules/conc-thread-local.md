# conc-thread-local

> Use thread-local state only for genuinely per-thread data; avoid unsynchronized mutable globals and do not confuse thread-local with task-local storage.

## Why It Matters

Reading or writing a mutable static requires an unsafe argument about all access paths,
including threads and reentrancy. Unsynchronized conflicting access with at least one
write can be a data race; multiple reads alone are not the same condition. In Rust 2024,
`static_mut_refs` denies shared or mutable references to a mutable static by default.
It is a lint level, not an unconditional ban on the declaration or every by-value access.
Permitting the lint does not prove the reference is valid.

`thread_local!` creates separate storage per OS thread. Use it only when separate state
is the intended behavior, not as a replacement for shared state. Async tasks may move
between threads; thread-local storage is not task-local storage. `Cell` and `RefCell`
can give safe local mutation, but `RefCell` can panic on conflicting or reentrant borrows.
There is no cross-thread lock for independent state; access and borrow checks still have
cost and must not be described as universally free.

## Bad — compiler-only

<!-- example: static-mut-reference-lint -->
```rust
// Compiler-only negative example: static_mut_refs is deny-by-default in Rust 2024.
static mut BUFFER: Vec<u8> = Vec::new();

fn append_to_buffer(data: &[u8]) {
    // Concurrent unsynchronized writes can cause UB; the implicit mutable
    // reference triggers static_mut_refs. Never run this fixture.
    unsafe {
        BUFFER.extend_from_slice(data);
    }
}

fn flush_buffer() -> Vec<u8> {
    unsafe {
        std::mem::take(&mut BUFFER) // still requires unsafe
    }
}
```

## Good

<!-- example: thread-local-buffer -->
```rust
use std::cell::RefCell;

thread_local! {
    static BUFFER: RefCell<Vec<u8>> = RefCell::new(Vec::with_capacity(4096));
}

fn append_to_buffer(data: &[u8]) {
    BUFFER.with_borrow_mut(|buf| buf.extend_from_slice(data));
}

fn flush_buffer() -> Vec<u8> {
    BUFFER.with_borrow_mut(|buf| std::mem::take(buf))
}
```

For `Copy` types, `Cell` avoids dynamic borrow checks. This sample deliberately uses a wrapping counter:

```rust
use std::cell::Cell;

thread_local! {
    static CALL_COUNT: Cell<u32> = Cell::new(0);
}

fn record_call() {
    CALL_COUNT.with(|c| c.set(c.get().wrapping_add(1)));
}

fn get_call_count() -> u32 {
    CALL_COUNT.with(|c| c.get())
}
```

## Key Points

- `with_borrow` / `with_borrow_mut` are stable convenience methods (since 1.73) on `LocalKey<RefCell<T>>` — prefer them over the longer `with(|v| v.borrow_mut())` form.
- Thread-local destruction has platform and process-exit caveats. Do not rely on it as the sole durable flush or resource-commit path; use explicit shutdown when the contract needs it.
- A local value may still be Send when its type permits ownership transfer. What stays per-thread is the thread-local storage association; do not infer a new Send/Sync rule from its location.
- For read-only global constants shared across threads, use `static` with an immutable type instead.

## When to Use

- Scratch buffers, caches, or accumulators that are logically per-thread and don't need to be shared
- Reusing allocations across calls within a single thread (e.g., formatting buffers, temporary vecs)
- Replacing a mutable global only when changing it to independent per-thread state preserves the required behavior

## See Also

- [own-refcell-interior](own-refcell-interior.md) - interior mutability for single-threaded code
- [own-mutex-interior](own-mutex-interior.md) - shared mutable state across threads requires `Mutex`

## References

- [Mutable static reference lint](https://doc.rust-lang.org/edition-guide/rust-2024/static-mut-references.html)
- [LocalKey access and destructor caveats](https://doc.rust-lang.org/std/thread/struct.LocalKey.html)
