# api-non-exhaustive

> Use non_exhaustive only when the public contract needs extension; test restrictions through an external crate and preserve existing compatibility.

For a new extensible enum, `#[non_exhaustive]` requires external matching code to handle
unknown variants. On a struct, it prevents external struct-literal construction;
provide usable constructors or builders. Inside the defining crate, these restrictions
do not apply. A same-crate example cannot verify downstream behavior.

<!-- example: extensible-api -->
```rust
#[non_exhaustive]
pub enum Status {
    Ready,
    Busy,
}

#[non_exhaustive]
pub struct Options {
    pub retries: u32,
}

impl Options {
    pub fn new(retries: u32) -> Self {
        Self { retries }
    }
}
```

An external consumer may read fields and use the constructor. Its enum match must
include a fallback. The compiler checks those restrictions, not that future variants
will preserve behavior, serialized formats, auto traits, size, or ABI commitments.
A future extension still needs compatibility review.

Adding non_exhaustive to an already-published exhaustive enum or constructible struct
can itself break callers. Do not add it as a universal cleanup. Closed domain sets may
intentionally promise exhaustive matching. Lack of local callers never proves absence
of external users; inspect exported paths, documentation and compatibility policy.

## References

- [Cargo compatibility rules](https://doc.rust-lang.org/cargo/reference/semver.html)
- [Non-exhaustive type attribute](https://doc.rust-lang.org/reference/attributes/type_system.html#the-non_exhaustive-attribute)
