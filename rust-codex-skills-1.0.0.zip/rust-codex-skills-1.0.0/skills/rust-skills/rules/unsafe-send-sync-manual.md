# unsafe-send-sync-manual

> Distinguish Send from Sync and let auto traits follow the representation; justify every manual unsafe implementation for all permitted callers.

## Different contracts

`Send` permits moving ownership to another thread. `Sync` permits sharing references
between threads (`&T` is Send when T is Sync). `Cell<T>` is Send when T is Send, but
Cell is not Sync. A private Cell inside a movable owner is not itself an unsound design.
`Rc<T>` is neither Send nor Sync; cloning it does not make cross-thread use safe.

<!-- example: cell-send -->
```rust
use std::cell::Cell;

pub struct Counter {
    value: Cell<u32>,
}

fn requires_send<T: Send>() {}

pub fn check_movable_counter() {
    requires_send::<Counter>();
}
```

This needs no `unsafe impl Send`. The compile-only negative fixture below must fail
because Cell is not Sync, not because of a missing import or definition.

<!-- example: cell-not-sync -->
```rust
fn requires_sync<T: Sync>() {}
fn reject_shared_cell() {
    requires_sync::<std::cell::Cell<u32>>();
}
```

## Prefer a representation with the right traits

<!-- example: owned-bytes-auto-traits -->
```rust
pub struct OwnedBytes {
    bytes: Box<[u8]>,
}

fn requires_send_sync<T: Send + Sync>() {}

pub fn check_owned_bytes() {
    requires_send_sync::<OwnedBytes>();
}
```

Raw pointers are neither Send nor Sync. A manual implementation for a pointer-owning
abstraction must establish ownership, lifetime, aliasing, thread affinity, destruction,
and synchronization for *every* operation the API allows. A caller's usual practice
of putting the type in a Mutex is not a universal proof. State generic bounds explicitly
and recheck the argument after representation or method changes.

`PhantomData<*const T>` can opt a type out of Send and Sync. `PhantomData<*mut T>` also
makes it invariant in T; it does not create a mutable borrow or encode a lifetime by
itself. Do not add a redundant marker to a raw-pointer field to claim a new guarantee.
Use the marker matching the abstraction's actual ownership and variance contract.

A missing safety comment is an assurance/reviewability gap. A false manual implementation
can be a soundness defect. Keep those evidence classes separate.

## References

- [Cell auto traits](https://doc.rust-lang.org/std/cell/struct.Cell.html)
- [Send and Sync](https://doc.rust-lang.org/nomicon/send-and-sync.html)
- [PhantomData](https://doc.rust-lang.org/std/marker/struct.PhantomData.html)
- [Safety comments](unsafe-safety-comment.md)
