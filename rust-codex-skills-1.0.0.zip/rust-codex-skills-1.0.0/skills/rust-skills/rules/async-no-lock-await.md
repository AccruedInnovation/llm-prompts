# async-no-lock-await

> Choose lock lifetimes that preserve state invariants; avoid blocking or needless contention, but keep justified async serialization.

## Lock choice is not a blanket prohibition

A Tokio mutex guard may span an await by design. This can be correct for a resource
whose operations must run in order. Assess cancellation while partially changed,
reentrancy, lock order, bounded waits, and contention. A short critical section over
plain data may fit a standard mutex, but blocking acquisition under contention can
stall an executor thread. The right choice follows the contract and measured load.

Do not mechanically move work outside a lock. Reading an ID, awaiting work for that
ID, then assigning its result to newly retargeted state can mix two different identities.
Even an unchanged ID may have been removed and re-added: use a non-reused revision.

## Conditional commit after an unlocked calculation

All mutations of this example's private state advance a revision. Revision exhaustion
rejects the operation before any mutation. The commit check and update must execute
under the same exclusive lock in shared use.

<!-- example: revision-state -->
```rust
#[derive(Debug, PartialEq, Eq)]
pub enum CommitError {
    Stale,
    RevisionExhausted,
}

#[derive(Debug, PartialEq, Eq)]
pub struct State {
    revision: u64,
    id: u64,
    value: Option<Vec<u8>>,
}

impl State {
    pub fn new(id: u64) -> Self {
        Self { revision: 0, id, value: None }
    }

    pub fn snapshot(&self) -> (u64, u64) {
        (self.revision, self.id)
    }

    pub fn retarget(&mut self, id: u64) -> Result<(), CommitError> {
        let next = self.revision.checked_add(1)
            .ok_or(CommitError::RevisionExhausted)?;
        self.revision = next;
        self.id = id;
        self.value = None;
        Ok(())
    }

    pub fn commit(&mut self, snapshot: (u64, u64), data: Vec<u8>)
        -> Result<(), CommitError>
    {
        if self.snapshot() != snapshot {
            return Err(CommitError::Stale);
        }
        let next = self.revision.checked_add(1)
            .ok_or(CommitError::RevisionExhausted)?;
        self.revision = next;
        self.value = Some(data);
        Ok(())
    }
}
```

<!-- example: revision-refresh -->
```rust
use std::future::Future;
use tokio::sync::Mutex;

pub async fn refresh<F, Fut>(state: &Mutex<State>, fetch: F)
    -> Result<(), CommitError>
where
    F: FnOnce(u64) -> Fut,
    Fut: Future<Output = Vec<u8>>,
{
    let snapshot = state.lock().await.snapshot();
    let data = fetch(snapshot.1).await;
    state.lock().await.commit(snapshot, data)
}
```

This sample discards stale results and performs no external write. It does not roll
back effects inside `fetch`, guarantee freshness of a remote system, or prescribe the
project's retry policy. Revisions must not be reused while an old result can arrive.
Use a generation or durable identity across owner replacement when that can occur.

## Intentional async serialization

<!-- example: serialized-async-operation -->
```rust
pub async fn serialized_append(
    values: &tokio::sync::Mutex<Vec<u8>>,
    value: u8,
) {
    let mut guard = values.lock().await;
    tokio::task::yield_now().await;
    guard.push(value);
}
```

The yield makes the lock's lifetime visible; a real operation needs a reason to wait.
Here cancellation before the push leaves data unchanged, and the push contains no
await. Do not flag this as a memory-safety error solely because the guard crosses
an await. A partially mutated protocol resource needs a stronger recovery design.
A single task owning the resource is another option, not a mandatory architecture.

## References

- [Tokio Mutex contract](https://docs.rs/tokio/latest/tokio/sync/struct.Mutex.html)
- [Cancellation](async-cancel-safety.md)
- [Ownership across suspension](async-clone-before-await.md)
- [Diagnostic alias](anti-lock-across-await.md)
