# unsafe-no-mangle-unsafe

> Treat exported names and linker placement as safety contracts; use unsafe attribute syntax supported by the project's compiler and required by its edition.

Rust 1.82 added `#[unsafe(no_mangle)]`, `#[unsafe(export_name = "...")]`, and
`#[unsafe(link_section = "...")]` in all editions. Rust 2024 requires the unsafe
form. The spelling does not establish symbol uniqueness, ABI agreement, linker
placement, alignment, lifetime, or initialization correctness.

<!-- example: unsafe-export -->
```rust
// SAFETY: this isolated fixture provides the only definition of the reserved
// symbol. Its consumer uses the matching C ABI and u32 parameter/result.
#[unsafe(no_mangle)]
pub extern "C" fn rust_skills_example_identity(value: u32) -> u32 {
    value
}
```

In a real product, reserve and inspect symbols across all linked objects. Check target
linker scripts and memory rules before changing sections. A safety note cannot make a
symbol collision safe. Do not reuse standard-library or foreign-library export names.
An exported safe function must be safe for all valid calls through its declared types.

For earlier editions, use `unsafe_attr_outside_unsafe` or the edition compatibility
lint group when reviewing migration. Do not claim the old spelling always emits a
deprecation warning. `cargo fix --edition` changes files and cannot verify linker or
foreign-call correctness. Preserve the MSRV rather than copying unsupported syntax.

## References

- [Unsafe attributes](https://doc.rust-lang.org/edition-guide/rust-2024/unsafe-attributes.html)
- [Foreign declarations](unsafe-extern-block.md)
