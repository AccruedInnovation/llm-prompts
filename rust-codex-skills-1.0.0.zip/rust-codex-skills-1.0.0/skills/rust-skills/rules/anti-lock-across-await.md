# anti-lock-across-await

> Diagnose lock ownership, blocking, contention, and state consistency together; an async guard across await is not automatically a defect.

Use [async-no-lock-await](async-no-lock-await.md) as the canonical lock-lifetime
guidance and examples. This diagnostic entry deliberately does not maintain a second
read/compute/write recipe.

For a suspected bug, state which task holds which resource, the next suspension or
blocking point, who can make progress, and the invariant a change must preserve.
A standard mutex held across suspension can deadlock or block the executor; an async
mutex avoids blocking acquisition but can still deadlock through dependency cycles.
Not every wait is deadlock, and an async guard crossing await is not undefined behavior.

Before extracting data and releasing a lock, check stale results, identity reuse,
competing commits, partial side effects, and cancellation. A cloned configuration is
a snapshot, not proof it remains current. Preserve justified serialization or use a
checked commit under one owner. Neither channels nor extra clones automatically fix
ordering, resource limits, shutdown, or recovery.

Apply repository lint policy. Do not add blanket denied lints or redesign valid locking
without a demonstrated obligation. Missing performance measurements justify a bounded
measurement, not an asserted speedup.
