# Concurrency

Triggered by shared state or concurrent execution.

Generated view; change the rule's first blockquote or its metadata, not this file.
Unknown compatibility is not established. Read the rule and its constraints before use.

- [conc-atomic-ordering](../../rules/conc-atomic-ordering.md) — Use the weakest correct memory `Ordering` for every atomic operation
- [conc-rayon-par-iter](../../rules/conc-rayon-par-iter.md) — Use rayon's `par_iter()` for CPU-bound data parallelism
- [conc-scoped-threads](../../rules/conc-scoped-threads.md) — Use `std::thread::scope` to borrow stack data across threads
- [conc-thread-local](../../rules/conc-thread-local.md) — Use thread-local state only for genuinely per-thread data; avoid unsynchronized mutable globals and do not confuse thread-local with task-local storage.
