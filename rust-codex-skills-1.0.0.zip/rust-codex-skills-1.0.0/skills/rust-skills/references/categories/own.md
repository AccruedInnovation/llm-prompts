# Ownership and borrowing

Common principles; preserve real ownership and lifetime needs.

Generated view; change the rule's first blockquote or its metadata, not this file.
Unknown compatibility is not established. Read the rule and its constraints before use.

- [own-arc-shared](../../rules/own-arc-shared.md) — Use `Arc<T>` for thread-safe shared ownership
- [own-borrow-over-clone](../../rules/own-borrow-over-clone.md) — Prefer `&T` borrowing over `.clone()`
- [own-clone-explicit](../../rules/own-clone-explicit.md) — Use explicit `Clone` for types where copying has meaningful cost
- [own-copy-small](../../rules/own-copy-small.md) — Implement `Copy` for small, simple types
- [own-cow-conditional](../../rules/own-cow-conditional.md) — Use `Cow<'a, T>` for conditional ownership
- [own-lifetime-elision](../../rules/own-lifetime-elision.md) — Rely on lifetime elision rules; add explicit lifetimes only when required
- [own-move-large](../../rules/own-move-large.md) — Treat large inline values and indirection as measured representation trade-offs
- [own-mutex-interior](../../rules/own-mutex-interior.md) — Use `Mutex<T>` for interior mutability across threads
- [own-rc-single-thread](../../rules/own-rc-single-thread.md) — Use `Rc<T>` for shared ownership in single-threaded contexts
- [own-refcell-interior](../../rules/own-refcell-interior.md) — Use `RefCell<T>` for interior mutability in single-threaded code
- [own-rwlock-readers](../../rules/own-rwlock-readers.md) — Use `RwLock<T>` when reads significantly outnumber writes
- [own-slice-over-vec](../../rules/own-slice-over-vec.md) — Accept `&[T]` not `&Vec<T>`, `&str` not `&String`
