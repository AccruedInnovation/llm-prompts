# Macros

Use only for justified repetition or syntax needs.

Generated view; change the rule's first blockquote or its metadata, not this file.
Unknown compatibility is not established. Read the rule and its constraints before use.

- [macro-export-crate-path](../../rules/macro-export-crate-path.md) — Export declarative macros with `#[macro_export]` and a clean import path
- [macro-fragment-specifiers](../../rules/macro-fragment-specifiers.md) — Capture with precise fragment specifiers, not raw `:tt`, where you can
- [macro-prefer-functions](../../rules/macro-prefer-functions.md) — Reach for a macro only when a function or generic cannot express it
- [macro-private-helpers](../../rules/macro-private-helpers.md) — Hide macro-generated helper items behind a `#[doc(hidden)] pub mod __private`
- [macro-proc-error-spans](../../rules/macro-proc-error-spans.md) — Report proc-macro errors as spanned compile errors, never by panicking
- [macro-proc-syn-quote](../../rules/macro-proc-syn-quote.md) — Build procedural macros with `syn`, `quote`, and `proc-macro2`
- [macro-proc-two-crate](../../rules/macro-proc-two-crate.md) — Put procedural macros in a dedicated `proc-macro = true` crate and re-export from the facade
- [macro-rules-hygiene](../../rules/macro-rules-hygiene.md) — Rely on `macro_rules!` hygiene and use `$crate` for paths to your crate's items
