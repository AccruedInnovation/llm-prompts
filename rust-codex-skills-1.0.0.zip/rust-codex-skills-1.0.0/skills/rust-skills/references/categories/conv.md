# Conversions

Boundary and loss/validation policy dependent.

Generated view; change the rule's first blockquote or its metadata, not this file.
Unknown compatibility is not established. Read the rule and its constraints before use.

- [conv-asmut-mutable](../../rules/conv-asmut-mutable.md) — Accept `impl AsMut<T>` for flexible mutable borrowed inputs instead of concrete mutable references
- [conv-fromstr-parsing](../../rules/conv-fromstr-parsing.md) — Implement `FromStr` to enable `str::parse` for string-to-type conversions
- [conv-tryfrom-fallible](../../rules/conv-tryfrom-fallible.md) — Implement `TryFrom` for fallible conversions instead of ad-hoc conversion functions
