# Type design

Use types for named invariants, not pattern compliance.

Generated view; change the rule's first blockquote or its metadata, not this file.
Unknown compatibility is not established. Read the rule and its constraints before use.

- [type-deref-coercion](../../rules/type-deref-coercion.md) — Implement `Deref`/`DerefMut` only for smart-pointer and transparent wrapper types
- [type-display-vs-debug](../../rules/type-display-vs-debug.md) — Use `Display` for user-facing output and `Debug` for diagnostics; never swap them
- [type-enum-states](../../rules/type-enum-states.md) — Use enums for mutually exclusive states
- [type-generic-bounds](../../rules/type-generic-bounds.md) — Add trait bounds only where needed, prefer where clauses for readability
- [type-never-diverge](../../rules/type-never-diverge.md) — Use `!` (never type) for functions that never return
- [type-newtype-ids](../../rules/type-newtype-ids.md) — Wrap IDs in newtypes: `UserId(u64)`
- [type-newtype-validated](../../rules/type-newtype-validated.md) — Use newtypes to enforce validation at construction time
- [type-no-stringly](../../rules/type-no-stringly.md) — Avoid stringly-typed APIs; use enums, newtypes, or validated types
- [type-numeric-fmt](../../rules/type-numeric-fmt.md) — Implement `LowerHex`, `UpperHex`, `Octal`, and `Binary` for numeric newtypes
- [type-option-nullable](../../rules/type-option-nullable.md) — Use `Option<T>` for values that might not exist
- [type-phantom-marker](../../rules/type-phantom-marker.md) — Use `PhantomData` to express type relationships without runtime cost
- [type-repr-transparent](../../rules/type-repr-transparent.md) — Use `#[repr(transparent)]` for newtypes in FFI contexts
- [type-result-fallible](../../rules/type-result-fallible.md) — Use `Result<T, E>` for operations that can fail
