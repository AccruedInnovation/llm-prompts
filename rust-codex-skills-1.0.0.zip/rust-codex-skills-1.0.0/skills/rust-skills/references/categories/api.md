# API design

Public contract or caller need; preserve compatibility.

Generated view; change the rule's first blockquote or its metadata, not this file.
Unknown compatibility is not established. Read the rule and its constraints before use.

- [api-builder-must-use](../../rules/api-builder-must-use.md) — Mark builder methods with `#[must_use]` to prevent silent drops
- [api-builder-pattern](../../rules/api-builder-pattern.md) — Use Builder pattern for complex construction
- [api-common-traits](../../rules/api-common-traits.md) — Implement standard traits (Debug, Clone, PartialEq, etc.) for public types
- [api-default-impl](../../rules/api-default-impl.md) — Implement `Default` for types with sensible default values
- [api-extension-trait](../../rules/api-extension-trait.md) — Use extension traits to add methods to external types
- [api-from-not-into](../../rules/api-from-not-into.md) — Implement `From<T>`, not `Into<U>` - From gives you Into for free
- [api-impl-asref](../../rules/api-impl-asref.md) — Use `AsRef<T>` when you only need to borrow the inner data
- [api-impl-fromiterator](../../rules/api-impl-fromiterator.md) — Implement `FromIterator` and `Extend` for collection types, and `IntoIterator` for all three reference forms
- [api-impl-into](../../rules/api-impl-into.md) — Accept `impl Into<T>` for flexible APIs, implement `From<T>` for conversions
- [api-must-use](../../rules/api-must-use.md) — Mark types and functions with `#[must_use]` when ignoring results is likely a bug
- [api-newtype-safety](../../rules/api-newtype-safety.md) — Use newtypes to prevent mixing semantically different values
- [api-non-exhaustive](../../rules/api-non-exhaustive.md) — Use non_exhaustive only when the public contract needs extension; test restrictions through an external crate and preserve existing compatibility.
- [api-operator-overload](../../rules/api-operator-overload.md) — Overload operators only when the semantics are natural and unsurprising
- [api-parse-dont-validate](../../rules/api-parse-dont-validate.md) — Parse into validated types at boundaries
- [api-sealed-trait](../../rules/api-sealed-trait.md) — Use sealed traits to prevent external implementations while allowing use
- [api-serde-optional](../../rules/api-serde-optional.md) — Make serde a feature flag, not a hard dependency for library crates
- [api-typestate](../../rules/api-typestate.md) — Use typestate pattern to encode state machine invariants in the type system
