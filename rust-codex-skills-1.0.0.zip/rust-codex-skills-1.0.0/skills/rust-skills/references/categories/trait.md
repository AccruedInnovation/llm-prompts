# Traits and generics

Use abstraction for a real boundary or need.

Generated view; change the rule's first blockquote or its metadata, not this file.
Unknown compatibility is not established. Read the rule and its constraints before use.

- [trait-associated-type-vs-generic](../../rules/trait-associated-type-vs-generic.md) — Use an associated type when each impl has exactly one output type; use a generic parameter when a type can implement the trait for many input types
- [trait-blanket-impl](../../rules/trait-blanket-impl.md) — Use a blanket impl `impl<T: Bound> Trait for T` to give behaviour to every type that satisfies a bound
- [trait-coherence-newtype](../../rules/trait-coherence-newtype.md) — Respect the orphan rule; wrap a foreign type in a newtype to implement a foreign trait on it
- [trait-default-methods](../../rules/trait-default-methods.md) — Define a trait in terms of a few required methods plus defaulted ones built on top of them
- [trait-dyn-vs-generic](../../rules/trait-dyn-vs-generic.md) — Choose static dispatch (generics / `impl Trait`) vs dynamic dispatch (`dyn Trait`) deliberately
- [trait-object-safety](../../rules/trait-object-safety.md) — Keep a trait dyn-compatible (object-safe) when you need `dyn Trait`
