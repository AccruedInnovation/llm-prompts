# Diagnostic references

Potential issues require concrete evidence, not automatic findings.

Generated view; change the rule's first blockquote or its metadata, not this file.
Unknown compatibility is not established. Read the rule and its constraints before use.

- [anti-clone-excessive](../../rules/anti-clone-excessive.md) — Don't clone when borrowing works
- [anti-collect-intermediate](../../rules/anti-collect-intermediate.md) — Don't collect intermediate iterators
- [anti-empty-catch](../../rules/anti-empty-catch.md) — Don't silently ignore errors
- [anti-expect-lazy](../../rules/anti-expect-lazy.md) — Don't use expect for recoverable errors
- [anti-format-hot-path](../../rules/anti-format-hot-path.md) — Don't use format! in hot paths
- [anti-index-over-iter](../../rules/anti-index-over-iter.md) — Don't use indexing when iterators work
- [anti-lock-across-await](../../rules/anti-lock-across-await.md) — Diagnose lock ownership, blocking, contention, and state consistency together; an async guard across await is not automatically a defect.
- [anti-over-abstraction](../../rules/anti-over-abstraction.md) — Don't over-abstract with excessive generics
- [anti-panic-expected](../../rules/anti-panic-expected.md) — Don't panic on expected or recoverable errors
- [anti-premature-optimize](../../rules/anti-premature-optimize.md) — Don't optimize before profiling
- [anti-string-for-str](../../rules/anti-string-for-str.md) — Don't accept &String when &str works
- [anti-stringly-typed](../../rules/anti-stringly-typed.md) — Don't use strings where enums or newtypes would provide type safety
- [anti-type-erasure](../../rules/anti-type-erasure.md) — Don't use Box<dyn Trait> when impl Trait works
- [anti-unwrap-abuse](../../rules/anti-unwrap-abuse.md) — Don't use `.unwrap()` in production code
- [anti-vec-for-slice](../../rules/anti-vec-for-slice.md) — Don't accept &Vec<T> when &[T] works
