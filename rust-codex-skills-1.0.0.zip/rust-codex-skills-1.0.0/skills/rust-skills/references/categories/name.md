# Naming

Follow coherent project and public API conventions.

Generated view; change the rule's first blockquote or its metadata, not this file.
Unknown compatibility is not established. Read the rule and its constraints before use.

- [name-acronym-word](../../rules/name-acronym-word.md) — Treat acronyms as words in identifiers: `HttpServer`, not `HTTPServer`
- [name-as-free](../../rules/name-as-free.md) — `as_` prefix: free reference conversion
- [name-consts-screaming](../../rules/name-consts-screaming.md) — Use `SCREAMING_SNAKE_CASE` for constants and statics
- [name-crate-no-rs](../../rules/name-crate-no-rs.md) — Don't suffix crate names with `-rs` or `-rust`
- [name-funcs-snake](../../rules/name-funcs-snake.md) — Use `snake_case` for functions, methods, variables, and modules
- [name-into-ownership](../../rules/name-into-ownership.md) — Use `into_` prefix for ownership-consuming conversions
- [name-is-has-bool](../../rules/name-is-has-bool.md) — Use `is_`, `has_`, `can_`, `should_` prefixes for boolean-returning methods
- [name-iter-convention](../../rules/name-iter-convention.md) — Use iter/iter_mut/into_iter for iterator methods
- [name-iter-method](../../rules/name-iter-method.md) — Name iterator methods `iter()`, `iter_mut()`, and `into_iter()` consistently
- [name-iter-type-match](../../rules/name-iter-type-match.md) — Name iterator types after their source method
- [name-lifetime-short](../../rules/name-lifetime-short.md) — Use short, conventional lifetime names: `'a`, `'b`, `'de`, `'src`
- [name-no-get-prefix](../../rules/name-no-get-prefix.md) — Omit get_ prefix for simple getters
- [name-to-expensive](../../rules/name-to-expensive.md) — Use `to_` prefix for expensive conversions that allocate or compute
- [name-type-param-single](../../rules/name-type-param-single.md) — Use single uppercase letters for type parameters: `T`, `E`, `K`, `V`
- [name-types-camel](../../rules/name-types-camel.md) — Use `UpperCamelCase` for types, traits, and enum names
- [name-variants-camel](../../rules/name-variants-camel.md) — Use `UpperCamelCase` for enum variants
