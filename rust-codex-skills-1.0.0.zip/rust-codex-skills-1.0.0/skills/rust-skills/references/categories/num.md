# Numeric safety

Domain/range dependent; define overflow and conversion behavior.

Generated view; change the rule's first blockquote or its metadata, not this file.
Unknown compatibility is not established. Read the rule and its constraints before use.

- [num-cast-try-from](../../rules/num-cast-try-from.md) — Avoid `as` for narrowing casts; use `From` for widening and `TryFrom` for narrowing
- [num-float-compare](../../rules/num-float-compare.md) — Don't compare floats with `==`; use a tolerance, and `total_cmp` for ordering
- [num-nonzero](../../rules/num-nonzero.md) — Use `NonZero*` types to forbid zero and unlock the niche optimization
- [num-overflow-explicit](../../rules/num-overflow-explicit.md) — Handle integer overflow explicitly: `checked_`/`saturating_`/`wrapping_`/`overflowing_`
- [num-saturating-clamp](../../rules/num-saturating-clamp.md) — Bound values with `clamp` and saturating arithmetic
