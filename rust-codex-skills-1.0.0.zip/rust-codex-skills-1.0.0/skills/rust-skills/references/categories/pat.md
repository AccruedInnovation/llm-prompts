# Pattern matching

Context and readability dependent.

Generated view; change the rule's first blockquote or its metadata, not this file.
Unknown compatibility is not established. Read the rule and its constraints before use.

- [pat-at-bindings](../../rules/pat-at-bindings.md) — Use `@` bindings to capture a value while matching it against a pattern
- [pat-exhaustive-enum](../../rules/pat-exhaustive-enum.md) — Match owned enums exhaustively; avoid catch-all `_` that hides new variants
- [pat-if-let-chains](../../rules/pat-if-let-chains.md) — Use `if let` chains to combine pattern bindings and conditions
- [pat-let-else](../../rules/pat-let-else.md) — Use `let ... else` for early-return pattern extraction
- [pat-matches-macro](../../rules/pat-matches-macro.md) — Use `matches!()` for boolean pattern tests
