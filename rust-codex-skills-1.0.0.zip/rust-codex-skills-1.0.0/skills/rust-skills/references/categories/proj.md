# Project structure

Repository and delivery conventions control.

Generated view; change the rule's first blockquote or its metadata, not this file.
Unknown compatibility is not established. Read the rule and its constraints before use.

- [proj-bin-dir](../../rules/proj-bin-dir.md) — Put multiple binaries in src/bin/
- [proj-build-rs-minimal](../../rules/proj-build-rs-minimal.md) — Keep `build.rs` minimal, deterministic, and idempotent
- [proj-feature-additive](../../rules/proj-feature-additive.md) — Design Cargo features to be strictly additive
- [proj-flat-small](../../rules/proj-flat-small.md) — Keep small projects flat
- [proj-lib-main-split](../../rules/proj-lib-main-split.md) — Keep `main.rs` minimal, logic in `lib.rs`
- [proj-mod-by-feature](../../rules/proj-mod-by-feature.md) — Organize modules by feature, not type
- [proj-mod-rs-dir](../../rules/proj-mod-rs-dir.md) — Use mod.rs for multi-file modules
- [proj-msrv-declare](../../rules/proj-msrv-declare.md) — Declare `rust-version` (MSRV) in Cargo.toml and test it in CI
- [proj-prelude-module](../../rules/proj-prelude-module.md) — Create prelude module for common imports
- [proj-pub-crate-internal](../../rules/proj-pub-crate-internal.md) — Use pub(crate) for internal APIs
- [proj-pub-super-parent](../../rules/proj-pub-super-parent.md) — Use pub(super) for parent-only visibility
- [proj-pub-use-reexport](../../rules/proj-pub-use-reexport.md) — Use pub use for clean public API
- [proj-workspace-deps](../../rules/proj-workspace-deps.md) — Use workspace dependency inheritance for consistent versions across crates
- [proj-workspace-large](../../rules/proj-workspace-large.md) — Use workspaces for large projects
