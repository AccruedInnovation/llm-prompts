# Memory

Conditional on workload or resource limits; measure material optimization.

Generated view; change the rule's first blockquote or its metadata, not this file.
Unknown compatibility is not established. Read the rule and its constraints before use.

- [mem-arena-allocator](../../rules/mem-arena-allocator.md) — Use arena allocators for batch allocations
- [mem-arrayvec](../../rules/mem-arrayvec.md) — Use `ArrayVec<T, N>` for fixed-capacity collections that never heap-allocate
- [mem-assert-type-size](../../rules/mem-assert-type-size.md) — Use static assertions to guard against accidental type size growth
- [mem-avoid-format](../../rules/mem-avoid-format.md) — Avoid `format!()` when string literals work
- [mem-box-large-variant](../../rules/mem-box-large-variant.md) — Box large enum variants to reduce overall enum size
- [mem-boxed-slice](../../rules/mem-boxed-slice.md) — Use `Box<[T]>` instead of `Vec<T>` for fixed-size heap data
- [mem-clone-from](../../rules/mem-clone-from.md) — Use `clone_from()` to reuse allocations when repeatedly cloning
- [mem-compact-string](../../rules/mem-compact-string.md) — Use compact string types for memory-constrained string storage
- [mem-drop-order](../../rules/mem-drop-order.md) — Know and control drop order: struct fields drop top-to-bottom, locals in reverse
- [mem-reuse-collections](../../rules/mem-reuse-collections.md) — Clear and reuse collections instead of creating new ones in loops
- [mem-smaller-integers](../../rules/mem-smaller-integers.md) — Use appropriately-sized integers to reduce memory footprint
- [mem-smallvec](../../rules/mem-smallvec.md) — Use `SmallVec` for usually-small collections
- [mem-take-replace](../../rules/mem-take-replace.md) — Use `mem::take` / `mem::replace` to move a value out of a `&mut` without cloning
- [mem-thinvec](../../rules/mem-thinvec.md) — Use `ThinVec<T>` for nullable collections with minimal overhead
- [mem-with-capacity](../../rules/mem-with-capacity.md) — Use `with_capacity()` when size is known
- [mem-write-over-format](../../rules/mem-write-over-format.md) — Use `write!()` into existing buffers instead of `format!()` allocations
- [mem-zero-copy](../../rules/mem-zero-copy.md) — Use zero-copy patterns with slices and `Bytes`
