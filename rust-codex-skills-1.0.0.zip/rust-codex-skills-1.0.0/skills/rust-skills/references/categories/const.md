# Compile-time choices

API, compiler version and actual execution constraints matter.

Generated view; change the rule's first blockquote or its metadata, not this file.
Unknown compatibility is not established. Read the rule and its constraints before use.

- [const-block](../../rules/const-block.md) — Use inline `const { }` blocks for compile-time evaluation and assertions
- [const-fn](../../rules/const-fn.md) — Make functions `const fn` when they can run at compile time
- [const-generics](../../rules/const-generics.md) — Parameterize over values with const generics `<const N: usize>`
- [const-vs-static](../../rules/const-vs-static.md) — Choose const for a value and static for a shared storage identity; measure storage costs instead of assuming inlining or duplication.
