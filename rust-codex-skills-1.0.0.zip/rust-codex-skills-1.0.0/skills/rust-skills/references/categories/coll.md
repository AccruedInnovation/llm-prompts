# Collections

Workload, ordering, security and resource needs control.

Generated view; change the rule's first blockquote or its metadata, not this file.
Unknown compatibility is not established. Read the rule and its constraints before use.

- [coll-binaryheap](../../rules/coll-binaryheap.md) — Use `BinaryHeap` for a priority queue or repeated max-extraction
- [coll-map-choice](../../rules/coll-map-choice.md) — Pick the map by access pattern: `HashMap` (fast, unordered), `BTreeMap` (sorted / range queries), `IndexMap` (insertion order)
- [coll-seq-choice](../../rules/coll-seq-choice.md) — Default to `Vec`; use `VecDeque` for queue/deque behaviour; avoid `LinkedList`
- [coll-set-membership](../../rules/coll-set-membership.md) — Use `HashSet`/`BTreeSet` for membership tests and dedup, not linear `Vec::contains`
