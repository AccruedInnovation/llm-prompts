# Lints

Repository policy; do not impose blanket lint sets.

Generated view; change the rule's first blockquote or its metadata, not this file.
Unknown compatibility is not established. Read the rule and its constraints before use.

- [lint-cargo-metadata](../../rules/lint-cargo-metadata.md) — Enable clippy::cargo for published crates
- [lint-cfg-check](../../rules/lint-cfg-check.md) — Enable `unexpected_cfgs` and declare known cfgs to catch feature-gate typos
- [lint-clippy-nursery-selected](../../rules/lint-clippy-nursery-selected.md) — Enable high-value `clippy::nursery` lints selectively, not the whole group
- [lint-deny-correctness](../../rules/lint-deny-correctness.md) — `#![deny(clippy::correctness)]`
- [lint-missing-docs](../../rules/lint-missing-docs.md) — Warn on missing documentation for public items
- [lint-pedantic-selective](../../rules/lint-pedantic-selective.md) — Enable clippy::pedantic selectively
- [lint-rustfmt-check](../../rules/lint-rustfmt-check.md) — Run cargo fmt --check in CI
- [lint-unsafe-doc](../../rules/lint-unsafe-doc.md) — Require documentation for unsafe blocks
- [lint-warn-complexity](../../rules/lint-warn-complexity.md) — Enable clippy::complexity for simpler code
- [lint-warn-perf](../../rules/lint-warn-perf.md) — Enable clippy::perf for performance improvements
- [lint-warn-style](../../rules/lint-warn-style.md) — Enable clippy::style for idiomatic code
- [lint-warn-suspicious](../../rules/lint-warn-suspicious.md) — Enable clippy::suspicious for likely bugs
- [lint-workspace-lints](../../rules/lint-workspace-lints.md) — Configure lints at workspace level for consistent enforcement
