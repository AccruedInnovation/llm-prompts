# Serialization

Wire/storage compatibility and input policy control.

Generated view; change the rule's first blockquote or its metadata, not this file.
Unknown compatibility is not established. Read the rule and its constraints before use.

- [serde-custom-with](../../rules/serde-custom-with.md) — Customize a field's (de)serialization with `with` / `serialize_with` / `deserialize_with`
- [serde-default-compat](../../rules/serde-default-compat.md) — Use `#[serde(default)]` for optional and backward-compatible fields
- [serde-deny-unknown-fields](../../rules/serde-deny-unknown-fields.md) — Choose unknown-field handling from the wire or configuration contract; distinguish ignored extra keys from missing required fields.
- [serde-enum-representation](../../rules/serde-enum-representation.md) — Choose enum tagging deliberately: externally, internally, adjacently tagged, or untagged
- [serde-flatten](../../rules/serde-flatten.md) — Inline nested structs or capture extra keys with `#[serde(flatten)]`
- [serde-rename-all](../../rules/serde-rename-all.md) — Match the external naming convention with `#[serde(rename_all = ...)]`
- [serde-skip-empty](../../rules/serde-skip-empty.md) — Omit empty fields with `skip_serializing_if`
- [serde-try-from-validate](../../rules/serde-try-from-validate.md) — Validate while deserializing with `#[serde(try_from = "Raw")]`
