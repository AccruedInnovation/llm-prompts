# Observability

Operational outcomes and data sensitivity control.

Generated view; change the rule's first blockquote or its metadata, not this file.
Unknown compatibility is not established. Read the rule and its constraints before use.

- [obs-error-chain](../../rules/obs-error-chain.md) — Log errors with their full source chain, and log each error exactly once
- [obs-instrument-spans](../../rules/obs-instrument-spans.md) — Use `#[tracing::instrument]` and spans to attach context to async tasks and requests
- [obs-levels-filter](../../rules/obs-levels-filter.md) — Use log levels meaningfully and filter with `EnvFilter` / `RUST_LOG`
- [obs-library-facade](../../rules/obs-library-facade.md) — Libraries emit through the tracing/log facade and never install a subscriber
- [obs-no-sensitive-data](../../rules/obs-no-sensitive-data.md) — Never log secrets or PII; redact or skip them
- [obs-structured-fields](../../rules/obs-structured-fields.md) — Record structured key-value fields, not values interpolated into the message string
- [obs-tracing-over-log](../../rules/obs-tracing-over-log.md) — Use `tracing` for structured, span-aware diagnostics instead of `println!` or bare `log`
