# Unsafe code

Triggered by safety boundaries; preserve invariants and tool support limits.

Generated view; change the rule's first blockquote or its metadata, not this file.
Unknown compatibility is not established. Read the rule and its constraints before use.

- [unsafe-extern-block](../../rules/unsafe-extern-block.md) — Match the real foreign ABI and preserve caller obligations; use unsafe extern syntax when the compiler and edition support or require it.
- [unsafe-maybeuninit](../../rules/unsafe-maybeuninit.md) — Use `MaybeUninit<T>` for uninitialized memory; never use `mem::uninitialized()` or `mem::zeroed()` for types with validity invariants.
- [unsafe-minimize-scope](../../rules/unsafe-minimize-scope.md) — Preserve the caller's safety contract; use small unsafe blocks only after establishing every operation's preconditions.
- [unsafe-miri-ci](../../rules/unsafe-miri-ci.md) — Use Miri as triggered dynamic evidence for unsafe, aliasing-sensitive, or dependency-boundary behavior when the selected tests and platform are supported.
- [unsafe-no-mangle-unsafe](../../rules/unsafe-no-mangle-unsafe.md) — Treat exported names and linker placement as safety contracts; use unsafe attribute syntax supported by the project's compiler and required by its edition.
- [unsafe-safety-comment](../../rules/unsafe-safety-comment.md) — Write a `// SAFETY:` comment above every `unsafe` block and a `# Safety` section in every `unsafe fn`.
- [unsafe-send-sync-manual](../../rules/unsafe-send-sync-manual.md) — Distinguish Send from Sync and let auto traits follow the representation; justify every manual unsafe implementation for all permitted callers.
