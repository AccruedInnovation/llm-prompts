# Closures

Ownership, lifetime and caller requirements control.

Generated view; change the rule's first blockquote or its metadata, not this file.
Unknown compatibility is not established. Read the rule and its constraints before use.

- [closure-disjoint-capture](../../rules/closure-disjoint-capture.md) — Capture only what you use; lean on edition-2021 disjoint closure captures
- [closure-fn-trait-bounds](../../rules/closure-fn-trait-bounds.md) — Require the least restrictive `Fn` trait a callback needs (`FnOnce` ⊇ `FnMut` ⊇ `Fn`)
- [closure-impl-fn-return](../../rules/closure-impl-fn-return.md) — Return closures as `impl Fn`/`FnMut`/`FnOnce`, not `Box<dyn Fn>`
- [closure-move-capture](../../rules/closure-move-capture.md) — Use `move` for closures that outlive the current scope; clone before `move` to keep the original
- [closure-static-vs-dyn](../../rules/closure-static-vs-dyn.md) — Accept `impl Fn` (generic) for hot callbacks; use `&dyn Fn`/`Box<dyn Fn>` to cut code size or to store them
