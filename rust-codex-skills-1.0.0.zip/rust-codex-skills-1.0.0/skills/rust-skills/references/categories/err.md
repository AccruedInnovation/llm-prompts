# Errors

Recoverable error and project error-contract guidance; no required error crate.

Generated view; change the rule's first blockquote or its metadata, not this file.
Unknown compatibility is not established. Read the rule and its constraints before use.

- [err-anyhow-app](../../rules/err-anyhow-app.md) — Use `anyhow` for application error handling
- [err-context-chain](../../rules/err-context-chain.md) — Add context with `.context()` or `.with_context()`
- [err-custom-type](../../rules/err-custom-type.md) — Define custom error types for domain-specific failures
- [err-doc-errors](../../rules/err-doc-errors.md) — Document error conditions with `# Errors` section in doc comments
- [err-expect-bugs-only](../../rules/err-expect-bugs-only.md) — Use `expect()` only for invariants that indicate bugs, not user errors
- [err-from-impl](../../rules/err-from-impl.md) — Implement `From<E>` for error conversions to enable `?` operator
- [err-lowercase-msg](../../rules/err-lowercase-msg.md) — Start error messages lowercase, no trailing punctuation
- [err-no-unwrap-prod](../../rules/err-no-unwrap-prod.md) — Avoid `unwrap()` in production code; use `?`, `expect()`, or handle errors
- [err-question-mark](../../rules/err-question-mark.md) — Use `?` operator for clean propagation
- [err-result-over-panic](../../rules/err-result-over-panic.md) — Return `Result<T, E>` instead of panicking for recoverable errors
- [err-source-chain](../../rules/err-source-chain.md) — Preserve error chains with `#[source]` or `source()` method
- [err-thiserror-lib](../../rules/err-thiserror-lib.md) — Use `thiserror` for library error types
