# Compiler optimization

Conditional and measured; preserve target/toolchain support.

Generated view; change the rule's first blockquote or its metadata, not this file.
Unknown compatibility is not established. Read the rule and its constraints before use.

- [opt-bounds-check](../../rules/opt-bounds-check.md) — Use iterators and patterns that eliminate bounds checks in hot paths
- [opt-cache-friendly](../../rules/opt-cache-friendly.md) — Organize data for cache-efficient access patterns
- [opt-codegen-units](../../rules/opt-codegen-units.md) — Treat codegen-unit count as a build-time/runtime trade-off and change it only with measured evidence.
- [opt-cold-unlikely](../../rules/opt-cold-unlikely.md) — Mark unlikely code paths with `#[cold]` to help compiler optimization
- [opt-inline-always-rare](../../rules/opt-inline-always-rare.md) — Use `#[inline(always)]` sparingly—only for critical hot paths proven by profiling
- [opt-inline-never-cold](../../rules/opt-inline-never-cold.md) — Consider `#[cold]` and `#[inline(never)]` only for measured cold paths
- [opt-inline-small](../../rules/opt-inline-small.md) — Use `#[inline]` for small hot functions
- [opt-likely-hint](../../rules/opt-likely-hint.md) — Treat branch-likelihood hints as measured, toolchain-qualified optimizations
- [opt-lto-release](../../rules/opt-lto-release.md) — Evaluate LTO for a measured release objective; do not assume thin or fat LTO is automatically faster or smaller.
- [opt-pgo-profile](../../rules/opt-pgo-profile.md) — Use Profile-Guided Optimization (PGO) for maximum performance
- [opt-simd-portable](../../rules/opt-simd-portable.md) — Use portable SIMD for vectorized operations across architectures
- [opt-target-cpu](../../rules/opt-target-cpu.md) — Use `target-cpu=native` for maximum performance on known deployment targets
