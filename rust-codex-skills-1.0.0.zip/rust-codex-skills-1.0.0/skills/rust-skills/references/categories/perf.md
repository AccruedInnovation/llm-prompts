# Performance

Conditional and benchmarked; no assumed speedups.

Generated view; change the rule's first blockquote or its metadata, not this file.
Unknown compatibility is not established. Read the rule and its constraints before use.

- [perf-ahash](../../rules/perf-ahash.md) — Use a faster hasher (`ahash` / `FxHashMap`) when DoS resistance is not needed
- [perf-black-box-bench](../../rules/perf-black-box-bench.md) — Use black_box in benchmarks
- [perf-chain-avoid](../../rules/perf-chain-avoid.md) — Avoid chain in hot loops
- [perf-collect-into](../../rules/perf-collect-into.md) — Use collect_into for reusing containers
- [perf-collect-once](../../rules/perf-collect-once.md) — Don't collect intermediate iterators
- [perf-drain-reuse](../../rules/perf-drain-reuse.md) — Use drain to reuse allocations
- [perf-entry-api](../../rules/perf-entry-api.md) — Use entry API for map insert-or-update
- [perf-extend-batch](../../rules/perf-extend-batch.md) — Use extend for batch insertions
- [perf-io-buffering](../../rules/perf-io-buffering.md) — Wrap `Read`/`Write` in `BufReader`/`BufWriter` for many small operations
- [perf-iter-lazy](../../rules/perf-iter-lazy.md) — Keep iterators lazy, collect only when needed
- [perf-iter-over-index](../../rules/perf-iter-over-index.md) — Prefer iterators over manual indexing
- [perf-profile-first](../../rules/perf-profile-first.md) — Profile before optimizing
- [perf-release-profile](../../rules/perf-release-profile.md) — Design and verify release profiles against an explicit operational objective; do not copy one universal "maximum optimization" block.
