# Async work

Triggered by asynchronous code; inspect cancellation and ownership.

Generated view; change the rule's first blockquote or its metadata, not this file.
Unknown compatibility is not established. Read the rule and its constraints before use.

- [async-async-fn-bounds](../../rules/async-async-fn-bounds.md) — Use `AsyncFn`/`AsyncFnMut`/`AsyncFnOnce` bounds instead of `F: Fn() -> Fut, Fut: Future`
- [async-bounded-channel](../../rules/async-bounded-channel.md) — Use bounded channels to apply backpressure and prevent unbounded memory growth
- [async-broadcast-pubsub](../../rules/async-broadcast-pubsub.md) — Use `broadcast` channel for pub/sub where all subscribers receive all messages
- [async-cancel-safety](../../rules/async-cancel-safety.md) — Define progress, ownership, deadlines, and terminal states before racing futures; cancellation safety depends on the operation and how the future is retained.
- [async-cancellation-token](../../rules/async-cancellation-token.md) — Use `CancellationToken` for graceful shutdown and task cancellation
- [async-clone-before-await](../../rules/async-clone-before-await.md) — Own or borrow data across await according to its lifetime and Send requirements; cloning is not a general fix for suspension or thread safety.
- [async-fn-in-trait](../../rules/async-fn-in-trait.md) — Use native `async fn` in traits (stable 1.75) instead of the `async_trait` macro
- [async-join-parallel](../../rules/async-join-parallel.md) — Use `join!` or `try_join!` for concurrent independent futures
- [async-joinset-structured](../../rules/async-joinset-structured.md) — Use `JoinSet` for managing dynamic collections of spawned tasks
- [async-mpsc-queue](../../rules/async-mpsc-queue.md) — Use `mpsc` channels for async message queues between tasks
- [async-no-lock-await](../../rules/async-no-lock-await.md) — Choose lock lifetimes that preserve state invariants; avoid blocking or needless contention, but keep justified async serialization.
- [async-oneshot-response](../../rules/async-oneshot-response.md) — Use `oneshot` channel for request-response patterns
- [async-select-racing](../../rules/async-select-racing.md) — Use select for an explicit race policy, preserving losing-operation state, fixed deadlines, and closed-channel behavior.
- [async-spawn-blocking](../../rules/async-spawn-blocking.md) — Use `spawn_blocking` for CPU-intensive work
- [async-tokio-fs](../../rules/async-tokio-fs.md) — Use `tokio::fs` instead of `std::fs` in async code
- [async-tokio-runtime](../../rules/async-tokio-runtime.md) — Configure Tokio runtime appropriately for your workload
- [async-try-join](../../rules/async-try-join.md) — Use `try_join!` for concurrent fallible operations with early return on error
- [async-watch-latest](../../rules/async-watch-latest.md) — Use watch for replaceable latest state, not event history; define initial delivery, seen revisions, and sender closure.
