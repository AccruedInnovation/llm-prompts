# Documentation

Audience, public contract and maintenance needs control.

Generated view; change the rule's first blockquote or its metadata, not this file.
Unknown compatibility is not established. Read the rule and its constraints before use.

- [doc-all-public](../../rules/doc-all-public.md) — Document all public items with `///` doc comments
- [doc-cargo-metadata](../../rules/doc-cargo-metadata.md) — Fill `Cargo.toml` metadata for published crates
- [doc-crate-readme](../../rules/doc-crate-readme.md) — Unify the README and crate root docs with `#![doc = include_str!("../README.md")]`
- [doc-errors-section](../../rules/doc-errors-section.md) — Include `# Errors` section for fallible functions
- [doc-examples-section](../../rules/doc-examples-section.md) — Include `# Examples` with runnable code
- [doc-hidden-setup](../../rules/doc-hidden-setup.md) — Use `# ` prefix to hide example setup code
- [doc-intra-links](../../rules/doc-intra-links.md) — Use intra-doc links to reference types and items
- [doc-link-types](../../rules/doc-link-types.md) — Use intra-doc links to connect related types and functions
- [doc-module-inner](../../rules/doc-module-inner.md) — Use `//!` for module-level documentation
- [doc-panics-section](../../rules/doc-panics-section.md) — Include `# Panics` section for functions that can panic
- [doc-question-mark](../../rules/doc-question-mark.md) — Use `?` in examples, not `.unwrap()`
- [doc-safety-section](../../rules/doc-safety-section.md) — Include `# Safety` section for unsafe functions
