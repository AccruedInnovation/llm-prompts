# Rust rule categories

Generated from canonical rule text and metadata. Read only relevant categories.

| Category | Applicability | Rules |
| --- | --- | --- |
| [Ownership and borrowing](categories/own.md) | Common principles; preserve real ownership and lifetime needs. | 12 |
| [Errors](categories/err.md) | Recoverable error and project error-contract guidance; no required error crate. | 12 |
| [Memory](categories/mem.md) | Conditional on workload or resource limits; measure material optimization. | 17 |
| [Unsafe code](categories/unsafe.md) | Triggered by safety boundaries; preserve invariants and tool support limits. | 7 |
| [API design](categories/api.md) | Public contract or caller need; preserve compatibility. | 17 |
| [Async work](categories/async.md) | Triggered by asynchronous code; inspect cancellation and ownership. | 18 |
| [Concurrency](categories/conc.md) | Triggered by shared state or concurrent execution. | 4 |
| [Compiler optimization](categories/opt.md) | Conditional and measured; preserve target/toolchain support. | 12 |
| [Numeric safety](categories/num.md) | Domain/range dependent; define overflow and conversion behavior. | 5 |
| [Type design](categories/type.md) | Use types for named invariants, not pattern compliance. | 13 |
| [Traits and generics](categories/trait.md) | Use abstraction for a real boundary or need. | 6 |
| [Conversions](categories/conv.md) | Boundary and loss/validation policy dependent. | 3 |
| [Compile-time choices](categories/const.md) | API, compiler version and actual execution constraints matter. | 4 |
| [Serialization](categories/serde.md) | Wire/storage compatibility and input policy control. | 8 |
| [Pattern matching](categories/pat.md) | Context and readability dependent. | 5 |
| [Macros](categories/macro.md) | Use only for justified repetition or syntax needs. | 8 |
| [Closures](categories/closure.md) | Ownership, lifetime and caller requirements control. | 5 |
| [Collections](categories/coll.md) | Workload, ordering, security and resource needs control. | 4 |
| [Naming](categories/name.md) | Follow coherent project and public API conventions. | 16 |
| [Tests](categories/test.md) | Choose evidence by risk; specialized tools are conditional. | 15 |
| [Documentation](categories/doc.md) | Audience, public contract and maintenance needs control. | 12 |
| [Observability](categories/obs.md) | Operational outcomes and data sensitivity control. | 7 |
| [Performance](categories/perf.md) | Conditional and benchmarked; no assumed speedups. | 13 |
| [Project structure](categories/proj.md) | Repository and delivery conventions control. | 14 |
| [Lints](categories/lint.md) | Repository policy; do not impose blanket lint sets. | 13 |
| [Diagnostic references](categories/anti.md) | Potential issues require concrete evidence, not automatic findings. | 15 |
