fn invalid_input() { let _ = sum_at(std::ptr::null::<i32>(),0); }
