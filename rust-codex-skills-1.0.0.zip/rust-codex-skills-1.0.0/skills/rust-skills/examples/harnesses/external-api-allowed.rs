extern crate example_api;
#[test] fn downstream() { let o=example_api::Options::new(3);assert_eq!(o.retries,3);let result=match example_api::Status::Ready {example_api::Status::Ready=>1,_=>0}; assert_eq!(result,1); }
