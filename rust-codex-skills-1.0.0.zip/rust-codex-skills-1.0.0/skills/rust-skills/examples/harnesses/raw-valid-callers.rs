#[test] fn valid() { let values=[3,7]; assert_eq!(unsafe {sum_at_raw(values.as_ptr(),values.len(),1)},Some(8)); }
#[test] fn overflow() { let values=[i32::MAX]; assert_eq!(unsafe {sum_at_raw(values.as_ptr(),1,0)},None); }
