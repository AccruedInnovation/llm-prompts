extern crate example_api;
fn f(s:example_api::Status)->u8 { match s { example_api::Status::Ready=>1,example_api::Status::Busy=>2 } }
