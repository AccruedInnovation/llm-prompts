fn invalid_safe_call() { let _ = sum_at_raw(std::ptr::null(),1,0); }
