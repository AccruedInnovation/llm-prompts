#[test] fn copy() { let mut dst=[0;4]; assert_eq!(copy_bytes(&mut dst,&[1,2,3,4]),Ok(())); assert_eq!(dst,[1,2,3,4]); }
#[test] fn mismatch_no_write() { let mut dst=[7;2]; assert_eq!(copy_bytes(&mut dst,&[1]),Err(LengthMismatch)); assert_eq!(dst,[7,7]); }
#[test] fn empty() { assert_eq!(copy_bytes(&mut [],&[]),Ok(())); }
