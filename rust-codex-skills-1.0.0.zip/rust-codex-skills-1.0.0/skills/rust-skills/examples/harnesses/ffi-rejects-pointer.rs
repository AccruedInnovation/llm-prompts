fn invalid_input() { let _ = copy_bytes(std::ptr::null_mut::<u8>(),std::ptr::null::<u8>()); }
