#[test] fn extra_key_tolerated() {assert_eq!(serde_json::from_str::<TolerantConfig>(r#"{"timeout_secs":30,"extra":1}"#).unwrap().timeout_secs,30);}
#[test] fn extra_key_rejected() {let e=serde_json::from_str::<StrictConfig>(r#"{"timeout_secs":30,"extra":1}"#).unwrap_err();assert!(e.to_string().contains("unknown field"));}
#[test] fn missing_required_not_defaulted() {let e=serde_json::from_str::<TolerantConfig>(r#"{"timout_secs":30}"#).unwrap_err();assert!(e.to_string().contains("missing field `timeout_secs`"));}
#[test] fn explicit_default_permits_omission() {assert_eq!(serde_json::from_str::<DefaultedConfig>(r#"{"timout_secs":30}"#).unwrap().timeout_secs,0);}
