#[tokio::test(flavor="current_thread")]
async fn stale_fetch_rejected() {
    let state=std::sync::Arc::new(Mutex::new(State::new(1)));
    let (entered_tx,entered_rx)=tokio::sync::oneshot::channel();
    let (release_tx,release_rx)=tokio::sync::oneshot::channel();
    let worker_state=state.clone();
    let task=tokio::spawn(async move {refresh(&worker_state,|id|async move {assert_eq!(id,1);entered_tx.send(()).unwrap();release_rx.await.unwrap();vec![1]}).await});
    entered_rx.await.unwrap();state.lock().await.retarget(2).unwrap();release_tx.send(()).unwrap();
    assert_eq!(task.await.unwrap(),Err(CommitError::Stale));assert_eq!(state.lock().await.value,None);
}
#[tokio::test(flavor="current_thread")]
async fn justified_async_lock() {
    let v=Mutex::new(Vec::new());
    tokio::join!(serialized_append(&v,1),serialized_append(&v,2));
    let mut result=v.lock().await.clone();result.sort();assert_eq!(result,vec![1,2]);
}
