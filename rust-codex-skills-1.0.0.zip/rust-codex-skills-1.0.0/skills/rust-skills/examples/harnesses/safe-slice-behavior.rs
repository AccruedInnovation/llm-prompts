#[test] fn valid() { assert_eq!(sum_at(&[10,20], 1),Some(21)); }
#[test] fn empty() { assert_eq!(sum_at(&[], 0),None); }
#[test] fn out_of_range() { assert_eq!(sum_at(&[4], 1),None); }
#[test] fn overflow() { assert_eq!(sum_at(&[i32::MAX], 0),None); }
