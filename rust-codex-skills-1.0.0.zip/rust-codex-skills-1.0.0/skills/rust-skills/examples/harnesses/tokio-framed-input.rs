#[tokio::test(flavor="current_thread")]
async fn complete_and_closed_stop() {
    let(tx,mut stop)=mpsc::channel(1);drop(tx);let mut input=&b"abcdefgh"[..];let mut frames=vec![];
    assert_eq!(read_frames(&mut input,&mut stop,|f|frames.push(f)).await.unwrap(),ReadEnd::Eof);
    assert_eq!(frames,vec![*b"abcd",*b"efgh"]);
}
#[tokio::test(flavor="current_thread")]
async fn empty_eof() { let(_tx,mut stop)=mpsc::channel(1);let mut input=&b""[..];assert_eq!(read_frames(&mut input,&mut stop,|_|panic!()).await.unwrap(),ReadEnd::Eof); }
#[tokio::test(flavor="current_thread")]
async fn partial_eof() { let(_tx,mut stop)=mpsc::channel(1);let mut input=&b"ab"[..];assert_eq!(read_frames(&mut input,&mut stop,|_|panic!()).await.unwrap_err().kind(),io::ErrorKind::UnexpectedEof); }
#[tokio::test(flavor="current_thread")]
async fn ready_stop_priority() { let(tx,mut stop)=mpsc::channel(1);tx.send(()).await.unwrap();let mut input=&b"abcd"[..];assert_eq!(read_frames(&mut input,&mut stop,|_|panic!()).await.unwrap(),ReadEnd::Stopped(vec![]));assert_eq!(input,b"abcd"); }
// The reader sends stop after producing two bytes. The next select sees stop
// ready, proving retained partial progress without timing or scheduler guesses.
struct StopAfterRead {sent:bool,tx:mpsc::Sender<()>}
impl AsyncRead for StopAfterRead {
    fn poll_read(mut self:std::pin::Pin<&mut Self>,_:&mut std::task::Context<'_>,buf:&mut tokio::io::ReadBuf<'_>)->std::task::Poll<io::Result<()>> {
        assert!(!self.sent);buf.put_slice(b"ab");self.sent=true;self.tx.try_send(()).unwrap();std::task::Poll::Ready(Ok(()))
    }
}
#[tokio::test(flavor="current_thread")]
async fn stop_returns_partial() {let(tx,mut stop)=mpsc::channel(1);let mut input=StopAfterRead{sent:false,tx};assert_eq!(read_frames(&mut input,&mut stop,|_|panic!()).await.unwrap(),ReadEnd::Stopped(b"ab".to_vec()));}
