#[tokio::test(flavor="current_thread")]
async fn command_close_exits_with_stop_pending() {
    let(tx,mut rx)=tokio::sync::mpsc::channel(2);tx.send(7).await.unwrap();drop(tx);
    let(_stop_tx,mut stop)=tokio::sync::oneshot::channel();let mut seen=vec![];
    tokio::time::timeout(std::time::Duration::from_secs(2),command_loop(&mut rx,&mut stop,|n|seen.push(n))).await.unwrap();assert_eq!(seen,vec![7]);
}
#[tokio::test(flavor="current_thread")]
async fn watch_initial_then_latest_and_close() {
    let(tx,rx)=tokio::sync::watch::channel(1);let mut tx=Some(tx);let mut values=vec![];
    observe_latest(rx,|n| {values.push(n);if n==1{let sender=tx.take().unwrap();sender.send(2).unwrap();sender.send(3).unwrap();drop(sender);}}).await;
    assert_eq!(values,vec![1,3]);
}
#[tokio::test(flavor="current_thread")]
async fn dropping_join_handle_detaches() {
    let(tx,rx)=tokio::sync::oneshot::channel();let task=tokio::spawn(async move {tokio::task::yield_now().await;tx.send(9).unwrap();});drop(task);assert_eq!(rx.await.unwrap(),9);
}
