extern crate example_api;
fn f() { let _=example_api::Options {retries:3}; }
