# Checked examples and their limits

The rule files own the Rust examples. Named fences feed `checks.json` and the runner;
harness files supply assertions or downstream consumer code, not copies of the example.
`catalog.json` inventories every Rust fence. It does not say every fence compiles or
that an example passed. Run results are separate records.

## Run

From this skill directory, with Python 3.11+ and a supported Rust compiler:

```sh
python scripts/check_examples.py --suite core --output core-results.json
python scripts/check_examples.py --suite all --output all-results.json
```

Use `--rustc /absolute/path/to/rustc` and `--cargo /absolute/path/to/cargo` for an explicit
toolchain. The runner invokes that compiler directly, not rustup installation commands.
Core checks need no external crates. The FFI runtime example is restricted to the
conventional Linux C ABI used in this delivery. Other compiler-only checks do not claim
that ABI works on a different target.

Tokio and Serde checks require Cargo and the dependency pins in `checks.json`. These
are test-only dependencies; do not add them to the project being reviewed. Resolution
is offline unless `--allow-network` is explicitly supplied. That flag is an execution
permission decision, not an instruction to enable network. Inspect the manifest and
use a trusted configured Cargo environment. Cargo may execute dependency build code.
The runner writes build files in a temporary directory and may use the configured
Cargo cache; the optional output path writes the requested result file.

Run one case using `--suite core --check revision-contract`. The checks cover editions
2021 and 2024 where declared, not all compiler versions. An edition is not a compiler
version. A failure on an older compiler is evidence about that configuration, not a
reason to silently upgrade a target project.

## Expected outcomes

`compile-pass` requires successful compilation. `compile-fail` requires failure and
specific diagnostics; missing imports or undefined names do not count as the intended
rejection. `compile-warning` requires successful compilation and the stated warning.
`run-pass` requires the exact stated Rust test count, zero failures, zero ignored tests,
and zero filtered tests. Rejection fixtures never run. Valid-pointer runtime tests use
live initialized arrays; they do not exercise undefined behavior.

The external API cases build a separate library and then a downstream crate. The
revision tests cover stale identity, ABA, competing commits, exhaustion without writes,
and error precedence. Tokio tests use channels and controlled polling rather than
sleep-based race guesses. Serde cases isolate unknown fields from missing fields.

Exit codes: `0` means every selected expectation passed; `1` means a known check failed;
`2` means invalid input or incomplete evidence (unavailable or timed-out checks). Inspect
the JSON to distinguish them. A missing dependency remains `NOT_RUN`, never a pass.
Timeout is `INCONCLUSIVE`. Failed prerequisite resolution has its own captured command.

## Qualification levels

Fifteen rules received targeted safety, async, API, serialization, thread-local, and storage review; a sixteenth received a narrow documentation correction. Only the named examples have
executable checks. Inherited examples remain `illustrative-unqualified`; do not copy
them as qualified implementations. Compilation cannot establish memory safety for all
callers, correct foreign signatures, every interleaving, or production behavior.
No Miri, Loom, fuzzing, sanitizer, Windows runtime, or agent-performance claim follows
from this runner. See the bundle's validation report for the runs actually completed.

To maintain the bundle, update the canonical rule or metadata, run
`maintenance/build_indexes.py` from the bundle root, run the applicable checks, and
refresh `maintenance/build_manifest.py`. Installed copies intentionally do not include
the bundle's maintenance tools. Preserve the source bundle for edits and rebuilds.
