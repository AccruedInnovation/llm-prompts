# Focused review guide

Use only the sections relevant to the assignment. The evidence and scope rules in
SKILL.md govern how to report findings. This guide supplies questions, not proof that
a defect exists or permission to impose a new requirement. Preserve correct code.


This is not a general architecture review and not a style/lint review. Focus on whether the codebase has the right tests, at the right levels, validating the right invariants, with enough realism to catch production-relevant failures.

**Core Testing Philosophy:**

Tests are not a coverage ritual. Tests are executable risk controls.

Evaluate the codebase by asking:

1. What must never break?
2. What failures would be expensive, silent, security-relevant, data-corrupting, or hard to debug?
3. Are those risks protected by direct, realistic, maintainable tests?
4. Are the tests checking behavior and invariants, or merely implementation details?
5. Would the current suite catch regressions caused by refactoring, dependency changes, persistence changes, concurrency changes, parser changes, or schema changes?

Prefer tests that lock down important behavior with the least brittleness. Do not recommend tests merely to increase line coverage.

---

## Analysis Dimensions

Analyze the codebase across the following categories.

### 1. Critical Invariant Coverage

Identify the most important invariants in the system and determine whether they are directly tested.

Examples:

* domain invariants
* authorization invariants
* state transition invariants
* persistence consistency invariants
* ordering invariants
* idempotency invariants
* serialization round-trip invariants
* API compatibility invariants
* audit/logging invariants
* feature-flag invariants

Flag invariants that are only indirectly tested through broad integration tests.

### 2. Behavioral Coverage vs Implementation Coverage

Evaluate whether tests assert user-visible, domain-visible, or contract-visible behavior rather than internal mechanics.

Flag tests that:

* assert private helper behavior while missing public contract behavior
* mirror implementation structure too closely
* break under harmless refactors
* fail to describe the behavior they protect
* validate mocks instead of outcomes

### 3. Happy Path Bias

Identify areas where the suite disproportionately tests successful flows while neglecting:

* invalid input
* empty input
* malformed input
* boundary values
* duplicate requests
* missing records
* conflicting records
* permission failures
* persistence failures
* network failures
* timeout paths
* cancellation paths
* rollback paths
* retry exhaustion

### 4. Error Path and Failure Semantics

Assess whether error behavior is intentionally specified and tested.

Check:

* typed domain errors
* infrastructure error translation
* error wrapping/context
* retryable vs non-retryable errors
* user-facing error mapping
* partial failure handling
* compensating actions
* rollback semantics
* preservation of original error causes
* absence of `unwrap`, `expect`, or panic paths outside tests unless justified

### 5. Property-Based Testing Opportunities

Identify pure or near-pure logic that would benefit from property-based tests.

Good candidates:

* parsers
* serializers/deserializers
* normalization logic
* graph traversal
* diffing/patching
* merge/conflict resolution
* schedulers
* state machines
* validators
* identifier generation/parsing
* permission matrices
* dependency resolution
* ordering/topological sorting
* financial/scientific/units calculations
* conversion between internal and external representations

Prefer `proptest` for Rust property tests unless the project already uses another tool.

For each recommendation, specify:

* property to test
* generated input shape
* important shrinking behavior
* failure class it would catch

### 6. Fuzzing Opportunities

Identify untrusted-input boundaries and complex decoders that should be fuzzed.

Good candidates:

* parsers
* binary formats
* text formats
* DSLs
* config loaders
* protocol handlers
* compressed or encoded inputs
* regex-heavy logic
* recursive structures
* JSON/TOML/YAML deserialization
* custom `serde` implementations
* file import/export paths

Prefer `cargo-fuzz` where appropriate.

Flag inputs that could trigger:

* panics
* hangs
* stack overflows
* memory blowups
* exponential behavior
* incorrect acceptance
* incorrect rejection
* data corruption

### 7. Snapshot and Golden Test Suitability

Evaluate where snapshot or golden-file testing would improve regression protection.

Good candidates:

* compilers
* code generators
* report generators
* CLI output
* rendered templates
* diagnostics
* generated schemas
* protocol output
* normalized document output
* migration-generated artifacts

Prefer:

* `insta` snapshots for readable structured outputs
* golden files for stable external artifacts
* explicit review workflow for intentional changes

Flag:

* snapshots that are too broad
* snapshots full of unstable values
* snapshots that hide semantic changes
* tests that update snapshots without semantic review
* golden files that lack source/input context

### 8. Async and Cancellation Testing

Analyze async code for missing tests around:

* cancellation safety
* timeout behavior
* task failure propagation
* dropped join handles
* background task shutdown
* select/race behavior
* lock ordering
* channel closure
* backpressure
* bounded queues
* blocking work inside async runtime
* graceful shutdown

Recommend deterministic approaches where possible:

* fake clocks
* controlled schedulers
* explicit cancellation points
* `tokio::time::pause`
* bounded channels in tests
* task instrumentation
* `loom` for low-level concurrency primitives

### 9. Concurrency and Shared State Testing

Identify shared-state or multi-threaded logic that lacks stress, interleaving, or deterministic concurrency tests.

Look for:

* `Arc<Mutex<T>>`
* `Arc<RwLock<T>>`
* atomics
* channels
* background workers
* caches
* registries
* global state
* once-init structures
* lock-free or low-level synchronization
* custom synchronization abstractions

Recommend `loom` when the code contains small concurrency primitives whose correctness depends on interleavings.

Do not recommend `loom` for broad application-level async workflows unless the code can be isolated into a small deterministic unit.

### 10. Persistence and Transaction Testing

Evaluate whether persistence behavior is tested realistically.

Check:

* transaction boundaries
* rollback behavior
* commit failure handling
* migration forward/backward behavior
* schema compatibility
* unique constraints
* foreign key constraints
* cascading deletes
* idempotency keys
* optimistic concurrency/version checks
* repository/domain boundary behavior
* serialization format compatibility
* corrupt or legacy data handling

Prefer integration tests with a real database engine when persistence semantics matter. Avoid over-reliance on mocks for repository behavior that depends on actual database constraints.

### 11. API and Contract Testing

Assess whether public APIs, HTTP endpoints, CLI commands, crate interfaces, or message protocols have contract tests.

Look for:

* missing tests for public functions
* missing tests for public error behavior
* missing serialization compatibility tests
* missing semver-sensitive behavior tests
* missing feature-flag combination tests
* missing OpenAPI/schema compatibility tests where applicable
* untested CLI exit codes and stderr/stdout contracts
* untested HTTP status/body/header behavior
* untested backward compatibility paths

### 12. Test Data and Fixture Quality

Evaluate the quality of test data.

Flag:

* enormous fixtures with unclear purpose
* overly magical builders
* hard-coded data copied across tests
* unrealistic data that hides production failures
* random data without deterministic seeds
* fixture mutation across tests
* tests that depend on execution order
* golden files without explanation
* missing minimal examples for core domain cases

Prefer:

* small focused fixtures
* explicit test data builders
* named scenario constructors
* deterministic randomness
* fixtures that encode domain meaning
* realistic integration fixtures for high-risk flows

### 13. Mocking and Test Double Discipline

Assess whether mocks, fakes, stubs, and test doubles are appropriate.

Flag:

* mocks that only verify call order without validating outcomes
* mocks of code that should be tested through integration
* fakes with behavior that diverges from production dependencies
* repository mocks hiding query/transaction bugs
* HTTP mocks that ignore headers/status/error bodies
* filesystem mocks hiding path/platform behavior
* clock randomness or time dependence without fake clocks
* global monkeypatch-style testing

Prefer:

* real implementations for critical infrastructure semantics
* thin fakes for deterministic external services
* contract tests shared between fake and real implementations
* dependency injection through constructors rather than frameworks

### 14. Test Isolation, Determinism, and Flakiness

Look for signs that tests may be flaky or order-dependent.

Check:

* sleeps in tests
* real time dependence
* external network calls
* shared ports
* shared temp directories
* global environment mutation
* test order assumptions
* parallel execution hazards
* nondeterministic iteration order
* randomness without seed capture
* time-zone dependence
* locale dependence

Recommend deterministic replacements:

* fake clocks
* temp directories per test
* randomized ports
* seeded RNG
* isolated databases
* explicit environment guards
* serial test markers only when unavoidable

### 15. Test Performance and Suite Shape

Evaluate whether the test suite provides fast feedback without sacrificing confidence.

Classify tests by role:

* fast unit tests
* property tests
* integration tests
* fuzz targets
* migration tests
* end-to-end tests
* slow/nightly tests
* release-gate tests

Flag:

* slow tests in the default loop without reason
* expensive setup repeated unnecessarily
* integration tests pretending to be unit tests
* too many brittle end-to-end tests
* lack of smoke tests
* lack of release-candidate tests
* missing CI separation between quick checks and expensive checks

### 16. CI and Release Gate Alignment

Assess whether tests are actually wired into CI/release workflows.

Check:

* `cargo test`
* workspace-wide tests
* feature-combination tests
* `cargo clippy`
* `cargo fmt`
* `cargo audit` / `cargo deny`
* doc tests
* examples
* benchmarks, if used as regression signals
* fuzz smoke runs, if appropriate
* migration tests
* platform matrix
* minimum supported Rust version, if relevant
* `no_std` or WASM targets, if relevant

Flag tests that exist but are not run automatically.

### 17. Documentation Tests and Examples

Evaluate whether public examples compile and remain accurate.

Check:

* doctests for public APIs
* examples under `examples/`
* README snippets
* getting-started commands
* generated documentation examples
* feature-gated examples
* examples that require unavailable external services

Prefer examples that demonstrate correct usage and prevent API drift.

---

## Rust-Specific Testing Tools and Patterns

Consider recommending these when they fit the risk:

* `proptest` for property-based tests
* `quickcheck` only if already established in the project
* `cargo-fuzz` for fuzzing untrusted input and parser-like boundaries
* `insta` for snapshot tests
* `trybuild` for macro/type-level compile-fail tests
* `loom` for low-level concurrency interleaving tests
* `tokio::test` and `tokio::time::pause` for async tests
* `tempfile` for isolated filesystem tests
* `assert_cmd` for CLI behavior
* `predicates` for CLI output assertions
* `wiremock`, `httpmock`, or equivalent for HTTP boundaries
* `testcontainers` or real local services for integration tests where semantics matter
* `criterion` only when performance regressions are important
* `mutest-rs` (`cargo mutest run`) for high-value logic when mutation testing is explicitly selected and the project has a qualified tool revision/nightly; preserve surviving mutants and tool failures separately

Do not recommend a tool by default. Recommend it only when it matches a concrete risk.

---

## What to Inspect

When available, inspect:

* `Cargo.toml`
* workspace layout
* `tests/`
* `benches/`
* `examples/`
* `src/**`
* `crates/**`
* `migrations/`
* `.github/workflows/`
* CI configuration
* fuzz targets
* snapshot/golden directories
* test fixtures
* README examples
* public API documentation
* issue references or TODOs indicating known regressions

---

## Do Not Recommend

Do not recommend:

* tests solely to increase coverage percentage
* mocks where real integration behavior is the actual risk
* property tests for trivial getters/setters
* fuzzing code that has no meaningful input surface
* snapshots for highly unstable output
* end-to-end tests when a smaller contract/integration test would catch the same issue
* brittle assertions against incidental formatting unless formatting is the contract
* introducing test frameworks that do not match the project’s complexity
* large fixture factories that obscure the tested behavior
* testing private implementation details unless the private logic is complex and cannot be better tested through a public contract
* sleeps or timing guesses as a solution to async test flakiness
* broad rewrites unless the current design makes meaningful verification impossible

---

## Review Discipline

Be specific. Tie every recommendation to a concrete risk.

Prefer this:

> The parser accepts untrusted project files but has no fuzz target or malformed-input regression tests. Add a `cargo-fuzz` target that feeds arbitrary bytes into the parser and asserts no panic, bounded runtime, and either valid AST or typed parse error.

Avoid this:

> Add more tests for the parser.

Prefer this:

> The state transition logic has five legal states but tests only cover the nominal transition path. Add a table-driven test covering all legal and illegal transitions, plus a property test that no transition sequence can produce an invalid terminal state.

Avoid this:

> Improve state machine tests.

Prefer this:

> Repository tests use mocks, so unique constraint and transaction rollback behavior are untested. Add integration tests against the real database engine for duplicate insert, rollback after mid-transaction failure, and idempotent retry.

Avoid this:

> Add integration tests.
