---
name: rust-implementation-structure
description: "Design Rust crate, module, type, state, and ownership boundaries for assigned implementation work. Use existing requirements; no special contract schema required."
---

# Rust implementation structure

Use for a material design choice, not every private edit. Read the task, accepted
design, code, public contracts, and existing tests. A requirement may be prose, an
issue, a PRD, or a repository contract; do not require a separate planning framework.

Map the assigned behavior to the smallest coherent crates, modules, types, traits,
features, and generated artifacts. Keep each invariant and mutable state under a clear
owner. Fix shared API, state transition, error, ordering, cancellation, recovery, and
compatibility semantics before separate implementations depend on them.

Use newtypes, enums, constructors, traits, or typestate when they prevent a meaningful
invalid state, clarify ownership, hide complexity, or create a useful test seam. Do not
create one trait per type or freeze private helper names without a real consumer need.
Types do not replace runtime validation of untrusted inputs or dynamic conditions.

For async and durable work, define task ownership, locks/channels, pending effects,
commit points, stale results, retries, shutdown, and recovery. For unsafe or FFI work,
state caller obligations, layouts, lifetimes, allocation and thread rules. Preserve
fixed upstream choices; propose a change rather than silently replacing them.

Return the relevant design beside its reason, permitted local choices, consumers,
and checks. A local choice can stay inline in the task. Broader work may need a short
linked design record, not a new document system. Compiler success cannot establish
protocol, persistence, cancellation, soundness, or installed behavior on its own.
