---
name: rust-evidence-reproducer
description: "Capture and minimize Rust failures, flaky tests, unsafe probes, benchmarks, and fault traces with enough context to rerun them. No special result format required."
---

# Rust evidence and reproducer

For a material check, record the exact code revision or file hashes including relevant
local changes; the claimed behavior; tool versions; compiler/edition/target; package,
features and test selection; Cargo.lock and important configuration; exact command,
working directory, inputs, allowed effects, timeout, and the observed result. Use the
existing report or issue rather than a new evidence system. Never record secrets.

Distinguish **PASS**, **FAIL**, **INCONCLUSIVE**, and **NOT_RUN**. Record unavailable,
unsupported, blocked, or optional status separately. A timeout or broken runner cannot
prove success. A compile-fail must fail for the intended reason, not a missing import.
An expected negative case passes only when the intended rejection and prohibited
side effects match its independent expectation. Never execute undefined behavior just
to demonstrate a crash when static or compile-only evidence answers the question.

Retain technique-specific evidence when it matters:

- Property/fuzz tests: seed, minimized input, corpus identity, budget, and a regression.
- Async/concurrency: explicit interleaving or schedule, progress and termination
  assertions, cancellation point, runtime configuration, and minimized state trace.
- Miri/sanitizers/ABI: toolchain, flags, selected paths, platform, and unsupported calls.
- Mutation tests: baseline result, mutant identity, survivors, timeouts, and dispositions.
- Benchmarks: baseline, workload, environment, warmup, samples/distribution, and variance.
- Crash/recovery: fault boundary, durable state before/after, restart and cleanup.

For flaky checks, preserve all attempts. A retry pass does not erase a failure. Minimize
a reproducer without removing the trigger or substituting a mock for the claimed real
consumer. Reuse evidence only within its unchanged subject, input, tool, and configuration
bounds. Report exactly what a model or simulation establishes and what remains untested.
