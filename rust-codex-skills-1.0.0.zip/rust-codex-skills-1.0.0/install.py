#!/usr/bin/env python3
"""Install standalone skills. Python 3.11+; no network, shell or Codex configuration edits."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import re
import shutil
import stat
import sys
import tempfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def reject_links(path: Path) -> None:
    """Reject existing links/reparse points, including the path's parents."""
    for item in [path, *path.parents]:
        try:
            info = item.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400):
            raise ValueError(f"symlink/reparse-point path is not accepted: {item}")


def files_in(root: Path) -> dict[str, str]:
    if not root.is_dir():
        raise ValueError(f"not a directory: {root}")
    reject_links(root)
    result = {}
    for p in sorted(root.rglob("*")):
        reject_links(p)
        if p.is_file():
            result[p.relative_to(root).as_posix()] = sha(p)
        elif not p.is_dir():
            raise ValueError(f"unsupported filesystem entry: {p}")
    return result


def load_manifest(root: Path) -> dict:
    manifest = json.loads((root / "skills-manifest.json").read_text(encoding="utf-8"))
    if manifest.get("schema") != "standalone-rust-skills.v1" or not manifest.get("skills"):
        raise ValueError("unsupported or empty skill manifest")
    for name, record in manifest["skills"].items():
        if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", name):
            raise ValueError(f"invalid skill name: {name}")
        if "SKILL.md" not in record["files"]:
            raise ValueError(f"missing entry point: {name}")
        for relative, expected in record["files"].items():
            p = PurePosixPath(relative)
            if p.is_absolute() or ".." in p.parts or "\\" in relative or ":" in relative:
                raise ValueError(f"invalid manifest path: {relative}")
            if not re.fullmatch(r"[a-f0-9]{64}", expected):
                raise ValueError(f"invalid file digest: {relative}")
    return manifest


def install(root: Path, destination: Path, names: list[str] | None = None, replace: bool = False, dry_run: bool = False) -> dict:
    manifest = load_manifest(root)
    names = sorted(set(names or manifest["skills"]))
    if not names or set(names) - set(manifest["skills"]):
        raise ValueError("unknown or empty skill selection")
    # absolute() preserves link names for validation; resolve only after the check.
    dest = Path(os.path.abspath(destination.expanduser()))
    reject_links(dest)
    if dest == root.resolve() or dest.is_relative_to(root.resolve()):
        raise ValueError("installation destination must be outside this bundle")
    if dest.exists() and not dest.is_dir():
        raise ValueError("destination exists but is not a directory")
    conflicts = []
    for name in names:
        source = root / "skills" / name
        if files_in(source) != manifest["skills"][name]["files"]:
            raise ValueError(f"source integrity mismatch: {name}; rebuild manifest after an intentional edit")
        target = dest / name
        reject_links(target)
        if target.exists():
            if not target.is_dir():
                raise ValueError(f"existing skill is not a directory: {target}")
            conflicts.append(name)
    if conflicts and not replace:
        raise ValueError("existing skills would be overwritten: " + ", ".join(conflicts) + "; use a different destination or explicit --replace")
    report = {"status": "DRY_RUN" if dry_run else "INSTALLED", "destination": str(dest), "skills": names, "replaced": conflicts, "backup": None, "manifest_sha256": sha(root / "skills-manifest.json"), "network_used": False}
    if dry_run:
        return report
    # Single-writer local installation. This is not an atomic multi-folder update
    # against an adversary changing directories concurrently; stop Codex during replace.
    dest.parent.mkdir(parents=True, exist_ok=True)
    reject_links(dest.parent)
    stage = Path(tempfile.mkdtemp(prefix=".rust-skills-stage-", dir=dest.parent))
    backup = None
    placed = []
    moved = []
    lock = None
    try:
        for name in names:
            shutil.copytree(root / "skills" / name, stage / name)
            if files_in(stage / name) != manifest["skills"][name]["files"]:
                raise ValueError(f"staged copy failed integrity check: {name}")
        dest.mkdir(exist_ok=True)
        reject_links(dest)
        lock = dest / ".rust-skills-install.lock"
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        os.close(fd)
        # Recheck after staging, before any previous installation is moved.
        for name in names:
            target = dest / name
            reject_links(target)
            if target.exists() != (name in conflicts):
                raise ValueError("destination changed during staging; retry with one installer")
        if conflicts:
            backup = Path(tempfile.mkdtemp(prefix=".rust-skills-backup-", dir=dest.parent))
            report["backup"] = str(backup)
        for name in names:
            target = dest / name
            if name in conflicts:
                target.rename(backup / name)
                moved.append(name)
            (stage / name).rename(target)
            placed.append(name)
        for name in names:
            if files_in(dest / name) != manifest["skills"][name]["files"]:
                raise ValueError(f"installed integrity mismatch: {name}")
        return report
    except Exception:
        # Revert only entries this invocation installed. Previous trees are moved,
        # not merged, so no stale source files survive an upgrade.
        for name in reversed(placed):
            shutil.rmtree(dest / name)
        for name in reversed(moved):
            (backup / name).rename(dest / name)
        raise
    finally:
        shutil.rmtree(stage)
        if lock is not None:
            # Do not remove a competing installer's lock when exclusive creation failed.
            if 'fd' in locals():
                lock.unlink(missing_ok=True)


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--dest", type=Path, default=Path.home() / ".agents/skills")
    p.add_argument("--skill", action="append", help="install only this skill; repeat as needed")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--replace", action="store_true", help="replace conflicting skill folders and retain sibling backups")
    a = p.parse_args()
    try:
        print(json.dumps(install(ROOT, a.dest, a.skill, a.replace, a.dry_run), indent=2))
        return 0
    except (OSError, ValueError, KeyError) as exc:
        print(json.dumps({"status": "ERROR", "error": str(exc)}), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
