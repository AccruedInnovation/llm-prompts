# Standalone Rust skills for Codex — 1.0.0

Fourteen generic skills for Rust implementation, review, and verification. This is a
folder-based Codex skill bundle, **not a BBK language package**. No BBK installation,
profile registry, worker contract, dispatch service, plugin, or external connector is
required. The installer copies only the folders under `skills/`.

The bundle retains the 265-rule reference library and the focused review material.
It corrects the identified unsafe and async guidance, replaces large entry points with
short selective instructions, and includes optional deterministic helpers and tests.
The rules remain guidance; repository contracts and the assignment control the work.

## Install

Extract the ZIP, then open a terminal in its `rust-codex-skills-1.0.0` directory.
The optional installer and helpers use **Python 3.11 or later** and its standard library.
Reading or manually copying a skill does not require Python or a Rust toolchain.

On Windows, in PowerShell:

```powershell
py -3 --version
py -3 .\install.py --dry-run
py -3 .\install.py
```

On Linux or macOS:

```sh
python3 --version
python3 install.py --dry-run
python3 install.py
```

The default destination is the current user's `~/.agents/skills`, the user-level
location documented for Codex [S01]. For one repository instead, set its destination:

```powershell
py -3 .\install.py --dest "C:\path\to\repo\.agents\skills"
```

```sh
python3 install.py --dest /path/to/repo/.agents/skills
```

Use the home and filesystem of the environment running Codex. Native Windows and WSL
have different homes; installing in one does not claim installation in the other.
Do not install the same skill names at both user and repository scope without checking
which copies Codex discovers. Standalone folder support was checked against the current
official documentation; no live Codex session ran during this delivery.

The installer refuses existing skill folders by default and checks all selected sources
before writing. `--replace` moves each conflicting folder to a printed backup directory
beside the skills directory, then installs a fresh tree without merging stale files.
Backups stay outside the discovery directory. Stop active use while replacing skills;
the installer is a single-writer local tool, not an atomic update across all readers.
It rejects symlinks and Windows reparse-point paths. Choose a real directory rather than
bypassing those checks. It never edits `AGENTS.md`, Codex configuration, or remote state.

To install a smaller set:

```sh
python3 install.py --skill rust-workflow --skill rust-skills --skill rust-unsafe-ffi-assurance
```

Each folder is self-contained. It can instead be copied unchanged into the selected
skills directory after checking for conflicting names. Do not copy the outer bundle
directory as though it were one skill. Preserve each folder's licence and notice.
Keep the source bundle for maintenance; install does not copy tests, evaluation material,
or delivery evidence into Codex's skill discovery directory.

## Use in Codex

Start ordinary Rust work with:

```text
$rust-workflow Implement the requested change and run the repository's relevant checks.
```

For a focused review:

```text
$rust-unsafe-ffi-assurance Review this API's safety boundary without changing code.
$rust-correctness-failure-review Review cancellation, channel closure, and stale commits.
$rust-api-crate-boundary-review Check this change against downstream API commitments.
```

The rule library is available directly:

```text
$rust-skills Find guidance for this async state change and check it against the repository's toolchain.
```

Only `rust-workflow` permits implicit invocation in the supplied metadata. Other skills
require explicit selection or deliberate use by the workflow, rather than all reviewers
loading for every Rust edit. Codex supports explicit `$skill-name` selection and invocation
policy in `agents/openai.yaml` [S01]. If newly installed skills do not appear, restart the
Codex session and check the actual install path. Do not treat that instruction as proof
that a specific local Codex version has been tested.

## Skills

| Skill | Purpose |
| --- | --- |
| [`rust-workflow`](skills/rust-workflow/SKILL.md) | Implement and review Rust with focused checks. |
| [`rust-skills`](skills/rust-skills/SKILL.md) | Select Rust rules that fit the task and toolchain. |
| [`comprehensive-analysis-rust`](skills/comprehensive-analysis-rust/SKILL.md) | Review Rust architecture and refactoring trade-offs. |
| [`rust-api-crate-boundary-review`](skills/rust-api-crate-boundary-review/SKILL.md) | Review public APIs and downstream compatibility. |
| [`rust-correctness-failure-review`](skills/rust-correctness-failure-review/SKILL.md) | Find concrete state, async, and failure-path defects. |
| [`rust-operational-readiness-review`](skills/rust-operational-readiness-review/SKILL.md) | Review deployment, shutdown, and recovery behavior. |
| [`rust-security-supply-chain-review`](skills/rust-security-supply-chain-review/SKILL.md) | Review trust boundaries and dependency risks. |
| [`rust-test-strategy-review`](skills/rust-test-strategy-review/SKILL.md) | Assess test coverage, failure cases, and evidence. |
| [`rust-unsafe-ffi-assurance`](skills/rust-unsafe-ffi-assurance/SKILL.md) | Check safety boundaries, pointers, and foreign APIs. |
| [`rust-implementation-structure`](skills/rust-implementation-structure/SKILL.md) | Design cohesive Rust modules, types, and state owners. |
| [`rust-implementation-structure-review`](skills/rust-implementation-structure-review/SKILL.md) | Check implementation against its assigned design. |
| [`rust-execution-slicing`](skills/rust-execution-slicing/SKILL.md) | Plan small Rust changes with early integration. |
| [`rust-evidence-reproducer`](skills/rust-evidence-reproducer/SKILL.md) | Reproduce failures and capture scoped test evidence. |
| [`rust-package-release-gates`](skills/rust-package-release-gates/SKILL.md) | Check the actual crate, binary, or installation. |

## What changed

The [change log](CHANGELOG.md) maps all nine findings from the prior review to their
implementation. Unsafe examples retain caller obligations. Async guidance preserves
state, progress and task ownership. Generated summaries use the rule's canonical text.
The selector returns specific rule IDs with reasons and unresolved compatibility rather
than loading the whole library. Project inspection never treats an unqualified `fmt`
recipe as a read-only check and never maps an unknown shared change to no affected work.
Reviewers distinguish proved defects, conditional concerns, assurance gaps and optional
improvements; they have no finding or test quota.

## Validate or maintain

From the source bundle directory:

```sh
python3 -B -m unittest discover -s tests -v
python3 maintenance/build_indexes.py --check
python3 maintenance/sync_review_contract.py --check
python3 maintenance/build_manifest.py --check
python3 skills/rust-skills/scripts/check_examples.py --suite core --output core-results.json
```

The Rust example suite is separate from the Python helper tests. The `all` suite adds
Tokio and Serde tests with declared dependency pins; it defaults to offline resolution.
See [example-check details](skills/rust-skills/examples/README.md) and the actual
[validation report](VALIDATION.md). Inherited examples are not all tested. The
[eight-task agent comparison kit](evals/README.md) is supplied but no agent trial ran.

After intentional edits, regenerate the canonical projections and the install inventory:

```sh
python3 maintenance/build_indexes.py
python3 maintenance/sync_review_contract.py
python3 maintenance/build_manifest.py
```

Rerun checks before installation. The skills manifest hashes installable files only;
its own hash and the outer ZIP checksum are separate. These hashes establish exact
content identity, not publisher authentication. See [sources and notices](SOURCES.md).

[S01]: https://developers.openai.com/codex/skills
