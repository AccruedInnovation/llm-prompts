# Authoring check failures and closure

The first core example run passed 32 configurations and failed two assertions about
compiler wording. Both FFI rejection cases did reject raw pointers with E0308, but
rustc described the two-argument failure as “arguments to this function are incorrect,”
not the test's assumed “mismatched types.” The corrected expectation still requires
E0308 and both exact slice-versus-pointer type mismatches. No function or caller safety
contract changed to satisfy the test; rejection fixtures never ran.

The first Python run found one real missing link (the example README had not yet been
written) and treated inline Rustdoc link-syntax demonstrations as actual Markdown file
links. The README was supplied. The checker now excludes inline code as well as fenced
code, while continuing to validate actual relative links. Final tests pass.

Additional final review corrected truncated UI descriptions, a documentation-link
claim, and related mutable-static, constant-storage and thread-local statements. New
static-reference and thread-local checks ran before the final skill inventory froze.
No failing product test, reference expectation, or required outcome was suppressed.
Optional Tokio/Serde dependency resolution remains visibly unavailable, not repaired
by substituting a mock runtime or changing pins.
