import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from support import ROOT,load
select=load('rule_selection','skills/rust-skills/scripts/select_rules.py')
inspect=load('project_inspection','skills/rust-workflow/scripts/inspect_project.py')

class SelectionTests(unittest.TestCase):
    def test_routine_is_small(self):
        r=select.select_rules();self.assertEqual({x['id'] for x in r['selected']},set(select.ROUTINE));self.assertLessEqual(len(r['selected']),6)
    def test_unsafe_priorities(self):
        r=select.select_rules(topics=['unsafe']);self.assertIn('unsafe-minimize-scope',[x['id'] for x in r['selected']])
    def test_async_priorities(self):
        r=select.select_rules(topics=['async'],query='cancellation EOF');self.assertIn('async-cancel-safety',[x['id'] for x in r['selected']])
    def test_old_msrv_excludes_syntax_not_invariant(self):
        r=select.select_rules(rule_ids=['unsafe-extern-block'],msrv='1.70',edition='2021');self.assertEqual(r['selected'],[]);self.assertIn('Preserve',r['excluded'][0]['invariant_note'])
    def test_matching_declared_constraints(self):
        r=select.select_rules(rule_ids=['unsafe-extern-block'],msrv='1.82',edition='2021');self.assertEqual(r['selected'][0]['compatibility'],'DECLARED_CONSTRAINTS_MATCH');self.assertIn('VERIFY',r['selected'][0]['code_use'])
    def test_unknown_is_not_supported(self):
        r=select.select_rules();self.assertTrue(all(x['compatibility']=='NOT_ESTABLISHED' for x in r['selected']))
    def test_miri_is_conditional(self):
        r=select.select_rules(rule_ids=['unsafe-miri-ci']);self.assertFalse(r['selected']);self.assertEqual(len(r['excluded']),1)
    def test_miri_nightly_is_not_qualification(self):
        r=select.select_rules(rule_ids=['unsafe-miri-ci'],channel='nightly');self.assertEqual(r['selected'][0]['compatibility'],'NOT_ESTABLISHED')
    def test_byte_budget_reports_deferral(self):
        r=select.select_rules(topics=['async'],byte_budget=256);self.assertFalse(r['selected']);self.assertGreater(r['deferred_count'],0)
    def test_count_limit_reports_deferral(self):
        r=select.select_rules(topics=['async'],limit=1);self.assertEqual(len(r['selected']),1);self.assertGreater(r['deferred_count'],0)
    def test_bad_inputs_rejected(self):
        for args in [{'topics':['nonsense']},{'rule_ids':['nonsense']},{'msrv':'stable'},{'msrv':'1.82','edition':'2024'},{'msrv':'1.85','rust_version':'1.82'},{'limit':0},{'byte_budget':0}]:
            with self.subTest(args=args),self.assertRaises(ValueError):select.select_rules(**args)
    def test_selected_digest_checked(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'rules').mkdir();p=ROOT/'skills/rust-skills/rules-index.json';(root/p.name).write_bytes(p.read_bytes());(root/'rules/unsafe-extern-block.md').write_text('changed')
            with patch.object(select,'SKILL',root),self.assertRaisesRegex(ValueError,'stale rule index'):
                select.select_rules(rule_ids=['unsafe-extern-block'])

class PlanningTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        (self.root/'Cargo.toml').write_text('[workspace]\nmembers=["crates/*"]\ndefault-members=["crates/app"]\n[workspace.package]\nedition="2021"\nrust-version="1.82"\n[workspace.dependencies]\ncore_alias={package="core",path="crates/core"}\n')
        for name in ['core','app','tool','free']:
            p=self.root/'crates'/name;p.mkdir(parents=True);(p/'src').mkdir();(p/'src/lib.rs').write_text('')
            (p/'Cargo.toml').write_text(f'[package]\nname="{name}"\nversion="0.1.0"\nedition.workspace=true\nrust-version.workspace=true\n')
        self.append('app','[dependencies]\ncore_alias={workspace=true}\n')
        self.append('tool','[build-dependencies]\napp={path="../app"}\n')
    def tearDown(self):self.temp.cleanup()
    def append(self,name,text):
        p=self.root/'crates'/name/'Cargo.toml';p.write_text(p.read_text()+text)
    def get(self,*paths):return inspect.inspect_project(self.root,list(paths) if paths else None)
    def test_reverse_dependency_closure(self):
        r=self.get('crates/core/src/lib.rs');self.assertEqual(r['affected_packages'],['app','core','tool']);self.assertEqual(r['scope'],'DECLARED_LOCAL_DEPENDENTS')
    def test_private_leaf_is_local(self):self.assertEqual(self.get('crates/free/src/lib.rs')['affected_packages'],['free'])
    def test_shared_changes_widen(self):
        for path in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml','Justfile','.github/workflows/ci.yml','build.rs']:
            with self.subTest(path=path):self.assertEqual(len(self.get(path)['affected_packages']),4)
    def test_unknown_and_empty_scope_widen(self):
        self.assertEqual(len(self.get()['affected_packages']),4);self.assertEqual(len(self.get('shared/generated.inc')['affected_packages']),4)
    def test_deleted_manifest_still_has_owner(self):self.assertEqual(self.get('crates/core/deleted.rs')['affected_packages'],['app','core','tool'])
    def test_target_dev_optional_edges_included(self):
        self.append('free','[target.\'cfg(unix)\'.dev-dependencies]\ncore={path="../core",optional=true}\n')
        self.assertEqual(len(self.get('crates/core/src/lib.rs')['affected_packages']),4)
    def test_unknown_path_dependency_widens(self):
        self.append('free','[dependencies]\nexternal={path="../../missing"}\n');r=self.get('crates/app/src/lib.rs');self.assertEqual(len(r['affected_packages']),4);self.assertTrue(r['issues'])
    def test_missing_member_widens(self):
        p=self.root/'Cargo.toml';p.write_text(p.read_text().replace('members=["crates/*"]','members=["crates/*","missing"]'));self.assertEqual(len(self.get('crates/app/src/lib.rs')['affected_packages']),4)
    def test_inherited_versions(self):
        p=self.get()['packages']['app'];self.assertEqual(p['edition'],'2021');self.assertEqual(p['rust_version'],'1.82')
    def test_fmt_recipe_not_accepted_as_check(self):
        (self.root/'Justfile').write_text('fmt:\n    cargo fmt --all\n');r=self.get('crates/free/src/lib.rs');self.assertEqual(r['proposed_checks'][0]['argv'],['cargo','fmt','--all','--','--check']);self.assertFalse(r['project_command_candidates'][0]['automatic_substitution'])
    def test_inspection_has_no_commands_or_mutations(self):
        before={str(p):p.read_bytes() for p in self.root.rglob('*') if p.is_file()};r=self.get();after={str(p):p.read_bytes() for p in self.root.rglob('*') if p.is_file()};self.assertEqual(before,after);self.assertEqual(r['executed_commands'],[])
    def test_command_effects_and_feature_limits_explicit(self):
        r=self.get('crates/app/src/lib.rs')
        for c in r['proposed_checks']:self.assertEqual(c['status'],'PROPOSED_NOT_RUN');self.assertNotIn('--all-features',c['argv']);self.assertIn('execute code',c['effects_note'])
    def test_escaping_paths_rejected(self):
        for path in ['../file','/tmp/file','C:\\windows\\x']:
            with self.subTest(path=path),self.assertRaises(ValueError):self.get(path)
    def test_windows_relative_path_normalized(self):self.assertEqual(self.get('crates\\free\\src\\lib.rs')['affected_packages'],['free'])
    def test_malformed_toml_is_error(self):
        (self.root/'Cargo.toml').write_text('invalid = [');
        with self.assertRaises(ValueError):self.get()
