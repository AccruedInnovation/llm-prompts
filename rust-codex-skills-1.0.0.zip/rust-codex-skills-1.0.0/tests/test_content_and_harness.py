import hashlib
import json
import re
import unittest
from pathlib import Path
from urllib.parse import unquote
from support import ROOT,load
harness=load('example_harness','skills/rust-skills/scripts/check_examples.py')
indexes=load('index_builder','maintenance/build_indexes.py')

class ContentTests(unittest.TestCase):
    def test_skill_entries_and_frontmatter(self):
        paths=list((ROOT/'skills').glob('*/SKILL.md'));self.assertEqual(len(paths),14)
        for p in paths:
            text=p.read_text(encoding='utf-8');front=text.split('---',2)[1];self.assertIn('name: '+p.parent.name,front)
            desc=next(x[13:] for x in front.splitlines() if x.startswith('description: '));self.assertTrue(json.loads(desc));self.assertLess(p.stat().st_size,9000)
    def test_evaluation_fixtures_exist(self):
        data=json.loads((ROOT/'evals/tasks.json').read_text());self.assertEqual(data['trial_status'],'NOT_RUN');self.assertEqual(len(data['tasks']),8)
        for task in data['tasks']:
            self.assertTrue(task['prompt']);self.assertTrue(task['required_outcomes']);self.assertTrue(task['forbidden_outcomes']);self.assertTrue((ROOT/'evals'/task['fixture']/'src/lib.rs').is_file())

    def test_no_runtime_coupling_in_entrypoints(self):
        for p in (ROOT/'skills').glob('*/SKILL.md'):
            text=p.read_text(encoding='utf-8');self.assertNotRegex(text,r'\b(?:BBK|Blueprint|bbk-rust)\b')
    def test_invocation_metadata(self):
        for p in (ROOT/'skills').glob('*/agents/openai.yaml'):
            text=p.read_text();name=p.parents[1].name;self.assertIn('$'+name,text);desc=json.loads(next(x.split(': ',1)[1] for x in text.splitlines() if x.strip().startswith('short_description: ')));self.assertTrue(25<=len(desc)<=64);self.assertIn('allow_implicit_invocation: '+('true' if name=='rust-workflow' else 'false'),text)
    def test_license_and_notice_preserved(self):
        for p in (ROOT/'skills').glob('*/SKILL.md'):self.assertTrue((p.parent/'LICENSE').is_file());self.assertTrue((p.parent/'NOTICE.md').is_file())
    def test_generated_outputs_current(self):
        for p,text in indexes.outputs().items():self.assertEqual(p.read_text(encoding='utf-8'),text,str(p))
    def test_one_review_contract(self):
        expected=(ROOT/'maintenance/common-review-contract.md').read_text(encoding='utf-8').strip();found=0
        for p in (ROOT/'skills').glob('*/SKILL.md'):
            m=re.search(r'<!-- BEGIN GENERATED REVIEW CONTRACT -->\n(.*?)\n<!-- END GENERATED REVIEW CONTRACT -->',p.read_text(encoding='utf-8'),re.S)
            if m:self.assertEqual(m[1],expected);found+=1
        self.assertGreaterEqual(found,6)
    def test_relative_markdown_links_in_skills_resolve(self):
        missing=[]
        for p in (ROOT/'skills').rglob('*.md'):
            text=p.read_text(encoding='utf-8');text=re.sub(r'(?ms)^```.*?^```[^\n]*','',text);text=re.sub(r'`[^`\n]*`','',text)
            for target in re.findall(r'(?<!!)\[[^\]\n]+\]\(([^\s)]+)\)',text):
                target=unquote(target.split('#',1)[0])
                if not target or re.match(r'^[a-z]+:',target):continue
                if not (p.parent/target).exists():missing.append(str(p.relative_to(ROOT))+': '+target)
        self.assertEqual(missing,[])
    def test_catalog_all_rules_and_fences(self):
        skill=ROOT/'skills/rust-skills';r=json.loads((skill/'rules-index.json').read_text());c=json.loads((skill/'examples/catalog.json').read_text());self.assertEqual(r['rule_count'],265);self.assertGreater(c['example_count'],1000)
        self.assertEqual(len(c['examples']),len({x['id'] for x in c['examples']}));self.assertEqual(len(harness.extract_examples(skill)),len([x for x in c['examples'] if x['classification']=='declared-check']))
    def test_deep_review_does_not_set_finding_quota(self):
        for p in (ROOT/'skills').glob('*/references/review-guide.md'):
            self.assertNotRegex(p.read_text(),r'HTMX|Alpine\.js|[3][–-][567] (?:tests|controls|bullets)')

class HarnessOracleTests(unittest.TestCase):
    def result(self,code=0,out='',err=''):return {'exit_code':code,'stdout':out,'stderr':err,'timed_out':False}
    def test_compile_rejection_requires_expected_diagnostic(self):
        self.assertEqual(harness.assess('compile-fail',self.result(1,err='E0425 missing value'),['E0277'])[0],'FAIL')
    def test_unrelated_error_cannot_mask_intended_error(self):
        self.assertEqual(harness.assess('compile-fail',self.result(1,err='E0277 E0425'),['E0277'])[0],'FAIL')
    def test_expected_rejection_not_runtime_success(self):
        self.assertEqual(harness.assess('compile-fail',self.result(1,err='E0277'),['E0277'])[0],'PASS')
        self.assertEqual(harness.assess('compile-fail',self.result(0),['E0277'])[0],'FAIL')
    def test_zero_tests_not_pass(self):
        self.assertEqual(harness.assess('run-pass',self.result(out='test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out'),[],1)[0],'FAIL')
    def test_partial_and_ignored_not_pass(self):
        for summary in ['1 passed; 0 failed; 1 ignored; 0 measured; 0 filtered out','1 passed; 0 failed; 0 ignored; 0 measured; 1 filtered out']:
            self.assertEqual(harness.assess('run-pass',self.result(out='test result: ok. '+summary),[],1)[0],'FAIL')
    def test_complete_test_count_passes(self):
        self.assertEqual(harness.assess('run-pass',self.result(out='test result: ok. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out'),[],2)[0],'PASS')
    def test_timeout_is_inconclusive(self):
        r=self.result();r['timed_out']=True;self.assertEqual(harness.assess('compile-pass',r,[])[0],'INCONCLUSIVE')
    def test_warning_requires_successful_compilation(self):
        self.assertEqual(harness.assess('compile-warning',self.result(1,err='warning: unsafe_op_in_unsafe_fn'),['unsafe_op_in_unsafe_fn'])[0],'FAIL')
        self.assertEqual(harness.assess('compile-warning',self.result(0,err='warning[E0133]: unsafe_op_in_unsafe_fn'),['unsafe_op_in_unsafe_fn'])[0],'PASS')
