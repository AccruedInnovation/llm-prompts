from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
ROOT=Path(__file__).resolve().parents[1]

def load(name, relative):
    spec=importlib.util.spec_from_file_location(name,ROOT/relative)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
