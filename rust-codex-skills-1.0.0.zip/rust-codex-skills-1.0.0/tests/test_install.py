import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch
from support import ROOT,load
installer=load('standalone_installer','install.py')

class InstallTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.base=Path(self.temp.name);self.dest=self.base/'user/.agents/skills';self.names=['rust-workflow','rust-skills']
    def tearDown(self):self.temp.cleanup()
    def test_dry_run_no_directories(self):
        r=installer.install(ROOT,self.dest,self.names,dry_run=True);self.assertEqual(r['status'],'DRY_RUN');self.assertFalse((self.base/'user').exists())
    def test_installs_all_exact_bytes(self):
        r=installer.install(ROOT,self.dest);m=installer.load_manifest(ROOT);self.assertEqual(len(r['skills']),14)
        for name in r['skills']:self.assertEqual(installer.files_in(self.dest/name),m['skills'][name]['files'])
    def test_selective_install_standalone(self):
        installer.install(ROOT,self.dest,['rust-workflow']);self.assertEqual([p.name for p in self.dest.iterdir()],['rust-workflow']);self.assertTrue((self.dest/'rust-workflow/scripts/inspect_project.py').is_file())
    def test_conflict_leaves_everything_unchanged(self):
        installer.install(ROOT,self.dest,['rust-workflow']);(self.dest/'rust-workflow/custom.txt').write_text('user content')
        before=installer.files_in(self.dest)
        with self.assertRaises(ValueError):installer.install(ROOT,self.dest,self.names)
        self.assertEqual(installer.files_in(self.dest),before);self.assertFalse((self.dest/'rust-skills').exists())
    def test_replace_keeps_backup_without_merging(self):
        installer.install(ROOT,self.dest,['rust-workflow']);(self.dest/'rust-workflow/custom.txt').write_text('user content')
        r=installer.install(ROOT,self.dest,self.names,replace=True);backup=Path(r['backup']);self.assertEqual((backup/'rust-workflow/custom.txt').read_text(),'user content');self.assertFalse((self.dest/'rust-workflow/custom.txt').exists());self.assertFalse(backup.is_relative_to(self.dest))
    def test_unknown_name_rejected_without_effects(self):
        with self.assertRaises(ValueError):installer.install(ROOT,self.dest,['../other'])
        self.assertFalse(self.dest.exists())
    def test_tampered_source_rejected(self):
        source=self.base/'source';source.mkdir();shutil.copyfile(ROOT/'skills-manifest.json',source/'skills-manifest.json');shutil.copytree(ROOT/'skills/rust-workflow',source/'skills/rust-workflow');(source/'skills/rust-workflow/SKILL.md').write_text('tampered')
        with self.assertRaisesRegex(ValueError,'integrity'):installer.install(source,self.dest,['rust-workflow'])
        self.assertFalse(self.dest.exists())
    def test_symlink_target_rejected(self):
        real=self.base/'real';real.mkdir();self.dest.mkdir(parents=True);(self.dest/'rust-workflow').symlink_to(real,target_is_directory=True)
        with self.assertRaises(ValueError):installer.install(ROOT,self.dest,['rust-workflow'],replace=True)
    def test_symlink_parent_rejected(self):
        real=self.base/'real';real.mkdir();link=self.base/'link';link.symlink_to(real,target_is_directory=True)
        with self.assertRaises(ValueError):installer.install(ROOT,link/'skills',['rust-workflow'])
    def test_existing_lock_preserved(self):
        self.dest.mkdir(parents=True);lock=self.dest/'.rust-skills-install.lock';lock.write_text('other installer')
        with self.assertRaises(OSError):installer.install(ROOT,self.dest,['rust-workflow'])
        self.assertEqual(lock.read_text(),'other installer');self.assertFalse((self.dest/'rust-workflow').exists())
    def test_rollback_after_second_install_rename_fails(self):
        installer.install(ROOT,self.dest,self.names);(self.dest/'rust-workflow/custom.txt').write_text('saved')
        before=installer.files_in(self.dest);original=Path.rename
        def fail(source,target):
            if source.name=='rust-workflow' and source.parent.name.startswith('.rust-skills-stage-'):raise OSError('injected rename failure')
            return original(source,target)
        with patch.object(Path,'rename',fail),self.assertRaisesRegex(OSError,'injected'):
            installer.install(ROOT,self.dest,self.names,replace=True)
        self.assertEqual(installer.files_in(self.dest),before)
    def test_malformed_manifest_path_rejected(self):
        source=self.base/'source';source.mkdir();m=installer.load_manifest(ROOT);m['skills']['rust-workflow']['files']['../escape']='0'*64;(source/'skills-manifest.json').write_text(json.dumps(m))
        with self.assertRaises(ValueError):installer.install(source,self.dest,['rust-workflow'])
