# Changes in 1.0.0

Source: `bbk-profile-rust-0.1.0-alpha.3(2).zip`; original skill names remain except
`bbk-rust` becomes `rust-workflow`. This is a standalone derivative, not the next BBK
profile release. The source ZIP remains unchanged. The original review is the task
basis; targeted corrections below are deliberate revisions, not source quotations.

| Review finding | Change | Evidence path |
| --- | --- | --- |
| RUST-01: unsound safe pointer wrappers | Slice-based safe boundaries; raw API remains unsafe with full caller obligations; real bounded C copy and empty/mismatch handling. | Named examples in `unsafe-minimize-scope` and `unsafe-extern-block`; core compiler/runtime suite. |
| RUST-02: Send/Sync and lint errors | Correct `Cell<T>: Send` versus `!Sync`, avoid gratuitous unsafe impls, assert Rust 2024 warning and explicit lint denial separately. Correct unsafe attribute and extern syntax guidance. | Compile-pass, compile-fail, and warning cases in the core suite. |
| RUST-03: lock guidance | Replace unconditional no-lock-across-await advice with state and cancellation analysis. Add revision-bound commit, all-mutation revision updates, stale/ABA/exhaustion checks, and intentional Tokio serialization. | Pure state runtime tests pass; Tokio interleaving suite supplied, not run without crates. |
| RUST-04: cancellation | Explain branch ownership, queue position, detachment and abort. Handle partial frames, EOF, closed channels, and watch initial/latest/terminal states. Correct cloning advice. | Native Arc/Rc checks; Tokio terminal-state tests supplied. |
| RUST-05: summary drift | Remove the large competing quick reference; generate category pages and indexed summaries from each rule's first blockquote and explicit metadata. Keep Miri and optimization conditional. | Generator drift tests and selective entry points. |
| RUST-06: whole-skill selection | Add a bounded rule selector with topic/query/explicit IDs, minimum-version and edition checks, reasons, exclusions, unknowns and truncation. Do not infer compatibility from prose keywords. | Selection tests for relevant IDs, budget, stale hash, unknowns, incompatible versions and Miri. |
| RUST-07: command and impact planning | Replace BBK gate code with an optional read-only Cargo manifest inspector. Track local reverse dependencies, widen shared/unknown changes, leave recipe commands unqualified, preserve format check versus write. | Static workspace/recipe fixtures and no-mutation assertions. |
| RUST-08: reviewer precision | Short entry points and retained deep references; one generated finding contract. Remove irrelevant UI preferences, fixed quotas, automatic severity and local-use-only visibility recommendations. | Metadata, link, contract and content regression checks. |
| RUST-09: content versus agent qualification | Inventory every Rust fence; run only explicit expectation-bound examples, including true downstream crates. Add a fixed eight-task comparison kit and keep trials separate from helper tests. | Actual example results; agent trial status remains NOT_RUN. |

## Related corrections

`api-non-exhaustive` now distinguishes new extensible APIs from breaking changes to
existing public types and tests from a separate consumer crate. `serde-deny-unknown-fields`
now distinguishes ignored extra keys, missing required keys and explicit defaults.
`async-clone-before-await`, `async-select-racing`, and `async-watch-latest` no longer repeat
the related incorrect ownership or closure claims. These extend the targeted review,
not an assertion that the rest of the corpus received an exhaustive semantic audit.

A narrow correction to `doc-intra-links` also removes the claim that Rustdoc automatically
rewrites links when source items are renamed. Its illustrative fences remain unqualified.

Related checks also correct the mutable-static lint distinction in `conc-thread-local` and
`const-vs-static`, including thread-local versus task-local state, destructor caveats,
constant storage and promoted references. Compiler-only probes check both editions and
configurable lint levels without executing invalid access.

## Packaging and execution changes

All 14 entry points use ordinary Codex skill folders and `agents/openai.yaml`. Only the
workflow is eligible for implicit invocation. Helpers need Python 3.11+ but no installed
BBK, YAML package, registry service, network or compiled language package. The optional
installer validates bytes, refuses overwrite, stages copies, retains replacement backups
and attempts rollback after a failed write. The installation path accepts real directories,
not links/reparse points. Tests cover this conservative behavior on Linux; Windows support
is intended but not established through a native Windows run.

The original 265 rule IDs remain. Sixteen rule bodies received targeted changes;
249 remain inherited. Existing licence texts and known provenance are retained. No
full-copy compiler qualification, independent model review, Miri result, or productivity
improvement is asserted.
