# Agent comparison kit — not run

This is a fixed eight-task set for comparing no skills, the supplied original Rust
rule skill, and the revised rule skill. The trial is not an automated score for prompt
quality. No model trial or claimed productivity improvement accompanies this bundle.

`tasks.json` owns prompts, expected outcomes, prohibited changes, and task mode.
`fixtures/` contains the starting Cargo projects, including correct counterexamples.
Treat the expected-outcome fields as evaluator material; give the agent only the
selected task prompt and fixture. Never execute invalid-pointer examples. The async
fixtures need their declared Tokio dependency; inability to resolve it limits the
execution claim, not the source-level review.

## Comparable runs

Use separate fresh sessions and fresh fixture copies. Hold model/version, reasoning
settings, repository, permissions, tools, dependency availability, context budget,
and wall-time budget constant. Do not let global or parent-directory skills leak into
the no-skill condition. Record the actual loaded skill paths and hashes. Randomize
condition order and repeat enough times to expose variation; do not claim statistical
significance from a few hand-picked successes.

Use three conditions:

- **none:** only the task and fixture; no custom Rust skill.
- **original:** the original `rust-skills` folder from the supplied archive, unchanged;
  explicitly select that skill. Do not install the original BBK profile or treat its
  orchestration as required for this knowledge comparison.
- **revised:** this bundle's `rust-skills` folder, explicitly selected in the same way.

This isolates the rule-reference revision, not the full 14-skill workflow. Run a
separate, labeled experiment for `rust-workflow` or focused reviewers. Do not attribute
a change in model, framework, loaded reviewer count, or tools to the rule text alone.
The original archive identity is recorded in `../maintenance/source-inventory.json`;
it is a required external input for the original condition, not silently reconstructed
from memory. The revised bundle does not reinstall the known-defective original.

## Score the actual outcome

For each task and run, retain the exact initial and final trees, transcript, tool
commands, test discovery and counts, model configuration, loaded context, runtime,
tokens when available, human interventions, and outcome evidence. A review task must
not edit its subject. An implementation task must satisfy the stated behavior through
a separate evaluator-owned check. Keep required expectations out of the agent's
editable workspace and do not modify them to fit its result.

Use `results-template.json` for one run. Score each required and forbidden outcome with
PASS / FAIL / NOT_ASSESSED and a supporting reference. Separate serious missed defects,
introduced defects, false positives, scope changes, dependency churn, interventions,
and time/context cost. Allow a correct empty review. Report task-level results and
uncertainty rather than collapsing soundness, cost, and prose quality into one number.
All checked rows need real evidence. Retain failed and interrupted trials.

The package regression suite checks that this kit contains eight prompts and real
fixtures; that structural check is not an agent trial. Core fixture compilation checks
also cannot prove that an agent will give the right answer.
