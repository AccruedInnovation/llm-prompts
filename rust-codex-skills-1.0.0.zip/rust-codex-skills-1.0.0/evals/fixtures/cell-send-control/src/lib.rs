use std::cell::Cell;
pub struct Counter { value:Cell<u32> }
impl Counter {pub fn new()->Self{Self{value:Cell::new(0)}}pub fn increment(&self){self.value.set(self.value.get().wrapping_add(1));}}
pub fn move_to_thread(counter:Counter) {std::thread::spawn(move || counter.increment()).join().unwrap();}
