pub struct Config {pub retries:u32}
impl Config {pub fn new(retries:u32)->Self{Self{retries}}}
