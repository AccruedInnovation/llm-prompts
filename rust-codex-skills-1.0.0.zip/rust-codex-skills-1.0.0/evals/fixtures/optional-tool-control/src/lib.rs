pub fn copy_into(dst:&mut [u8],src:&[u8])->Result<(), &'static str>{
 if dst.len()!=src.len(){return Err("length mismatch");}dst.copy_from_slice(src);Ok(())
}
