pub fn sum_at(ptr:*const i32,len:usize,index:usize)->i32 {
    assert!(index<len);
    // SAFETY: index is inside len.
    (unsafe {*ptr.add(index)})+1
}
