pub struct Cache {pub id:u64,pub value:Option<Vec<u8>>}
impl Cache {
 pub fn begin_fetch(&self)->u64{self.id}
 pub fn retarget(&mut self,id:u64){self.id=id;self.value=None;}
 pub fn commit(&mut self,_fetched_id:u64,value:Vec<u8>){self.value=Some(value);}
}
