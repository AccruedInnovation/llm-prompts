pub fn increment(value:u32)->Option<u32>{Some(value.wrapping_add(1))}
