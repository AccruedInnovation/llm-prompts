# Sources, provenance, and rights

## Supplied sources

The controlling request asks for the prior review's updates in generic skills installable
in Codex, explicitly not a BBK language package. This bundle derives from the supplied
`bbk-profile-rust-0.1.0-alpha.3(2).zip`. Its SHA-256 is
`000cd01298b033a65eacd640d2c1fe20c7828540bddd4fcd7f7f44cda76eecc7`.
`maintenance/source-inventory.json` records the original file hashes. `maintenance/changed-rules.json`
records the targeted rule revisions. This bundle does not claim to update the original
profile, its Python package, or its 36-test baseline suite.

The supplied `rust-skills-review-r1/review.md` identified RUST-01 through RUST-09. The
change log maps those findings to actual changes. The task permits these corrections;
rewritten examples and new tooling are authored changes, not assertions that the old
source already said the same thing.

The source profile supplies an MIT licence credited to the Blueprint Bootstrap Kit
contributors. Its rule metadata attributes the Rust rule collection to leonardomso and
states MIT. The focused reviewer prompts are marked user-supplied in the source. We retain
the available licence and attribution material in the root and each installable skill.
This record does not invent an upstream commit, publication date, signature, or extra
third-party licence rights. See each skill's NOTICE.md. This bundle is not an OpenAI
product or a claim of OpenAI endorsement.

## Official references checked on 2026-09-08

| Reference | Use in this revision |
| --- | --- |
| [Codex skills](https://developers.openai.com/codex/skills) | Standard SKILL.md folders, references/scripts, `.agents/skills`, explicit selection and optional openai.yaml invocation metadata. The page currently redirects to OpenAI's ChatGPT Learn skill documentation. |
| [Pointer read](https://doc.rust-lang.org/std/ptr/fn.read.html) | Pointer validity, alignment and initialized values require more than an index check. |
| [Cell](https://doc.rust-lang.org/std/cell/struct.Cell.html) | Send when T is Send; not Sync. |
| [Rust 2024 unsafe operation lint](https://doc.rust-lang.org/edition-guide/rust-2024/unsafe-op-in-unsafe-fn.html) | Warning by default; explicit lint policy can deny it. |
| [Unsafe extern](https://doc.rust-lang.org/edition-guide/rust-2024/unsafe-extern.html) | Rust 1.82 syntax and Rust 2024 requirement. |
| [Unsafe attributes](https://doc.rust-lang.org/edition-guide/rust-2024/unsafe-attributes.html) | Attribute safety and edition distinction. |
| [Tokio Mutex](https://docs.rs/tokio/latest/tokio/sync/struct.Mutex.html) | Deliberate guards across await and queue behavior. |
| [Tokio select](https://docs.rs/tokio/latest/tokio/macro.select.html) | Cancellation, losing futures, enabled branches, fairness and channel closure. |
| [Tokio JoinHandle](https://docs.rs/tokio/latest/tokio/task/struct.JoinHandle.html) | Detachment, retained handles and limits of abort. |
| [Tokio watch](https://docs.rs/tokio/latest/tokio/sync/watch/index.html) | Latest-value semantics, seen state and closure. |
| [Mutable static references](https://doc.rust-lang.org/edition-guide/rust-2024/static-mut-references.html), [LocalKey](https://doc.rust-lang.org/std/thread/struct.LocalKey.html), and [constant items](https://doc.rust-lang.org/reference/items/constant-items.html) | Lint levels, thread-local lifetime limits, and storage versus value semantics. |
| [Cargo SemVer](https://doc.rust-lang.org/cargo/reference/semver.html) | Downstream compatibility; local absence of callers does not justify removal. |
| [Rust 1.40 release](https://blog.rust-lang.org/2019/12/19/Rust-1.40.0/) | non_exhaustive stabilization constraint. |
| [Serde container attributes](https://serde.rs/container-attrs.html) and [field attributes](https://serde.rs/field-attrs.html) | Unknown fields, required fields, defaults and flatten limitations. |

Rule-specific references remain beside the rules. Research review is not a runtime test.
The optional Tokio/Serde suite pins come from the supplied ADK-Rust 2.1.0 Cargo.lock;
no claim is made that those dependencies were present or resolved locally.

## Execution provenance

Core Rust checks used the supplied Rust 1.97.1 Linux x86_64 toolchain. Component hashes
matched its supplied channel manifest. That proves consistency with those inputs, not
external authentication. No compiler binaries, dependency caches, account credentials,
or toolchain archives ship in this skills bundle. Toolchain details and command results
are in the validation evidence. No publishing, remote installation or live Codex session
occurred. No prior-source test result substitutes for this bundle's tests.
