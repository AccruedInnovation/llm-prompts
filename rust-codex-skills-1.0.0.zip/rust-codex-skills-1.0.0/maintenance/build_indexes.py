#!/usr/bin/env python3
"""Generate rule summaries and example inventory from canonical text and metadata."""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKILL = ROOT / "skills/rust-skills"


def rust_blocks(text: str):
    # Inventory fences, not a compiler: unmarked inherited blocks stay illustrative.
    expression = re.compile(r"(?P<marker><!-- example: (?P<id>[a-z0-9-]+) -->\s*)?^```(?P<info>rust[^\n]*)\n(?P<code>.*?)^```\s*$", re.M | re.S)
    for number, match in enumerate(expression.finditer(text), 1):
        yield number, match.group("id"), match.group("info"), match.group("code"), text[:match.start()].count("\n") + 1


def outputs() -> dict[Path, str]:
    meta = json.loads((SKILL / "references/rule-metadata.json").read_text())
    checks_path = SKILL / "examples/checks.json"
    checks = json.loads(checks_path.read_text())["checks"] if checks_path.exists() else []
    by_example: dict[str, list[str]] = {}
    for check in checks:
        for example in check.get("examples", []):
            by_example.setdefault(example, []).append(check["id"])
        for example in check.get("library_examples", []):
            by_example.setdefault(example, []).append(check["id"])
    rules = []
    catalog = []
    named = set()
    for path in sorted((SKILL / "rules").glob("*.md")):
        text = path.read_text()
        id_ = path.stem
        if id_ not in meta["rules"]:
            raise ValueError(f"missing rule metadata: {id_}")
        summary = next((line[2:].strip() for line in text.splitlines() if line.startswith("> ")), None)
        if not summary:
            raise ValueError(f"missing canonical summary: {id_}")
        record = {"id": id_, "summary": summary, "path": f"rules/{id_}.md", "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "bytes": path.stat().st_size, **meta["rules"][id_]}
        rules.append(record)
        for number, marker, info, code, line in rust_blocks(text):
            example_id = marker or f"{id_}-block-{number:02d}"
            if example_id in named:
                raise ValueError(f"duplicate example: {example_id}")
            named.add(example_id)
            catalog.append({"id": example_id, "rule": id_, "path": f"rules/{id_}.md", "line": line, "info": info, "sha256": hashlib.sha256(code.encode()).hexdigest(), "classification": "declared-check" if example_id in by_example else "illustrative-unqualified", "checks": sorted(by_example.get(example_id, []))})
    extra = set(meta["rules"]) - {r["id"] for r in rules}
    if extra:
        raise ValueError(f"metadata for missing rules: {sorted(extra)}")
    if set(by_example) - named:
        raise ValueError(f"checks refer to missing examples: {set(by_example)-named}")
    generated = {}
    generated[SKILL / "rules-index.json"] = json.dumps({"schema": "rust-rule-index.v1", "version": "1.0.0", "rule_count": len(rules), "source": "rule blockquotes and references/rule-metadata.json", "rules": rules}, indent=2) + "\n"
    generated[SKILL / "examples/catalog.json"] = json.dumps({"schema": "rust-example-catalog.v1", "example_count": len(catalog), "declared_check_count": len(checks), "note": "A declared check is an expectation, not evidence it ran. See the actual result record. Unlisted fences are not independent runnable fixtures.", "examples": catalog}, indent=2) + "\n"
    categories = meta["categories"]
    index = "# Rust rule categories\n\nGenerated from canonical rule text and metadata. Read only relevant categories.\n\n| Category | Applicability | Rules |\n| --- | --- | --- |\n"
    for prefix, definition in categories.items():
        entries = [r for r in rules if r["category"] == prefix]
        index += f"| [{definition['name']}](categories/{prefix}.md) | {definition['applicability']} | {len(entries)} |\n"
        body = f"# {definition['name']}\n\n{definition['applicability']}\n\nGenerated view; change the rule's first blockquote or its metadata, not this file.\nUnknown compatibility is not established. Read the rule and its constraints before use.\n\n"
        for r in entries:
            body += f"- [{r['id']}](../../{r['path']}) — {r['summary']}\n"
        generated[SKILL / f"references/categories/{prefix}.md"] = body
    generated[SKILL / "references/categories.md"] = index
    return generated


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--check", action="store_true")
    args = p.parse_args()
    drift = []
    for path, expected in outputs().items():
        if args.check:
            if not path.is_file() or path.read_text() != expected:
                drift.append(str(path.relative_to(ROOT)))
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(expected)
    if drift:
        print(json.dumps({"status": "FAIL", "drift": drift}, indent=2))
        return 1
    print(json.dumps({"status": "PASS", "operation": "check" if args.check else "generate"}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
