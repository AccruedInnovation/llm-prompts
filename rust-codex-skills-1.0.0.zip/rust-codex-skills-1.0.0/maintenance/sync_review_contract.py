#!/usr/bin/env python3
"""Keep the small review contract identical in independently installable skills."""
import argparse
import re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PATTERN=re.compile(r'<!-- BEGIN GENERATED REVIEW CONTRACT -->.*?<!-- END GENERATED REVIEW CONTRACT -->',re.S)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--check',action='store_true');a=p.parse_args()
    source=(ROOT/'maintenance/common-review-contract.md').read_text(encoding='utf-8').strip()
    expected='<!-- BEGIN GENERATED REVIEW CONTRACT -->\n'+source+'\n<!-- END GENERATED REVIEW CONTRACT -->'
    drift=[]
    for path in sorted((ROOT/'skills').glob('*/SKILL.md')):
        text=path.read_text(encoding='utf-8')
        if PATTERN.search(text):
            updated=PATTERN.sub(lambda _:expected,text)
            if updated!=text:
                drift.append(path.parent.name)
                if not a.check:path.write_text(updated,encoding='utf-8')
    if drift and a.check:print('FAIL: '+', '.join(drift));return 1
    print('PASS: review contract '+('checked' if a.check else 'generated'));return 0
if __name__=='__main__':raise SystemExit(main())
