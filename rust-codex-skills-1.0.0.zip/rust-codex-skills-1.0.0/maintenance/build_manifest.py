#!/usr/bin/env python3
"""Generate an acyclic inventory of installable skill bytes, not this manifest itself."""
import argparse
import hashlib
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def expected():
    skills={}
    for path in sorted((ROOT/'skills').iterdir()):
        if not path.is_dir():continue
        files={}
        for f in sorted(path.rglob('*')):
            if '__pycache__' in f.parts or f.suffix=='.pyc':
                raise ValueError(f'remove execution cache before packaging: {f}')
            if f.is_symlink():raise ValueError(f'no symlinks in delivery: {f}')
            if f.is_file():files[f.relative_to(path).as_posix()]=hashlib.sha256(f.read_bytes()).hexdigest()
        skills[path.name]={'files':files}
    return json.dumps({'schema':'standalone-rust-skills.v1','version':'1.0.0','skills':skills},indent=2)+'\n'

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--check',action='store_true');a=p.parse_args()
    text=expected();out=ROOT/'skills-manifest.json'
    if a.check:
        if not out.is_file() or out.read_text(encoding='utf-8')!=text:
            print('FAIL: skill manifest drift');return 1
    else:out.write_text(text,encoding='utf-8')
    print('PASS: skill inventory '+('checked' if a.check else 'generated'));return 0
if __name__=='__main__':raise SystemExit(main())
