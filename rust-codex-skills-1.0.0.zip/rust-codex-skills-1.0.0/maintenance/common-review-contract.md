## Findings and evidence

Review only the assigned subject. State the revision or changed files, inspected scope,
assumptions, and important omissions once. A review does not grant permission to edit,
change a public contract, add a dependency, publish, or deploy.

For each supported finding, give the exact path and symbol; the governing requirement
or invariant; a concrete input, failure trace, or interleaving; evidence and its limits;
consequence; the smallest permitted fix; and a regression check. Mark compatibility
impact and unresolved assumptions. Use the project's report format when it captures
these facts; do not create another mandatory report.

Classify evidence as **reproduced defect**, **source-proved defect**, **conditional
hypothesis**, **assurance gap**, or **optional improvement**. Source-proved means the
code and stated preconditions establish the failure without an untested material
assumption. Compilation alone does not prove soundness, behavior, or installed use.
Missing tests, comments, or optional tools do not by themselves prove a product defect.
Derive severity from consequence, reachability, exposure, and the actual obligation,
not the topic name. Keep uncertainty separate from severity.

Return **No supported findings** when appropriate. Recommend no fixed number of tests,
controls, refactors, or reviewers. Preserve correct counterexamples and explain any
important rebuttal. Do not call self-review independent review or treat an unrun check
as passing. Keep existing acceptance conditions intact; report a conflict rather than
quietly weakening them.
