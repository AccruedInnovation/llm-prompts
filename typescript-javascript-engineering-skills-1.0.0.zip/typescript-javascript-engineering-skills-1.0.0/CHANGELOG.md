# Changelog

## 1.0.0 — 2026-09-08

First standalone edition of the supplied TypeScript/JavaScript skills. This is a content revision and local-skill conversion, not a successor BBK profile release. The source is `bbk-profile-typescript-javascript-0.1.0-alpha.3(2).zip`.

### What remains

Keep the thirteen concern areas, first-class checked JavaScript, framework/toolchain neutrality, proportionate strictness changes, public type/runtime/package distinctions, actual consumer evidence, and restraint around needless abstractions. Keep the nine original reference themes: strictness, type-driven development, runtime/module model, compatibility, testing evidence, performance, implementation structure, execution slicing, and support limits.

### Accepted review changes

| Review area | Applied content change | Primary location |
| --- | --- | --- |
| Worked engineering methods | Add failure → bounded repair → check → valid-countercase methods. Put prevention advice in the implementation skill, not only reviews. | Development and all specialist worked-case guides. |
| Checker guarantees | Distinguish JSDoc from enabled checking, inspect effective strict flags and selected files, and show mutation invalidating narrowing without assertions. Cover shallow readonly and false predicates. | Preflight, development, type review and strictness reference. |
| False test passes | Isolate negative type fixtures, inspect diagnostic code/location, add valid neighbors and a widening control, confirm test discovery/selection/completion, and assert forbidden effects on rejection. | Test strategy and its worked cases. |
| Async ownership | Distinguish observing a promise from voiding it. Show non-awaited callbacks, bounded finite work, queued-memory limits, cooperative cancellation, pre-abort, listener removal on success, joined started tasks, undefined rejection, and cleanup-error policy. | Development and async/resource review. |
| Runtime data and trust | Separate shape/domain validation from authority and current state. Add configuration grammar, JSON loss, raw duplicate-key tests, revision/tenant guards and explicit concurrency limits. | Runtime-data and security review. |
| Package consumers | Add a specifier-to-runtime/declaration trace, exports/typesVersions example, packed clean consumer, missing-declaration bad artifact, alias diagnosis, dual-identity reasoning, and version-bound native TypeScript/ESM guidance. | API/module/package review. |
| Browser workflows | Add stale-success/error/disposal cases even when abort is ignored, guarded optimistic rollback, conditional React cleanup and request-local SSR, accessible dialog testing, and old-page/new-deployment compatibility. | Browser/UI review. |
| Review discipline | Require the strongest reasonable rebuttal, proportionate evidence and clear limits. Give a claim one owner and the smallest sufficient set of checks, not necessarily one test. Deepen performance diagnosis and lightly refine operational, structural and reproduction procedures. | Comprehensive review, shared policy references and remaining specialists. |

Examples keep their important limits: a finite concurrency cap is not a streaming memory bound; cancellation does not roll back effects; a sync in-memory guard is not a database transaction; a type pass is not a runtime pass; and TSX syntax checking is not React or browser qualification.

### Standalone conversion

Rename the old `bbk-tsjs` entry to `tsjs-project-preflight`. Retain all twelve other skill names. Remove runtime/profile bindings and required cross-package references from operational instructions. Each folder has minimal name/description frontmatter, local references and its own copy of the original license. Other skill names are optional navigation only.

The root installer copies selected folders without overwriting and supports an alternate destination. It does not change Codex settings or remove prior installations. Root validation scripts remain outside installed skill folders. There are no mandatory manifests, source hashes, self-sealing files, generated dashboards, or automatic dependency installs. Use existing revision and changed-file information during work; create a delivery checksum only at the end when useful.

### Verification added

Six temporary-directory installer tests and 35 Node test cases check 23 marked snippets taken from the actual Markdown. The tests cover expected compiler failures, runtime failures and repairs, valid alternatives, cancellation/cleanup, guard discrimination, and actual good/bad tarball consumers. Twelve specialist guides also provide analytic and manual methods outside those executable cases.

These checks establish only their named properties. They do not measure agent performance, validate an actual Codex session, or execute browser/framework and alternate-runtime integration. See [VALIDATION.md](VALIDATION.md).
