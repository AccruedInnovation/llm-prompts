#!/usr/bin/env python3
"""Run local checks without installing or downloading dependencies."""
from __future__ import annotations
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys
ROOT = Path(__file__).resolve().parents[1]
def find_module(tool: str, filename: str, package: str) -> Path | None:
    local = ROOT/'node_modules'/package/filename
    if local.is_file(): return local
    found = shutil.which(tool)
    if found:
        p = Path(found).resolve()
        candidates = [p.parent.parent/filename, p.parent/'node_modules'/package/filename]
        if package == 'npm' and p.name.endswith('.js'): candidates.insert(0,p)
        for c in candidates:
            if c.is_file(): return c
    return None

def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--typescript',type=Path,help='Installed TypeScript lib/typescript.js, if not auto-detected.')
    parser.add_argument('--npm-cli',type=Path,help='Installed npm bin/npm-cli.js, if not auto-detected.')
    args=parser.parse_args()
    ts=args.typescript or find_module('tsc','lib/typescript.js','typescript')
    npm=args.npm_cli or find_module('npm','bin/npm-cli.js','npm'); node=shutil.which('node')
    if not node or not ts or not npm or not ts.is_file() or not npm.is_file():
        print('UNAVAILABLE: Node.js, TypeScript or npm not found. No dependencies were installed. '
              'Pass --typescript and --npm-cli for existing installations. Structural checks run separately.',file=sys.stderr);return 2
    env=dict(os.environ,TYPESCRIPT_MODULE=str(ts.resolve()),NPM_CLI_JS=str(npm.resolve()),PYTHONDONTWRITEBYTECODE='1')
    commands=[[sys.executable,str(ROOT/'tools/check_bundle.py')],
              [sys.executable,str(ROOT/'tests/test_install.py'),'-v'],
              [node,'--test',str(ROOT/'tests/examples.test.mjs')]]
    for command in commands:
        print('\nRUN:', ' '.join(command),flush=True)
        try: result=subprocess.run(command,cwd=ROOT,env=env,timeout=120)
        except subprocess.TimeoutExpired:
            print('INCONCLUSIVE: timed out; not a pass.',file=sys.stderr);return 1
        if result.returncode != 0: return 1
    return 0
if __name__=='__main__': raise SystemExit(main())
