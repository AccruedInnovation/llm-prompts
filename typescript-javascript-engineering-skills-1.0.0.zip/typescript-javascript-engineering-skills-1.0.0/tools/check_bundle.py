#!/usr/bin/env python3
"""Read-only checks for this bundle's constrained SKILL.md format and local references."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import re
import sys
from urllib.parse import unquote, urlsplit

EXPECTED = {
    'tsjs-project-preflight', 'tsjs-development-practices', 'comprehensive-analysis-tsjs',
    'tsjs-api-module-package-review', 'tsjs-async-resource-failure-review',
    'tsjs-browser-ui-review', 'tsjs-evidence-reproducer', 'tsjs-implementation-structure-review',
    'tsjs-operational-release-review', 'tsjs-runtime-data-contract-review',
    'tsjs-security-supply-chain-review', 'tsjs-test-strategy-review', 'tsjs-type-contract-review',
}

def check(root: Path) -> dict:
    root = root.resolve()
    errors = []
    skills = sorted((root / 'skills').glob('*/SKILL.md'))
    actual = {p.parent.name for p in skills}
    if actual != EXPECTED:
        errors.append(f'Skill set differs: missing={sorted(EXPECTED-actual)}, extra={sorted(actual-EXPECTED)}')
    names = set()
    local_links = 0
    examples = set()
    reference_count = 0
    for skill in skills:
        content = skill.read_text(encoding='utf-8')
        match = re.match(r'\A---\nname: ([a-z0-9-]+)\ndescription: ([^\n]+)\n---\n', content)
        if not match:
            errors.append(f'Invalid two-field frontmatter: {skill.relative_to(root)}')
            continue
        name, description = match.groups()
        if name != skill.parent.name or name in names or len(name) > 64 or '--' in name:
            errors.append(f'Invalid/duplicate name: {name}')
        if not description.strip() or len(description) > 1024:
            errors.append(f'Invalid description: {name}')
        names.add(name)
        if not (skill.parent / 'LICENSE').is_file():
            errors.append(f'Missing license: {name}')
        reference_count += len(list((skill.parent/'references').glob('*.md')))
        for p in skill.parent.rglob('*'):
            if p.is_symlink(): errors.append(f'Unexpected symlink: {p.relative_to(root)}')
            if not p.is_file() or p.suffix != '.md': continue
            text = p.read_text(encoding='utf-8')
            if '\x00' in text: errors.append(f'NUL byte: {p.relative_to(root)}')
            if len(re.findall(r'^```', text, re.M)) % 2:
                errors.append(f'Unbalanced code fence: {p.relative_to(root)}')
            if re.search(r'\b(?:BBK|Blueprint|OMP)\b|alpha\.4|profile-lock|bbk[_-]', text, re.I):
                errors.append(f'Framework-specific instruction: {p.relative_to(root)}')
            for marker in re.findall(r'<!-- example: ([a-z0-9-]+) -->', text):
                if marker in examples: errors.append(f'Duplicate example marker: {marker}')
                examples.add(marker)
            for target in re.findall(r'\[[^\]\n]+\]\(([^)\s]+)\)', text):
                parts = urlsplit(target)
                if parts.scheme or target.startswith('#'): continue
                resolved = (p.parent / unquote(parts.path)).resolve()
                local_links += 1
                if not resolved.is_relative_to(skill.parent.resolve()):
                    errors.append(f'Cross-skill/external local dependency: {p.relative_to(root)} -> {target}')
                elif not resolved.is_file():
                    errors.append(f'Broken local link: {p.relative_to(root)} -> {target}')
    # Check root/support documentation paths too (without asserting their prose semantics).
    for p in root.rglob('*.md'):
        if p.is_relative_to(root/'skills'): continue
        text = p.read_text(encoding='utf-8')
        for target in re.findall(r'\[[^\]\n]+\]\(([^)\s]+)\)', text):
            parts = urlsplit(target)
            if parts.scheme or target.startswith('#'): continue
            resolved = (p.parent / unquote(parts.path)).resolve()
            local_links += 1
            if not resolved.is_relative_to(root) or not resolved.exists():
                errors.append(f'Broken/support external link: {p.relative_to(root)} -> {target}')
    return {'status': 'PASS' if not errors else 'FAIL', 'skills': len(skills),
            'reference_files': reference_count, 'local_links_checked': local_links,
            'marked_examples': len(examples), 'errors': errors,
            'limit': 'Structural checks only; not a Codex load test or semantic proof.'}

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', nargs='?', type=Path, default=Path(__file__).resolve().parents[1])
    result = check(parser.parse_args().root)
    print(json.dumps(result, indent=2))
    sys.exit(0 if result['status'] == 'PASS' else 1)
