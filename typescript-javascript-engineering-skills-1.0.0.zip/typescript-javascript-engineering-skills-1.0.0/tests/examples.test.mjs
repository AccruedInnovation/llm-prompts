// Checks use the exact marked examples in the shipped Markdown, not copied substitutes.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readdirSync, readFileSync, writeFileSync, mkdirSync, mkdtempSync, rmSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import { spawnSync } from 'node:child_process';
import { getEventListeners } from 'node:events';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const require = createRequire(import.meta.url);
let ts;
try { ts = require(process.env.TYPESCRIPT_MODULE || 'typescript'); }
catch { throw new Error('TypeScript unavailable. Run tools/run_checks.py or set TYPESCRIPT_MODULE to installed lib/typescript.js. No download is attempted.'); }
const examples = new Map(), used = new Set();
function collect(dir) {
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const path = join(dir, entry.name);
    if (entry.isDirectory()) collect(path);
    else if (entry.name.endsWith('.md')) {
      const pattern = /<!-- example: ([a-z0-9-]+) -->\s*```([^\n]+)\n([\s\S]*?)\n```/g;
      for (const match of readFileSync(path, 'utf8').matchAll(pattern)) {
        assert(!examples.has(match[1]), `duplicate marker ${match[1]}`);
        examples.set(match[1], { lang: match[2], code: match[3], path });
      }
    }
  }
}
collect(join(root, 'skills'));
function example(id) { assert(examples.has(id), `missing ${id}`); used.add(id); return examples.get(id); }
function diagnosticsFor(code, ext = '.ts', overrides = {}) {
  const dir = mkdtempSync(join(tmpdir(), 'tsjs-types-'));
  try {
    const file = join(dir, `case${ext}`); writeFileSync(file, code);
    const options = { strict: true, target: ts.ScriptTarget.ES2022,
      module: ts.ModuleKind.ESNext, noEmit: true, skipLibCheck: false, ...overrides };
    const program = ts.createProgram([file], options);
    return ts.getPreEmitDiagnostics(program).filter(d => d.category === ts.DiagnosticCategory.Error)
      .map(d => ({ code: d.code, line: d.file && d.start !== undefined
        ? d.file.getLineAndCharacterOfPosition(d.start).line + 1 : null,
        text: ts.flattenDiagnosticMessageText(d.messageText, '\n') }));
  } finally { rmSync(dir, { recursive: true, force: true }); }
}
function check(id, overrides = {}, transform = x => x) {
  const x = example(id); return diagnosticsFor(transform(x.code), x.lang === 'js' ? '.js' : '.ts', overrides);
}
function codes(ds) { return ds.map(d => d.code); }
async function runtime(id) {
  const x = example(id);
  const code = x.lang === 'ts' ? ts.transpileModule(x.code, { compilerOptions: {
    module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022,
  } }).outputText : x.code;
  return import(`data:text/javascript;base64,${Buffer.from(code).toString('base64')}`);
}
function deferred() {
  let resolve, reject;
  const promise = new Promise((yes, no) => { resolve = yes; reject = no; });
  return { promise, resolve, reject };
}
const tick = () => new Promise(setImmediate);
const observe = promise => promise.then(value => ({ ok: true, value }), error => ({ ok: false, error }));
const removeDirective = code => code.replace(/\/\/ @ts-expect-error[^\n]*/g, '// Removed only to inspect the diagnostic.');

test('tool identities and expected marked examples', t => {
  assert.equal(examples.size, 23);
  t.diagnostic(`Node ${process.version}; TypeScript ${ts.version}; ${process.platform}/${process.arch}`);
});
test('strict umbrella override changes null assignment guarantee', () => {
  assert.deepEqual(check('strict-override', { strictNullChecks: false }), []);
  assert.deepEqual(codes(check('strict-override')), [2322]);
});
test('JSDoc alone does not enable JavaScript checking', () => {
  assert.deepEqual(check('jsdoc-only', { allowJs: true, checkJs: false }), []);
  assert.deepEqual(codes(check('jsdoc-only', { allowJs: true, checkJs: true })), [2322]);
});
test('wrong expected-error fixture passes on arity, not argument type', () => {
  assert.deepEqual(check('wrong-error-acceptance'), []);
  assert.deepEqual(check('wrong-error-acceptance', {}, removeDirective).map(d => [d.code, d.line]), [[2554, 4]]);
});
test('repaired negative fixture isolates the intended error and rejects a widened API', () => {
  assert.deepEqual(check('intended-negative'), []);
  assert.deepEqual(check('intended-negative', {}, removeDirective).map(d => [d.code, d.line]), [[2345, 5]]);
  assert.deepEqual(codes(check('intended-negative', {}, code => code.replace('value: number', 'value: unknown'))), [2578]);
});
test('selected TypeScript examples pass semantic strict checking', () => {
  for (const id of ['request-state', 'stale-narrowing', 'readonly-alias', 'predicate', 'async-foreach']) assert.deepEqual(check(id), [], id);
});
test('stale narrowing fails at runtime while snapshot preserves chosen semantics', async () => {
  const x = await runtime('stale-narrowing'); assert.throws(() => x.unsafeLabel(), TypeError); assert.equal(x.snapshotLabel(), 'PRESENT');
});
test('readonly view does not stop mutation through aliases', async () => {
  assert.equal((await runtime('readonly-alias')).readThroughAlias(), 3);
});
test('predicate true and false cases expose its defective claim', async () => {
  const x = await runtime('predicate'); assert.equal(x.isTextWrong(1), true); assert.equal(x.isTextWrong(''), false);
  for (const value of [1, null, {}]) assert.equal(x.isText(value), false);
  for (const value of ['', 'text']) assert.equal(x.isText(value), true);
});
test('request state rejects stale results', async () => {
  const { complete } = await runtime('request-state'); const state = { kind: 'loading', requestId: 2 };
  assert.equal(complete(state, 1, 'old'), state);
  assert.deepEqual(complete(state, 2, 'new'), { kind: 'ready', requestId: 2, data: 'new' });
});
test('forEach returns early but ordered iteration joins and propagates failure', async () => {
  const { notJoined, ordered } = await runtime('async-foreach'); const gate = deferred(); let completed = false;
  await notJoined([1], async () => { await gate.promise; completed = true; }); assert.equal(completed, false);
  gate.resolve(); await tick(); assert.equal(completed, true);
  const held = deferred(), started = []; let settled = false;
  const work = ordered([1, 2], async n => { started.push(n); if (n === 1) await held.promise; });
  work.then(() => { settled = true; }); await tick(); assert.deepEqual(started, [1]); assert.equal(settled, false);
  held.resolve(); await work; assert.deepEqual(started, [1, 2]);
  const failed = []; await assert.rejects(ordered([1, 2], async n => { failed.push(n); throw new Error('stop'); }), /stop/);
  assert.deepEqual(failed, [1]);
});
test('bounded scheduling caps active work and preserves order', async () => {
  const { mapBounded } = await runtime('bounded-map'); const gates = Array.from({ length: 4 }, deferred);
  let active = 0, maximum = 0; const started = [];
  const promise = mapBounded([0, 1, 2, 3], 2, async n => {
    started.push(n); maximum = Math.max(maximum, ++active);
    try { return await gates[n].promise; } finally { active--; }
  });
  assert.deepEqual(started, [0, 1]); gates[1].resolve(20); await tick(); assert.deepEqual(started, [0, 1, 2]);
  gates[2].resolve(30); await tick(); assert.deepEqual(started, [0, 1, 2, 3]); gates[3].resolve(40); gates[0].resolve(10);
  assert.deepEqual(await promise, [10, 20, 30, 40]); assert.equal(maximum, 2); assert.equal(active, 0);
});
test('synchronous task failure prevents additional starts', async () => {
  const { mapBounded } = await runtime('bounded-map'); const started = [];
  await assert.rejects(mapBounded([0, 1, 2], 2, n => { started.push(n); throw new Error('sync'); }), /sync/); assert.deepEqual(started, [0]);
});
test('undefined rejection is failure and already-started work remains joined', async () => {
  const { mapBounded } = await runtime('bounded-map'); const gate = deferred(), started = []; let settled = false;
  const result = observe(mapBounded([0, 1, 2], 2, n => { started.push(n); return n === 0 ? Promise.reject(undefined) : gate.promise; }));
  result.then(() => { settled = true; }); await tick(); assert.deepEqual(started, [0, 1]); assert.equal(settled, false);
  gate.resolve('sibling committed'); assert.deepEqual(await result, { ok: false, error: undefined });
});
test('pre-abort starts no bounded tasks', async () => {
  const { mapBounded } = await runtime('bounded-map'); const c = new AbortController(), reason = new Error('preabort'); c.abort(reason); let starts = 0;
  assert.deepEqual(await observe(mapBounded([1], 1, () => { starts++; }, c.signal)), { ok: false, error: reason });
  assert.equal(starts, 0); assert.equal(getEventListeners(c.signal, 'abort').length, 0);
});
test('abort stops new tasks, joins started tasks and removes listeners', async () => {
  const { mapBounded } = await runtime('bounded-map'); const c = new AbortController(), gates = [deferred(), deferred()], starts = [], reason = new Error('abort');
  const result = observe(mapBounded([0, 1, 2], 2, n => { starts.push(n); return gates[n].promise; }, c.signal));
  c.abort(reason); gates[0].resolve(0); gates[1].resolve(1);
  assert.deepEqual(await result, { ok: false, error: reason }); assert.deepEqual(starts, [0, 1]); assert.equal(getEventListeners(c.signal, 'abort').length, 0);
});
test('bounded success, empty input and invalid limits have defined behavior', async () => {
  const { mapBounded } = await runtime('bounded-map'); const c = new AbortController();
  assert.deepEqual(await mapBounded([2], 2, n => n * 3, c.signal), [6]); assert.equal(getEventListeners(c.signal, 'abort').length, 0);
  assert.deepEqual(await mapBounded([], 2, () => { throw new Error('must not start'); }), []);
  for (const n of [0, -1, 1.5, Infinity]) await assert.rejects(mapBounded([], n, x => x), RangeError);
  await assert.rejects(mapBounded(null, 1, x => x), TypeError);
});
test('delay rejects pre-abort without registering a listener', async () => {
  const { delay } = await runtime('abortable-delay'); const c = new AbortController(), reason = new Error('early'); c.abort(reason);
  assert.deepEqual(await observe(delay(10, c.signal)), { ok: false, error: reason }); assert.equal(getEventListeners(c.signal, 'abort').length, 0);
});
test('delay abort clears timer and listener', async () => {
  const { delay } = await runtime('abortable-delay'); const c = new AbortController(), original = globalThis.clearTimeout; let cleared = 0;
  globalThis.clearTimeout = handle => { if (handle !== undefined) cleared++; return original(handle); };
  try {
    const result = observe(delay(100, c.signal)), reason = new Error('late'); c.abort(reason);
    assert.deepEqual(await result, { ok: false, error: reason }); assert.equal(cleared, 1); assert.equal(getEventListeners(c.signal, 'abort').length, 0);
  } finally { globalThis.clearTimeout = original; }
});
test('delay cleans normal completion, ignores later abort, and rejects invalid bounds', async () => {
  const { delay } = await runtime('abortable-delay'); const c = new AbortController(), result = delay(1, c.signal); await result;
  assert.equal(getEventListeners(c.signal, 'abort').length, 0); c.abort(); assert.equal(await result, undefined);
  for (const ms of [-1, 0.5, Infinity, 2147483648]) await assert.rejects(delay(ms), RangeError);
});
test('cleanup preserves primary and both-error order', async () => {
  const { runAndRelease } = await runtime('cleanup-errors'); let calls = 0;
  assert.equal(await runAndRelease(() => 7, () => { calls++; }), 7); assert.equal(calls, 1);
  const primary = new Error('primary'), cleanup = new Error('cleanup');
  assert.equal((await observe(runAndRelease(() => { throw primary; }, () => {}))).error, primary);
  assert.equal((await observe(runAndRelease(() => 1, () => { throw cleanup; }))).error, cleanup);
  const both = await observe(runAndRelease(() => Promise.reject(undefined), () => { throw cleanup; }));
  assert.equal(both.ok, false); assert(both.error instanceof AggregateError); assert.deepEqual(both.error.errors, [undefined, cleanup]);
});
test('Promise.all rejection neither rolls back nor stops sibling effects', async () => {
  const gate = deferred(); let effects = 0; const sibling = gate.promise.then(() => { effects++; });
  await assert.rejects(Promise.all([Promise.reject(new Error('one failed')), sibling]), /one failed/);
  assert.equal(effects, 0); gate.resolve(); await sibling; assert.equal(effects, 1);
});
test('rename guards isolate authorization, revision and valid updates', async () => {
  const { parseRename, applyRename } = await runtime('rename-guard'), row = { tenantId: 'a', name: 'old', revision: 2 }, original = { ...row };
  const command = parseRename({ name: 'new', revision: 2 });
  assert.throws(() => applyRename({ tenantId: 'b' }, row, command), e => e.code === 'FORBIDDEN'); assert.deepEqual(row, original);
  assert.throws(() => applyRename({ tenantId: 'a' }, row, parseRename({ name: 'new', revision: 1 })), e => e.code === 'CONFLICT'); assert.deepEqual(row, original);
  applyRename({ tenantId: 'a' }, row, command); assert.deepEqual(row, { tenantId: 'a', name: 'new', revision: 3 });
});
test('rename parser, combined precedence and revision bound reject before mutation', async () => {
  const { parseRename, applyRename } = await runtime('rename-guard');
  for (const input of [null, [], {}, { name: 'new' }, { name: '', revision: 0 }, { name: 'n', revision: -1 }, { name: 'n', revision: 0, tenantId: 'b' }]) assert.throws(() => parseRename(input), e => e.code === 'INVALID');
  const row = { tenantId: 'a', name: 'old', revision: Number.MAX_SAFE_INTEGER }, before = { ...row };
  assert.throws(() => applyRename({ tenantId: 'b' }, row, { name: 'new', revision: 0 }), e => e.code === 'FORBIDDEN');
  assert.throws(() => applyRename({ tenantId: 'a' }, row, { name: 'new', revision: row.revision }), e => e.code === 'REVISION_LIMIT'); assert.deepEqual(row, before);
});
test('foreign-tenant assertion rejects a deliberately guardless implementation', async () => {
  const { parseRename } = await runtime('rename-guard'), row = { tenantId: 'a', name: 'old', revision: 2 }, command = parseRename({ name: 'new', revision: 2 });
  const wrong = (_actor, record, value) => { record.name = value.name; record.revision++; };
  assert.throws(() => assert.throws(() => wrong({ tenantId: 'b' }, row, command), /FORBIDDEN/), assert.AssertionError); assert.equal(row.name, 'new');
});
test('configuration grammar preserves missing, false, empty and malformed distinctions', async () => {
  const { parseEnabled, parsePort } = await runtime('config-parsers');
  assert.equal(parseEnabled(undefined), false); assert.equal(parseEnabled('false'), false); assert.equal(parseEnabled('true'), true);
  for (const raw of ['', '0', 'yes', ' false ']) assert.throws(() => parseEnabled(raw));
  assert.equal(parsePort(undefined), 8080); assert.equal(parsePort('00080'), 80); assert.equal(parsePort('65535'), 65535);
  for (const raw of ['', ' ', '0', '-1', '+1', '1.5', '12x', '65536', '9007199254740993']) assert.throws(() => parsePort(raw));
});
test('JSON has the stated default wire forms and BigInt failure', async () => {
  const { wireForms, defaultBigIntSerialization } = await runtime('json-loss');
  assert.deepEqual(wireForms(), { object: '{"keep":1}', array: '[null]', nonfinite: '{"value":null}', explicitNull: '{"value":null}' }); assert.throws(defaultBigIntSerialization, TypeError);
});
test('field authorization rejects foreign or forbidden updates without partial mutation', async () => {
  const { updateDisplayName } = await runtime('field-authorization'), row = { ownerId: 'a', displayName: 'old' }, before = { ...row };
  assert.throws(() => updateDisplayName({ id: 'b' }, row, { displayName: 'new' }), /FORBIDDEN/); assert.deepEqual(row, before);
  assert.throws(() => updateDisplayName({ id: 'a' }, row, { displayName: 'new', ownerId: 'b' }), /FIELD_NOT_ALLOWED/); assert.deepEqual(row, before);
  updateDisplayName({ id: 'a' }, row, { displayName: 'new' }); assert.deepEqual(row, { ownerId: 'a', displayName: 'new' });
});
test('latest loader ignores stale success even when fetch ignores abort', async () => {
  const { makeLatestLoader } = await runtime('latest-loader'), a = deferred(), b = deferred(), states = [], errors = [], signals = [];
  const loader = makeLatestLoader((key, signal) => { signals.push(signal); return key === 'a' ? a.promise : b.promise; }, s => states.push(s), e => errors.push(e));
  const first = loader.load('a'), second = loader.load('b'); assert.equal(signals[0].aborted, true); b.resolve('new'); await second; a.resolve('old'); await first;
  assert.deepEqual(states.at(-1), { status: 'ready', key: 'b', value: 'new' }); assert.deepEqual(errors, []);
});
test('latest loader ignores stale errors but reports current failure', async () => {
  const { makeLatestLoader } = await runtime('latest-loader'), a = deferred(), b = deferred(), states = [], errors = [];
  const loader = makeLatestLoader(key => key === 'a' ? a.promise : b.promise, s => states.push(s), e => errors.push(e));
  const first = loader.load('a'), second = loader.load('b'), failure = new Error('current'); b.reject(failure); await second; a.reject(new Error('stale')); await first;
  assert.deepEqual(states.at(-1), { status: 'failed', key: 'b' }); assert.deepEqual(errors, [failure]);
});
test('disposed latest loader rejects new work and suppresses late results', async () => {
  const { makeLatestLoader } = await runtime('latest-loader'), gate = deferred(), states = [], errors = [];
  const loader = makeLatestLoader(() => gate.promise, s => states.push(s), e => errors.push(e));
  const work = loader.load('a'); loader.dispose(); gate.resolve('late'); await work;
  assert.deepEqual(states, [{ status: 'loading', key: 'a' }]); assert.deepEqual(errors, []); await assert.rejects(loader.load('b'), /disposed/);
});
test('React hook has valid TSX syntax only; no React/browser execution claim', () => {
  const x = example('react-cleanup'); const result = ts.transpileModule(x.code, { fileName: 'hook.tsx', reportDiagnostics: true,
    compilerOptions: { module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022, jsx: ts.JsxEmit.ReactJSX } }); assert.deepEqual(codes(result.diagnostics || []), []);
});
function localNpm(args, cwd, temp) {
  const cli = process.env.NPM_CLI_JS; assert(cli && existsSync(cli), 'NPM_CLI_JS must point to installed npm-cli.js; run tools/run_checks.py.');
  const config = join(temp, 'empty.npmrc'); writeFileSync(config, '');
  const result = spawnSync(process.execPath, [cli, ...args], { cwd, encoding: 'utf8', timeout: 20000,
    env: { ...process.env, npm_config_cache: join(temp, 'cache'), npm_config_userconfig: config,
      npm_config_offline: 'true', npm_config_update_notifier: 'false', npm_config_audit: 'false', npm_config_fund: 'false' } });
  assert(!result.error, String(result.error)); assert.equal(result.status, 0, result.stderr || result.stdout); return result.stdout;
}
function packedConsumer(missingDeclaration = false) {
  const temp = mkdtempSync(join(tmpdir(), 'tsjs-pack-'));
  try {
    const pkg = join(temp, 'source'), pack = join(temp, 'pack'), consumer = join(temp, 'consumer');
    for (const d of [join(pkg, 'dist'), join(pkg, 'legacy'), pack, consumer]) mkdirSync(d, { recursive: true });
    writeFileSync(join(pkg, 'package.json'), example('esm-package-json').code); writeFileSync(join(pkg, 'dist/index.js'), example('esm-runtime').code);
    if (!missingDeclaration) writeFileSync(join(pkg, 'dist/index.d.ts'), example('esm-declaration').code);
    writeFileSync(join(pkg, 'legacy/index.d.ts'), example('legacy-declaration').code);
    const packed = JSON.parse(localNpm(['pack', '--ignore-scripts', '--json', '--pack-destination', pack], pkg, temp)); assert.equal(packed.length, 1);
    assert(packed[0].files.some(f => f.path === 'dist/index.js')); assert.equal(packed[0].files.some(f => f.path === 'dist/index.d.ts'), !missingDeclaration);
    const tarball = join(pack, packed[0].filename); assert(existsSync(tarball)); rmSync(pkg, { recursive: true });
    writeFileSync(join(consumer, 'package.json'), '{"private":true,"type":"module"}\n');
    localNpm(['install', '--offline', '--ignore-scripts', '--no-audit', '--no-fund', tarball], consumer, temp);
    const entry = join(consumer, 'consumer.mts'); writeFileSync(entry, example('esm-consumer').code);
    const options = { strict: true, target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.NodeNext,
      moduleResolution: ts.ModuleResolutionKind.NodeNext, noEmit: true, skipLibCheck: false };
    const program = ts.createProgram([entry], options), ds = ts.getPreEmitDiagnostics(program).filter(d => d.category === ts.DiagnosticCategory.Error);
    if (missingDeclaration) assert(ds.some(d => d.code === 7016), ds.map(d => ts.flattenDiagnosticMessageText(d.messageText, '\n')).join('\n'));
    else {
      assert.deepEqual(codes(ds), []);
      assert(program.getSourceFiles().some(f => f.fileName.replaceAll('\\', '/').endsWith('/node_modules/tsjs-skill-consumer-demo/dist/index.d.ts')));
      writeFileSync(join(consumer, 'consumer.mjs'), ts.transpileModule(example('esm-consumer').code, { compilerOptions: {
        module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022 } }).outputText);
      const result = spawnSync(process.execPath, ['consumer.mjs'], { cwd: consumer, encoding: 'utf8', timeout: 10000 });
      assert.equal(result.status, 0, result.stderr); assert.equal(result.stdout.trim(), 'exports');
      const cjs = spawnSync(process.execPath, ['-e', 'require("tsjs-skill-consumer-demo")'], { cwd: consumer, encoding: 'utf8', timeout: 10000 });
      assert.notEqual(cjs.status, 0); assert.match(cjs.stderr, /ERR_PACKAGE_PATH_NOT_EXPORTED/);
    }
  } finally { rmSync(temp, { recursive: true, force: true }); }
}
test('actual packed ESM consumer resolves declarations and runtime without workspace source', { timeout: 30000 }, () => packedConsumer(false));
test('actual bad tarball with missing declarations fails its consumer check', { timeout: 30000 }, () => packedConsumer(true));
test('every marked example receives its declared syntax, type, runtime or package check', () => {
  assert.deepEqual([...used].sort(), [...examples.keys()].sort());
});
