"""Installer smoke tests use only disposable destinations, not the user's actual Codex setup."""
import importlib.util
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('check_bundle', ROOT/'tools'/'check_bundle.py')
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)

class InstallTests(unittest.TestCase):
    def run_install(self, *args):
        return subprocess.run([sys.executable, str(ROOT/'install.py'), *map(str,args)],
                              capture_output=True, text=True, timeout=30)
    def test_dry_run_writes_nothing(self):
        with tempfile.TemporaryDirectory() as d:
            dest = Path(d)/'skills'
            result = self.run_install('--dest',dest,'--dry-run')
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertFalse(dest.exists())
    def test_all_skills_copy_exactly_and_stay_self_contained(self):
        with tempfile.TemporaryDirectory() as d:
            dest=Path(d)/'skills'
            result=self.run_install('--dest',dest)
            self.assertEqual(result.returncode,0,result.stderr)
            for source in (ROOT/'skills').rglob('*'):
                if source.is_file(): self.assertEqual(source.read_bytes(),(dest/source.relative_to(ROOT/'skills')).read_bytes())
            report=checker.check(Path(d))
            self.assertEqual(report['status'],'PASS',report)
    def test_conflict_refuses_entire_plan_and_preserves_existing(self):
        with tempfile.TemporaryDirectory() as d:
            dest=Path(d)/'skills'; existing=dest/'tsjs-type-contract-review'
            existing.mkdir(parents=True);(existing/'mine.txt').write_text('keep')
            result=self.run_install('--dest',dest)
            self.assertEqual(result.returncode,2)
            self.assertEqual([p.name for p in dest.iterdir()],['tsjs-type-contract-review'])
            self.assertEqual((existing/'mine.txt').read_text(),'keep')
    def test_select_one_skill(self):
        with tempfile.TemporaryDirectory() as d:
            dest=Path(d)/'skills';name='tsjs-async-resource-failure-review'
            result=self.run_install('--dest',dest,'--skill',name)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertEqual([p.name for p in dest.iterdir()],[name])
            self.assertTrue((dest/name/'references/worked-cases.md').is_file())
    def test_unknown_name_rejects_without_writing(self):
        with tempfile.TemporaryDirectory() as d:
            dest=Path(d)/'skills';result=self.run_install('--dest',dest,'--skill','not-a-skill')
            self.assertNotEqual(result.returncode,0)
            self.assertFalse(dest.exists())
    def test_list_writes_nothing(self):
        result=self.run_install('--list')
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertEqual(len(result.stdout.splitlines()),13)

if __name__=='__main__': unittest.main()
