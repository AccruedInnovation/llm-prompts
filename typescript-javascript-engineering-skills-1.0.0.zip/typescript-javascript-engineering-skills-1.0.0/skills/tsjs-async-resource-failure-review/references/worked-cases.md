# Worked async ownership and cleanup cases

These examples define limited policies so their correctness can be tested. They are not a required concurrency library. Prefer an established project primitive when it provides the needed behavior.

## A callback compiles but its caller does not join it

<!-- example: async-foreach -->
```ts
// Intentionally defective when callers require completion of every effect.
export async function notJoined(
  values: number[], effect: (value: number) => Promise<void>,
): Promise<void> {
  values.forEach(async value => { await effect(value); });
}

export async function ordered(
  values: number[], effect: (value: number) => Promise<void>,
): Promise<void> {
  for (const value of values) await effect(value);
}
```

**Inspect/failure:** TypeScript accepts the callback, but `forEach` does not join its promise. The outer operation can resolve before effects finish and rejection can go unobserved.

**Repair/proof:** the ordered version suits dependent work. Hold the first effect at an explicit barrier; the owning promise must remain pending and the next effect must not start. Reject the first effect; the owner must reject and later effects must not start.

**Valid countercase:** a finite independent batch may use `await Promise.all(values.map(effect))`. On success it waits for every member. On failure it rejects early without waiting for siblings to settle; it neither rolls back nor cancels them. For an intentionally detached callback, transfer the task to a real lifetime/error owner. Prefixing the call with `void` alone does not do that.

## Bound started work without creating all promises first

**Use:** a finite in-memory array of independent items. **Policy chosen here:** preserve result order, cap active tasks, stop launching after the first observed failure or abort, wait for already-started tasks, then reject with the first observed reason. No rollback or forced cancellation of those tasks is claimed. A caller signal reaches the task, which may ignore it. Input and output arrays still use O(n) storage; this is not an open-ended streaming queue.

<!-- example: bounded-map -->
```js
export async function mapBounded(input, limit, task, signal) {
  if (!Array.isArray(input)) throw new TypeError("input must be an array");
  if (!Number.isSafeInteger(limit) || limit < 1) {
    throw new RangeError("limit must be a positive safe integer");
  }
  if (typeof task !== "function") throw new TypeError("task must be callable");
  const items = [...input]; // Snapshot the finite list, not deep copies of items.
  const results = new Array(items.length);
  let next = 0;
  let failed = false;
  let failure;
  function stop(reason) {
    if (!failed) { failed = true; failure = reason; }
  }
  const onAbort = () => stop(signal.reason);
  if (signal?.aborted) throw signal.reason;
  signal?.addEventListener("abort", onAbort, { once: true });
  try {
    if (signal?.aborted) onAbort();
    async function worker() {
      while (!failed) {
        const index = next++;
        if (index >= items.length) return;
        try {
          results[index] = await task(items[index], index, signal);
        } catch (error) {
          stop(error); // A separate flag also handles rejection with undefined.
        }
      }
    }
    const workers = Array.from(
      { length: Math.min(limit, items.length) }, () => worker(),
    );
    await Promise.all(workers);
    if (failed) throw failure;
    return results;
  } finally {
    signal?.removeEventListener("abort", onAbort);
  }
}
```

**Proof:** with controlled task barriers, assert active work never exceeds `limit`, results keep input order when completions reverse, a synchronous throw and an `undefined` rejection both stop new work, and pre-abort starts no tasks. On failure, hold a sibling pending and verify the owner stays pending until that sibling finishes. Inspect listener removal on success and abort.

**Limits:** if a started task never settles, this function waits forever. A production deadline needs a task that can stop or a defined containment/reconciliation path; a timeout wrapper cannot prove that an effect ended. Sibling effects may commit before or after the first failure. Abort and failure precedence is first observed, not globally ordered physical time. Avoid arbitrary concurrency defaults: choose a limit from the resource contract or measurements.

**Valid countercase:** use serial iteration for dependent effects or a small joined batch where scale is already bounded. For open-ended input, use bounded pull/backpressure and output streaming instead of copying all items or building an unlimited queue behind this limiter.

## Remove abort listeners on success too

**Use:** a small cancellable timer. **Failure:** a once-only listener remains attached to a long-lived signal when the timer finishes normally and no abort occurs.

<!-- example: abortable-delay -->
```js
export function delay(ms, signal) {
  if (!Number.isSafeInteger(ms) || ms < 0 || ms > 2147483647) {
    return Promise.reject(new RangeError("ms is outside this example's timer range"));
  }
  return new Promise((resolve, reject) => {
    if (signal?.aborted) { reject(signal.reason); return; }
    let timer;
    let settled = false;
    function finish(failed, reason) {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      signal?.removeEventListener("abort", onAbort);
      if (failed) reject(reason); else resolve();
    }
    const onAbort = () => finish(true, signal.reason);
    signal?.addEventListener("abort", onAbort, { once: true });
    if (signal?.aborted) { onAbort(); return; }
    timer = setTimeout(() => finish(false), ms);
  });
}
```

**Proof:** pre-abort rejects without starting a timer; mid-wait abort rejects with the signal reason; normal completion leaves no abort listener; later abort changes no completed result. Test timer cleanup with an instrumented scheduler and selected real-runtime tests. Timers are scheduling requests, not exact wall-clock deadlines.

**Valid countercase:** a runtime's existing cancellable timer API already owns these lifetimes. Use it rather than copying this helper. The example assumes ordinary trusted `AbortSignal` and timer APIs, not hostile objects masquerading as signals.

## Cleanup must not silently replace the primary failure

**Use:** an operation and resource release can both fail. **Chosen policy:** preserve a lone error; report both, in operation-then-release order, if both fail. Other documented project policies may be valid.

<!-- example: cleanup-errors -->
```js
export async function runAndRelease(run, release) {
  let value;
  let failed = false;
  let primary;
  try { value = await run(); }
  catch (error) { failed = true; primary = error; }
  try { await release(); }
  catch (cleanup) {
    if (failed) throw new AggregateError([primary, cleanup], "operation and cleanup failed");
    throw cleanup;
  }
  if (failed) throw primary;
  return value;
}
```

**Proof:** test success/success, failure/success, success/failure and both failures, including a rejection with `undefined`. Assert release runs once. **Valid countercase:** a project's release is infallible or an established resource abstraction already preserves both causes. Do not wrap every error layer redundantly.

## A stream must slow its producer

**Use:** Node writable output, Web Streams, an async iterator or an adapter between them. **Inspect:** where the producer pauses, how much queues retain, and who observes terminal errors.

**Failure:** ignoring a Node writable's `false` return keeps buffering; retrying that same chunk duplicates data because the write was accepted. Waiting only for `drain` can miss error/close completion.

**Repair/proof:** use a project-appropriate pipeline/iterator that handles the required terminal states, or implement the full contract explicitly. Throttle the destination; measure bounded buffer growth and exact output. Fail the destination; assert source termination and cleanup. Stop iteration early; inspect resource closure. Check compression/decoding and object-mode bounds independently.

**Valid countercase:** a provably small bounded buffer that meets the memory and completion contract. Do not demand streaming for every string.

## Source notes

Technical facts checked 2026-09-08: [floating promises](https://typescript-eslint.io/rules/no-floating-promises/), [misused promises](https://typescript-eslint.io/rules/no-misused-promises/), [Node AbortSignal](https://nodejs.org/api/globals.html#class-abortsignal), and [Node streams](https://nodejs.org/api/stream.html). The finite scheduler and error policies above are new examples, not promises from those sources.
