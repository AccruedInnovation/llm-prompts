---
name: tsjs-async-resource-failure-review
description: Review promises, event-loop ordering, cancellation, timers, streams, workers, child processes, retries, idempotency, transactions, shutdown, and resource cleanup in TypeScript/JavaScript.
---

# TS/JS Async, Resource, and Failure Review

JavaScript's event loop does not remove concurrency. State can change across `await`, callbacks can race, workers and subprocesses add parallelism, and streams introduce backpressure and partial completion.


## Review method and limits

Start with the requested claim and affected code, callers, configuration and tests. Keep a review read-only unless repair is authorized. Use cheap reliable checks early, but do not block useful source review on an unavailable build or call a mandatory unrun check passed. Trace a concrete failure before recommending a repair. Test the strongest reasonable rebuttal: an existing boundary check, intentional scope limit, different consumer promise, or resource owner elsewhere may resolve the concern.

Report material findings with location, expected versus observed behavior, consequence, evidence strength, smallest repair and a closure check. Distinguish observed defects, supported analytical defects/risks, missing evidence, and advice. Preserve valid uses and harmless private choices. Do not add findings to meet a quota. Stop once the assigned claims and risky boundaries have sufficient coverage; state unreviewed scope.

Use existing revision and changed-file information. Record only evidence needed for the claim; defer optional hashes to final delivery and avoid self-hashing manifests or metadata repair loops. A skill does not grant installation, network, credentials, publication, deployment, or destructive authority. Same-session self-review is not independent review.

## Bind the execution model

Identify:

- runtime and version;
- async frameworks and schedulers;
- request/job/event ownership;
- transaction and persistence boundaries;
- cancellation and timeout mechanisms;
- streams, sockets, workers, child processes, timers, listeners, and other handles;
- retry, duplicate-delivery, and idempotency policy;
- shutdown and restart behavior;
- test scheduler, fake timers, and open-handle diagnostics.

## Promise and callback correctness

Review for:

- floating promises and ignored rejections;
- missing `await` or unintended sequentialization;
- callback/promise double completion;
- async constructors or initialization ordering;
- catch-and-log paths that lose failure;
- `Promise.all` partial effects and cancellation assumptions;
- `Promise.race` losers that continue running;
- result ordering assumptions;
- unhandled rejection and uncaught exception policy;
- stale closure state across `await`.

## Cancellation and deadlines

Trace cancellation end to end:

```text
request or parent signal
  → operation
  → nested calls
  → stream / worker / process / database call
  → cleanup
  → durable state after interruption
```

Check:

- `AbortSignal` propagation;
- timeout versus cancellation classification;
- cleanup handlers and listener removal;
- cancellation after partial side effects;
- late results after caller abandonment;
- whether retries respect the original deadline;
- whether cancellation can interrupt a critical commit and what state remains.

A timeout wrapper that stops waiting but leaves work running is not full cancellation.

## Streams and backpressure

Inspect:

- producer/consumer rate mismatch;
- ignored write return values;
- missing drain or pipeline completion handling;
- partial reads/writes;
- premature close and destroy semantics;
- error propagation across pipeline stages;
- cancellation and listener cleanup;
- memory buffering limits;
- object-mode assumptions;
- browser/Node/Web stream adaptation.

## Resources and lifecycle

Review ownership and cleanup of:

- timers and intervals;
- event listeners and subscriptions;
- sockets, files, database clients and transactions;
- workers and child processes;
- locks or distributed leases;
- caches and retained closures;
- test fixtures and temporary resources.

Every resource should have a clear owner and terminal cleanup path for success, failure, cancellation, timeout, and shutdown.

## State, retries, and durability

Check:

- state changes split by `await` without conflict control;
- duplicate messages or webhooks;
- retrying non-idempotent operations;
- lost acknowledgement windows;
- transaction scope and external calls inside transactions;
- partial batch success;
- restart/replay behavior;
- consistency of cache and durable state;
- optimistic concurrency and stale writes;
- compensation versus complete-forward recovery.

## Testing

Use applicable methods:

- deterministic fake clocks plus selected real-time tests;
- forced cancellation at each material boundary;
- duplicate and out-of-order delivery;
- stream backpressure and consumer failure;
- worker/process crash and late result;
- retry exhaustion and partial success;
- restart with persisted state;
- property or model-based state-machine tests;
- open-handle and resource-leak checks;
- fault injection around transactions and external effects.

Do not let fake timers become the only evidence for behavior dependent on real scheduler or I/O semantics.

## Output

Report ownership, cancellation, completion, durable-state, retry, and cleanup assertions separately. Classify findings as promise lifecycle, race/order, cancellation, backpressure, resource leak, retry/idempotency, transaction/durability, shutdown/recovery, or evidence gap.

## Planned structure

When a project design fixes these boundaries, compare planned and actual ownership of promises, AbortSignals, timers, listeners, subscriptions, streams, workers, child processes, transactions, caches, and shutdown. Moving an internal helper is harmless; changing who starts, cancels, joins, drains, retries, commits, or cleans a resource is normally material.

## Work the lifecycle, not only the promise expression

For each important task, identify who starts it, observes rejection, decides its terminal state, and waits for or contains it at shutdown. `void` can satisfy a lint convention without handling a rejection. An async callback in a `void` callback slot can compile even when the caller never awaits it. Inspect the actual API contract and project-qualified promise lint rules.

Choose ordered iteration for dependent effects, a finite joined batch for bounded independent work, or a bounded queue for large or open-ended input. Bound queue length and result buffering as well as active tasks. Avoid creating all promises before applying a limiter. Decide how to handle overload rather than choosing an arbitrary concurrency number.

For cancellation, test a pre-aborted signal, mid-flight abort, success without abort, late completion, and cleanup failure. `{ once: true }` removes a listener after that event; it does not remove it when success occurs first. Preserve the original error or report both errors when cleanup also fails. Never turn uncertain remote completion into a safe automatic retry without idempotency/reconciliation evidence.

For backpressure, trace source pull/read, buffering, transformation, destination writes and terminal error propagation. A Node writable returning `false` accepted that chunk but asks the producer to wait before more writes; do not retry the same chunk as though it was rejected. Use an appropriate pipeline when it owns the needed completion and cleanup; still check adapters and external resources. Test a slow or failing consumer and early iterator exit.

The worked examples include finite bounded work, cancellation listener cleanup, and preserved primary/cleanup errors. They state what they do not prove for remote effects, open-ended streams and production deadlines.

## Targeted methods and references

Read only the relevant [worked cases](references/worked-cases.md). Use the failure, repair, proof and valid countercase to guide the task; these examples are not mandatory project designs. Do not load every reference by default.
