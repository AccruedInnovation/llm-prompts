---
name: tsjs-runtime-data-contract-review
description: Review runtime trust boundaries, parsing, validation, coercion, versioning, schemas, configuration, persistence, IPC, and external data before values become trusted TypeScript or JavaScript domain objects.
---

# TS/JS Runtime Data Contract Review

TypeScript type annotations do not validate runtime input. This review asks where runtime values become trusted and whether that transition is justified.


## Review method and limits

Start with the requested claim and affected code, callers, configuration and tests. Keep a review read-only unless repair is authorized. Use cheap reliable checks early, but do not block useful source review on an unavailable build or call a mandatory unrun check passed. Trace a concrete failure before recommending a repair. Test the strongest reasonable rebuttal: an existing boundary check, intentional scope limit, different consumer promise, or resource owner elsewhere may resolve the concern.

Report material findings with location, expected versus observed behavior, consequence, evidence strength, smallest repair and a closure check. Distinguish observed defects, supported analytical defects/risks, missing evidence, and advice. Preserve valid uses and harmless private choices. Do not add findings to meet a quota. Stop once the assigned claims and risky boundaries have sufficient coverage; state unreviewed scope.

Use existing revision and changed-file information. Record only evidence needed for the claim; defer optional hashes to final delivery and avoid self-hashing manifests or metadata repair loops. A skill does not grant installation, network, credentials, publication, deployment, or destructive authority. Same-session self-review is not independent review.

## Trigger boundaries

Apply to relevant values from:

- HTTP, RPC, GraphQL, WebSocket, webhooks, queues, and events;
- JSON, YAML, TOML, CSV, XML, binary protocols, files, archives, and form data;
- environment variables and configuration;
- database rows, cache entries, migrations, and persisted snapshots;
- CLI arguments and process input;
- browser storage, cookies, headers, URLs, and service workers;
- `postMessage`, workers, child processes, IPC, plugins, and host tools;
- third-party SDKs and generated clients;
- tool, agent, or extension messages.

## Contract questions

For each material boundary identify:

```text
producer and consumer
wire or storage representation
version and compatibility policy
initial untrusted type
parser/validator/normalizer
trusted domain type
unknown-field behavior
absent/null/undefined behavior
defaulting and coercion
error and partial-success behavior
redaction and observability
migration/retry/replay behavior
```

## Review criteria

### Validation and parsing

- External values begin as `unknown`, bytes, or strings rather than an asserted domain type.
- Structural validation happens before dependent logic or mutation. Authorization and state-dependent guards run at the protected operation, with conflict control where state can change.
- Parsing returns a trusted representation rather than a boolean followed by a second unchecked conversion.
- Coercion is explicit and does not silently turn malformed input into plausible data.
- Defaults distinguish absent input from explicit values.
- Numeric ranges, units, dates, encodings, identifiers, and precision are checked where meaningful.
- Recursive or large inputs have depth, size, and resource bounds.

### Schema and type ownership

Determine the canonical source:

```text
runtime schema generates types
types generate runtime schema
external protocol schema generates both
manually maintained contract with drift checks
```

Flag parallel mutable definitions without a credible drift check. Do not demand a second schema system where one owned definition and consumer tests already protect the contract.

### Compatibility

Assess independently:

- structural parse compatibility;
- semantic meaning;
- unknown/new field behavior;
- removed/renamed fields;
- enum evolution;
- default changes;
- ordering and duplicate semantics;
- version negotiation;
- persistent-data migration;
- mixed producer/consumer versions;
- rollback and replay.

### Error handling

- Invalid input fails with a stable classification.
- Error messages contain enough location/context to diagnose but do not leak secrets.
- Partial records or batched input have a declared all-or-nothing or partial-success policy.
- Retry does not duplicate committed effects.
- Invalid cached or persisted data has a repair or quarantine path.

## Testing

Select applicable evidence:

- valid/minimal/maximal examples;
- malformed and adversarial data;
- missing, null, undefined, unknown, duplicate, and extra fields;
- old/new version fixtures;
- round-trip only when round-trip is actually promised;
- differential tests against a previous parser or independent implementation;
- property or fuzz tests for parsers and decoders;
- persistence migration, downgrade, and rollback fixtures;
- actual host/plugin message fixtures.

Do not accept a compile-time type fixture as runtime-validation evidence.

## Output

For each boundary report the untrusted source, trust transition, runtime validator, canonical schema source, compatibility claim, failure behavior, tests, and exact gap. Distinguish:

```text
missing runtime validation
validation after side effects
schema/type drift
unsafe coercion/defaulting
compatibility defect
persistence/migration defect
resource-exhaustion risk
missing evidence
```

Return `PASS`, `FAIL`, `BLOCKED`, or `INCONCLUSIVE` only for assigned runtime-contract assertions.

## Planned structure

When a project design fixes these boundaries, identify one owner for each runtime schema/parser and its static type/declaration projection. Flag independently authored duplicate schemas, unvalidated trust-boundary assertions, moved validation after side effects, or runtime shape drift as material when they affect a fixed/shared contract. Private parser helper layout remains delegated.

## Separate four questions at a boundary

Determine whether the representation is well formed, whether the values satisfy domain rules, whether this actor may perform the operation, and whether the current state still allows it. Parsing answers the first questions, not all four. A brand or generated client likewise does not grant authority. Do not duplicate parsing in every private helper when one trusted owner already established it.

Identify what can change after validation. Snapshot stable values when that is the contract; check permissions and state-dependent conditions at the effect, using a transaction or conditional write when concurrency requires it. Do not accept caller-supplied ownership as proof of stored ownership.

For JSON/configuration, test absent versus null, explicit false and zero, numeric precision, non-finite values, empty strings, units and date-only versus timestamp meaning. Inspect raw serialized input for duplicate-key behavior: an already-parsed object cannot preserve duplicate members the parser discarded. Specify resource limits at each needed layer, including compressed bytes, decoded text, nesting and collection sizes.

Distinguish parsed JSON from arbitrary in-process objects with getters, prototypes or proxies. Accessing such objects can execute code; a data validator is not isolation from hostile plugins. Keep trust claims bounded to the actual representation and producer.

## Targeted methods and references

Read only the relevant [worked cases](references/worked-cases.md), [compatibility-policy](references/compatibility-policy.md). Use the failure, repair, proof and valid countercase to guide the task; these examples are not mandatory project designs. Do not load every reference by default.
