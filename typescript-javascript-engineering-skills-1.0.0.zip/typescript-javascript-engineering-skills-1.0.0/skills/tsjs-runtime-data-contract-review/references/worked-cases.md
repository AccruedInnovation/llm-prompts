# Worked data, authority, and serialization cases

## Parse, authorize, check state, then mutate

**Use:** rename a stored object. **Failure:** a schema-valid ID is treated as permission; or a foreign-object test fails parsing before it reaches authorization.

This example uses an in-memory synchronous update to expose the order. It defines a narrow policy: actor and record tenant must match; revision must match; then change the name and increment the revision. Actor identity and the stored record come from trusted code, not request fields. The parser expects ordinary data from JSON decoding, not hostile getters or proxies.

<!-- example: rename-guard -->
```js
export class RuleError extends Error {
  constructor(code) { super(code); this.name = "RuleError"; this.code = code; }
}

export function parseRename(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw new RuleError("INVALID");
  }
  const keys = Object.keys(value);
  if (keys.some(key => key !== "name" && key !== "revision") ||
      !Object.hasOwn(value, "name") || !Object.hasOwn(value, "revision") ||
      typeof value.name !== "string" || value.name.length < 1 || value.name.length > 80 ||
      !Number.isSafeInteger(value.revision) || value.revision < 0) {
    throw new RuleError("INVALID");
  }
  return { name: value.name, revision: value.revision };
}

export function applyRename(actor, record, command) {
  if (record.tenantId !== actor.tenantId) throw new RuleError("FORBIDDEN");
  if (record.revision !== command.revision) throw new RuleError("CONFLICT");
  if (record.revision === Number.MAX_SAFE_INTEGER) throw new RuleError("REVISION_LIMIT");
  record.name = command.name;
  record.revision += 1;
}
```

**Proof:** a valid foreign-tenant request yields `FORBIDDEN` and leaves the record unchanged; an owned stale request yields `CONFLICT`; a valid current owned request succeeds; invalid shape fails parsing before mutation. A combined foreign/stale case establishes the chosen precedence separately. Removing the tenant guard must make the foreign-tenant test fail. Test the revision limit too.

**Production limit:** a database implementation must enforce authorization and revision constraints with appropriate transactions/conditional writes; a prior read followed by an unrelated `await` is not equivalent. Check emitted messages/outbox rows or remote calls too if the actual operation has them. This example does not create that infrastructure.

**Valid countercase:** a trusted internal call can reuse a parsed command. Do not parse it again in every helper. A privileged cross-tenant operation needs its own explicit policy, not an automatic prohibition based on this example.

## Configuration strings do not have boolean or integer semantics by default

**Failure:** `Boolean("false")` enables an option; `Number("")` becomes zero; a permissive parse accepts a numeric prefix with trailing text. Decide an explicit grammar and error/default policy.

<!-- example: config-parsers -->
```js
export function parseEnabled(raw) {
  if (raw === undefined) return false;
  if (raw === "true") return true;
  if (raw === "false") return false;
  throw new TypeError("ENABLED must be true or false");
}

export function parsePort(raw) {
  if (raw === undefined) return 8080;
  if (typeof raw !== "string" || !/^[0-9]+$/.test(raw)) {
    throw new TypeError("PORT must contain only decimal digits");
  }
  const value = Number(raw);
  if (!Number.isSafeInteger(value) || value < 1 || value > 65535) {
    throw new RangeError("PORT must be in 1..65535");
  }
  return value;
}
```

**Proof:** absent input uses the named default; false stays false; empty, whitespace, signed, fractional, trailing-text and out-of-range port inputs reject. This selected grammar permits leading zeros. A project may choose another grammar, permit port 0 or accept more boolean tokens; write and test that policy rather than importing these defaults silently.

**Valid countercase:** a configuration library already implements the documented grammar and covered behavior. Reuse it; review coercion settings instead of adding a second parser.

## JSON can change a contract's meaning

<!-- example: json-loss -->
```js
export function wireForms() {
  return {
    object: JSON.stringify({ keep: 1, omitted: undefined }),
    array: JSON.stringify([undefined]),
    nonfinite: JSON.stringify({ value: NaN }),
    explicitNull: JSON.stringify({ value: null }),
  };
}
export function defaultBigIntSerialization() {
  return JSON.stringify({ value: 1n }); // Intentionally throws without a policy.
}
```

**Inspect/proof:** default serialization omits the object's undefined property, turns the undefined array element into null, and emits null for NaN. Explicit null remains null. A BigInt without a conversion policy throws. Test actual wire bytes and the consumer, not just object equality before serialization. A replacer or custom `toJSON` can change these cases; include it in the tested contract.

For patch APIs, define omitted/retain versus null/clear versus explicit value. For identifiers beyond safe integer precision, preserve the intended text/BigInt representation through parsing and transport instead of casting a rounded number back to text. For signed or exact-byte formats, ordinary JSON serialization is not automatically canonicalization.

**Valid countercase:** a contract deliberately treats omitted and null the same, or normalizes values before serialization. Verify that declared meaning rather than preserving irrelevant distinctions everywhere.

## Duplicates, dates and resource bounds need their own tests

An object literal or parsed object cannot test rejected duplicate JSON members after a parser has discarded them. Supply raw text such as `{"mode":"safe","mode":"other"}`. If duplicate rejection matters, use a qualified duplicate-aware parser; a regex over JSON text or a post-parse key scan is not a general solution. When last-member-wins is the accepted contract, test it as such.

For dates, distinguish calendar dates, instants with an offset, and local scheduled times with a named time zone. Validate calendar validity and any daylight-saving ambiguity policy. Do not convert a calendar date to a UTC instant merely for storage convenience when that changes meaning. Test leap days, invalid days, offset bounds and ambiguous/nonexistent local times only where the contract uses them.

Bound raw bytes, decompressed bytes, nesting and collection counts where each can exhaust resources. A tiny compressed body may decode into a large one; an item-count limit alone need not bound recursive content. Test just-below/at/above actual limits and assert rejection before prohibited effects.

## Source notes

The examples are newly authored policies. Relevant technical basis, checked 2026-09-08: [ECMAScript JSON serialization](https://tc39.es/ecma262/multipage/structured-data.html#sec-json.stringify) and [OWASP authorization](https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html). The temporal and resource cases are design questions for the project's own contract, not a claim that these sources choose its policy.
