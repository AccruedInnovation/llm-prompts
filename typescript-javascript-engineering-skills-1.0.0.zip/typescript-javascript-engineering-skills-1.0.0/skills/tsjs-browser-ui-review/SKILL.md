---
name: tsjs-browser-ui-review
description: Review browser-specific TypeScript/JavaScript UI behavior, accessibility, DOM trust boundaries, CSP/XSS, SSR/hydration, routing, storage, service workers, performance, and browser compatibility.
---

# TS/JS Browser and UI Review

Apply only when a browser or browser-like runtime is part of the declared subject. Do not presume one framework or rendering model.


## Review method and limits

Start with the requested claim and affected code, callers, configuration and tests. Keep a review read-only unless repair is authorized. Use cheap reliable checks early, but do not block useful source review on an unavailable build or call a mandatory unrun check passed. Trace a concrete failure before recommending a repair. Test the strongest reasonable rebuttal: an existing boundary check, intentional scope limit, different consumer promise, or resource owner elsewhere may resolve the concern.

Report material findings with location, expected versus observed behavior, consequence, evidence strength, smallest repair and a closure check. Distinguish observed defects, supported analytical defects/risks, missing evidence, and advice. Preserve valid uses and harmless private choices. Do not add findings to meet a quota. Stop once the assigned claims and risky boundaries have sufficient coverage; state unreviewed scope.

Use existing revision and changed-file information. Record only evidence needed for the claim; defer optional hashes to final delivery and avoid self-hashing manifests or metadata repair loops. A skill does not grant installation, network, credentials, publication, deployment, or destructive authority. Same-session self-review is not independent review.

## Bind the browser contract

Record:

- supported browsers, versions and devices;
- client-only, SSR, static, server-driven, or hybrid rendering;
- bundler, CSS/asset pipeline and source maps;
- hydration and server/client data boundary;
- routing/history model;
- storage, cookies and service workers;
- accessibility requirements;
- CSP, Trusted Types and security posture;
- performance and bundle budgets;
- real-browser test coverage.

## Correctness and state

Review:

- ownership of server, URL, global, component and derived state;
- stale async results and request cancellation;
- optimistic updates and rollback;
- race conditions between navigation, hydration and data loading;
- focus, selection and scroll preservation;
- error, empty, loading and offline states;
- event listener and observer cleanup;
- browser storage versioning and corruption;
- service-worker update and cache invalidation.

## Accessibility

Inspect applicable:

- semantic HTML and landmark structure;
- accessible names and descriptions;
- keyboard navigation and visible focus;
- focus movement for dialogs, errors and route changes;
- screen-reader announcements;
- form labels, validation and error recovery;
- contrast, motion and reduced-motion behavior;
- zoom/reflow and responsive layout;
- pointer alternatives;
- automated versus manual coverage.

Accessibility is behavior, not only lint output.

## Security and privacy

Review:

- unsafe DOM/HTML sinks;
- URL and navigation construction;
- CSP and Trusted Types integration;
- `postMessage` origin/source/payload validation;
- cookies, storage and cross-origin credentials;
- CSRF/CORS assumptions;
- secrets and private data in bundles;
- source-map exposure;
- third-party scripts and analytics;
- service-worker scope and cache poisoning;
- SSR/hydration injection boundaries.

## Performance

Use measured evidence for:

- bundle and route chunk size;
- startup and interaction latency;
- main-thread blocking;
- rendering and layout work;
- network waterfalls and caching;
- image/font/asset behavior;
- memory retention and detached DOM;
- long tasks and event-loop delay;
- server-render and hydration cost.

Do not recommend a framework rewrite, code splitting, memoization, workers, or server-driven UI without a demonstrated requirement and cost model.

## Testing

Use real browsers for claims involving:

- layout, accessibility tree or focus;
- navigation/history;
- service workers and cache;
- CSP/security policy;
- browser APIs and scheduling;
- SSR hydration;
- supported-browser compatibility.

DOM emulation remains useful for fast component logic but is not sufficient evidence for every browser assertion.

## Output

Classify findings as browser correctness, accessibility, security/privacy, hydration, routing/storage, service-worker/cache, performance, compatibility, or evidence gap. State browsers and artifacts tested, what was emulated, and what remains unqualified.

## Trace complete user workflows

Start overlapping reads, resolve the newer one first, then complete or fail the older one. Inspect visible data, loading/error state and owned resources; abort alone may not suppress a late callback. For optimistic writes, test two updates and a delayed failure: a rollback must not erase a newer accepted change. Cancellation does not undo a server write.

Navigate away during a load, change route parameters, and return. Check the state owner, disposal, focus/scroll policy and stale error handling. Choose request identity, version checks or framework-native invalidation according to the actual workflow; do not impose latest-wins on actions that must all complete.

For a dialog or form, use keyboard-only open, focus movement, validation error, successful action and close. Check accessible name, announced errors, visible focus and focus return; include zoom/reflow and representative assistive technology where required. A lint pass alone does not establish the interaction.

During an application update, keep an old page open while a new deployment becomes available. Exercise a later lazy chunk, offline load, service-worker activation and storage/schema compatibility. Do not delete assets or caches still needed by supported active clients without a recovery policy.

Apply framework-specific details only when that framework is present. React effect setup must have matching cleanup; disabling Strict Mode is not a repair for a leaked subscription. SSR request-specific state must not live in a shared mutable module singleton. The worked cases include these conditional checks; they do not mandate a framework or rendering rewrite.

## Targeted methods and references

Read only the relevant [worked cases](references/worked-cases.md), [performance-policy](references/performance-policy.md). Use the failure, repair, proof and valid countercase to guide the task; these examples are not mandatory project designs. Do not load every reference by default.
