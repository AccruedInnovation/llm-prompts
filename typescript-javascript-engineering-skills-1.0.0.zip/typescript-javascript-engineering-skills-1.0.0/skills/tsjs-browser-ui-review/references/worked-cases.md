# Worked browser workflows

Review the project's real user interaction and supported browsers. The pure state examples below can run under Node to test ordering; that does not establish browser, accessibility, React or SSR integration behavior.

## Older results must not overwrite a newer read

**Use:** latest-request search or detail view. **Failure:** request A starts, B starts, B finishes, then A overwrites B. Aborting A alone may not prevent a callback that already completed or a callee that ignores the signal.

**Chosen repair:** operation identity protects the local commit; cancellation also requests resource cleanup. This example assumes trusted synchronous `commit` and `report` callbacks that do not throw. It does not parse an HTTP payload or undo a submitted write.

<!-- example: latest-loader -->
```js
export function makeLatestLoader(fetchValue, commit, report) {
  let version = 0;
  let controller;
  let disposed = false;
  return {
    async load(key) {
      if (disposed) throw new Error("loader is disposed");
      const ownVersion = ++version;
      controller?.abort();
      const ownController = new AbortController();
      controller = ownController;
      commit({ status: "loading", key });
      try {
        const value = await fetchValue(key, ownController.signal);
        if (!disposed && ownVersion === version) {
          commit({ status: "ready", key, value });
        }
      } catch (error) {
        if (!disposed && ownVersion === version && !ownController.signal.aborted) {
          commit({ status: "failed", key });
          report(error);
        }
      } finally {
        if (ownVersion === version) controller = undefined;
      }
    },
    dispose() {
      disposed = true;
      version += 1;
      controller?.abort();
      controller = undefined;
    },
  };
}
```

**Proof:** use controlled completion barriers, not sleeps. Make fetch deliberately ignore abort; complete B then A and confirm B remains visible. Reject A after B succeeds; no stale error should appear. Dispose during a load; late completion must not commit. A current request failure must end its loading state and reach the error observer. A post-disposal load must reject rather than quietly restart.

**Limits:** a fetch that never settles remains pending; local stale-result protection is not proof of canceled network/server work. Data validation belongs at the actual response boundary. **Valid countercase:** events or writes that must all complete need ordered/accumulating semantics, not latest-wins. Prefer a framework's existing query invalidation when it enforces the contract.

## Optimistic failure must not erase newer success

**Inspect:** operation identity, baseline version and the authoritative result. **Failure:** edit A optimistically changes a field, edit B changes it again and succeeds, then A's late failure restores the original field.

**Repair:** reconcile or roll back only the state still owned by A, or refetch authoritative state using the current version. Do not rely on a captured object alone. **Proof:** control both completion orders and assert newer accepted state survives. Inspect the server's final state as well as the UI. Abort of a submitted write is not rollback.

**Valid countercase:** an explicit single-flight editor prevents B from starting until A finishes. Verify the enforced rule before adding multi-operation bookkeeping.

## A React subscription needs matching cleanup

Apply only in a React project. This complete hook illustrates a browser subscription, not a network fetch policy:

<!-- example: react-cleanup -->
```tsx
import { useEffect, useState } from "react";

export function useViewportWidth(): number | null {
  const [width, setWidth] = useState<number | null>(null);
  useEffect(() => {
    const update = () => setWidth(window.innerWidth);
    update();
    window.addEventListener("resize", update);
    return () => window.removeEventListener("resize", update);
  }, []);
  return width;
}
```

**Proof in the actual project:** mount, perform a resize, unmount, and repeat. Observe one active subscription while mounted and none after unmount. Exercise development Strict Mode's extra setup/cleanup cycle; do not disable it or add a one-time flag to conceal missing cleanup. Keep initial server/client markup consistent for the `null` state in the consuming UI.

**Valid countercase:** a framework or host owns the subscription and guarantees disposal. Verify that owner rather than adding a redundant effect. This bundle's syntax check of this snippet does not claim React execution or actual browser evidence.

## SSR state must belong to its request

**Failure:** a mutable module singleton stores the current user's data, and an interleaved request reads it. Clearing it after response completion does not prevent overlap.

**Repair:** allocate request-local application/store state and pass it to the render. For Vue SSR, use the framework's per-request application/store pattern; other SSR frameworks have their own lifetime rules. Keep caches separate and key/isolate any user-specific entries.

**Proof:** interleave two requests with distinct user/tenant markers and an explicit barrier. Assert each response and serialized hydration payload contains only its allowed marker, including error paths. Render actual pages in the project's SSR harness; a pure function test alone is not the integrated proof.

**Valid countercase:** a shared immutable template or an appropriately partitioned public-data cache. Do not outlaw all module-level values.

## Dialog, form and navigation accessibility

Use a real browser and required assistive technology. Open the dialog with a keyboard, inspect the accessible name and focus destination, tab in both directions, produce a validation error, correct it, complete the action, close and inspect focus return. Check what happens if the original trigger no longer exists. Do not let a loading overlay or route change strand focus.

Test visible focus, labels/descriptions, error announcements, reduced motion and zoom/reflow against actual requirements. Automated checks help find defects; they do not prove all of this behavior. Prefer semantic/native controls when they meet the interaction contract, and test them in the supported environments rather than assume correctness from tag choice.

## Old page plus new deployment

Keep an old page open, deploy a new build, then visit a not-yet-loaded route. Test old chunk URLs, service-worker update/activation, offline behavior, storage migration and recovery from missing assets. Decide how long old assets remain available and how clients recover before deleting them; bound storage without breaking active clients.

Inspect version agreement among HTML, JS/CSS, worker, storage schema and API. Forced reload may lose user work; test the chosen update experience and compatibility policy. **Valid countercase:** a static site without service workers or persisted state need not add them to pass this review.

## Source notes

Checked 2026-09-08: [React useEffect](https://react.dev/reference/react/useEffect), [Vue SSR state isolation](https://vuejs.org/guide/scaling-up/ssr.html#cross-request-state-pollution), and [W3C modal dialog pattern](https://www.w3.org/WAI/ARIA/apg/patterns/dialog-modal/). The ordering/update scenarios are new engineering cases. They do not mandate latest-wins, an SSR framework, or a service-worker architecture.
