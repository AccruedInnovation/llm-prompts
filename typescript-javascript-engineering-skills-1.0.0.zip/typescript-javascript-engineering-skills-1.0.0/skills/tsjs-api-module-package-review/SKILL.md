---
name: tsjs-api-module-package-review
description: Review public TypeScript/JavaScript APIs, ESM/CommonJS behavior, conditional and subpath exports, declaration resolution, package contents, clean installation, actual consumers, and compatibility.
---

# TS/JS API, Module, and Package Review

Review the artifact consumers actually receive, not only source files in the workspace.


## Review method and limits

Start with the requested claim and affected code, callers, configuration and tests. Keep a review read-only unless repair is authorized. Use cheap reliable checks early, but do not block useful source review on an unavailable build or call a mandatory unrun check passed. Trace a concrete failure before recommending a repair. Test the strongest reasonable rebuttal: an existing boundary check, intentional scope limit, different consumer promise, or resource owner elsewhere may resolve the concern.

Report material findings with location, expected versus observed behavior, consequence, evidence strength, smallest repair and a closure check. Distinguish observed defects, supported analytical defects/risks, missing evidence, and advice. Preserve valid uses and harmless private choices. Do not add findings to meet a quota. Stop once the assigned claims and risky boundaries have sufficient coverage; state unreviewed scope.

Use existing revision and changed-file information. Record only evidence needed for the claim; defer optional hashes to final delivery and avoid self-hashing manifests or metadata repair loops. A skill does not grant installation, network, credentials, publication, deployment, or destructive authority. Same-session self-review is not independent review.

## Bind the package contract

Record:

- package manager and lockfile;
- package name, version, privacy and publication policy;
- `type`, `main`, `module`, `browser`, `types`, `typesVersions`, `exports`, `imports`, `bin`, `files`, and `sideEffects`;
- source and output extensions: `.ts`, `.mts`, `.cts`, `.js`, `.mjs`, `.cjs`, `.d.ts`, `.d.mts`, `.d.cts`;
- TypeScript `module` and `moduleResolution`;
- transpiler, bundler, declaration emitter, minifier, and source-map policy;
- supported runtimes, bundlers, TypeScript versions, conditions, and consumers;
- whether ESM, CommonJS, or dual publication is actually claimed.

## Public API review

Inspect:

- root and subpath exports;
- runtime values versus type-only exports;
- declaration paths and module format;
- accidental exports through barrels;
- deep imports previously used by consumers;
- default/named export interop;
- callable/constructable behavior;
- thrown/rejected error contracts;
- callback, event, and async behavior;
- public data/schema compatibility;
- side effects at import time;
- tree-shaking declarations and reality;
- browser/server split.

A change may be source-type compatible but runtime-breaking, or runtime-compatible while declaration-breaking. Report these separately.

## Resolution surfaces

Evaluate applicable combinations:

```text
TypeScript NodeNext or Node16 consumer
TypeScript bundler-mode consumer
Node ESM import
Node CommonJS require, only when claimed
plain JavaScript consumer
browser bundler consumer
Bun/Deno/Worker consumer, only when claimed
custom export conditions
exact plugin or extension host, when claimed
```

Check condition ordering and whether unsupported consumers receive an explicit failure rather than an accidentally wrong implementation.

## Packaged artifact

Inspect a clean pack/dry-run result or equivalent:

- included and excluded files;
- generated declarations and maps;
- README/licence/package metadata;
- executable bins, shebangs and modes;
- stale source-only paths;
- undeclared dependencies hidden by workspace hoisting;
- missing runtime assets, schemas, WASM/native files, CSS, or templates;
- source maps referencing unavailable or sensitive sources;
- package size and unexpected secrets;
- lifecycle scripts and build assumptions.

Then install the packed artifact into a clean consumer when the assurance contract requires it. Do not use the source workspace as the only consumer.

## Compatibility dimensions

Assess independently:

- TypeScript source and inference;
- runtime API and behavior;
- module resolution;
- package contents;
- exported conditions and subpaths;
- CLI behavior;
- wire/schema or persistence contracts;
- supported runtime versions;
- mixed-version or migration behavior.

SemVer tooling is supporting evidence, not the sole compatibility authority.

## Gate guidance

Typical material or consequential evidence includes:

```text
semantic type check
clean build
built entry-point load
clean declaration emit
pack dry run and archive inspection
clean consumer install
ESM consumer
CommonJS consumer if claimed
TypeScript consumer configurations
CLI execution if applicable
browser/host load if applicable
```

Do not require dual-package testing when the package does not claim dual support.

## Output

Return exact package subject and digest, consumers tested, conditions exercised, declarations inspected, files included, compatibility dimensions, failures, and residual gaps. Distinguish packaging failure, resolver mismatch, declaration defect, runtime defect, unsupported consumer, and test-infrastructure failure.

## Planned structure

When a project design fixes these boundaries, treat package manifests, public entry points, conditional exports, declarations, runtime exports, browser/server splits, generated clients, and clean consumer fixtures as consequential artifact and contract topology. Compare planned and actual consumer shape, not merely source imports. A private module move is not material unless it changes ownership, public resolution, declarations, effects, behavior, or a fixed decision.

## Trace one consumer completely

Record requested specifier, requesting file's module mode, runtime/compiler versions, active conditions, selected runtime file, selected declaration file and observed behavior. Use `--traceResolution` or the project's equivalent to establish a disputed type path; resolve and execute the actual runtime path separately.

Inspect `exports` condition order and declaration format. TypeScript does not read `typesVersions` in cases where it reads `exports`; listing both is not proof a fallback works. `paths` informs TypeScript resolution but does not rewrite emitted imports. A bundler may supply a runtime mapping; verify rather than assume it is missing or present.

Tie CommonJS/ESM findings to the supported Node version and graph. Some Node versions can `require()` suitable synchronous ESM; top-level await changes that condition. Do not prescribe universal dual output or assert a version-free interoperability rule. When both paths are promised, exercise both in one process if identity, caches, class instances or singletons matter. Two isolated load passes do not establish shared identity.

For a package claim, build using the declared process, pack an actual archive, inspect contents, install outside the source workspace and exercise public entry points plus their declaration consumers. Remove access to source aliases and hoisted dependencies. Use a disposable location and approved dependency policy; `pack`, install and lifecycle hooks can have effects. A dry-run list is not an installed-consumer test.

Verify native TypeScript execution against the host's exact syntax and config handling. Node type stripping ignores tsconfig and does not run a semantic checker; supported syntax and flags vary by version. Do not turn local execution into a universal runtime claim.

## Targeted methods and references

Read only the relevant [worked cases](references/worked-cases.md), [runtime-module-model](references/runtime-module-model.md), [compatibility-policy](references/compatibility-policy.md). Use the failure, repair, proof and valid countercase to guide the task; these examples are not mandatory project designs. Do not load every reference by default.
