# Runtime, module and artifact model

The effective TS/JS product is defined by several independently versioned tools and contracts:

```text
source language mode
  → semantic checker
  → transformer/emitter
  → bundler/minifier
  → declaration emitter
  → package/archive/container
  → runtime/host
  → actual consumer
```

Record each separately. A project may use different TypeScript versions for command-line checking, compiler APIs, language services and lint integrations.

## Module contract

Capture:

- package `type`;
- `.ts/.mts/.cts` and `.js/.mjs/.cjs` use;
- TypeScript `module` and `moduleResolution`;
- `verbatimModuleSyntax` and interop settings;
- `exports`, `imports`, `types`, `typesVersions`, `main`, `module`, `browser` and `bin`;
- conditions and subpaths;
- dynamic import and top-level await;
- path aliases and runtime equivalents;
- supported ESM/CommonJS/bundler consumers.

Do not add dual publication merely for compatibility optics. Separate implementations can create distinct runtime identities and declaration surfaces. Check the actual arrangement; a shared implementation can avoid duplicate state but does not remove consumer checks.

## Runtime-native TypeScript

A runtime executing TypeScript syntax may erase types without running the project's semantic checker or respecting its complete `tsconfig`. Treat runtime-native execution as an emit/runtime mechanism, not as proof of type correctness.


The diagram is a list of distinct evidence responsibilities, not a mandatory order. Checking and declaration generation may run beside bundling; some projects need no bundler or declaration output. Native execution differs by runtime/version: for example, Node's type stripping does not run a semantic checker and ignores tsconfig. Check required syntax and runtime flags instead of generalizing from one host. See [Node TypeScript documentation](https://nodejs.org/api/typescript.html), checked 2026-09-08.
