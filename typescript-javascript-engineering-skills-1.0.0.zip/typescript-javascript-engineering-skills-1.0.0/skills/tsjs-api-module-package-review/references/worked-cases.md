# Worked resolution and packed-consumer review

## Exports, declarations and typesVersions select different paths

**Use:** a package advertises both `exports` and a legacy declaration path. **Failure:** an agent assumes `typesVersions` supplies a fallback even when the resolver is reading `exports`.

The small package below intentionally includes a decoy legacy declaration. It promises ESM import only. It is a test fixture, not a publication template or recommendation to ship conflicting declarations.

`package.json`:

<!-- example: esm-package-json -->
```json
{
  "name": "tsjs-skill-consumer-demo",
  "version": "1.0.0",
  "private": true,
  "type": "module",
  "types": "./legacy/index.d.ts",
  "typesVersions": { "*": { "*": ["legacy/index.d.ts"] } },
  "exports": { ".": { "types": "./dist/index.d.ts", "import": "./dist/index.js" } },
  "files": ["dist", "legacy"]
}
```

`dist/index.js`:

<!-- example: esm-runtime -->
```js
export function marker() { return "exports"; }
```

`dist/index.d.ts`:

<!-- example: esm-declaration -->
```ts
export declare function marker(): "exports";
```

`legacy/index.d.ts` (deliberate decoy):

<!-- example: legacy-declaration -->
```ts
export declare function marker(): "legacy";
```

A NodeNext consumer named `consumer.mts`:

<!-- example: esm-consumer -->
```ts
import { marker } from "tsjs-skill-consumer-demo";
const selected: "exports" = marker();
console.log(selected);
```

**Trace:** the ESM request chooses the root export. TypeScript reads the `types` branch and accepts the `"exports"` literal contract; `typesVersions` is not read on that path. Node import selects `dist/index.js`. Record requesting file mode, conditions, versions and selected files. Compile the consumer in NodeNext mode and run it separately. A compiler declaration pass is not runtime evidence.

**Valid countercase:** an older or differently configured supported resolver may use the legacy route. Test that separate promise. Do not treat absence of CommonJS support here as a defect.

## Pack, install, and test outside the source workspace

For a real project, first complete its approved build. Inspect scripts and dependencies before packing. For the tiny no-dependency fixture above, an explicit local example is:

```text
npm pack --ignore-scripts --json --pack-destination <disposable-output>
```

Use the returned actual archive name; do not guess it from package metadata. Inspect the tar contents and install that archive in a separate temporary consumer with no source aliases or workspace dependencies. For this no-dependency fixture, `npm install --offline --ignore-scripts --no-audit --no-fund <absolute-tarball-path>` needs no registry access when the environment provides npm itself. For real packages, use the project's allowed install flags, cache/network policy and required lifecycle behavior instead of silently skipping necessary scripts.

Compile and execute `consumer.mts` from that clean consumer. Test public subpaths and expected unsupported paths, declaration/runtime agreement, bins and assets only where claimed. If supported builds use a bundler, test its production consumer path too. A source-workspace pass, pack file list or tar extraction alone is not this evidence.

**Discrimination check:** omit a required declaration or runtime asset from a disposable bad tarball. The appropriate consumer check must fail; repair the artifact and repeat the same path. Do not mutate the only real release artifact to perform a probe.

## A path alias can type-check and still fail at runtime

**Inspect:** source specifier, effective `paths` mapping, emitted specifier and actual runtime loader. TypeScript's `paths` does not rewrite the emitted import. If a plain Node consumer receives that alias without another resolver, loading can fail.

**Repair:** use a valid runtime/package specifier, package imports/exports where appropriate, or the already-declared bundler/runtime mapping. **Proof:** execute emitted code outside the source workspace. **Valid countercase:** the shipped bundler output has resolved the alias correctly. Do not report all aliases as defective or add another alias to hide an installed-consumer failure.

## Dual-module identity and native TypeScript are versioned claims

For promised ESM/CommonJS consumers, load both from one installed artifact in the same process where identity matters. Create an instance through one path and pass it to the other; inspect `instanceof`, caches, registrations and singleton state. Distinct implementations can duplicate state. A shared implementation can avoid this, so inspect rather than assume the hazard.

Modern Node behavior for requiring ESM depends on version and whether the module graph is synchronous. Test the supported graph, including transitive top-level await where relevant, instead of repeating a version-free rule. An export map can still intentionally deny a path independent of those runtime abilities.

For Node's native type stripping, inspect syntax, file extensions, runtime flags, module resolution and config expectations. It ignores tsconfig and does not perform semantic checking. A `.ts` file that runs on one host does not prove a declaration, bundle, consumer or other runtime works. Do not choose a new toolchain solely because it is newer.

## Source notes

Checked 2026-09-08: [TypeScript module reference](https://www.typescriptlang.org/docs/handbook/modules/reference.html), [Node CommonJS/ESM interop](https://nodejs.org/api/modules.html#loading-ecmascript-modules-using-require), [Node native TypeScript](https://nodejs.org/api/typescript.html), and [npm pack](https://docs.npmjs.com/cli/v10/commands/npm-pack/). Commands above are illustrative and effectful; the fixture test records the exact local versions it actually uses.
