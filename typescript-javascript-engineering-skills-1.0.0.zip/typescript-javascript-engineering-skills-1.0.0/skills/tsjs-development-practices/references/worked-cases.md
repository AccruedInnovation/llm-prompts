# Worked implementation decisions

These are small teaching examples, not required APIs or a new runtime library. Start from the project's actual contract. Each case names a failure, a bounded repair, a distinguishing check and a valid alternative.

## A result belongs to one request

**Use:** asynchronous reads populate a latest-request view. **Inspect:** combinations of `loading`, `error`, `data` and request identity. Separate flags can express contradictory states or let an old result end a new loading state.

**Repair:** model the relevant states and accept completion only for the active operation. This example chooses latest-request read semantics; it is not a policy for payments, audit events or writes that must all complete.

<!-- example: request-state -->
```ts
export type RequestState<T> =
  | { kind: "idle" }
  | { kind: "loading"; requestId: number }
  | { kind: "ready"; requestId: number; data: T }
  | { kind: "failed"; requestId: number; error: Error };

export function complete<T>(
  state: RequestState<T>, requestId: number, data: T,
): RequestState<T> {
  if (state.kind !== "loading" || state.requestId !== requestId) return state;
  return { kind: "ready", requestId, data };
}
```

**Proof:** start request 2; submit request 1's result; state remains loading for 2. Submit result 2; state becomes ready with its data. A compile-time invalid-state fixture and a runtime transition test prove different things. Add failure/disposal behavior to the real API, not just this success reducer.

**Do not flag:** independent jobs whose results must accumulate. They need a different state contract, not a latest-wins rule.

## A checked property can change

**Use:** code narrows a shared property then calls other code or awaits work. **Failure:** a callee deletes the property and later use throws, although strict compilation succeeds.

**Repair:** save a primitive before the call when the operation is defined over that snapshot. When it must use the latest state, recheck at use; for durable shared writes, use the storage system's conditional update/transaction. `readonly` alone does not stop another reference from changing the object.

**Proof:** have the callee mutate the property; assert snapshot behavior or expected conflict according to the contract. Do not replace a current-state obligation with stale snapshot behavior just to make the test pass.

**Do not flag:** a local immutable value with no intervening mutation path. Assertions backed by a real invariant need not become new parser calls.

## An async callback needs a joining caller

**Use:** a task maps over inputs or registers an event callback. **Failure:** `forEach(async ...)` returns before work completes; `void someTask()` changes no rejection behavior.

**Repair:** use an awaited ordered loop for dependent effects, a joined finite batch for bounded independent effects, or bounded scheduling for large inputs. For a synchronous event callback, deliberately transfer work to an existing task owner and handle rejection. A `.catch()` handler must not introduce an unobserved rejection of its own.

**Proof:** hold task completion behind a barrier. The owning operation must stay pending, or its documented detached-task owner must account for the outstanding work. Fail a task and check who receives the error; shut down and inspect remaining work.

**Do not flag:** a small `Promise.all` batch with independent operations and explicit partial-effect behavior. Serial execution is not always safer or faster.

## A parser cannot grant access

**Use:** a well-formed request names a stored object. **Failure:** the API validates the ID's syntax then updates an object owned by another actor.

**Repair:** parse once, then obtain trusted actor identity, enforce access against stored ownership, and check revision/state at the update. Keep private helpers simple once these facts are established. Do not take ownership solely from a request field.

**Proof:** send a schema-valid foreign-object request with all other guards satisfied. Assert the intended denial and no write/event; also prove an authorized update succeeds. Repeat with a stale revision to isolate conflict handling.

**Do not flag:** a documented privileged operation whose authenticated scope expressly permits that access. Verify its authority and audit requirements instead.

## Source notes

The procedures and cases are new engineering guidance added in this revision. Relevant language facts: [TypeScript object types](https://www.typescriptlang.org/docs/handbook/2/objects.html), [floating promises](https://typescript-eslint.io/rules/no-floating-promises/), and [misused promises](https://typescript-eslint.io/rules/no-misused-promises/). Access-control distinction: [OWASP authorization guidance](https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html). Checked 2026-09-08. Cases are not quotations or source-mandated architectures.
