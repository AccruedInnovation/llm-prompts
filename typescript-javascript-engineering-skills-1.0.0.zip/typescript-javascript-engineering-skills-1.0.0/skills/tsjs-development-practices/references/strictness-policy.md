# TypeScript and checked-JavaScript strictness policy

Strictness describes effective checking of specific files, not their suffix or an umbrella flag. Preserve project policy; treat broader changes as migrations.

## Language modes

- `typescript-strict`: semantic checking runs for the affected files and the strict-family checks provided by that compiler are effectively enabled. Inspect per-option overrides, excluded files, suppressions and `noCheck`. Record any relevant exception rather than hide it in this label.
- `typescript-partially-strict`: semantic checking runs, but one or more relevant strict-family checks are disabled or bypassed. Describe the effective guarantees.
- `typescript-transpile-only`: the path only transforms or executes TypeScript syntax; no authoritative semantic check covers it.
- `javascript-checked`: an identified checker checks the affected JavaScript, via `checkJs`, file-level `@ts-check`, or another configured method. JSDoc supplies type information; it does not enable or run checking. State whether evidence is editor-only or an executed validation command.
- `javascript-unchecked`: no authoritative semantic check covers the path. JSDoc may still assist the editor.
- `mixed`: affected paths have different modes. Map the difference rather than average it.

## Inspect effective settings

Resolve inheritance and project references with the project-pinned compiler. Check file inclusion as well as flags. `allowJs` permits JavaScript in a project; it is not the same as `checkJs`. `strict: true` can coexist with `strictNullChecks: false`. Options such as `noUncheckedIndexedAccess` and `exactOptionalPropertyTypes` are separate choices, not evidence implied by `strict`. `lib` declarations describe available APIs; they do not supply missing runtime APIs.

Run commands against the intended config. For compiler CLI invocations, inspect whether a file list overrides project discovery. Solution configs can delegate checking to referenced projects; inspect those projects, not only the root. Record CLI/compiler API/language-service version differences only when they affect the claim.

## Migration and exceptions

Scope stricter checks to a named risk. Separate modeling defects from dependency noise; preserve public consumer behavior and avoid unrelated suppression churn. Check declaration consumers without hiding relevant errors behind `skipLibCheck`. An assertion can be justified by a real invariant; it is not a runtime validator. `readonly` and the absence of assertions do not establish deep immutability or soundness.

Prefer `@ts-expect-error` over an indefinite ignore for an intentional negative fixture, but isolate the intended error. The directive detects an error on the next line, not a particular diagnostic. Add a valid neighbor; inspect code/location when the exact diagnostic is the claim. Do not match full message text without need.

## Source notes

Technical corrections checked on 2026-09-08 against the official TypeScript documentation: [strict](https://www.typescriptlang.org/tsconfig/strict.html), [JavaScript checking](https://www.typescriptlang.org/docs/handbook/intro-to-js-ts.html), [TSConfig reference](https://www.typescriptlang.org/tsconfig/), and [expected errors](https://www.typescriptlang.org/docs/handbook/release-notes/typescript-3-9.html). Verify behavior with the compiler versions the project supports; these notes do not impose a new compiler version.
