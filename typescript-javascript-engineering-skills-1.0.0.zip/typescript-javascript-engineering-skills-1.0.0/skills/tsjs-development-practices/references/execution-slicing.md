# TypeScript/JavaScript execution slicing

An execution slice is the smallest coherent integrated step that creates useful feedback. It is not one file, one function, one package, one agent or a line-count budget.

Useful TS/JS touchpoints include:

- a built CLI invocation;
- an actual API exchange with runtime validation;
- a packed package installed by a clean consumer;
- a real browser interaction;
- an plugin or extension host load and lifecycle trace;
- a generated artifact inspected from canonical inputs;
- an async cancellation/backpressure/recovery observation;
- a report or document package reviewed by its consumer.

A slice must name one integration owner, exact participating work units and contracts, assertions/evidence, containment or rollback, and every temporary path alias, mock, fixture adapter, shim, generated declaration, temporary export or host stub with its disposition.

Foundation-first work is valid when it supplies a required prerequisite or retires a named risk, has its own inspectable result and check, and identifies its next integrated use. Do not invent a safety risk merely to justify ordinary required foundation work.
