---
name: tsjs-project-preflight
description: Inspect a TypeScript or JavaScript project's effective checker, runtime, build, module, and consumer setup before cross-tool work. Use when that setup is unclear; not for every trivial edit or as a broad code review.
---

# TypeScript/JavaScript Project Preflight

Find the real project contract before changing code. Keep the result small enough to use immediately. Reuse known setup for a narrow edit unless relevant files or assumptions changed.

## Establish the effective project

1. Read applicable repository instructions, the task, affected source, package scripts, and CI checks. Find the actual workspace and package roots. Preserve unrelated local changes.
2. Identify runtime targets and supported consumers: Node.js, browsers, Bun, Deno, Workers, Electron, or an exact extension host. Support is a project claim, not something this skill certifies.
3. Separate semantic checking, transformation, bundling/minification, declaration generation, linting, tests, installation, and execution. Name which command checks which files and which artifact the consumer receives.
4. Inspect inherited configs, project references, file inclusion, exclusions and suppressions. Use the project-pinned checker's `--showConfig`, `--listFilesOnly`, or `--explainFiles` where available and useful. Resolve each relevant project, not only a root solution config. Explicit CLI file lists may bypass a project config; check the actual invocation.
5. Record package manager/version, lockfile, dependency boundaries, module/resolution modes, package entry points, export conditions, build outputs, assets and runtime configuration that affect this task.
6. Classify affected paths using [strictness-policy.md](references/strictness-policy.md). JSDoc is type information, not proof that checking ran. `strict: true` can have strict-family overrides. A build with `noCheck`, a transpiler, or native type stripping is not semantic checking.
7. Choose the smallest useful checks and, when installed, focused skills below. Do not require a full tool survey or create a framework to report a few facts.

## Keep the evidence claims separate

Type checking does not validate incoming JSON, authorize an operation, or prove a package loads. A successful bundler run does not prove types. A source-workspace pass does not prove a packed or deployed artifact works. ESM, CommonJS, TypeScript and bundler resolution can select different paths. Async work still needs ownership, cancellation, cleanup, and state checks.

Use [runtime-module-model.md](references/runtime-module-model.md) to trace the relevant paths, and [support-matrix.md](references/support-matrix.md) for scope limits. The build steps may branch or run independently; they are not a required serial pipeline.

## Select only the relevant skill

| Task | Optional focused skill |
| --- | --- |
| Write or fix code | `tsjs-development-practices` |
| Narrowing, declarations, inference, strictness | `tsjs-type-contract-review` |
| Parsing, configuration, persisted or external data | `tsjs-runtime-data-contract-review` |
| Exports, module resolution, packed consumers | `tsjs-api-module-package-review` |
| Promises, cancellation, streams, retries, cleanup | `tsjs-async-resource-failure-review` |
| Test design, false passes, selection, fixtures | `tsjs-test-strategy-review` |
| Authorization, injection, dependencies, installation | `tsjs-security-supply-chain-review` |
| Startup, deployment, migration, rollback | `tsjs-operational-release-review` |
| Browser state, accessibility, rendering, caches | `tsjs-browser-ui-review` |
| Ownership or planned-versus-actual structure | `tsjs-implementation-structure-review` |
| Reproduce a specific failure or evidence claim | `tsjs-evidence-reproducer` |
| Explicit broad inherited-codebase survey | `comprehensive-analysis-tsjs` |

These names are optional navigation aids, not dependencies. A selected specialist can run alone. Do not activate the whole set, duplicate a review, or load every reference for a private change.

## Example: a build is not a type check

A package uses a fast transformer for its build and an editor reports no errors. Inspect CI and file inclusion before saying its TypeScript is checked. Where semantic checking is absent, report that limit and use the runtime checks that exist. Add a check only within the task's scope. A transpile-only project with explicit runtime tests is not automatically broken or required to migrate tools.

## Return and stop

Return the effective roots/paths, runtime and language modes, relevant commands and subjects, chosen checks, and any missing prerequisite that blocks a specific claim. For a simple task, a few lines suffice; continue the assigned work rather than ending at preflight.

Repository checks and protected requirements remain binding. Skills do not grant network, installation, credentials, publication, deployment, or destructive authority. Inspect effects before running scripts; never install or upgrade tools silently. Avoid metadata churn: use existing revisions and changed-file records during work, finish content and tests first, and compute any useful delivery checksum once at the end. Do not build self-hashing manifests or repair chains for optional metadata.
