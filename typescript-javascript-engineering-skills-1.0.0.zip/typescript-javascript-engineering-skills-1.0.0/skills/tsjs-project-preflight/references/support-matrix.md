# Scope and runtime coverage

This is a guide to applying the skills, not a certification of any runtime or tool version.

| Subject | Treatment |
| --- | --- |
| Node service or CLI | Inspect actual build, checking, configuration, signals, dependencies, artifact and consumer behavior. |
| ESM or CommonJS library | Check only promised consumers, exports, declarations, package contents and runtime behavior. Dual support adds conditions; it is not a default. |
| Browser app or library | Review production bundle, actual browser workflows, accessibility, state, security and caches. DOM emulation cannot establish every browser claim. |
| TypeScript, checked JavaScript, mixed workspace | Determine actual checking per path. Preserve checked JavaScript as a valid design; do not require migration to `.ts`. |
| Monorepo | Inspect package boundaries, inherited configs, project references, aliases, hoisting and clean consumers. |
| Bun, Deno, edge/Worker | Use exact runtime, APIs, deployment limits and consumer fixtures. Node evidence is not proof for another host. |
| SSR or hybrid UI | Test per-request state, server/client boundaries, serialization and actual hydration. |
| Electron, mobile/React Native, extensions | These skills cover shared TS/JS concerns, not full host/device qualification. Add host-specific evidence for the claimed behavior. |
| Native addon or WASM | Inspect the wrapper, packaging, memory/ABI and lifecycle boundary. Native implementation and platform correctness need their own expertise and checks. |
| Untrusted code execution | Do not treat language types or ordinary runtime permissions as a hostile-code security boundary. |

Identify adjacent obligations and unavailable environments rather than overclaiming support. A generic skill needs no profile registry, runtime service, or orchestration host.
