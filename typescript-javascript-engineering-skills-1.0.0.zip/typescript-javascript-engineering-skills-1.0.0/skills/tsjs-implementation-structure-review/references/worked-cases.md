# Worked structure and ownership review

## A private move is not a contract change

**Use:** a helper moves from one file to another. **Inspect:** exports, caller behavior, dependency direction, state/effect owner, generated output and required test access.

**Failure in review:** a reviewer demands identical private file trees even though the task delegates that layout.

**Repair/proof:** compare the required public and ownership contracts and run their relevant checks. Record a harmless private difference without manufacturing a finding. **Valid finding:** the move makes a package import another package's private source or exposes a formerly private export; identify that changed boundary, not file count.

## The API is unchanged but the resource owner changed

**Failure:** a subscription used to start on `start()` and end on `stop()`. A refactor starts it at module import. Types still match, yet tests/imports now allocate resources before initialization and no caller owns cleanup.

**Inspect:** exact start, stop, error and repeated-use paths. **Repair:** restore explicit ownership or obtain authority for the changed lifetime with a real disposal contract. An unchanged function signature is not evidence of unchanged effects.

**Proof:** import the module without starting it; inspect resource acquisition. Start/stop twice, fail initialization and check no remaining subscriptions or duplicate handlers. Use the host's real lifecycle where that is the claim. **Valid countercase:** an intentionally process-owned singleton with explicit startup/shutdown policy; verify the policy instead of banning singletons.

## A foundation step can be legitimate

A parser contract, shared type definition, migration tool or package boundary can be a required precursor. Ask what prerequisite it supplies, who consumes it next and what check establishes its own result. Do not force a fabricated user interface or claim a safety risk merely to justify foundation work. Conversely, a folder of stubs with no useful consumer or proof is not an integrated outcome.

A work step may span source, declarations, schema, build and consumer tests. Keep one integration owner and the smallest coherent result. Temporary aliases, adapters, mock servers and exports need an explicit removal, retained-fixture or supported-product decision, not an automatic permanent place.

## A type abstraction must prevent a real error

**Failure in design:** every string receives a brand, wrappers mirror each function and package splits add only relay calls. **Review:** identify the invalid combination, ownership boundary or change cost each abstraction addresses. Compare a simpler option under the same contract.

**Proof:** an identity abstraction should reject a meaningful wrong-ID consumer and preserve runtime validation where needed. A wrapper should hide a volatile implementation or establish a test/effect boundary. **Valid countercase:** closely related IDs are frequently confused at a material boundary; a small brand/constructor can be justified. Do not remove it merely for line-count reduction.

## Basis

These cases extend the supplied ownership, information-hiding and delegated-freedom rules. They are review methods, not a required folder layout, architecture framework or named contract schema.
