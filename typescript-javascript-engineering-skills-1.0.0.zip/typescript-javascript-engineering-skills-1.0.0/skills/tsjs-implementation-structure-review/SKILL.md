---
name: tsjs-implementation-structure-review
description: Review TypeScript/JavaScript design and implementation structure for module boundaries, shared contracts, state and resource ownership, consumer paths, and planned-versus-actual behavior. Use for architecture conformance or refactoring review, not private layout preferences.
---

# TS/JS Implementation Structure Review

Use for a material ownership, package-boundary, or planned-versus-actual review. A task description, existing design, or concise inline contract is enough; do not demand a separate design document. Do not turn ordinary private layout choices into conformance defects.


## Review method and limits

Start with the requested claim and affected code, callers, configuration and tests. Keep a review read-only unless repair is authorized. Use cheap reliable checks early, but do not block useful source review on an unavailable build or call a mandatory unrun check passed. Trace a concrete failure before recommending a repair. Test the strongest reasonable rebuttal: an existing boundary check, intentional scope limit, different consumer promise, or resource owner elsewhere may resolve the concern.

Report material findings with location, expected versus observed behavior, consequence, evidence strength, smallest repair and a closure check. Distinguish observed defects, supported analytical defects/risks, missing evidence, and advice. Preserve valid uses and harmless private choices. Do not add findings to meet a quota. Stop once the assigned claims and risky boundaries have sufficient coverage; state unreviewed scope.

Use existing revision and changed-file information. Record only evidence needed for the claim; defer optional hashes to final delivery and avoid self-hashing manifests or metadata repair loops. A skill does not grant installation, network, credentials, publication, deployment, or destructive authority. Same-session self-review is not independent review.

## Authority and subject

Bind:

- applicable design, contract, and revision;
- exact slice IDs where applicable;
- exact candidate and relevant local changes;
- effective project and toolchain configuration;
- fixed decisions, delegated freedom, prohibited shortcuts, and acceptance criteria;
- exact assertions assigned to this review.

The applicable project design remains authoritative. This skill proposes findings; it does not change scope, grant effects, waive assertions, or declare readiness/release.

## Type-driven structure checks

Review six meanings of “type”:

1. **Identity:** distinct domain, package, resource, route, message, and host identities do not collapse into interchangeable primitives where confusion is consequential.
2. **State:** consequential closed states and transitions are explicit and exhaustively handled; static types do not conceal runtime transition gaps.
3. **Boundary:** exported types, runtime schemas, declarations, package exports, module conditions, messages, configuration, and consumer behavior remain synchronized.
4. **Ownership:** one package/module owns mutable state, timers, subscriptions, workers, streams, caches, processes, AbortSignals, cleanup, and source-of-truth decisions.
5. **Failure:** absence, rejection, conflict, timeout, cancellation, partial completion, stale input, degraded operation, and recovery are caller-visible where handling differs.
6. **Evidence:** not-run, blocked, tool error, inconclusive, pass, and fail remain distinct.

Recommend a type or abstraction only when it prevents a material invalid combination, localizes an invariant, clarifies ownership, stabilizes a boundary, improves change locality, creates a real seam, or hides consequential complexity.

## Planned-versus-actual materiality

Treat these as normally material:

- public/shared export or declaration surface;
- package `exports`/`imports`, entry-point, ESM/CommonJS, browser, bin, or host/plugin shape;
- runtime schema, serialized event/message, persistence, configuration, or migration contract;
- state/effect/resource owner;
- cancellation, cleanup, stream/backpressure, worker, subscription, process, or shutdown owner;
- fixed decision or prohibited shortcut;
- test seam or touchpoint required for independent work;
- behavior path whose owner or failure semantics changed.

Treat these as normally within delegated freedom unless independently poor:

- private helper names and locations;
- equivalent local iteration style;
- private test utility placement;
- internal refactoring that preserves fixed ownership, public contracts, behavior, effects, and evidence.

Do not use raw file-count or exact private-tree equality as the primary conformance rule.

## Slice quality

A TS/JS execution slice should:

- expose one real CLI, API, UI, package-consumer, protocol/host, report, or other inspectable touchpoint;
- include the TypeScript/static path and the actual emitted/runtime/consumer path where relevant;
- name one integration owner;
- include all packages/modules/contracts required to make the touchpoint real;
- bind explicit assertions and evidence;
- contain or reverse effects;
- name temporary aliases, mocks, fixture adapters, generated declarations, temporary exports, shims, or servers and their disposition;
- enable a clear next slice or capability.

A foundation-first slice is valid when it supplies a required prerequisite or retires a named risk, has its own inspectable result and check, and names the earliest integrated successor. Do not force an artificial end-to-end demonstration before its required foundation exists, or let foundation work postpone real integration without a reason.

## Review disposition

Return exactly one:

- `CONFORMS`;
- `ADVISORY_DIVERGENCE`;
- `MATERIAL_DIVERGENCE`;
- `BLOCKED`;
- `NOT_APPLICABLE`.

For material divergence, identify the exact fixed decision, public/shared contract, owner, behavior path, effect boundary, assertion, or slice affected. For blocked review, identify the missing inventory, built artifact, declaration, consumer, runtime, browser, or host evidence. Preserve delegated private differences without manufacturing findings.

## Distinguish a layout change from an ownership change

Trace one producer-to-consumer path and one failure path through the proposed and actual structure. A private file move can preserve the contract. Moving a subscription into module initialization can instead change who owns its lifetime, even if exports and types stay identical. Check that difference through import, start, stop and repeat-use behavior.

Evaluate a foundation step by its actual required prerequisite and proof, not by a forced vertical-demo rule. Keep one owner for shared contracts and integration. Do not demand branded IDs, an event bus, a dependency-injection framework, or a standalone contract object when a simple API and tests meet the requirement.

Challenge a suspected mismatch against the task's delegated freedom before recording it. When no governing design exists, report a supported design weakness or proposed improvement, not nonconformance to an invented plan.

## Targeted methods and references

Read only the relevant [worked cases](references/worked-cases.md), [implementation-structure](references/implementation-structure.md), [execution-slicing](references/execution-slicing.md). Use the failure, repair, proof and valid countercase to guide the task; these examples are not mandatory project designs. Do not load every reference by default.
