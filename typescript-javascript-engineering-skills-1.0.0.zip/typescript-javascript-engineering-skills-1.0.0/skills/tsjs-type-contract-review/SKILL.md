---
name: tsjs-type-contract-review
description: Review TypeScript and checked-JavaScript static contracts, declarations, inference, narrowing, escape hatches, strictness, and public type compatibility against an exact candidate and assertion set.
---

# TS/JS Type Contract Review

Review compile-time contracts only as far as the configured checker and consumer fixtures support them. Do not confuse type success with runtime validation or artifact loading.


## Review method and limits

Start with the requested claim and affected code, callers, configuration and tests. Keep a review read-only unless repair is authorized. Use cheap reliable checks early, but do not block useful source review on an unavailable build or call a mandatory unrun check passed. Trace a concrete failure before recommending a repair. Test the strongest reasonable rebuttal: an existing boundary check, intentional scope limit, different consumer promise, or resource owner elsewhere may resolve the concern.

Report material findings with location, expected versus observed behavior, consequence, evidence strength, smallest repair and a closure check. Distinguish observed defects, supported analytical defects/risks, missing evidence, and advice. Preserve valid uses and harmless private choices. Do not add findings to meet a quota. Stop once the assigned claims and risky boundaries have sufficient coverage; state unreviewed scope.

Use existing revision and changed-file information. Record only evidence needed for the claim; defer optional hashes to final delivery and avoid self-hashing manifests or metadata repair loops. A skill does not grant installation, network, credentials, publication, deployment, or destructive authority. Same-session self-review is not independent review.

## Bind the checker contract

Record:

- exact TypeScript CLI/compiler API/language-service identities where they differ;
- `tsconfig`/`jsconfig` inheritance and project-reference graph;
- affected package and consumer configs;
- `strict`, `allowJs`, `checkJs`, `noCheck`, `skipLibCheck`, `noUncheckedIndexedAccess`, `exactOptionalPropertyTypes`, `useUnknownInCatchVariables`, and related options;
- module, module resolution, target, lib, JSX, decorators, declaration, and composite settings;
- whether emit is separate from checking;
- public declaration generation and compatibility policy.

If semantic checking is not configured, return that limitation explicitly. Do not manufacture a type-safety pass from transpilation.

## Review areas

### Escape hatches

Inspect applicable uses of:

- explicit and implicit `any`;
- unsafe `unknown` narrowing;
- `as`, double assertions, non-null assertions;
- `@ts-ignore`, `@ts-expect-error`, `@ts-nocheck`;
- ambient declarations and module augmentation;
- broad index signatures;
- unchecked dynamic property access;
- `skipLibCheck` implications;
- generated declarations whose source contract is unclear.

An escape hatch is not automatically a defect. Evaluate its trust boundary, local rationale, public leakage, tests, and removal condition.

### Domain and state modeling

Check:

- discriminated unions and exhaustive handling;
- invalid state combinations;
- primitive identifiers with material confusion risk;
- optional, absent, `undefined`, and `null` semantics;
- state transitions enforced only by call ordering;
- overly broad booleans or partial objects;
- variance, covariance, and callback parameter assumptions where material;
- whether generics preserve or erase useful relationships.

### Public type surface

Review:

- exported functions, classes, values, types, interfaces, namespaces, and modules;
- declaration paths versus runtime paths;
- inferred public return types that expose implementation details;
- overload implementation compatibility;
- conditional and mapped type behavior;
- generic defaults and constraints;
- nominal/branding expectations;
- source compatibility for existing consumers;
- JavaScript/JSDoc consumer behavior where claimed.

### Narrowing and control flow

Check custom type predicates, assertion functions, discriminant logic, catch variables, truthiness narrowing, and impossible branches. A type predicate must be justified by runtime evidence, not merely silence checker errors.

## Evidence methods

Use only applicable methods:

- project semantic type check;
- targeted consumer compilation;
- expected-success and expected-failure type fixtures;
- declaration emit and comparison;
- API/declaration extraction where repository-qualified;
- JavaScript/JSDoc consumer fixture;
- supported TypeScript-version matrix;
- compile-only regression for a reported inference or overload defect.

A snapshot of `.d.ts` text is not sufficient when equivalent declarations may reorder or when consumer behavior is the real assertion. Prefer semantic consumer fixtures for important contracts.

## Strictness changes

Treat enabling strictness options as a migration:

1. identify affected packages and consumers;
2. separate real modeling defects from dependency/tooling noise;
3. estimate suppression or compatibility burden;
4. avoid unrelated mass edits;
5. pin the intended policy in repository configuration;
6. preserve a regression fixture for material discoveries.

Do not recommend “enable every strict flag” as a context-free refactor.

## Output

Return exact assertions and findings. Classify each as:

- checker configuration gap;
- public type compatibility defect;
- unsafe trust transition;
- domain/state modeling weakness;
- declaration/runtime divergence;
- consumer coverage gap;
- advisory style issue.

Include checker identity, configs, commands, affected consumers, compatibility dimensions, evidence, and residual gaps. Use `PASS`, `FAIL`, `BLOCKED`, or `INCONCLUSIVE` only for the assigned type-contract assertions.

## Go beyond escape-hatch counts

Resolve the effective strict-family flags and actual files. Check per-option overrides, project references, file-level suppressions, editor/CLI differences and a build configured with `noCheck`. Separate `strict` from additional choices such as exact optional properties and checked indexing.

Trace narrowing through calls, callbacks, getters, mutable aliases and `await`. A check is evidence about a value at one point, not a guarantee that shared state stays unchanged. Review shallow `readonly`, mutable array aliases, covariance and callback variance at the actual supported compiler settings. Do not infer safety from a lack of `any` or assertions.

For custom predicates, test true and false branches. A predicate that recognizes only small numbers must not claim every false result is nonnumeric. Check assertion functions against runtime failure behavior. Prefer a parser that returns a checked value when repeated property access could read a different value.

For negative type tests, use a positive neighbor and one invalid feature. `@ts-expect-error` does not bind a diagnostic code. When the precise error is the claim, inspect its file, position and code in the project compiler harness. Protect against a fixture passing because of wrong arity, missing imports or missing ambient types. Keep declaration consumer compilation separate from runtime checks.

## Targeted methods and references

Read only the relevant [worked cases](references/worked-cases.md), [strictness-policy](references/strictness-policy.md), [type-driven-development](references/type-driven-development.md). Use the failure, repair, proof and valid countercase to guide the task; these examples are not mandatory project designs. Do not load every reference by default.
