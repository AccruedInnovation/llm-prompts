# Worked static-contract cases

Use the project's supported compiler versions. The paired cases below distinguish compiler behavior from runtime safety. Intentionally defective examples are not recommended code.

## Strict is an effective configuration, not one field

**Inspect:** inherited config, CLI arguments and the actual included file. With `strict: true` and `strictNullChecks: false`, the next declaration compiles; with strict null checking it must fail.

<!-- example: strict-override -->
```ts
export const title: string = null;
```

**Repair/proof:** establish the actual policy, then check this fixture under both settings. A flag migration needs its own scope and consumer checks. **Valid countercase:** a project intentionally using partial strictness; report its limit instead of claiming an unapproved migration is mandatory.

## JSDoc does not enable checking

<!-- example: jsdoc-only -->
```js
/** @type {number} */
export const count = "wrong";
```

**Failure:** this annotation is treated as proof a CI semantic check ran. **Repair/proof:** identify a command that includes the file with JavaScript checking enabled; test that it reports the assignment error. The same file can have useful editor information while no CI checker runs. **Valid countercase:** explicitly unchecked JavaScript; do not call it checked, but do not require conversion to TypeScript.

## Strictly compiling narrowing can fail after mutation

<!-- example: stale-narrowing -->
```ts
function clear(item: { label?: string }): void {
  delete item.label;
}

// Intentionally defective: the call invalidates the earlier check.
export function unsafeLabel(): string {
  const item: { label?: string } = { label: "present" };
  if (item.label !== undefined) {
    clear(item);
    return item.label.toUpperCase();
  }
  return "missing";
}

// Correct only for a contract that uses the captured label.
export function snapshotLabel(): string {
  const item: { label?: string } = { label: "present" };
  const label = item.label;
  if (label !== undefined) {
    clear(item);
    return label.toUpperCase();
  }
  return "missing";
}
```

**Proof:** both compile under the tested strict compiler. `unsafeLabel()` throws; `snapshotLabel()` returns `PRESENT`. For a latest-state contract, recheck the object instead of making this snapshot repair. Inspect effects across callbacks and `await` as well as direct calls.

**Valid countercase:** a callee with no access to the checked object or its aliases, under an enforced ownership contract. Do not report every function call after narrowing as a defect.

## Readonly is not deep immutability

<!-- example: readonly-alias -->
```ts
export function readThroughAlias(): number {
  const owner = { nested: { value: 1 } };
  const view: Readonly<typeof owner> = owner;
  view.nested.value = 2; // Readonly is shallow.
  owner.nested.value = 3; // Another mutable reference still exists.
  return view.nested.value;
}
```

**Proof:** this compiles and returns 3. **Repair:** choose controlled ownership, an appropriate copy, or a suitable immutable representation if the contract needs it. Freezing only the outer object is not deep freezing. Deep freezing arbitrary graphs can have cost and host-object limits; do not prescribe it everywhere.

**Valid countercase:** a readonly view intended only to prevent property reassignment through that API. That is useful even without global immutability. Check mutable arrays too: an alias may insert a value that violates another consumer's narrower assumption. Use readonly parameters where they express no mutation; do not claim they remove all aliases.

## A declared predicate can lie

<!-- example: predicate -->
```ts
// Intentionally defective: a nonzero number is truthy too.
export function isTextWrong(value: unknown): value is string {
  return Boolean(value);
}

export function isText(value: unknown): value is string {
  return typeof value === "string";
}
```

**Proof:** check 1, empty string, nonempty string, null and a plain object. The wrong predicate accepts 1 and rejects the empty string, despite its declared type. Test the false branch too: a predicate recognizing only short strings cannot safely claim every rejected value is non-string.

**Repair:** make the runtime check establish the stated predicate or return a parsed/result value with a narrower claim. **Valid countercase:** a predicate with an enforced invariant and a check that covers its actual domain. Do not replace every predicate with a schema library.

## Source notes

Verified technical basis: [strict](https://www.typescriptlang.org/tsconfig/strict.html), [JavaScript checking](https://www.typescriptlang.org/docs/handbook/intro-to-js-ts.html), [object types and aliasing](https://www.typescriptlang.org/docs/handbook/2/objects.html), and [type compatibility and soundness](https://www.typescriptlang.org/docs/handbook/type-compatibility.html). Checked 2026-09-08. The worked counterexamples are new; rerun with supported project versions rather than infer universal compiler behavior.
