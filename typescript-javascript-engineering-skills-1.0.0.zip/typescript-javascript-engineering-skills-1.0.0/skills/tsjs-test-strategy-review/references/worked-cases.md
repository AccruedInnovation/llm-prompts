# Worked tests that reject false passes

## The expected-error fixture passes for the wrong reason

**Use:** testing a public type rejection. **Inspect:** all diagnostics on the directive's next line, not merely the compiler exit status.

<!-- example: wrong-error-acceptance -->
```ts
declare function acceptsValue(value: unknown): void;

// @ts-expect-error Intended to prove strings are rejected; this claim is false.
acceptsValue("text", "unintended extra argument");
```

The first argument is valid. The extra argument satisfies the directive. A green compile therefore does not prove rejection of strings.

**Repair:** isolate the invalid argument and add a valid neighbor:

<!-- example: intended-negative -->
```ts
declare function acceptsNumber(value: number): void;

acceptsNumber(12);
// @ts-expect-error A string is not accepted by the public numeric API.
acceptsNumber("text");
```

**Proof:** compile the positive and negative fixture. Where the exact diagnostic matters, remove the directive in a disposable copy and inspect code/location: the first case reports wrong arity, the repaired case reports wrong argument type. Do not base acceptance on full message text unless wording is part of the contract. A control that changes the API to accept strings must invalidate the intended negative test rather than pass through an unrelated error.

**Valid countercase:** a broad regression test whose claim is only that the expression is invalid for any reason. State that weaker claim; not every fixture needs a diagnostic API harness.

## Zero selected tests is not completion

**Use:** test scripts, CI filtering or cached runs. **Failure:** a selector misses the intended suite; the runner exits 0 because its policy allows no tests. Another variant pipes a failing check into a successful final command or appends `|| true`.

**Repair:** keep the runner's intended selection explicit and inspect completed case IDs/counts and skips. Preserve nonzero status through the shell/process wrapper. Do not install a new coverage service for this check.

**Proof:** deliberately use an empty selector in a disposable run. A required-test gate must not accept it as proof of the intended suite. Then run the valid selection and confirm completion. An async assertion must be awaited or returned according to the runner's contract.

**Valid countercase:** an intentionally empty optional test partition whose parent verifies required coverage elsewhere. It must not claim the omitted requirement itself passed.

## A negative case reaches the wrong guard

**Use:** an update checks syntax, access and revision. **Failure:** the "foreign tenant" test omits a required field, fails parsing, and asserts only "some error"; authorization can be absent and the test still passes.

**Repair:** supply a valid shape and current revision, use a real foreign owner, assert the authorization outcome, and inspect protected state plus external effects. Keep parser, authority, revision and combined-precedence cases separate.

**Proof:** remove the authorization guard in a disposable mutation or substitute a deliberately defective fixture. The foreign-owner case must fail while its valid neighbor succeeds. Do not change production code merely to demonstrate the mutation; isolate it.

**Valid countercase:** a parser test that explicitly claims only malformed-input rejection. Do not require it to prove access control.

## A runtime mock erases the boundary

**Use:** an installed CLI or package fails outside the workspace. **Failure:** unit tests import source directly and mock the resolver/file loader, so omitted assets or declarations cannot fail.

**Repair:** keep unit tests for logic and add a small built/packed-consumer check for the promised path. Record source, artifact and resolver separately.

**Proof:** omit the needed asset in a disposable defective artifact; the consumer check fails for that omission. Restore it; the same external consumer passes. A build transcript is not a substitute.

**Valid countercase:** isolated pure-function behavior needs no tarball or browser. Match the check to its stated claim.

## Source notes

The negative-fixture behavior follows [TypeScript's expected-error documentation](https://www.typescriptlang.org/docs/handbook/release-notes/typescript-3-9.html), checked 2026-09-08. The selection, guard and mock cases are new review methods; adapt them to the actual runner and contract. Do not assume a runner's defaults without inspecting its version and settings.
