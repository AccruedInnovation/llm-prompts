---
name: tsjs-test-strategy-review
description: Design or review TypeScript/JavaScript type, runtime, integration, package-consumer, browser, property, fuzz, fault, mutation, performance, and evidence strategy proportionally.
---

# TS/JS Test Strategy Review

Design evidence around exact assertions. Do not maximize test count or coverage percentage.


## Review method and limits

Start with the requested claim and affected code, callers, configuration and tests. Keep a review read-only unless repair is authorized. Use cheap reliable checks early, but do not block useful source review on an unavailable build or call a mandatory unrun check passed. Trace a concrete failure before recommending a repair. Test the strongest reasonable rebuttal: an existing boundary check, intentional scope limit, different consumer promise, or resource owner elsewhere may resolve the concern.

Report material findings with location, expected versus observed behavior, consequence, evidence strength, smallest repair and a closure check. Distinguish observed defects, supported analytical defects/risks, missing evidence, and advice. Preserve valid uses and harmless private choices. Do not add findings to meet a quota. Stop once the assigned claims and risky boundaries have sufficient coverage; state unreviewed scope.

Use existing revision and changed-file information. Record only evidence needed for the claim; defer optional hashes to final delivery and avoid self-hashing manifests or metadata repair loops. A skill does not grant installation, network, credentials, publication, deployment, or destructive authority. Same-session self-review is not independent review.

## Separate test layers

### Static and type-level

Use where applicable:

- semantic type checking;
- JavaScript `checkJs` or `@ts-check`;
- expected-success type consumers;
- expected-failure type fixtures;
- declaration emit and public inference checks;
- project-reference and supported TypeScript-version checks;
- lint rules that establish a declared property.

A type test does not prove runtime behavior.

### Runtime component and integration

- pure unit behavior;
- real boundary integration;
- malformed runtime inputs;
- persistence and transaction behavior;
- cancellation, retry and idempotency;
- streams, timers, workers, subprocesses and shutdown;
- actual emitted entry-point execution;
- generated artifact consistency.

### Package and consumer

- pack/dry-run contents;
- clean installation;
- Node ESM import;
- CommonJS require only when claimed;
- TypeScript NodeNext/bundler consumers;
- plain JavaScript consumer;
- CLI bin behavior;
- browser or host loading;
- declaration and source-map resolution.

### Browser and UI

- real browser for behavior emulators cannot establish;
- accessibility and keyboard interaction;
- routing/history and storage;
- SSR/hydration and server/client boundaries;
- CSP/XSS-sensitive behavior;
- service worker/cache behavior;
- supported browser matrix.

## Higher-assurance techniques

Select only when useful:

- property-based testing for broad input/state invariants;
- fuzzing for parsers, decoders, protocols and untrusted structured data;
- model-based/state-machine testing for workflows and async protocols;
- differential testing against a prior version or independent implementation;
- metamorphic testing when exact expected outputs are difficult;
- deterministic failpoints for persistence and multi-step effects;
- mutation testing for important logic and test-suite discrimination;
- performance, bundle-size and memory regression tests.

Missing optional tooling is advisory. A required technique that cannot run is `BLOCKED`.

## Test realism

Review whether tests accidentally rely on:

- workspace hoisting or undeclared dependencies;
- source aliases absent from runtime;
- transpilation different from production;
- DOM emulation for browser-only behavior;
- fake timers for all scheduling behavior;
- mocks that erase the contract being tested;
- shared mutable fixtures;
- network or wall-clock nondeterminism;
- retries that conceal flakiness;
- snapshots without semantic review;
- source files rather than the built or packed artifact.

## Coverage and selection

Coverage is a navigation aid, not a universal release threshold. Ask:

- which critical assertions have no test;
- which lines are covered without meaningful assertions;
- which failures or variants remain unexercised;
- whether generated and package surfaces are included;
- whether tests run under supported runtime/module conditions;
- whether a cheaper deterministic check can establish the same claim.

## Flakiness and retries

Preserve every attempt. Distinguish:

```text
candidate failure
test assertion defect
fixture defect
infrastructure failure
timing sensitivity
known bounded nondeterminism
```

A later pass does not erase an earlier failure. Retry policy must be declared before the run and include a final disposition.

## Evidence preservation

Record:

- candidate revision and relevant local changes;
- runtime, TypeScript, package-manager and test-runner versions;
- package, feature/condition, browser, and environment selection;
- exact command;
- seed and minimized failure;
- corpus or fixture digest;
- all attempts and durations;
- built or packed artifact identity;
- coverage gaps and exclusions.

## Output

Give each material claim one owner and the smallest sufficient set of checks. Avoid duplicate work, but retain complementary evidence and useful independent confirmation. Identify redundant tests, missing layers, unrealistic fixtures, flaky evidence, and inappropriate independence. Return a proportional recommended gate plan rather than “run everything.”

## Execution-slice evidence

For each planned work step, test the declared integrated touchpoint rather than only its technical layers. Bind static, build, runtime, package-consumer, browser, or host evidence separately. Confirm one integration owner, exact candidate revision and relevant local changes, failure containment, and every temporary scaffold's removal, fixture retention, or promotion-review disposition.

## Try to make a wrong implementation pass

Before relying on an important test, name one plausible defect it must catch. Check the test's expected result independently of the implementation; add a bounded deliberate fault where that is the cheapest convincing check. Shared helpers are not automatically wrong, but one algorithm must not generate both the result and its only oracle.

Negative type fixtures need an expected-success neighbor and one invalid feature. Where exact diagnostics matter, inspect code and position. A suppressed arity error is not proof the argument type was rejected. Detect public `any` leakage through meaningful consumer operations, not just text snapshots.

Confirm discovery, selection, completion and failure propagation: intended case names/counts, focus/skip filters, awaited assertions, runner config, cache behavior and shell exit status. A zero-test pass, `|| true`, or a successful final pipeline command is not proof that earlier required checks succeeded. Do not trust a summary when raw output contradicts it.

For each independent guard, use a validly shaped input that passes unrelated guards; assert the intended error and unchanged protected state/effects. Inspect outbox, storage, emitted messages and external calls where the contract forbids them. Test combined violations separately for error precedence. A cancellation rejection alone does not prove running work stopped.

Use controlled completion barriers for ordering tests instead of arbitrary sleeps. Fake time tests timer logic; selected real-runtime tests still matter for I/O and scheduler behavior. Keep emulated, real-browser, packed-consumer and production-artifact claims separate.

## Targeted methods and references

Read only the relevant [worked cases](references/worked-cases.md), [testing-evidence-policy](references/testing-evidence-policy.md). Use the failure, repair, proof and valid countercase to guide the task; these examples are not mandatory project designs. Do not load every reference by default.
