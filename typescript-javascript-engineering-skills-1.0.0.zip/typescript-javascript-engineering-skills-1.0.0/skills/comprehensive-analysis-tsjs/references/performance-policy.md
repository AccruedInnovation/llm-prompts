# TypeScript/JavaScript performance method

Start with a user-visible or operational problem, a workload, and a measurable criterion. Do not prescribe an optimization from syntax alone.

## Diagnose before changing architecture

1. Reproduce a representative workload: payload sizes, concurrent users/tasks, warm/cold state, cache hit rate, runtime, hardware, build mode and relevant limits. Distinguish a selected budget from a measured result.
2. Capture a baseline and variation with repeated samples. Separate startup, throughput, latency tails, allocation and retained memory. Averages alone may hide deadline failures; percentiles from different stages do not simply add into an end-to-end percentile.
3. Profile the path. Distinguish CPU work, I/O wait, downstream saturation, queue delay, rendering/layout, garbage collection and type-check/build overhead. A larger heap is not by itself a leak; inspect retained objects after comparable repeated cycles.
4. State a cause and a bounded repair. Examples: redundant linear scans, unbounded queued tasks, repeated serialization, a retained listener, an avoidable request dependency, or a missing index. Show why the proposed change addresses that cause.
5. Measure the same workload before/after. Check correctness, error/cancellation behavior, memory, and resource bounds as well as speed. Include cold starts or low-volume cases when caching, workers or code splitting add overhead.
6. Keep the change only if the result supports the required gain without unacceptable regressions. Add the smallest stable regression check, documenting noisy environments and margins.

## Choose the repair conditionally

An obvious unbounded buffer or quadratic path at the stated scale can justify an analytical finding before benchmarking. Label it as analysis, state the bound, and measure the candidate before making a speed claim. Do not delay a clear correctness repair to collect irrelevant timings.

Memoization needs bounded keys, invalidation and memory policy. Workers add startup, copying/transfer and coordination cost; they can address CPU contention, not every slow request. Streaming requires producer backpressure and a slow-consumer test. Code splitting can reduce initial load while adding later fetch latency. A framework or native-addon change needs a stronger case than a narrow algorithm or ownership repair.

## Review dimensions

Consider algorithmic work, event-loop delay, startup/module load, bundles/assets, network dependencies, parsing/copying, allocation/GC, retained closures/listeners/caches, streams, worker/process overhead, build/type-check/test time, and diagnostics. Select only relevant dimensions.

## Report

State workload, environment, baseline, samples/variation, attributed cause, proposed or tested repair, observed change, correctness checks and limits. Do not report modeled estimates as measured gains or use a microbenchmark to claim whole-application performance.
