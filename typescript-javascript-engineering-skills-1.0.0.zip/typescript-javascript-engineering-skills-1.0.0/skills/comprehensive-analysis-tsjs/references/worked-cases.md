# Worked broad-review judgments

A survey should find important supported issues and useful next decisions, not maximize criticism. Start with the user's scope and actual consumer path.

## A missing local parser is not always missing validation

**Suspicion:** a private function receives a domain value with no schema check. **Strongest rebuttal:** all callers use a single owned parser before the function, and the value's required assumptions remain valid.

**Inspect/proof:** trace callers and any bypass, mutation, deserialization or plugin path. A supplied parser plus valid consumer coverage can rebut duplicate-validation demands. **Real defect:** an external path bypasses the boundary or mutates a checked field before use. Name that path and its failed assumption; fix its owner rather than adding parsing everywhere.

## A source pass can conceal a missing consumer

**Suspicion:** every workspace test passes but the public package has no installed consumer check. **Inspect:** actual export targets, declaration files, assets and supported environments. Missing evidence alone is not a demonstrated failure.

**Proof:** create a clean consumer of the actual archive. If it cannot load a required asset, record the observed defect. If no consumer environment is available, keep the limit as missing evidence. **Valid countercase:** a private pure function has no publication claim; do not demand package installation for it.

## A concurrency recommendation needs the effect contract

**Suspicion:** a finite `Promise.all` appears in a codebase. **Strongest rebuttal:** items are independent, the batch is bounded and partial effects are acceptable. That can be sound.

**Inspect/proof:** trace input size, active/queued work, ordering, failure and cancellation. An open-ended stream accumulated into all promises or a retry that duplicates committed effects creates a different, supported concern. Recommend the smallest limit or ownership repair, not a blanket serial rewrite.

## Large code is not automatically a bad module

**Suspicion:** a module has many lines or a package has few classes. **Inspect:** public surface, hidden complexity, independent change, coupling and testability. A large cohesive implementation with a small stable API can be preferable to many thin wrappers.

**Repair/proof:** split only when a named responsibility, state owner, volatile dependency or independent test justifies the boundary. Verify the consumer and failure paths after a change. **Valid countercase:** a module mixes independent authorities and forces unrelated changes; explain the actual coupling, not a line-count threshold.

## A reported speed improvement needs the same workload

**Failure:** a warm-cache microbenchmark justifies replacing a framework or claiming lower cold-start latency. **Inspect/proof:** hold workload, environment, inputs and warm/cold conditions comparable; attribute the actual delay. Test memory and error behavior too. State estimates separately. **Valid countercase:** a clear unbounded queue or quadratic loop at the stated scale can justify an analytical risk before measurements, without fabricated benchmark numbers.

## Decide and stop

Return reviewed scope, important preserved behavior, severity-ordered supported findings, the smallest repairs, checks run and exact gaps. Do not infer the entire codebase is defect-free from a sample. Do not create specialist work merely because a specialist exists, and do not require a refactor when no material issue survives rebuttal.

## Basis

These cases apply the supplied comprehensive-review philosophy and the accepted revision goals. They are proposed review methods, not additional product requirements or empirical claims about agent performance.
