---
name: tsjs-operational-release-review
description: Review TypeScript/JavaScript build, artifact, configuration, deployment, migration, source-map, observability, startup, shutdown, rollback, package, CLI, service, plugin, and host readiness.
---

# TS/JS Operational and Release Review

Review the exact artifact and environment intended for use. A source checkout passing tests is not release evidence.


## Review method and limits

Start with the requested claim and affected code, callers, configuration and tests. Keep a review read-only unless repair is authorized. Use cheap reliable checks early, but do not block useful source review on an unavailable build or call a mandatory unrun check passed. Trace a concrete failure before recommending a repair. Test the strongest reasonable rebuttal: an existing boundary check, intentional scope limit, different consumer promise, or resource owner elsewhere may resolve the concern.

Report material findings with location, expected versus observed behavior, consequence, evidence strength, smallest repair and a closure check. Distinguish observed defects, supported analytical defects/risks, missing evidence, and advice. Preserve valid uses and harmless private choices. Do not add findings to meet a quota. Stop once the assigned claims and risky boundaries have sufficient coverage; state unreviewed scope.

Use existing revision and changed-file information. Record only evidence needed for the claim; defer optional hashes to final delivery and avoid self-hashing manifests or metadata repair loops. A skill does not grant installation, network, credentials, publication, deployment, or destructive authority. Same-session self-review is not independent review.

## Bind the release subject

Identify:

- application, service, CLI, library, browser bundle, plugin, extension, worker, or package;
- exact source candidate and relevant configuration;
- runtime versions and operating systems;
- package manager and lockfile;
- build, declaration, bundle, minification and source-map configuration;
- package/container/archive subject;
- deployment and rollback mechanism;
- configuration and secret sources;
- observability and support expectations;
- migration and compatibility obligations.

## Build and artifact integrity

Check:

- clean/frozen installation;
- clean production build;
- separation of type checking and emit;
- generated artifact consistency;
- package/archive inclusion set;
- runtime assets and native/WASM files;
- reproducible or at least provenance-bound output;
- source maps, licences and notices;
- version reporting and build identity;
- no dependency on unpublished source paths, workspace hoisting, or developer-only aliases.

## Startup, shutdown and failure

For services, CLIs, workers and extensions review:

- missing and invalid configuration;
- startup ordering and partial initialization;
- dependency unavailable behavior;
- readiness versus liveness;
- signal and cancellation handling;
- graceful drain and timeout policy;
- child/worker/resource cleanup;
- exit codes and stdout/stderr;
- crash diagnostics and restart behavior;
- late async work after shutdown.

## Configuration

- Resolve configuration once at a boundary where practical.
- Distinguish absent, empty and invalid values.
- Record precedence among files, environment, flags, remote config and defaults.
- Prevent secrets from entering canonical output, logs, client bundles or source maps.
- Validate configuration before irreversible effects.
- Include a safe diagnostic view that redacts sensitive values.

## Deployment, migration and rollback

Review:

- compatible old/new versions and mixed-version windows;
- database or storage migration ordering;
- feature flags and staged rollout;
- cache/schema compatibility;
- deployment interruption and retry;
- rollback after partial migration;
- package or binary side-by-side behavior;
- stale worker, service worker or CDN cache behavior;
- release withdrawal or revocation.

## Observability

Require proportional evidence for:

- structured errors and correlation;
- startup and shutdown state;
- dependency and queue health;
- event-loop delay or saturation where material;
- memory/resource growth;
- retry and duplicate effects;
- user-visible failures;
- source-map availability and access control;
- version/build identity;
- privacy and redaction.

## Subject-specific gates

### Library/package

- pack dry run and archive inspection;
- clean consumer installation;
- declared runtime/module consumers;
- declaration resolution;
- licence/readme/metadata;
- publication provenance where claimed.

### CLI

- bin mapping, shebang and executable mode;
- clean install;
- help/version;
- exit codes;
- stdin/stdout/stderr;
- signals and temporary-file cleanup;
- behavior outside the source workspace.

### Service

- production build and startup;
- config validation;
- readiness/liveness;
- graceful shutdown;
- migration and rollback;
- dependency/fault scenarios;
- operational limits.

### Browser application/library

- production bundle and assets;
- supported browser load;
- CSP/source maps;
- cache/service-worker update;
- SSR/hydration where applicable;
- bundle and performance budgets.

### Plugin or extension

- discovery by the exact host;
- command/tool/hook registration;
- representative invocation;
- restart/unload behavior;
- compatibility diagnostics;
- no leaked process or state.

## Output

Return release subject, environment, artifacts and digests, commands, compatibility matrix, operational findings, rollback status, unsupported configurations, and residual risk. Do not declare release authority; report whether the assigned operational assertions pass.

## Rehearse the actual start, stop and update path

Launch the built/installed result from a different working directory. Load required assets, parse real configuration and inspect error/exit behavior; a source import can conceal missing output or CWD dependence. Resolve package-owned assets from their installed module location, while preserving the defined base for user-supplied relative paths.

Inject partial startup failure after the first resource opens. During shutdown, stop admission, classify in-flight work, drain or abort within the defined deadline, then close owned resources. Repeat the shutdown request and inspect late work. A process exiting does not prove external effects stopped; preserve uncertain outcomes.

Rehearse a mixed-version deployment and rollback against state created by the newer version. Restoring an old binary is not evidence that old code can read the new data. Check source-map diagnosis against the matching build without disclosing sensitive source or payloads. Report rehearsals as executed, analytical, or not run.

## Targeted methods and references

Read only the relevant [worked cases](references/worked-cases.md), [compatibility-policy](references/compatibility-policy.md). Use the failure, repair, proof and valid countercase to guide the task; these examples are not mandatory project designs. Do not load every reference by default.
