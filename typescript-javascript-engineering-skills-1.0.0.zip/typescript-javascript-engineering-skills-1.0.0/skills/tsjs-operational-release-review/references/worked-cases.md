# Worked operational rehearsals

These cases describe tests to run on the real supported artifact in a disposable environment. A written rehearsal is not an executed result. Keep release permission separate from review conclusions.

## The installed CLI loads assets from the wrong directory

**Inspect:** where the CLI resolves its own templates/schemas/defaults and how they enter the archive. **Failure:** source-workspace tests pass, but `./assets/defaults.json` resolves from the caller's CWD and fails when the installed CLI runs elsewhere.

**Repair:** for an ESM module's owned asset, resolve from its module URL, for example `new URL("./assets/defaults.json", import.meta.url)` when that is the actual installed relative layout. For CommonJS, use its appropriate module location. Include the asset in the built/packed output. Preserve the documented CWD rule for user-supplied relative paths; those are a different contract.

**Proof:** pack/install the actual artifact, launch from a separate empty directory, and exercise the asset-dependent command plus help/version, exit status and stdout/stderr. A disposable bad artifact with the asset omitted must fail the consumer test. Ensure it did not fall back to a source checkout.

**Valid countercase:** a CLI intentionally reads a user file relative to CWD. Do not convert all paths to module-relative paths.

## Partial startup and repeated shutdown

**Failure:** configuration passes, a client opens, then a worker fails to initialize. Cleanup only exists on normal shutdown. Or shutdown closes the database while admitted jobs still attempt writes.

**Repair:** define lifecycle ownership and order: reject invalid config before effects; release acquired resources on partial startup; stop new admission on shutdown; drain or cancel owned jobs under the selected deadline; close resources after their last permitted use. Repeated shutdown requests must not trigger duplicate destructive effects. Report ambiguous external completion honestly.

**Proof:** fail each meaningful acquisition point, send shutdown while work is active, and repeat the request. Observe listener/timer/client counts, pending tasks, exit behavior and durable state. Timeout limits the observation; it is not a pass or proof all external work stopped.

**Valid countercase:** a small process with no persistent handles may rely on ordinary completion. Do not add a lifecycle framework solely to satisfy a template.

## Rollback after the new version writes data

**Failure:** a deployment check only restores the old executable without testing data or caches written by the new version.

**Repair:** define whether rollback reads the new representation, uses a compatibility period, restores a qualified backup, or requires a forward correction. Do not pretend an irreversible migration is reversible.

**Proof:** run the new build, create representative new state, interrupt a migration at a supported recovery point, then exercise the declared rollback/recovery path and the old consumer where promised. Include background jobs and client/cache versions in the actual scope.

**Valid countercase:** an explicitly non-rollbackable transition with authorized exposure limits and a tested recovery plan. A reviewer cannot silently waive a required rollback promise.

## Source-map diagnosis and privacy

**Failure:** a trace uses source maps from another build, or published maps expose restricted source. **Repair/proof:** produce an error from the exact minified artifact, resolve it with the matching map and verify the intended access policy and redaction. An available map file alone does not establish correct diagnosis. **Valid countercase:** a product deliberately omits public maps while keeping controlled internal diagnostics; evaluate that promise instead of requiring public source.

## Basis

These are new applications of the supplied operational checks. Verify module/path and process details in the documentation for the actual runtime; no runtime version or successful rehearsal is implied by this guide.
