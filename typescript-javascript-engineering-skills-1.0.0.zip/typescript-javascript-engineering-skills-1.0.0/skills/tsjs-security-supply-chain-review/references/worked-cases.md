# Worked access-control and supply-chain checks

Run security probes only on authorized disposable subjects. Establish input source, protected asset, reachable operation, attacker control and permissions before choosing severity. These cases are defensive review methods, not an instruction to exercise live systems.

## A schema-valid update contains a forbidden field

**Failure:** an endpoint copies a parsed request into a stored object. Syntax validation does not prevent changing an owner/role field the caller may not edit; a mixed allowed/forbidden update can partly mutate before failure.

The example below deliberately defines only a synchronous in-memory policy. Identity comes from trusted authentication context; the stored object supplies its owner. It accepts exactly one editable field and checks all guards before mutation.

<!-- example: field-authorization -->
```js
export function updateDisplayName(actor, record, patch) {
  if (record.ownerId !== actor.id) throw new Error("FORBIDDEN");
  if (patch === null || typeof patch !== "object" || Array.isArray(patch)) {
    throw new Error("INVALID");
  }
  const keys = Object.keys(patch);
  if (keys.length !== 1 || keys[0] !== "displayName" ||
      typeof patch.displayName !== "string" || patch.displayName.length === 0) {
    throw new Error("FIELD_NOT_ALLOWED");
  }
  record.displayName = patch.displayName;
}
```

**Proof:** a correct owner's allowed update succeeds. A foreign owner's valid update returns `FORBIDDEN` with no mutation. A valid owner submitting `{displayName: "new", ownerId: "other"}` receives `FIELD_NOT_ALLOWED`; neither field changes. Also inspect outbox/messages/external calls in the real operation. Isolate each guard with unrelated preconditions satisfied; test combined violations separately when precedence matters.

**Limits/repair:** the example assumes plain decoded data, trusted actor/record and no concurrent async step. For storage, enforce authority and current-state conditions at a transaction or conditional update. This is not a sandbox for malicious in-process objects or a general permission engine.

**Valid countercase:** a separate privileged ownership-transfer API with explicit authority and its own checks. Do not declare it vulnerable solely because this example forbids that field.

## A type or client restriction is not a server guard

**Inspect:** a branded ID, generated client or UI hides forbidden actions, but raw network callers can submit them. **Failure:** the server trusts those constraints without enforcing stored ownership and workflow state.

**Repair/proof:** use a schema-valid request directly against the protected boundary; assert denial and no protected effects. Test authorized behavior too. A CORS policy concerns browser access, not universal server authorization. A TypeScript type describes static assumptions, not who may perform an action.

**Valid countercase:** an internal-only helper reached after a complete trusted boundary. Confirm all callers and reuse that boundary instead of installing duplicate checks everywhere.

## Installation may execute code even during inspection

**Use:** a dependency or build-tool change. **Inspect:** lifecycle scripts, plugins/loaders, native builds, downloaded binaries, package source, registry settings, lockfile and permissions exposed during install/build.

**Failure:** an audit/probe runs arbitrary package scripts with inherited credentials; a successful script-disabled install is then described as proof that a script-dependent artifact works.

**Repair:** inspect metadata and package contents first; use the declared package manager and approved lock state. Suppress scripts for bounded inspection when appropriate, then qualify any necessary scripts only in the authorized isolated environment. Avoid implicit downloads via unpinned `npx`/exec recipes. Do not silently upgrade a tool to run a review.

**Proof:** on a harmless disposable fixture, observe whether the chosen install command executes a marker script and changes the lockfile. Separate that observation from actual required build/runtime behavior. Record unavailable registry/advisory data as a limit rather than fabricating a clean scan.

**Valid countercase:** an approved, required native build under a restricted, qualified job. Script presence alone does not establish malicious intent or an exploitable vulnerability.

## Scope a dependency advisory to the real deployment

Trace affected versions, actual dependency graph, import/load path, exposed input and permissions. Preserve the advisory even if exploitability is uncertain, and distinguish a development/build exposure from a runtime exposure. A "dev dependency" can still execute in CI; a package merely present on disk may not expose the cited runtime path.

Choose a bounded fix consistent with compatibility and dependency policy. Report what the scan and your code-path review prove separately; no vulnerable-package count establishes whole-application security.

## Containment must match the threat model

Node process permissions do not protect against malicious code. An OS/container boundary also needs deliberate privilege, filesystem, network and secret controls; it is not safe solely because it exists. Data parsing cannot neutralize arbitrary code already running in the process. Treat inaccessible threat-model evidence as a gap, not a claim of containment.

## Source notes

Checked 2026-09-08: [OWASP authorization](https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html) and [Node permissions](https://nodejs.org/api/permissions.html). The field-guard and install-discrimination cases are newly authored procedures; their policies are illustrative and do not override project commitments.
