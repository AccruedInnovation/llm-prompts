---
name: tsjs-evidence-reproducer
description: Capture reproducible TypeScript/JavaScript preflight, type, build, test, package, browser, fuzz, performance, and failure evidence with exact subject and environment identity.
---

# TS/JS Evidence and Reproducer

Evidence proves one declared assertion against one exact subject.


## Review method and limits

Start with the requested claim and affected code, callers, configuration and tests. Keep a review read-only unless repair is authorized. Use cheap reliable checks early, but do not block useful source review on an unavailable build or call a mandatory unrun check passed. Trace a concrete failure before recommending a repair. Test the strongest reasonable rebuttal: an existing boundary check, intentional scope limit, different consumer promise, or resource owner elsewhere may resolve the concern.

Report material findings with location, expected versus observed behavior, consequence, evidence strength, smallest repair and a closure check. Distinguish observed defects, supported analytical defects/risks, missing evidence, and advice. Preserve valid uses and harmless private choices. Do not add findings to meet a quota. Stop once the assigned claims and risky boundaries have sufficient coverage; state unreviewed scope.

Use existing revision and changed-file information. Record only evidence needed for the claim; defer optional hashes to final delivery and avoid self-hashing manifests or metadata repair loops. A skill does not grant installation, network, credentials, publication, deployment, or destructive authority. Same-session self-review is not independent review.

## Required identity

Capture as applicable:

```text
candidate revision and relevant local changes
effective project configuration, when relevant
repository revision and dirty state
package/workspace selection
runtime and version
TypeScript CLI/compiler API/language-service versions
package manager and dependency lockfile
transpiler, bundler, declaration emitter, linter and test runner
module and resolution modes
runtime/export conditions
browser/OS/architecture
relevant nonsecret environment and configuration
command and working directory
built artifact or tarball identity (a final digest when useful)
assertion and fixture version
```

Redact secrets. Record only the nonsecret facts needed to reproduce the check; do not hash low-entropy secrets or expose private values through logs.

## Evidence classes

Keep separate:

- semantic type-check receipt;
- lint/format receipt;
- transformation/build receipt;
- declaration receipt;
- built-artifact load receipt;
- test receipt;
- packed-artifact/consumer receipt;
- browser/host receipt;
- security/fault receipt;
- performance or resource receipt.

Do not reuse one class as another.

## Nondeterministic evidence

Preserve:

- every retry and disposition;
- random seed and minimized failing input;
- fuzz corpus/crash digest and budget;
- property counterexample;
- browser trace, screenshot or network log where authorized;
- async/fault injection point and durable state;
- benchmark workload, samples, variance, baseline and machine state;
- mutation inventory and surviving-case disposition;
- test infrastructure failures separately from candidate failures.

Use fresh-run semantic receipts for nondeterministic output; do not demand byte equality unless bytes are part of the claim.

## Reuse

Reuse a prior pass only when the complete dependency closure remains unchanged: candidate, configuration, toolchain, package graph, lockfile, conditions, environment, fixture, assertion and evidence method. Explain the reuse decision.

## Return

Provide assertion, subject, environment, command, result, evidence references, reuse status, limitations, and exact reproduction steps. Keep `PASS`, `FAIL`, `NOT_RUN`, and `INCONCLUSIVE` observations distinct. Record skipped, blocked, and tool-error causes separately; preserve the runner's raw result.

## Structure and slice evidence

Also capture:

```text
applicable design and work-step references
source-to-built-artifact mapping where needed
planned-versus-actual changes where material
fixed-decision and delegated-freedom references
exact package/export/declaration/runtime-schema observations
slice touchpoint and integration owner
scaffolding disposition
candidate revision and relevant local changes
```

A source-tree inventory may establish path presence but not semantic conformance. Public declarations require declaration/consumer evidence; runtime schemas require representative runtime evidence; async/resource ownership may require fault/cancellation evidence; host extensions require exact-host loading.

## Minimize without changing the defect

First capture the actual failure and exact command. Reduce files, inputs and dependencies one dimension at a time, rerunning the intended assertion. Preserve the runtime/module condition, artifact path, error code and required side effects. An unrelated parse or missing-import error is not a successful reproduction of the original failure.

Include a valid control and a repaired control when available. For async failures, use explicit barriers or controlled completion order, preserve timeouts as limits rather than successes, and inspect started work plus state after caller completion. For package failures, retain the packed-consumer path instead of minimizing to source imports that eliminate the cause.

A small note with command, config, outcome, evidence location and limits normally suffices. Keep failed attempts, but do not hash every log or rewrite documents to chase metadata differences. Use a final artifact digest only when it adds useful identity. Reproduction is not an independent review merely because it runs in another subprocess.

## Targeted methods and references

Read only the relevant [worked cases](references/worked-cases.md), [testing-evidence-policy](references/testing-evidence-policy.md). Use the failure, repair, proof and valid countercase to guide the task; these examples are not mandatory project designs. Do not load every reference by default.
