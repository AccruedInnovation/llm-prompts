# Testing and evidence policy

## Distinct claims

Keep semantic checking, lint/format, transformation/build, declarations, component/integration runtime, built artifacts, packed consumers, browser/host, faults/security, and performance evidence distinct. Give each claim one owner and the smallest sufficient set of checks. Independent expectations and complementary methods may both be needed. Do not duplicate checks only to inflate confidence.

## A passing command is not enough

Confirm the intended cases were discovered, selected and completed. Record case names/counts or another sufficient execution record, skips, focus filters, retries and exit status. Zero selected cases, an unawaited assertion, a truncated run or swallowed exit status cannot prove the claim. A fresh run with no cache can help investigate a stale pass; do not discard caches for every check.

For a guard test, satisfy unrelated preconditions, reach the intended guard, assert its rejection class and verify forbidden state changes or effects did not happen. Test combined violations separately when error precedence matters. When useful, show one deliberately wrong implementation the test rejects; do not require mutation testing everywhere.

## Subject, reuse, and missing checks

Use existing revision and changed-file information. Record the tool/runtime, dependency state, target/module conditions, relevant config, fixture and method that affect the claim. Reuse a result when those dependencies remain unchanged; explain the boundary. Rerun affected checks after repair. Do not require unrelated whole-system identity churn.

Use `PASS`, `FAIL`, `NOT_RUN`, and `INCONCLUSIVE` as observations when no project vocabulary exists. Keep raw runner output. Availability, skip, tool error, and blocking cause are separate facts; no unavailable required check becomes a pass. Preserve every retry, seed, minimized failure, relevant trace and benchmark sample. Nondeterministic output needs a semantic check unless exact bytes are the contract.

## Proportional checks

Routine work may need cheap targeted checks; changed boundaries need real integration; distributed artifacts need the actual consumer path where claimed; consequential failure modes may need faults and independent review. Preserve mandatory project checks. Coverage percentage is diagnostic, not a quality verdict.

Use existing test reports; a small result note is enough when it preserves the needed facts. Do not add per-file hashes, seals, or recursive manifests during editing. Finish content first; compute a useful detached delivery checksum only at final handoff. Hashes do not replace tests.
