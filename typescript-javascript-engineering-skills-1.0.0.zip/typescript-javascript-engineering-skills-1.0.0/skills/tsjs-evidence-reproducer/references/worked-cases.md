# Worked reproduction methods

## Reduce the fixture without changing the error

**Use:** a type consumer fails on declaration resolution. **Failure:** a minimized example drops the package config and now fails for a missing import, but the report calls that reproduction of the original type defect.

**Repair:** preserve the requested specifier, module mode, relevant exports, selected declaration, compiler version and diagnostic code/location. Reduce unrelated declarations in small steps. Keep a valid consumer control.

**Proof:** the original and minimized fixture fail at the intended contract; the repaired variant passes the same check. When the exact diagnostic is material, inspect it rather than using an undifferentiated nonzero exit. **Valid countercase:** a broad "does not compile" claim may need less specificity; state that weaker claim.

## Keep the artifact boundary

**Use:** a packaged CLI lacks an asset. **Failure:** the reproducer imports source and creates the asset in the working directory, removing the cause.

**Repair:** include the package recipe or the small inspected artifact, an isolated consumer, the exact command/CWD and required asset operation. Keep all work local unless access is authorized. **Proof:** the bad packed result fails outside the workspace, and the repaired packed result passes. **Valid countercase:** a pure function bug can be minimized without a package; do not retain unrelated build steps.

## Control completion, not elapsed sleep

**Use:** overlapping async operations produce the wrong state. **Failure:** a test waits an arbitrary number of milliseconds and passes only on the review machine.

**Repair:** expose a barrier at the relevant seam, hold one task and complete another deliberately. Keep production scheduling semantics where they matter; do not replace the only real I/O proof with a fake clock.

**Proof:** record exact start/completion order, terminal state and outstanding tasks; include late failure and cancellation. A timeout means the expected observation did not complete, not that the tested invariant held. **Valid countercase:** a test of an actual deadline still needs elapsed-time evidence with a declared tolerance and environment.

## Preserve an honest small report

A useful reproduction record can be one paragraph plus commands: claim, subject/revision and relevant changes, environment, input, expected/observed result, evidence, repair control and limits. Record each retry's result and why it ran. No source hashes are needed merely to document a local code excerpt. A final transferable artifact may use one detached checksum; do not make logs hash one another.

The record must not claim a fresh model review, another operating system, a browser or a host was tested when only a local subprocess ran. Stating a missing check is more useful than a broad unsupported pass.

## Basis

These procedures extend the supplied evidence rules. They introduce no profile registry, receipt schema, remote service, acceptance authority or automatic requirement to hash project files.
