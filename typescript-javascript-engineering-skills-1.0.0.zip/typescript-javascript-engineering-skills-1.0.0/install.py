#!/usr/bin/env python3
"""Copy selected standalone skills into a local Codex skill directory; never overwrite."""
from __future__ import annotations
import argparse
from pathlib import Path
import re
import shutil
import sys

ROOT = Path(__file__).resolve().parent

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dest', type=Path, default=Path.home() / '.agents' / 'skills',
                        help='Destination skill directory (default: ~/.agents/skills).')
    parser.add_argument('--skill', action='append', default=[],
                        help='Install only this skill; repeat to select several. Default: all.')
    parser.add_argument('--dry-run', action='store_true', help='Check and print the plan without writing.')
    parser.add_argument('--list', action='store_true', help='List available skills without writing.')
    args = parser.parse_args()
    sources = {p.parent.name: p.parent for p in sorted((ROOT / 'skills').glob('*/SKILL.md'))}
    if not sources:
        parser.error('No skills found beside this installer.')
    if args.list:
        print('\n'.join(sources))
        return 0
    requested = sorted(set(args.skill)) if args.skill else list(sources)
    unknown = set(requested) - sources.keys()
    if unknown:
        parser.error('Unknown skill(s): ' + ', '.join(sorted(unknown)))
    dest = args.dest.expanduser().absolute()
    if dest.resolve().is_relative_to(ROOT):
        parser.error('Choose a destination outside this extracted bundle.')
    problems = []
    for name in requested:
        src = sources[name]
        text = (src / 'SKILL.md').read_text(encoding='utf-8')
        if not re.search(r'^name: ' + re.escape(name) + r'$', text, re.M):
            problems.append(f'Unexpected skill name in {src / "SKILL.md"}')
        if src.is_symlink() or any(p.is_symlink() for p in src.rglob('*')):
            problems.append(f'Source contains a symlink: {src}')
        target = dest / name
        if target.exists() or target.is_symlink():
            problems.append(f'Already exists; refusing to overwrite: {target}')
    if dest.exists() and not dest.is_dir():
        problems.append(f'Destination is not a directory: {dest}')
    if problems:
        print('\n'.join(problems), file=sys.stderr)
        return 2
    for name in requested:
        print(f'{"Would copy" if args.dry_run else "Copy"}: {sources[name]} -> {dest / name}')
    if args.dry_run:
        return 0
    # Preflight covers all expected conflicts before any copying. On a later I/O
    # failure, retain completed copies and name the partial path; never delete user data.
    current = None
    try:
        dest.mkdir(parents=True, exist_ok=True)
        for name in requested:
            current = dest / name
            shutil.copytree(sources[name], current)  # Fails if a target appears meanwhile.
    except OSError as error:
        print(f'Copy failed at {current}: {error}. Earlier copies may exist; inspect before retrying.',
              file=sys.stderr)
        return 1
    print(f'Installed {len(requested)} skill(s). If Codex does not show them, restart it.')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
