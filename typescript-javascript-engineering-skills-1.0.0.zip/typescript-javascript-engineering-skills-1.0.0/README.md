# TypeScript / JavaScript Engineering Skills

**Version 1.0.0 · 2026-09-08**

Thirteen standalone skills for implementation, focused review and failure reproduction. The set retains the original concern split and adds concrete failures, bounded repairs, checks that expose wrong results, and valid countercases. It does not prescribe one framework, runtime, package manager, schema library, or build system.

These are generic local skills, not a BBK language package. No BBK runtime, profile loader, orchestration service, package manifest, hooks, or MCP connection is required. Each folder under `skills/` contains its own `SKILL.md`, local references and license. You may copy any one folder independently. The installer and test tools at the bundle root are optional maintenance aids; they are not part of the installed skills.

## Install

Extract the archive and open a terminal in `typescript-javascript-engineering-skills-1.0.0`.

With Python 3.10 or newer, install all skills for the current user:

**Windows PowerShell:**

```powershell
py -3 .\install.py --dry-run
py -3 .\install.py
```

**Linux or macOS:**

```sh
python3 install.py --dry-run
python3 install.py
```

The default destination is the current Python user's home directory followed by `.agents/skills`. On a normal Windows account, that is `%USERPROFILE%\.agents\skills`. Run the installer in the same environment as Codex; a Windows account, WSL distribution, container and remote host may have different homes.

For a repository-local install, pass that repository's actual skill directory:

```sh
python3 install.py --dest /absolute/path/to/repository/.agents/skills
```

To install only selected skills, repeat `--skill`:

```sh
python3 install.py --skill tsjs-development-practices --skill tsjs-type-contract-review
```

Use `python3 install.py --list` to list names. On Windows, replace `python3` with `py -3` in these examples.

**No overwrite:** the installer checks every selected target before copying. Any existing selected folder, file or link stops the whole plan before writes. It does not merge, delete, or upgrade an earlier installation. Compare existing copies, preserve your edits, and move only the specific obsolete folders outside the skill discovery paths before installing a replacement. A later disk or permission failure may leave completed or partial copies; the installer reports the path and does not delete user data automatically.

**Manual install:** copy the individual folders inside `skills/` into your selected skill directory, preserving each folder's contents. The resulting path must look like `.agents/skills/tsjs-development-practices/SKILL.md`, not `.agents/skills/typescript-javascript-engineering-skills-1.0.0/skills/...`. No Python or Node installation is needed just to copy and use these instruction files.

OpenAI's current local-skill documentation identifies `$HOME/.agents/skills` for user skills and `.agents/skills` within repositories. In Codex CLI or the IDE extension, use `/skills` or `$` to select a skill. Changes should appear automatically; restart Codex when they do not. These instructions follow [OpenAI's skill documentation](https://developers.openai.com/codex/skills/), checked on 2026-09-08. Actual Codex discovery was not exercised in the validation environment.

## Choose a skill

Start directly with the relevant specialist when the project setup is already known. Use preflight only when checker, runtime, module or consumer assumptions need inspection. An ordinary fix does not need all thirteen skills or a comprehensive report.

| Skill | Use |
| --- | --- |
| [tsjs-project-preflight](skills/tsjs-project-preflight/SKILL.md) | Establish effective checking, build, runtime and consumer paths. |
| [tsjs-development-practices](skills/tsjs-development-practices/SKILL.md) | Implement or fix code with explicit types, state, boundaries and resource ownership. |
| [tsjs-type-contract-review](skills/tsjs-type-contract-review/SKILL.md) | Review inference, narrowing, mutation, declarations, strictness and public type promises. |
| [tsjs-runtime-data-contract-review](skills/tsjs-runtime-data-contract-review/SKILL.md) | Review parsing, configuration, serialized data, semantic guards and representation loss. |
| [tsjs-api-module-package-review](skills/tsjs-api-module-package-review/SKILL.md) | Trace module resolution and verify real packed consumers. |
| [tsjs-async-resource-failure-review](skills/tsjs-async-resource-failure-review/SKILL.md) | Review promises, queues, cancellation, retries, streams and cleanup. |
| [tsjs-test-strategy-review](skills/tsjs-test-strategy-review/SKILL.md) | Find false passes, wrong-error type fixtures, missing test execution and weak rejection checks. |
| [tsjs-security-supply-chain-review](skills/tsjs-security-supply-chain-review/SKILL.md) | Review authorization, injection, dependency exposure and install-time effects. |
| [tsjs-operational-release-review](skills/tsjs-operational-release-review/SKILL.md) | Review startup, configuration, packaged assets, shutdown, rollout and recovery. |
| [tsjs-browser-ui-review](skills/tsjs-browser-ui-review/SKILL.md) | Review stale results, lifecycle, accessible workflows, rendering and deployment compatibility. |
| [tsjs-implementation-structure-review](skills/tsjs-implementation-structure-review/SKILL.md) | Review contract, ownership and design conformance without enforcing private file layout. |
| [tsjs-evidence-reproducer](skills/tsjs-evidence-reproducer/SKILL.md) | Reproduce a specific failure while preserving its true diagnostic and consumer path. |
| [comprehensive-analysis-tsjs](skills/comprehensive-analysis-tsjs/SKILL.md) | Conduct an explicitly requested broad codebase survey and prioritize supported findings. |

Example Codex prompts:

```text
$tsjs-development-practices Fix the supplied bug. Preserve the public API and run the affected checks.

$tsjs-async-resource-failure-review Review this request worker's cancellation and shutdown paths. Do not edit code.

$tsjs-test-strategy-review Check whether these tests can pass without proving their stated claims.
```

The descriptions allow focused selection; actual automatic trigger behavior has not been benchmarked. Skill instructions do not override the task, repository rules, permissions, or required checks. Names of other skills are optional navigation aids, not dependencies.

## Content and examples

The bundle includes 32 local reference files, including 12 new worked-case guides. Repeated policy references intentionally live inside each consuming skill so selective installation has no external-file dependency. Read only references relevant to the task.

Examples state their scope. Some intentionally fail, expose unsound checking, or contain a defective contract to test whether a check can detect it. They are teaching fixtures, not a production utility library. The marked snippets are the exact source used by the example tests. The unmarked decision procedures and browser workflows need case-specific review or execution; a marker count is not proof of every prose claim.

See [CHANGELOG.md](CHANGELOG.md) for the accepted review changes, [SOURCES.md](SOURCES.md) for origin and primary references, and [VALIDATION.md](VALIDATION.md) for executed checks and limits.

## Re-run bundle checks

The standalone skills have no tool dependency. Maintaining this bundle's examples uses Python 3.10+, Node, an already installed TypeScript compiler and npm. From the extracted bundle:

```sh
python3 tools/check_bundle.py
python3 tools/run_checks.py
```

The first command checks structure and local links with Python's standard library. The second also runs isolated installer tests and the example suite. It locates the installed `node`, `tsc` and `npm`; it does not fetch a compiler or upgrade dependencies. For a nonstandard tool layout, use `--typescript /absolute/path/to/typescript.js` and `--npm-cli /absolute/path/to/npm-cli.js` with `run_checks.py`.

The example suite creates disposable fixtures, performs offline local `npm pack` and `npm install` with lifecycle scripts disabled, compiles selected snippets, and executes tests in temporary directories. It does not publish packages or change your project, global packages, or actual skill directory. Inspect the scripts before running them. Missing tools are reported as unavailable, not passed. Compiler diagnostic expectations may need review against a different TypeScript version; do not silently weaken a test to make it pass.

## License and attribution

The original MIT notice remains in [LICENSE](LICENSE) and in every standalone skill folder. Its original contributor name records attribution only; it does not introduce a runtime or packaging dependency. The adapted instructions and new helper/example code ship under the same license. External documentation stays with its respective authors; this bundle links to it rather than redistributing the pages.
