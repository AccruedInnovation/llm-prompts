# Sources and scope

## Supplied source

The baseline is the thirteen `skills/*/SKILL.md` files and nine `references/*.md` files in `bbk-profile-typescript-javascript-0.1.0-alpha.3(2).zip`. The original MIT notice appears in [LICENSE](LICENSE). The agreed content review in the conversation supplies the revision scope; [CHANGELOG.md](CHANGELOG.md) maps that scope to the result.

The original files provide the concern split and broad guidance. This edition newly authors the worked methods, examples, repairs, tests, installer and standalone layout. They are not evidence that the original package exhibited a particular runtime bug. The examples state chosen semantics and valid alternatives instead of silently turning them into universal requirements.

## Primary references checked on 2026-09-08

These sources support specific language/runtime facts and installation guidance. They do not override the receiving project's actual requirements. Live pages can change; use the supported project version and confirm important behavior locally. Local example runs used the versions in [VALIDATION.md](VALIDATION.md), not an assumed latest toolchain.

| Source | Content used |
| --- | --- |
| [OpenAI: Build skills](https://developers.openai.com/codex/skills/) | Required skill fields, local directories, explicit invocation and discovery. |
| [TypeScript: JavaScript projects](https://www.typescriptlang.org/docs/handbook/intro-to-js-ts.html) | JSDoc versus enabling JavaScript checks. |
| [TypeScript: strict](https://www.typescriptlang.org/tsconfig/strict.html) | Strict-family options and explicit overrides. |
| [TypeScript: object types](https://www.typescriptlang.org/docs/handbook/2/objects.html) | Readonly views and mutation through aliases. |
| [TypeScript: 3.9 release notes](https://www.typescriptlang.org/docs/handbook/release-notes/typescript-3-9.html) | Expected-error directives and unused suppression diagnostics. |
| [TypeScript: module reference](https://www.typescriptlang.org/docs/handbook/modules/reference.html) | Resolution modes, exports, typesVersions and paths. |
| [typescript-eslint: no-floating-promises](https://typescript-eslint.io/rules/no-floating-promises/) | Voiding a promise does not observe rejection. |
| [typescript-eslint: no-misused-promises](https://typescript-eslint.io/rules/no-misused-promises/) | Async callbacks in non-awaiting positions. |
| [Node: globals](https://nodejs.org/api/globals.html) | AbortSignal state and listener lifecycle. |
| [Node: streams](https://nodejs.org/api/stream.html) | Backpressure and write-return semantics. |
| [Node: CommonJS modules](https://nodejs.org/api/modules.html) | Version- and graph-dependent ESM interoperability. |
| [Node: TypeScript](https://nodejs.org/api/typescript.html) | Type stripping, syntax limits and tsconfig boundaries. |
| [Node: permissions](https://nodejs.org/api/permissions.html) | Limits of the permission model for hostile code. |
| [npm: pack, version 10](https://docs.npmjs.com/cli/v10/commands/npm-pack/) | Local tarball creation and pack behavior. |
| [ECMAScript: structured data](https://tc39.es/ecma262/multipage/structured-data.html) | Default JSON serialization and parsing semantics. |
| [OWASP: authorization](https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html) | Per-operation permission checks and authorization tests. |
| [React: useEffect](https://react.dev/reference/react/useEffect) | Setup, cleanup and development Strict Mode. |
| [Vue: server-side rendering](https://vuejs.org/guide/scaling-up/ssr.html) | Request-local state and cross-request state leakage. |
| [W3C: modal dialog pattern](https://www.w3.org/WAI/ARIA/apg/patterns/dialog-modal/) | Keyboard and focus obligations for a dialog workflow. |

Relevant worked guides contain their own source notes so a selectively installed skill retains useful references. Links are background evidence, not permission to send repository content to an external service. A task can use the local guidance without fetching every linked page.
