# HTTP representation caching and duplicate submissions

## One URL, two HTML forms

Contract: `GET /items` returns a complete page normally and an HTML fragment for `HX-Request: true`. The route is cacheable. When that header selects the representation, the cache must distinguish it, for example through `Vary: HX-Request`. Preserve existing vary dimensions such as encoding; do not overwrite them accidentally.

Read htmx headers only as representation preferences, not authentication. A client can set them. For private responses, establish appropriate cache controls and user/session isolation as well; adding one vary field does not make a shared cache safe.

Flawed illustrative response construction:

```python
body = fragment if hx_request else full_page
headers = {"Content-Type": "text/html"}
```

When the route is cacheable and the cache key does not otherwise distinguish variants, a full page can be served to a fragment request or the reverse. The defect is conditional: a non-cacheable route or an explicitly variant-aware cache may already satisfy the contract.

## Consumer checks

Use the actual framework client and deployed cache configuration where the claim needs them. Request full page then fragment, then repeat in reverse order with cold cache state. Require the correct body shape and a cache distinction. Inspect header names and vary tokens case-insensitively. Validate conditional requests using representation-specific validators: a validator for the full page must not incorrectly produce a fragment `304` response. Preserve other cache dimensions.

The local [web_cache_case.py](../scripts/web_cache_case.py) checks bodies, vary tokens, and deliberately distinct example validators. It rejects missing vary and shared-validator examples. It does not simulate a reverse proxy or prove browser history, focus, htmx swaps, or real cache behavior.

Add actual browser checks for history restoration, focus, target replacement, and progressive enhancement only where the application promises them. A JSON-only API needs its JSON/HTTP contract, not htmx conventions.

## Duplicate form submission and disconnect

State which operation may commit, what identifies a duplicate, and which authority decides the result. Hold one accepted request before acknowledgement, then submit a duplicate. For a policy requiring one effect, observe the real effect count and returned operation identity, not just a disabled submit button. Client-side prevention is useful UX, not an enforcement boundary.

Disconnect the client after the server commits and before the response reaches it. Verify that a retry recovers the existing result or follows the explicit duplicate policy rather than creating a second effect. Cancellation of the request coroutine does not prove a database or thread call rolled back.

Test authorization and CSRF through actual middleware before claiming those properties. A fragment header must not bypass either check. Avoid logging sensitive request content in evidence.

Sources: [htmx caching](https://htmx.org/docs/#caching), [HTTP caching specification](https://www.rfc-editor.org/rfc/rfc9111.html), [asyncio cancellation](https://docs.python.org/3.14/library/asyncio-task.html). Local fixtures and example policies are suite-authored.
