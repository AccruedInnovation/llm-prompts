"""Local representation-contract checks, not browser or cache integration tests."""
from __future__ import annotations
from dataclasses import dataclass
import json

@dataclass(frozen=True)
class Response:
    body: str
    headers: dict[str, str]


def response(fragment: bool, *, broken_vary: bool = False, shared_validator: bool = False) -> Response:
    headers = {'Content-Type':'text/html', 'Cache-Control':'public, max-age=30',
               'Vary':'Accept-Encoding' if broken_vary else 'Accept-Encoding, HX-Request',
               'ETag':'"shared"' if shared_validator else ('"fragment-v1"' if fragment else '"page-v1"')}
    body = '<section id="items">one</section>'
    if not fragment:
        body = '<!doctype html><html><body>' + body + '</body></html>'
    return Response(body, headers)


def check_pair(full: Response, fragment: Response) -> None:
    for item in (full, fragment):
        headers = {key.lower():value for key,value in item.headers.items()}
        tokens = {part.strip().lower() for part in headers.get('vary','').split(',')}
        if not {'hx-request','accept-encoding'} <= tokens:
            raise AssertionError('missing-vary-dimension')
        if headers.get('content-type') != 'text/html':
            raise AssertionError('wrong-media-type')
    if not full.body.startswith('<!doctype html>') or fragment.body.startswith('<!doctype html>'):
        raise AssertionError('wrong-representation')
    full_headers = {key.lower():value for key,value in full.headers.items()}
    fragment_headers = {key.lower():value for key,value in fragment.headers.items()}
    if full_headers['etag'] == fragment_headers['etag']:
        raise AssertionError('shared-representation-validator')


def self_check() -> dict[str, object]:
    check_pair(response(False), response(True))
    for variant, code in [('vary','missing-vary-dimension'), ('etag','shared-representation-validator')]:
        kwargs = {'broken_vary':True} if variant == 'vary' else {'shared_validator':True}
        try:
            check_pair(response(False,**kwargs), response(True,**kwargs))
        except AssertionError as exc:
            if str(exc) != code:
                raise
        else:
            raise AssertionError('known cache contract defect was not detected')
    return {'status':'PASS','known_defects_detected':2,'browser_or_cache_executed':False}

if __name__ == '__main__':
    print(json.dumps(self_check(), sort_keys=True))
