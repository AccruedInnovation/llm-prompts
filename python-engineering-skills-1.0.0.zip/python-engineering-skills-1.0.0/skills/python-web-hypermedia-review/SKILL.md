---
name: python-web-hypermedia-review
description: "Review Python HTTP, forms, server-rendered pages, and htmx fragments: authorization, representation caching, duplicate submissions, and disconnects. Use only for an actual web interface."
---

# Python Web and Hypermedia Review

This is an optional focused skill. Do not load it for an ordinary library, CLI, worker, pipeline, or non-web service.

## Bind the declared interaction style

Identify whether the system uses JSON APIs, server-rendered pages, HTML fragments, HTMX, Alpine, forms, WebSockets, events, or a mixture. Do not impose HATEOAS or hypermedia when the accepted architecture is a different style.

## Review

- route and method semantics;
- request parsing and boundary validation;
- authentication, authorization, CSRF, CORS, cookies, and trusted hosts;
- response media types, status codes, headers, redirects, caching, and errors;
- full-page versus fragment contracts;
- progressive enhancement and non-JavaScript behavior where promised;
- HTMX headers, target/swap behavior, history, out-of-band updates, and error fragments;
- Alpine/client state that duplicates server authority or couples to unstable internal data shapes;
- idempotency and duplicate submissions;
- streaming, disconnects, cancellation, and background work;
- accessibility and focus behavior;
- API/version compatibility and generated clients where applicable;
- observability and privacy of request data.

## Full-page and fragment cache case

Read [representation caching and duplicate submission](references/web-cases.md). When one cacheable URL varies by `HX-Request`, establish a cache key distinction such as `Vary: HX-Request`, preserve other vary dimensions, and test full-to-fragment and fragment-to-full requests through the cache. Check representation-specific validators and authorization isolation as applicable.

Use [the response-contract example](scripts/web_cache_case.py) to see positive and deliberately wrong responses. It checks header/body rules only; it does not qualify a framework, browser, reverse proxy, or shared cache. A JSON-only service does not need htmx behavior.

## Validation

Use contract tests, browser or fragment tests, authorization/CSRF fixtures, caching and conditional-request tests, disconnect/duplicate tests, and selected end-to-end flows according to the assurance contract.

Return only web-specific findings and route non-web architecture, package, runtime, security, or operations issues to the corresponding focused skill. Do not create a second comprehensive review.

## Use and evidence limits

Use this guidance within the task’s scope and permitted effects. Examples define their own small contracts; adapt them only after establishing the project’s actual requirements. Review is read-only unless repair is requested. Local references belong to this skill; other skill names are optional further expertise. Keep checks not run, observed failures, environment failures, and passed assertions distinct.
