# Shutdown with active jobs and a failing dependency

## State the real service contract

Choose the actual policy: finish accepted work, cancel work before effects, or stop by a deadline and record unresolved operations for recovery. Define “accepted” and the durable point. Distinguish jobs queued, running, committed, failed, cancelled before effects, and unknown. Do not infer delivery from a queue's empty state or a future's completion flag.

## Arrange a controlled rehearsal

Run the installed worker or service in a permitted disposable environment with a representative dependency. Create one completed job, one held before its effect, one held after commit but before acknowledgement, and a queued job where the real model allows these states. Use explicit failpoints or controlled dependency responses; do not infer state from a delay.

Stop admission and confirm new work receives the promised rejection or retry response. Begin shutdown, then make the dependency unavailable. Observe queue counts, live tasks/threads/processes, operation IDs, durable records, cleanup, and the exit reason. Test a second shutdown request when it changes cleanup behavior.

## Required observations

| State at shutdown | What to inspect |
| --- | --- |
| Not accepted | No success response or accepted-work record |
| Accepted, not started | Drained, explicitly cancelled without effect, or retained for recovery |
| Running before commit | Bounded stop or known continuing owner; no invented rollback |
| Committed, acknowledgement lost | Commit discovered on recovery; retry does not duplicate it |
| Thread call still running | Its owner, eventual result, resource bound, and exit policy |
| Dependency unavailable | Actionable failure, bounded retry, and recovery path |

Exercise restart using the retained operation state. Confirm whether each accepted job must execute once, at least once with idempotency, or under another explicit policy. Do not silently upgrade a best-effort worker to an exactly-once claim.

## Non-findings and proportionality

A read-only scheduled job may simply stop and retry next run when no durable accepted-work promise exists. A small finite batch may need no queue service. A CLI may only need resource cleanup and a truthful nonzero exit. Name the required outcome before adding durable journals, telemetry stacks, or coordination services.

A smoke test in this suite is not an operational rehearsal of the user's product. Retain exact artifact, environment, failpoints, observed state, deadline, and untested conditions. Use the actual supported OS signal and process behavior before making platform claims.

Sources for mechanism distinctions: [asyncio cancellation](https://docs.python.org/3.14/library/asyncio-task.html), [executor cancellation](https://docs.python.org/3.14/library/concurrent.futures.html), [queue shutdown](https://docs.python.org/3.14/library/asyncio-queue.html). The job-state contract and rehearsal are suite-authored guidance.
