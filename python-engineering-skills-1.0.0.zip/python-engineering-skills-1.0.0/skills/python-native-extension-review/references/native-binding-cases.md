# Native and FFI cases

Use the section for the actual binding technology and version. Do not infer native safety from a Python test or a wheel tag.

## ctypes: return type, argument type, and lifetime

Suppose the actual C header declares an opaque pointer returned by `device_open` and released by `device_close`. The default ctypes integer return convention is not the pointer contract. On a platform with wider pointers it can lose information. Read the header before choosing widths, calling convention, and error treatment.

Illustrative binding for a documented `void *device_open(const char *)` and `void device_close(void *)` API:

```python
import ctypes

# `library` is an already selected and authorized ctypes library handle.
library.device_open.argtypes = [ctypes.c_char_p]
library.device_open.restype = ctypes.c_void_p
library.device_close.argtypes = [ctypes.c_void_p]
library.device_close.restype = None
```

This is not a complete loader or wrapper. Define null/error behavior, input encoding, handle owner, use-after-close prevention, allocator pairing, thread rules, and cleanup after partial failure. Use the correct loader for the library's calling convention; do not guess `CDLL` versus `WinDLL`.

**Check:** Compile a harmless native fixture with the actual signature under the supported toolchain. Verify failure/open/use/close paths and one matching close per owned handle. Do not invoke a deliberately wrong ABI in the reviewer process. Keep crash-oriented tests in bounded child processes with diagnostic evidence.

## Callbacks: reference and unregister ordering

C code retaining a callback pointer does not keep the Python callback object alive by itself. Store a strong reference for as long as C may call it. During shutdown, prevent new calls, unregister, wait for in-flight calls as required by the API, then release Python references and native handles. A reference alone does not prove C has stopped calling.

**Check:** Use a fixture that can hold an in-flight callback at a barrier. Request shutdown, release the callback, and confirm unregister-and-join completes before the reference is discarded. Also test native setup failure after callback registration. Do not invent a join operation if the real API provides none; state the missing lifetime guarantee.

## Other binding technologies

| Boundary | Version-specific contract to establish | Failure-focused check |
| --- | --- | --- |
| CPython C API | Owned/borrowed references, error indicator and return convention, module and interpreter state | Fail after each acquired reference; verify cleanup and preserved Python error |
| cffi | Lifetime of owned cdata, buffers, and callbacks under the selected API/ABI mode | Retain a pointer beyond a temporary allocation in a safe fixture; establish the correct keeper |
| Cython | Generated C, memoryview ownership, exception declarations, and `nogil` regions | Exception and buffer-lifetime paths, plus checked generated output |
| PyO3 | Version-specific bound/owned objects, thread attachment, borrow rules, panic and exception translation | Drop, callback, and concurrent-access cases under supported interpreter modes |

These are questions for the actual binding documentation, not portable guarantees or untested API snippets. Do not transplant ctypes reference-retention rules as the complete ownership model for every binding.

## Distribution and free threading

Bind the built extension and shared libraries to the wheel under test. Verify ABI claims against symbols and target versions. Record post-import GIL state on a free-threaded interpreter; a module that causes GIL fallback has not been tested GIL-disabled. Subinterpreter, free-threaded, and alternative-interpreter compatibility are distinct claims.

Only make claims for toolchains and platforms actually exercised. This suite's Python-only validation does not compile or qualify any of these illustrative native boundaries.

Sources: [ctypes foreign functions and callbacks](https://docs.python.org/3.14/library/ctypes.html), [CPython C API introduction](https://docs.python.org/3.14/c-api/intro.html), [C API free threading](https://docs.python.org/3.14/howto/free-threading-extensions.html). Consult the installed version's official cffi, Cython, or PyO3 documentation before making API-level findings.
