"""pytest examples: precise guards, known-defect detection, and setup cleanup.

Requires pytest already available. Child suites intentionally fail setup; the
parent checks their exact error and cleanup observation. No production effects.
"""
from __future__ import annotations
import os
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET
import pytest

class Unauthenticated(ValueError):
    pass

class InvalidQuantity(ValueError):
    pass


def submit(authenticated: bool, quantity: int, sent: list[int]) -> str:
    if not authenticated:
        raise Unauthenticated('authentication-required')
    if type(quantity) is not int or quantity <= 0:
        raise InvalidQuantity('positive-integer-required')
    sent.append(quantity)
    return 'accepted'


def weakened_submit(authenticated: bool, quantity: int, sent: list[int]) -> str:
    if not authenticated:
        raise Unauthenticated('authentication-required')
    # Deliberately missing the quantity guard for the mutation demonstration.
    sent.append(quantity)
    return 'accepted'


def check_quantity_guard(implementation) -> None:
    sent: list[int] = []
    try:
        implementation(True, -1, sent)
    except InvalidQuantity as exc:
        if str(exc) != 'positive-integer-required':
            raise AssertionError('wrong quantity error') from exc
    else:
        raise AssertionError('quantity guard accepted invalid input')
    if sent:
        raise AssertionError('rejected input caused a send')


def test_quantity_guard() -> None:
    check_quantity_guard(submit)


def test_good_input_is_sent() -> None:
    sent: list[int] = []
    assert submit(True, 3, sent) == 'accepted'
    assert sent == [3]


def test_authentication_guard_uses_valid_quantity() -> None:
    sent: list[int] = []
    with pytest.raises(Unauthenticated, match='^authentication-required$'):
        submit(False, 3, sent)
    assert sent == []


def test_explicit_error_precedence() -> None:
    with pytest.raises(Unauthenticated, match='^authentication-required$'):
        submit(False, -1, [])


def test_known_missing_guard_is_detected() -> None:
    with pytest.raises(AssertionError, match='^quantity guard accepted invalid input$'):
        check_quantity_guard(weakened_submit)


@pytest.mark.parametrize('registered_cleanup', [False, True])
def test_fixture_setup_failure(tmp_path: Path, registered_cleanup: bool) -> None:
    marker = tmp_path / 'closed.txt'
    test_path = tmp_path / 'test_child.py'
    registration = 'request.addfinalizer(close)' if registered_cleanup else 'pass'
    test_path.write_text("""import pathlib
import pytest

@pytest.fixture
def connection(request):
    marker = pathlib.Path(%r)
    def close():
        marker.write_text("closed", encoding="utf-8")
    # The resource has now been acquired.
    %s
    raise RuntimeError("configuration-failed-after-acquisition")
    yield object()
    close()

def test_body(connection):
    raise AssertionError("body-must-not-run")
""" % (str(marker), registration), encoding='utf-8')
    env = dict(os.environ)
    env.pop('PYTEST_ADDOPTS', None)
    env.pop('PYTHONPATH', None)
    env['PYTEST_DISABLE_PLUGIN_AUTOLOAD'] = '1'
    report = tmp_path / 'junit.xml'
    config = tmp_path / 'empty.ini'
    config.write_text('[pytest]\n', encoding='utf-8')
    result = subprocess.run([sys.executable, '-m', 'pytest', '-q', '-c', str(config),
                             '--confcutdir', str(tmp_path), '--junitxml', str(report), str(test_path)],
                            cwd=tmp_path, env=env, text=True, capture_output=True, timeout=20)
    assert result.returncode == 1, result.stdout + result.stderr
    tree = ET.parse(report)
    cases = tree.findall('.//testcase')
    assert len(cases) == 1
    error = cases[0].find('error')
    assert error is not None
    assert error.attrib.get('message', '').startswith('failed on setup with')
    assert 'configuration-failed-after-acquisition' in (error.text or '')
    assert 'body-must-not-run' not in (error.text or '')
    assert marker.exists() is registered_cleanup
    if registered_cleanup:
        assert marker.read_text(encoding='utf-8') == 'closed'
