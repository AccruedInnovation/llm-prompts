# Tests that expose the intended failure

## Fixture failure before yield

Flawed ordering:

```python
@pytest.fixture
def connection():
    conn = acquire()
    configure(conn)  # can raise after successful acquisition
    yield conn
    conn.close()
```

Pytest cannot run the post-yield cleanup if setup fails before yielding. Register the cleanup after acquisition and before the next possible failure:

```python
@pytest.fixture
def connection(request):
    conn = acquire()
    request.addfinalizer(conn.close)
    configure(conn)
    return conn
```

Alternatively, enter an appropriate resource context manager or `ExitStack` before later setup. Cleanup must be safe for the successfully acquired state; do not register a close for an object that does not yet exist. The acquisition function owns cleanup of its own partial failure. For several resources, define order and cleanup-failure treatment.

**Test:** Make configuration fail after successful acquisition. Check a separate close marker in the child pytest process. Both fixture variants must report a setup error for the intended configuration failure; only the registered-cleanup variant closes. A test body that never executes does not prove any application assertion.

The runnable [test_failure_cases.py](../scripts/test_failure_cases.py) invokes these broken fixtures in temporary child suites and verifies their reports and cleanup markers. Those child errors are expected observations, not hidden skipped tests.

## Test the intended guard

Suppose an operation must validate a positive quantity before sending a write, but authentication runs first. This is too weak:

```python
with pytest.raises(Exception):
    submit(authenticated=False, quantity=-1)
```

It may test only authentication. Instead use valid authentication and all other valid fields, require the quantity-specific error, and verify no write occurred. Test authentication separately with a valid quantity. When error precedence itself matters, add a separate case with both invalid inputs.

A positive case must verify the exact authorized write. A no-op implementation should not pass. A mutation case should bypass the quantity guard and show that the same assertion helper catches the defect. Do not let an unrelated exception make the mutant appear caught.

Mock calls can establish a local no-call property. They do not establish that a real database rolled back or a remote write did not occur after cancellation. Add the actual integration test where that is the claim.

## Concurrency and recovery

Use an event to prove the worker reached a point, then cancel or fail the caller. Preserve continuing work, cleanup, task outcomes, and durable effects. Sleeps may bound a wait or poll a known condition, but elapsed time alone should not define the expected schedule. Test a failed worker while the producer is blocked, not only normal draining.

For a migration, retain initial, forward, interrupted, resumed, and rollback states appropriate to the actual contract. A transaction-per-test fixture can hide an application commit boundary. Verify the real connection and transaction owner when making a durability claim.

## Packaging and type checks

Use actual import origins for installed-only tests; controlling CWD alone is insufficient. A missing module or `py.typed` marker should make the intended consumer check fail, not be supplied by an editable checkout. Keep valid and invalid typing consumers separate and verify diagnostic locations rather than counting any checker error as success.

## Results and scope

A passing local example proves its fixture and assertion logic under the recorded tools. It is not an agent evaluation, a production integration result, or proof that every possible mutant is detected. Retain first-run failures and all retries. A missing tool is not a clean test result.

Sources: [pytest teardown failures and safe fixture structure](https://docs.pytest.org/en/stable/how-to/fixtures.html#handling-errors-for-yield-fixture), [pytest import practices](https://docs.pytest.org/en/stable/explanation/goodpractices.html). The guard and mutation examples define their own test contract.
