"""A deliberately narrow tar-header validator, not a secure extractor.

Validates a fixed, small list of already-read headers. It neither extracts nor
limits decompression, actual disk/CPU usage, races, or all OS path aliases.
"""
from __future__ import annotations
import io
import json
import re
import tarfile

class RejectedArchive(ValueError):
    pass

_SAFE_PART = re.compile(r'[A-Za-z0-9_-][A-Za-z0-9_.-]*\Z')
_RESERVED = {'CON', 'PRN', 'AUX', 'NUL'} | {f'{p}{n}' for p in ('COM','LPT') for n in range(1,10)}


def validate_headers(members: list[tarfile.TarInfo], *, max_members: int = 8,
                     max_total_bytes: int = 1024) -> None:
    if len(members) > max_members:
        raise RejectedArchive('member-count')
    total = 0
    seen: set[str] = set()
    for member in members:
        parts = member.name.split('/')
        if (not parts or any(p in ('', '.', '..') or not _SAFE_PART.fullmatch(p)
                             or p.endswith('.') or p.split('.')[0].upper() in _RESERVED
                             for p in parts)):
            raise RejectedArchive('unsafe-path')
        if not member.isfile():
            raise RejectedArchive('member-type')
        key = member.name.casefold()
        if key in seen:
            raise RejectedArchive('duplicate-name')
        seen.add(key)
        if member.size < 0:
            raise RejectedArchive('declared-size')
        total += member.size
        if total > max_total_bytes:
            raise RejectedArchive('declared-size')


def example_members(name: str, kind: bytes = tarfile.REGTYPE) -> list[tarfile.TarInfo]:
    first = tarfile.TarInfo('good.txt'); first.size = 1
    second = tarfile.TarInfo(name); second.type = kind; second.size = 1
    return [first, second]


def self_check() -> dict[str, object]:
    validate_headers(example_members('safe/data.txt'))
    negative = [
        (example_members('../outside'), 'unsafe-path'),
        (example_members('/absolute'), 'unsafe-path'),
        (example_members('folder/../outside'), 'unsafe-path'),
        (example_members('C:\\outside'), 'unsafe-path'),
        (example_members('NUL.txt'), 'unsafe-path'),
        (example_members('link', tarfile.SYMTYPE), 'member-type'),
        (example_members('pipe', tarfile.FIFOTYPE), 'member-type'),
        (example_members('GOOD.txt'), 'duplicate-name'),
    ]
    for members, code in negative:
        try:
            validate_headers(members)
        except RejectedArchive as exc:
            if str(exc) != code:
                raise AssertionError('unrelated rejection') from exc
        else:
            raise AssertionError('forbidden archive header accepted')
    huge = tarfile.TarInfo('large.txt'); huge.size = 1025
    try:
        validate_headers([huge])
    except RejectedArchive as exc:
        if str(exc) != 'declared-size':
            raise AssertionError('wrong size rejection') from exc
    else:
        raise AssertionError('size budget not enforced')
    # A small real in-memory tar fixture: no extraction or filesystem mutation.
    memory = io.BytesIO()
    with tarfile.open(fileobj=memory, mode='w') as archive:
        for name in ('good.txt', '../outside'):
            header = tarfile.TarInfo(name); header.size = 1
            archive.addfile(header, io.BytesIO(b'x'))
    memory.seek(0)
    with tarfile.open(fileobj=memory, mode='r:') as archive:
        try:
            validate_headers(archive.getmembers())
        except RejectedArchive as exc:
            if str(exc) != 'unsafe-path':
                raise AssertionError('wrong real-archive rejection') from exc
        else:
            raise AssertionError('real archive traversal accepted')
    return {'status':'PASS', 'header_rejections': len(negative) + 1,
            'real_tar_rejection':'unsafe-path', 'extraction_performed': False}

if __name__ == '__main__':
    print(json.dumps(self_check(), sort_keys=True))
