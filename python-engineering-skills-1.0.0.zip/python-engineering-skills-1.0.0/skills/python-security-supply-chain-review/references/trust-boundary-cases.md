# Concrete trust-boundary cases

## Build isolation is not hostile-code containment

Entry: an untrusted source package or build backend. Execution path: metadata generation or wheel build hooks. Assets: inherited credentials, writable files, network access, and the user's environment.

Pip's isolated build environment separates Python build dependencies. That fact does not establish restrictions on operating-system effects. A virtual environment and a temporary directory are not a security boundary for hostile Python code.

Inspect which hooks run, executable identity, inherited secrets, readable and writable roots, network policy, and OS containment. For a trusted project, normal dependency isolation can be enough for its reproducibility goal; do not call it a security defect merely because it is not a sandbox. For hostile code, test the declared containment with harmless sentinel attempts in a disposable environment, no real credentials, and a bounded process. Check the sentinel cannot escape the permitted boundary. Never run unknown package code simply to learn whether it is dangerous.

## Subprocess parsing depends on the target

Entry: an untrusted filename or option passed to a helper. Inspect executable lookup, target type, arguments, current directory, environment, output limits, and child cleanup. `shell=False` is useful for ordinary direct executable calls, but not a complete verdict: Windows batch files can receive shell interpretation without the caller explicitly requesting it. `--` only ends option parsing for programs that support that convention.

Prefer a known direct executable or an API that does not insert an extra interpreter when that fits the task. Where a batch or shell script is required, apply its actual quoting and validation rules and run literal-argument tests on the supported OS. Do not prescribe `shell=True` as a generic fix. Use inert metacharacter strings and an argument-echo fixture, not a destructive payload. Require exact round-trip arguments and no unexpected sentinel effect.

A subprocess timeout does not itself establish that all descendants stopped. Test the promised process-tree cleanup separately under the actual platform model.

## Archive headers, traversal, and resource limits

Entry: an uploaded archive. Required example policy: validate all member headers before writing anything; reject absolute/traversal paths, links, special files, duplicate names, too many files, or excessive declared sizes. [archive_header_case.py](../scripts/archive_header_case.py) implements only this bounded header check for a deliberately narrow portable-name subset.

**Hostile fixture:** a valid small file followed by `../outside`. Require `unsafe-path`, no extracted files, and no outside sentinel. Separate link and size cases must reach their own guards with otherwise valid headers. Reject all members before extraction in this example; do not leave the first file written and describe the operation as atomic rejection.

Header inspection does not enforce actual expanded bytes, CPU, disk, time, or memory consumption. Filters do not prevent all denial of service. If extraction is allowed, use a fresh destination under exclusive ownership, the applicable extraction filter, independent runtime budgets, and a deliberate cleanup policy. Address races, symlinks, Unicode/case aliases, and platform-specific names in the actual destination model. The small example is not a complete portable path-security library.

## Report what the check proves

An inventory or scanner result is evidence within its scope, not proof that no exploit exists. State the entry, asset, observed failure or supported risk, current authority, smallest containment change, and precise regression case. Keep unavailable platform tests and containment infrastructure separate from an observed candidate defect.

Sources: [pip build isolation](https://pip.pypa.io/en/stable/reference/build-system/#build-isolation), [subprocess security](https://docs.python.org/3.14/library/subprocess.html#security-considerations), [tar extraction hints](https://docs.python.org/3.14/library/tarfile.html#hints-for-further-verification).
