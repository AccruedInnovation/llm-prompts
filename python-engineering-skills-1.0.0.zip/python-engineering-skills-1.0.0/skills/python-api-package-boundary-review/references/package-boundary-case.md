# Public boundary case: the resource exists only in the checkout

## Contract

A library's public `load_defaults()` function loads shipped configuration through `importlib.resources`. Its wheel must include the resource. Source tests and an editable installation both pass. The resource is missing from the wheel because package-data configuration excludes it.

## Investigation

Inspect the actual wheel file list, not just the source path. Install it non-editably in a fresh environment and call the public API outside the checkout. Record the module's resolved origin and the distribution's installed files. An installed-file receipt must explain the package code used by the consumer.

A consumer test that inserts `src/` into `sys.path` can find the resource anyway. The actual origin therefore belongs in the evidence; working directory, package name, or version alone is insufficient. Inspect namespace locations when no single `__file__` exists.

## Positive, negative, and contamination cases

Good wheel: the public function returns the exact expected default values and code comes from its installed distribution.

Incomplete wheel: code imports from the new install, but the required resource cannot be found. Require the resource-specific error or absence; a missing unrelated dependency does not count.

Contaminated environment: inject a fake checkout package with the same import name. The origin check must reject it even if its function returns the right default values. This distinguishes consumer behavior from proof of which artifact supplied it.

Use the same reasoning for a missing `py.typed`, a missing module, and a console entry point with the wrong target. Do not require typing markers from a package that makes no typing-distribution promise.

## Repair and non-finding

Repair package inclusion in the canonical backend configuration, rebuild, and retest the exact new wheel. Do not “fix” the test by keeping the checkout on `PYTHONPATH`. A flat project layout is not automatically a defect; an installed-only claim without import-origin evidence is the problem.

The optional `python-package-release-gates` skill contains the full installed-consumer recipe. This skill can be used alone: the minimum requirement remains a bound wheel, clean non-editable install, resolved import locations, actual public/resource behavior, and a missing-content test.

Sources: [pytest import behavior](https://docs.pytest.org/en/stable/explanation/goodpractices.html), [importlib resources](https://docs.python.org/3.14/library/importlib.resources.html), [importlib metadata](https://docs.python.org/3.14/library/importlib.metadata.html).
