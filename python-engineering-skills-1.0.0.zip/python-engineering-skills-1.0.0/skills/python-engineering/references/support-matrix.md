# Python scope and support

This suite provides engineering guidance, not a certification of a project, interpreter, or platform.

Ordinary pure-Python libraries, CLIs, services, asyncio, pyproject-based distributions, optional static typing, runtime validation, and sdist/wheel behavior are its main scope.

Processes, plugins, migrations, free-threaded CPython, native extensions, public stub packages, and web interfaces require their own applicable checks. Load specialist guidance only when those boundaries exist.

Embedded/mobile/WASM/GPU Python, alternative interpreters, large scientific native stacks, and operating-system vendor packages require platform-specific primary documentation and evidence. Do not infer support from these skills or a successful local test.

Examples that use `TaskGroup` target Python 3.11 or later; version-specific notes name their trigger. A project's supported range governs its own checks. Never change that range merely to match an example.
