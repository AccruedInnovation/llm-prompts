# Small Python decision recipes

Read only the case that affects the change. These are engineering choices, not a demand to add every mechanism.

## Choose a value form by what it must protect

A static distinction between IDs may need `NewType`. An external value still needs runtime parsing. A dictionary shape used by a checker may need `TypedDict`; this does not reject bad dictionaries. A consumer substitution boundary may need `Protocol`; a single concrete implementation with no changing dependency may need only ordinary construction.

For stable values, define construction and ownership. `@dataclass(frozen=True)` restricts field rebinding but leaves a stored list mutable. Convert a caller-owned list to an owned tuple when that matches the contract; inspect the tuple's elements too. Copying a top-level container does not establish deep ownership.

Choose explicit variants when a set of flags permits invalid combinations. Do not wrap every primitive or add a model framework without a named correctness or maintenance benefit.

## Choose concurrency by lifetime and effects

Use a task group when a scope owns a set of coroutines and must join them at exit. Use `gather` when its result and failure behavior matches the contract; a failure propagated to the caller does not automatically stop siblings. Record the owner of those remaining tasks.

Limit work before creating an unbounded task set. A fixed worker pool with a bounded queue can limit admission; a semaphore inside millions of tasks does not limit their count. Include results, producer buffers, retries, and per-item size in the budget.

Cancellation of a caller waiting for blocking thread work does not prove that work stopped. Before retrying a write, distinguish rejected, not started, running, completed, and unknown outcomes. Use idempotency or reconciliation when the external operation needs it.

## Choose a test by the claim

For a parser, check accepted values and precise rejection without effects. For a resource, fail after acquisition and observe cleanup. For a concurrency rule, arrange the order using events and observe continuing work. For a package, install and inspect actual imports and resources. For performance, measure the actual workload instead of prescribing a technique.

Do not require a new test framework for a small counterexample. A short repeatable script may be enough; a stronger claim may require real integration.

## Choose evidence by what it can prove

A local example demonstrates its own behavior. A type-check demonstrates the selected static contract. A source test does not prove wheel contents. A wheel consumer does not prove a deployed service's shutdown or recovery. State the narrow result and the missing observation.

Sources for language behavior: [dataclasses](https://docs.python.org/3.14/library/dataclasses.html), [typing](https://docs.python.org/3.14/library/typing.html), [asyncio tasks](https://docs.python.org/3.14/library/asyncio-task.html), and [futures](https://docs.python.org/3.14/library/concurrent.futures.html). Apply documentation for the project's exact support range.
