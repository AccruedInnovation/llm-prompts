# Python environment and package policy

The repository owns its interpreter range, environment manager, build backend, lock or range policy, indexes, extras, commands, and supported artifacts.

Keep these evidence subjects separate:

```text
source tree
editable install
installed wheel
sdist-derived wheel
container/image
deployed service
```

Evidence may be reused only for the exact subject and environment closure it proves. This guidance never authorizes creating an environment, installing packages, upgrading Python, changing a backend, or resolving dependencies beyond the task’s permitted effects.

Libraries normally declare compatible ranges and test selected lower/current combinations. Applications normally bind a complete environment. Exceptions require an explicit project policy.
