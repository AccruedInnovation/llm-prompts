---
name: python-engineering
description: "Implement or debug Python changes using the repository’s interpreter, commands, types, package layout, and tests. Use for routine Python work; use focused skills for a requested specialist review."
---

# Python Engineering

Use this skill for ordinary Python implementation and debugging. Respect the assignment, repository instructions, and existing support promises. A skill adds guidance, not permission to run tools, change scope, install dependencies, or publish.

## Establish the actual subject

Inspect the relevant source, tests, `pyproject.toml`, dependency files, and repository commands before editing. Identify the supported and selected interpreter, executable and environment, build backend, package layout, import roots, resources, and any native boundary. Read metadata without importing the application first; importing can perform work.

Keep source-tree, editable-install, installed-wheel, sdist-derived-wheel, image, and deployed behavior separate. Likewise separate static checking, runtime value validation, and runtime annotation use; async, thread, process, and free-threaded safety; and runtime, typing, import, serialized, and operational compatibility.

For a small change, record only facts that affect the task. For a consequential claim, retain the exact code, environment, command, inputs, and observed result. An unavailable required check leaves that claim unproved, not passed.

## Work sequence

1. State the behavior to change and what must remain unchanged. Trace its actual caller, validation, owner, effects, and consumer.
2. Select the smallest coherent change within that scope. Keep each important invariant and resource under one owner. Preserve good existing abstractions; add a layer only for a named boundary, invariant, testing need, or changing dependency.
3. Use explicit runtime parsing at external boundaries. An annotation, `cast`, `NewType`, `TypedDict`, or frozen dataclass is not a validator. Restricted field assignment is not deep immutability.
4. Make task, queue, process, transaction, and cleanup ownership explicit when present. A timeout or cancelled awaiter does not prove external work stopped or rolled back.
5. Add the cheapest test that can expose the intended defect, including a relevant failure case. Do not weaken expected behavior to make the candidate pass.
6. Run authorized repository checks, repair within scope, and recheck affected behavior. For a distribution claim, test an installed artifact and its import origins, not just a checkout.
7. Return changed behavior, files, actual checks, and remaining limits. Do not invent acceptance, independent review, or a pass on another platform.

## Select deeper guidance by need

Use a focused installed skill only when its subject applies. Ordinary work does not require a broad survey plus every specialist. A single agent can perform the work unless the task requires separate assurance; do not call a second pass independent review.

| Task | Focused skill name |
| --- | --- |
| Broad inherited-code review | `comprehensive-analysis-python` |
| New boundaries or agreed-design comparison | `python-implementation-structure-authoring`, `python-implementation-structure-review` |
| Explicit delivery planning | `python-execution-slice-design` |
| Runtime, tests, types | `python-runtime-correctness-review`, `python-test-strategy-review`, `python-typing-contract-review` |
| Public package or release | `python-api-package-boundary-review`, `python-package-release-gates` |
| Failure reproduction | `python-evidence-reproducer` |
| Trust, operations, native code, web | Corresponding `python-…-review` skill |

These names are optional further expertise, not dependencies of this skill. Do not claim to have read an unavailable skill.

## Tool and environment rules

Use the repository's tools and dependency policy. Do not introduce a second checker, another environment manager, a backend migration, or an interpreter upgrade just to follow a generic recipe. Environment creation, installs, resolution, application imports, and build hooks require permission for their effects. An authorized implementation task may already allow necessary local checks; do not ask for permission again for each harmless command within it.

A missing optional tool is a limitation, not a reason to block useful work. A required unavailable tool blocks only its affected proof. Use an allowed equivalent only when it establishes the same claim.

## Local references

Read [decision recipes](references/decision-recipes.md) when choosing a representation, concurrency pattern, or proof. Read the relevant policy note for [compatibility](references/compatibility-policy.md), [environments and packages](references/environment-package-policy.md), [testing and evidence](references/testing-evidence-policy.md), [performance](references/performance-policy.md), or [scope and support](references/support-matrix.md). Do not load all references for every edit.


## Use and evidence limits

Use this guidance within the task’s scope and permitted effects. Examples define their own small contracts; adapt them only after establishing the project’s actual requirements. Review is read-only unless repair is requested. Local references belong to this skill; other skill names are optional further expertise. Keep checks not run, observed failures, environment failures, and passed assertions distinct.
