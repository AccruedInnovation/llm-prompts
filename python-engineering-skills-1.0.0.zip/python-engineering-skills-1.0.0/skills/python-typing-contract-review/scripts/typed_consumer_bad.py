"""Negative static fixture: only the final argument should violate the protocol.

Do not execute as a product module. Run separately from positive type-checks.
"""
from typing import Protocol

class Writer(Protocol):
    def write(self, value: str) -> int: ...

class WrongWriter:
    def write(self) -> int:
        return 0

def emit(writer: Writer) -> int:
    return writer.write('sample')

result: int = emit(WrongWriter())  # expected: incompatible argument/protocol
