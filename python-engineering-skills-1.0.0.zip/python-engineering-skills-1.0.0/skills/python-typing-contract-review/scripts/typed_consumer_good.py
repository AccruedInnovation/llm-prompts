"""Positive static consumer fixture. Use the project's configured checker."""
from typing import Protocol

class Writer(Protocol):
    def write(self, value: str) -> int: ...

class StringWriter:
    def write(self, value: str) -> int:
        return len(value)

def emit(writer: Writer) -> int:
    return writer.write('sample')

result: int = emit(StringWriter())
