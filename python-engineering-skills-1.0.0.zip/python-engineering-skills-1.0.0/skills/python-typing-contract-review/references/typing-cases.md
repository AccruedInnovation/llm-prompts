# Typing guarantees and downstream examples

## Four constructs that do not validate input

```python
from typing import NewType, Protocol, TypedDict, cast, runtime_checkable

UserId = NewType("UserId", int)

class Request(TypedDict):
    count: int

@runtime_checkable
class Writer(Protocol):
    def write(self, value: str) -> int: ...

class WrongWriter:
    def write(self) -> None:
        pass

raw: object = "not an integer"
value = cast(int, raw)  # runtime value is still a string
```

`NewType` distinguishes identifiers for a checker but passes through its input. A `TypedDict` value remains a normal dictionary. `cast` asserts a static fact rather than checking it. `isinstance(WrongWriter(), Writer)` can be true because the member exists despite the incompatible signature. Validate the required behavior at the actual input or substitution boundary.

A non-finding: after an explicit parser or a proven invariant, a narrow `cast` can document a fact the configured checker cannot express. Prefer a locally explained cast over a broad ignore that also hides unrelated errors. Do not ban `Any` in an intentionally dynamic adapter; prevent it from erasing a material public contract.

## Positive and negative downstream checks

[typed_consumer_good.py](../scripts/typed_consumer_good.py) declares a consumer protocol and passes a compatible writer. [typed_consumer_bad.py](../scripts/typed_consumer_bad.py) passes a writer whose method takes no value. Both files have complete definitions and the same valid standard-library imports; they differ at the final call that should be rejected. Do not execute the deliberately invalid consumer as a runtime test.

Use the repository's configured checker and target version. Run each file separately to prevent one negative fixture from making a normal suite permanently red. The good file must pass. The bad file must report an argument/protocol incompatibility at `emit(WrongWriter())`; a missing import, checker crash, or zero selected files does not satisfy the negative check. Exact wording is checker-version-specific; bind the diagnostic code or structured location when available.

These local examples prove the rule only. For a library promise, use the actual installed library, stubs, public imports, and declared checker configuration in analogous downstream files. Exercise keyword-only changes, overload selection, protocol evolution, enum/literal expansion, and `TypedDict` field changes only where those surfaces are public.

## Runtime annotation consumers

Create a module in which a public annotation names a class defined later in the module. Observe import and the framework's actual resolution step separately. Add a missing runtime reference case, including a type imported only under `TYPE_CHECKING` if the project uses that pattern. Check the promised error and timing.

On Python 3.14, default deferred annotation evaluation differs from the future import's stringized behavior. Keep the module's annotation policy explicit and test across the actual supported range. Calling `typing.get_type_hints` can evaluate code; do not run it on untrusted input or custom annotation providers merely for inventory.

Do not infer that schema generation validates runtime values, that a static pass proves a validator's coercion policy, or that a runtime test proves packaged stubs are complete.

Sources: [typing](https://docs.python.org/3.14/library/typing.html), [annotationlib](https://docs.python.org/3.14/library/annotationlib.html), [Python 3.14 annotations](https://docs.python.org/3.14/whatsnew/3.14.html#pep-649-pep-749-deferred-evaluation-of-annotations). Example contracts and downstream checks are suite-authored.
