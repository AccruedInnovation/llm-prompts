# Async ownership, cancellation, and bounded work

Use these cases when the real application has the named lifetime or effect. [async_cases.py](../scripts/async_cases.py) supplies runnable, local demonstrations for Python 3.11+. Tests use events for ordering; timeouts bound a broken demonstration, not establish its order.

## Sibling failure: two valid contracts

```python
# Illustrative only: failure can propagate while other awaitables continue.
results = await asyncio.gather(fetch_a(), fetch_b())
```

Do not infer that the other request stopped when this raises. For independently useful results, continuing siblings may be intended. Keep references and provide an owner that observes completion, exceptions, and shutdown. `return_exceptions=True` changes result collection; inspect exceptions as results rather than silently treating them as data.

```python
# Illustrative only: this scope owns and joins both coroutines.
async with asyncio.TaskGroup() as group:
    a = group.create_task(fetch_a())
    b = group.create_task(fetch_b())
```

For an ordinary child failure, the group cancels and awaits the remaining children and raises grouped failure. Child cancellation has distinct behavior; `KeyboardInterrupt` and `SystemExit` also need their documented treatment. Do not flatten all failures into one generic result. A group does not undo already committed work, stop thread calls, or make cancellation-suppressing coroutines terminate promptly.

**Test:** Hold one sibling at an event after it announces it has started. Fail the other. Under `gather`, observe the caller's exception, then release the held sibling and observe its completion. Under a task group, verify the held coroutine ran its cancellation cleanup and did not reach the guarded success effect. Keep the loop alive after failure so `asyncio.run` shutdown does not accidentally cancel siblings and hide the distinction.

**Non-finding:** Intentional independent requests that return partial results and have explicit completion ownership do not require conversion to a task group.

## Cancelled waiter, continuing thread

```python
# Illustrative: cancelling the awaiter need not stop write_record.
await asyncio.to_thread(write_record, record)
```

An already-running executor call cannot be stopped by cancelling its future. A caller timeout therefore may leave the write in progress. The same applies when a task group owns the coroutine that awaits it. Identify the actual stop mechanism, cooperative cancellation point, deadline, transaction, and eventual-result owner. Thread cleanup and shutdown can outlive the request.

**Test:** Let the worker announce entry, block it on a thread event, cancel the awaiting task, and observe `CancelledError`. Only then release the worker. Verify that its harmless test effect happens after the caller sees cancellation. Join owned work in `finally`; a demonstration must not leak its own thread.

**Repair choices:** Bound synchronous I/O with a real deadline; use a worker that supports cooperative stop; retain and reconcile a durable operation ID; or isolate work in a process when termination is an authorized and safe policy. None promises rollback of an already committed remote effect. Choose the mechanism from the real effect contract, not convenience.

**Non-finding:** A read-only operation can continue after caller cancellation when bounded cost, shutdown ownership, and acceptable lifetime are explicit.

## Semaphore versus bounded admission

```python
# Illustrative defect for unbounded jobs:
tasks = [asyncio.create_task(handle_under_semaphore(job)) for job in jobs]
await asyncio.gather(*tasks)
```

A semaphore can cap active calls while every task and input remains retained. State the limit on accepted inputs, live tasks, queued items, item size, producer buffers, retries, and collected results. Avoid claiming a memory bound while accumulating all results in a list.

A fixed set of workers plus a finite-capacity queue is one suitable approach. Await `put` in a bounded producer; do not create a new producer task for each enqueue. Return results to a bounded or streaming consumer where necessary. Under Python 3.11/3.12, a deliberate sentinel or cancellation protocol can be simpler than a new dependency; newer queue shutdown APIs have different drain semantics.

**Test:** Hold all workers, start a known-size producer, and observe the number of workers, queue occupancy, and the one item waiting to be enqueued. Compare this with a semaphore-only batch that keeps all tasks pending. Release workers and verify every accepted item receives exactly the promised processing outcome. Test worker failure separately to detect a producer left blocked on a full queue.

**Non-finding:** An explicitly small fixed batch does not need a permanent queue subsystem merely to avoid a few tasks.

## Cancellation, deadlines, and cleanup

Use `try/finally` and owned context managers. If catching `CancelledError`, normally clean up and re-raise it. Do not translate it into success or consume it in a general retry loop. Required cleanup may itself await; a later cancellation can interrupt it. Define bounded cleanup and record its unresolved state rather than promising unconditional completion.

A timeout defines how the caller stops waiting; determine which work it cancels, what can continue, and whether elapsed time includes cancellation cleanup. Shielding changes cancellation propagation, not task ownership; retain and join shielded work. Nested timeout tests should distinguish their own deadline from an unrelated `TimeoutError` raised by the operation.

For a committing operation, use failpoints before send, after send, before commit, after commit, and before acknowledgement as applicable. At each point check durable state and whether retry can duplicate the effect. A cancelled future's state is not a transaction receipt.

Sources: [asyncio tasks and cancellation](https://docs.python.org/3.14/library/asyncio-task.html), [running executor calls](https://docs.python.org/3.14/library/concurrent.futures.html#concurrent.futures.Future.cancel), [queues and shutdown](https://docs.python.org/3.14/library/asyncio-queue.html). The schedules, result checks, and repair selection are suite-authored guidance; they do not certify an application.
