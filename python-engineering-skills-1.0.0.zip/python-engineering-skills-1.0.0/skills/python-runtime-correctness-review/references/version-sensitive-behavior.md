# Version-sensitive Python behavior

Checked against official documentation on 2026-09-08. This is a trigger list, not a support matrix or an instruction to upgrade. Use the project's minimum and selected versions and record implementation, platform, and configuration. Recheck version-sensitive claims when the supported range changes.

| Trigger | Relevant behavior | Small useful check | What it does not prove |
| --- | --- | --- | --- |
| Python 3.11+ async code | `TaskGroup` and exception groups add scoped failure/cleanup behavior. | Fail an owned child while another is blocked; observe cleanup and grouped errors. | Thread stop, remote rollback, or every cancellation interleaving. |
| Python 3.13+ queue shutdown | `asyncio.Queue.shutdown` exists; immediate shutdown can unblock `join` without normal work completion. | Compare graceful drain with immediate abandonment and inspect job outcomes. | That `join` alone establishes successful processing. |
| Python 3.14 process support | `fork` is no longer the default anywhere. On POSIX systems supporting it, `forkserver` becomes the default; Windows and macOS retain their relevant spawn behavior. | Inspect `get_all_start_methods()` and the selected context. Run a worker from an importable file with `if __name__ == "__main__"`. | Support for unavailable start methods or effects inherited under another method. |
| Annotation-consuming code on Python 3.14 | Default annotation evaluation is deferred; the future import keeps stringized behavior. | Load a module with forward references, then call the actual schema or introspection consumer under each supported version. | Runtime value validation or safety of resolving hostile annotations. |
| Free-threaded CPython 3.13+ | Build capability and runtime GIL state differ. Some extensions may enable the GIL at import. | Record `Py_GIL_DISABLED` build configuration and `sys._is_gil_enabled()` before and after relevant imports where available. | Race freedom, subinterpreter support, or performance benefit. |

## Process-context review

Libraries should accept a caller-supplied context where process integration needs one instead of globally selecting a start method. Build queues, locks, pools, and processes from compatible contexts. Passing a synchronization object made for a different context may fail or be unsupported.

Test the real message form across the chosen process boundary. A nested closure that works in a fork-inherited process is not proof of spawn serialization. The worker entry must be importable without starting recursive workers or opening application connections as an import side effect. Capture child errors, queue drain, join, and cleanup; do not treat a parent exit code as complete worker evidence.

## Annotation review

`get_type_hints` and other evaluators may run annotation expressions. A module that imports successfully may still fail when a framework later resolves a forward reference. Imports hidden under `TYPE_CHECKING` can leave runtime names unavailable. Prefer the exact version's appropriate non-evaluating inspection facility when only displaying annotations; no generic string format should be advertised as a universal sandbox for custom annotation providers.

## Free-threaded review

Check state after the imports that occur in the real application, not just at interpreter startup. Preserve explicit `PYTHON_GIL` or command-line overrides in evidence when relevant. Do not force the GIL off around an incompatible native module as a substitute for proving support. Review shared mutation and compound operations even when a GIL-enabled run passes.

Sources: [multiprocessing contexts](https://docs.python.org/3.14/library/multiprocessing.html#contexts-and-start-methods), [3.14 annotation change](https://docs.python.org/3.14/whatsnew/3.14.html#pep-649-pep-749-deferred-evaluation-of-annotations), [annotationlib](https://docs.python.org/3.14/library/annotationlib.html), [free threading](https://docs.python.org/3.14/howto/free-threading-python.html), [queue shutdown](https://docs.python.org/3.14/library/asyncio-queue.html#asyncio.Queue.shutdown).
