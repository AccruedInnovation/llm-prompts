"""Controlled local concurrency examples. Python 3.11+; no external effects.

Each timeout bounds fixture failure. Events, not elapsed sleeps, determine order.
"""
from __future__ import annotations
import asyncio
from concurrent.futures import ThreadPoolExecutor
import json
import threading


def expect(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


async def sibling_case(grouped: bool) -> dict[str, object]:
    entered, release = asyncio.Event(), asyncio.Event()
    trace: list[str] = []

    async def held() -> None:
        entered.set()
        try:
            await release.wait()
            trace.append('sibling_effect')
        finally:
            trace.append('sibling_cleanup')

    async def fail() -> None:
        await entered.wait()
        raise RuntimeError('intentional-child-failure')

    if grouped:
        saw_expected = False
        try:
            async with asyncio.TaskGroup() as group:
                task = group.create_task(held())
                group.create_task(fail())
        except* RuntimeError as errors:
            expect(all(str(e) == 'intentional-child-failure' for e in errors.exceptions),
                   'unrelated task-group failure')
            saw_expected = True
        expect(saw_expected, 'task group did not fail')
        expect(task.cancelled(), 'owned sibling was not cancelled')
        expect(trace == ['sibling_cleanup'], 'effect escaped cancellation schedule')
    else:
        task = asyncio.create_task(held())
        failure = asyncio.create_task(fail())
        try:
            try:
                await asyncio.gather(task, failure)
            except RuntimeError as exc:
                expect(str(exc) == 'intentional-child-failure', 'unrelated failure')
            else:
                raise AssertionError('gather did not propagate failure')
            expect(not task.done(), 'gather stopped sibling unexpectedly')
            trace.append('caller_observed_failure')
            release.set()
            await task
        finally:
            release.set()
            for child in (task, failure):
                if not child.done():
                    child.cancel()
            await asyncio.gather(task, failure, return_exceptions=True)
        expect(trace == ['caller_observed_failure', 'sibling_effect', 'sibling_cleanup'],
               'wrong gather trace')
    return {'mode': 'TaskGroup' if grouped else 'gather', 'trace': trace}


async def continuing_thread_case() -> dict[str, object]:
    loop = asyncio.get_running_loop()
    entered = asyncio.Event()
    release = threading.Event()
    trace: list[str] = []
    trace_lock = threading.Lock()

    def worker() -> str:
        loop.call_soon_threadsafe(entered.set)
        if not release.wait(5):
            raise RuntimeError('fixture-release-timeout')
        with trace_lock:
            trace.append('worker_effect')
        return 'completed'

    executor = ThreadPoolExecutor(max_workers=1)
    future = executor.submit(worker)

    async def await_worker() -> str:
        return await asyncio.wrap_future(future)

    task = asyncio.create_task(await_worker())
    try:
        await asyncio.wait_for(entered.wait(), timeout=3)
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            with trace_lock:
                trace.append('caller_observed_cancelled')
        else:
            raise AssertionError('awaiting task ignored cancellation')
        expect(future.running(), 'the native future should still run')
        release.set()
        result = await asyncio.wait_for(asyncio.wrap_future(future), timeout=3)
        expect(result == 'completed', 'worker result missing')
    finally:
        release.set()
        if not task.done():
            task.cancel()
        await asyncio.gather(task, return_exceptions=True)
        # The worker is bounded and released even on failure; close our own executor.
        executor.shutdown(wait=True, cancel_futures=True)
    expect(trace == ['caller_observed_cancelled', 'worker_effect'], 'wrong thread trace')
    return {'trace': trace, 'worker_result': result}


async def admission_cases() -> dict[str, object]:
    n, workers, capacity = 64, 2, 3
    sem = asyncio.Semaphore(workers)
    release = asyncio.Event()
    full = asyncio.Event()
    active = 0

    async def sem_worker() -> None:
        nonlocal active
        async with sem:
            active += 1
            if active == workers:
                full.set()
            try:
                await release.wait()
            finally:
                active -= 1

    tasks = [asyncio.create_task(sem_worker()) for _ in range(n)]
    try:
        await asyncio.wait_for(full.wait(), timeout=3)
        pending = sum(not t.done() for t in tasks)
        expect(pending == n and active == workers, 'semaphore fixture not at hold point')
    finally:
        release.set()
        await asyncio.gather(*tasks)

    queue: asyncio.Queue[int | None] = asyncio.Queue(maxsize=capacity)
    release_workers = asyncio.Event()
    workers_held = asyncio.Event()
    queue_blocked = asyncio.Event()
    in_progress = 0
    queued = 0
    completed: set[int] = set()
    peak_queue = 0

    async def consume() -> None:
        nonlocal in_progress
        while True:
            item = await queue.get()
            try:
                if item is None:
                    return
                in_progress += 1
                if in_progress == workers:
                    workers_held.set()
                await release_workers.wait()
                expect(item not in completed, 'duplicate fixture item')
                completed.add(item)
                in_progress -= 1
            finally:
                queue.task_done()

    async def produce() -> None:
        nonlocal queued, peak_queue
        for item in range(n):
            if item == workers + capacity:
                await workers_held.wait()
                queue_blocked.set()
            await queue.put(item)
            queued += 1
            peak_queue = max(peak_queue, queue.qsize())
        for _ in range(workers):
            await queue.put(None)

    async with asyncio.TaskGroup() as group:
        consumers = [group.create_task(consume()) for _ in range(workers)]
        producer = group.create_task(produce())
        try:
            await asyncio.wait_for(queue_blocked.wait(), timeout=3)
            # Producer signalled immediately before an await on the full queue.
            expect(queue.qsize() == capacity, 'queue not full at planned hold point')
            expect(in_progress == workers, 'workers not held')
            expect(queued == workers + capacity and not producer.done(),
                   'producer admission did not stop at the expected bound')
            live_work_tasks = sum(not t.done() for t in consumers) + int(not producer.done())
        finally:
            release_workers.set()
    expect(completed == set(range(n)), 'incomplete fixture processing')
    expect(peak_queue <= capacity, 'queue bound violated')
    return {'semaphore_pending_tasks': pending, 'semaphore_active_limit': workers,
            'bounded_queue_capacity': capacity, 'bounded_work_tasks_at_hold': live_work_tasks,
            'accepted_at_hold': workers + capacity, 'processed': len(completed),
            'note': 'completed set is fixture evidence, not a streaming-memory design'}


async def worker_failure_case() -> dict[str, object]:
    queue: asyncio.Queue[int] = asyncio.Queue(maxsize=1)
    held = asyncio.Event()
    fail_now = asyncio.Event()
    producer_cleaned = asyncio.Event()

    async def producer() -> None:
        try:
            for item in range(100):
                await queue.put(item)
        finally:
            producer_cleaned.set()

    async def consumer() -> None:
        await queue.get()
        try:
            held.set()
            await fail_now.wait()
            raise RuntimeError('worker-failed')
        finally:
            queue.task_done()

    saw_failure = False
    try:
        async with asyncio.TaskGroup() as group:
            p = group.create_task(producer())
            group.create_task(consumer())
            await held.wait()
            fail_now.set()
    except* RuntimeError as errors:
        expect(all(str(e) == 'worker-failed' for e in errors.exceptions), 'unexpected error')
        saw_failure = True
    expect(saw_failure and p.cancelled() and producer_cleaned.is_set(),
           'blocked producer was not cancelled and cleaned up')
    return {'producer_cancelled': True, 'producer_cleanup': True,
            'note': 'queued work is intentionally unresolved after fixture failure'}


async def self_check() -> dict[str, object]:
    async with asyncio.timeout(15):
        return {'status': 'PASS', 'cases': [await sibling_case(False),
                await sibling_case(True), await continuing_thread_case(),
                await admission_cases(), await worker_failure_case()]}

if __name__ == '__main__':
    print(json.dumps(asyncio.run(self_check()), sort_keys=True))
