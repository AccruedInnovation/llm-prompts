---
name: python-implementation-structure-authoring
description: "Design Python module boundaries, value ownership, validation, resource lifetime, and test seams within an agreed scope. Preserve public contracts and leave harmless private choices open."
---

# Python Implementation Structure Authoring

Use this skill to design a material Python change or elaborate an agreed design. Reuse a supplied design, PRD, or contract, including an `ImplementationStructureContract` when one exists. A plain task brief is sufficient for a small scope; do not require a particular schema or orchestration system.

## Authoring sequence

1. Identify the current brief or contract, baseline, subject, scope, interfaces, required checks, fixed decisions, allowed local choices, and prohibited shortcuts. Use the existing revision or a content identity where it matters; do not invent contract IDs.
2. Inspect source and project metadata without running them. Establish the interpreter, backend, import layout, dependencies, and repository commands. Run a bounded experiment only when the task permits it; separate the observed result from the planned design.
3. Map the realization using the repository's actual packaging and import model:
   - distribution, wheel, sdist, application, service, or internal-only repository;
   - package, namespace package, module, entry point, plugin group, generated artifact, migration, native extension, test, and fixture topology;
   - source-tree, editable-install, wheel, sdist-derived-wheel, and deployed subjects where materially different.
4. Make consequential Python contracts explicit:
   - public runtime import/export surface;
   - public typing surface, stubs, `py.typed`, overloads, and checker expectations;
   - runtime schemas and validation at external or persistence trust boundaries;
   - exception taxonomy and stable caller handling;
   - serialization, persistence, configuration, CLI, plugin, and process-message contracts;
   - resource, context-manager, task, process, queue, transaction, and cancellation ownership.
5. Apply the type-depth test. Recommend a type or abstraction only when it prevents a material invalid combination, localizes an invariant, clarifies ownership, stabilizes a boundary, improves change locality, creates a meaningful test seam, or hides consequential complexity.
6. Distinguish three different claims:
   - static annotation or type-checker evidence;
   - runtime construction and validation evidence;
   - operational or consumer evidence in the supported environment.
7. Record fixed decisions narrowly. Suitable fixed decisions include public import names, distribution metadata, state ownership, runtime validation location, process-message schema, task/cancellation ownership, persistence or migration sequencing, effect ownership, and supported package subjects.
8. Preserve delegated freedom for private helper names, local iteration, equivalent private module placement, internal representation choices that preserve the fixed contracts, and test utility layout.
9. Define test seams and touchpoints before independent work begins. Prefer consumer-visible imports, installed-wheel behavior, CLI entry points, plugin discovery, runtime validation, async cancellation, process handoff, migration rehearsal, and package inspection over private-tree equality.
10. Return unsupported or uncertain areas explicitly. Do not invent support for native extensions, free-threaded execution, alternative interpreters, platform packaging, or deployment environments that the repository does not claim or the available evidence does not establish.

## Python type vocabulary

Use the least powerful form that protects the actual contract:

- domain-specific identity values instead of interchangeable strings or integers where confusion is material;
- `Enum` or closed literal/discriminated forms for closed states and outcomes;
- frozen dataclasses when ordinary field rebinding should be restricted; establish immutable value semantics through reachable values, construction, copying, and ownership, not `frozen=True` alone;
- `TypedDict` for dictionary-shaped static contracts without implying runtime validation;
- `Protocol` at genuine consumer-defined substitution and test seams;
- abstract bases only when runtime nominal behavior or registration is required;
- runtime validation models or explicit parsing at untrusted boundaries;
- exception classes or result dispositions when callers need stable failure classification;
- context managers and async context managers for resource lifetime;
- explicit task, cancellation, process, queue, transaction, and retry ownership.
- evidence dispositions that keep `NOT_RUN`, `BLOCKED`, `ERROR`, `INCONCLUSIVE`, `PASS`, and `FAIL` distinct rather than collapsing availability or infrastructure failure into a test result.

Do not introduce deep inheritance, a protocol for every class, duplicate DTO/model layers without distinct semantics, or framework-specific schemas in the stable domain without a real boundary need.

## Worked boundary and selection rules

Read [value boundaries and ownership](references/value-boundaries.md) when external input, domain identity, mutable values, or construction rules matter. It includes a strict JSON policy, a flawed frozen container, a detached immutable value, and precise rejection cases. Use [the executable boundary example](scripts/boundary_case.py) only as a bounded learning case, not as a generic validator to paste into every project.

The example deliberately chooses a strict contract. Projects may choose coercion or extensible fields, but must define those choices and test them. Required validation must raise a real error, not rely on `assert`, which optimized execution can remove.

## Return

Return the proposed Python responsibilities, public contracts, value and resource owners, validation locations, failure behavior, consumer checks, and fixed versus private choices. Retain the agreed design as the source of truth. State any unresolved shared decision and the permitted work that can continue. A design is not implementation evidence or execution permission.


## Use and evidence limits

Use this guidance within the task’s scope and permitted effects. Examples define their own small contracts; adapt them only after establishing the project’s actual requirements. Review is read-only unless repair is requested. Local references belong to this skill; other skill names are optional further expertise. Keep checks not run, observed failures, environment failures, and passed assertions distinct.
