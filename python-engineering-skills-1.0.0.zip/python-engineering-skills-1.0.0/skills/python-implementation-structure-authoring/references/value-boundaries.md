# Runtime value boundaries and ownership

## Choose a construct for its actual guarantee

| Need | Useful form | Limit to inspect |
| --- | --- | --- |
| Distinguish identifiers statically | `NewType` | Returns its input at runtime; it does not parse or validate. |
| Describe mapping fields to a checker | `TypedDict` | Does not reject an incoming dictionary. |
| Express a consumer's substitution boundary | `Protocol` | Runtime-checkable protocols do not verify signatures or behavior. |
| Tell a checker a fact already established | `cast` | Performs no runtime check. |
| Restrict ordinary attribute assignment | Frozen dataclass | Does not freeze reachable objects or validate annotations. |
| Hold domain values | Class or dataclass with a deliberate constructor | Direct construction, aliases, nested values, and deserialization need a policy. |
| Accept outside input | Explicit parser or suitable validation library | Coercion, unknown fields, limits, errors, and ownership remain design choices. |

Do not require a dependency where a short parser protects the whole contract. Conversely, do not replace a tested project validator with a hand-written example without a reason.

## The frozen-container defect

```python
from dataclasses import dataclass

@dataclass(frozen=True)
class BadSnapshot:
    values: list[int]

caller_values = [1]
snapshot = BadSnapshot(caller_values)
caller_values.append(2)
snapshot.values.append(3)
```

The final value is `[1, 2, 3]`. Two references can mutate the same list. A frozen wrapper or shallow copy does not provide immutable nested values. Converting to a tuple is enough only when each reachable element has the required semantics too.

A non-finding: a frozen object intentionally holds a mutable shared cache, and the contract names its owner, synchronization, and lifetime. Do not claim this is an immutable value; do not demand a deep copy if sharing is deliberate.

## Worked strict boundary

[boundary_case.py](../scripts/boundary_case.py) defines a small learning contract, not a general wire format:

* Input is UTF-8 JSON bytes, at most 4,096 bytes, with an object at the root.
* `count` and `readings` are required. `count` is an exact integer from 1 through 1,000, excluding Boolean values. `readings` is a list of exactly that many finite numbers; Boolean values and numeric strings are invalid.
* `note` may be absent or null, both deliberately meaning no note; otherwise it is a string of at most 80 characters. Required fields never treat null as absence.
* Unknown fields, repeated keys, non-finite constants, out-of-range counts, and non-finite parsed numbers fail. Check after float conversion too: a numeric exponent such as `1e999` can overflow even without a named `Infinity` constant.
* The returned `Snapshot` owns a tuple of floats and exposes no caller-owned list. Its constructor checks its own invariants; direct invalid construction also fails.

The parser separates decoding, object shape, field validation, normalization, and domain construction. It raises `InvalidSnapshot` with a stable code. No effects occur while input is invalid. Public messages do not include the raw payload.

| Input or operation | Expected result |
| --- | --- |
| `{"count":2,"readings":[1,2.5]}` | `count == 2`, `readings == (1.0, 2.5)`, `note is None` |
| Same with `"note":null` | Same deliberate no-note semantics |
| Missing `count` / `"count":null` | `missing:count` / `type:count`, separately |
| `"count":true` or `"count":"2"` | `type:count` |
| Count zero or 1,001 | `range:count` |
| A repeated key | `duplicate-key` before application validation |
| Unknown field | `unknown-field` |
| `NaN`, `Infinity`, or `-Infinity` | `nonfinite-constant` |
| Reading `1e999` | `value:readings` |
| Wrong list length | `length:readings` |
| Invalid UTF-8 or invalid JSON syntax | `decode` |
| Payload exceeds the byte limit | `size` |

Test a valid case first so a reject-everything parser fails. Then exercise each rule with unrelated fields valid. Inspect exact codes, not just `ValueError`. Mutate the caller's decoded list after construction and verify that the returned value stays unchanged. Try direct invalid construction. Run required checks under `python -O` as well: correctness must not depend on removable assertions.

An application may intentionally coerce numeric strings or accept extension fields. That is a different contract, not automatically a defect. Preserve its specified behavior and test the consequences.

## Limitations and sources

The small byte limit bounds this fixture's input, not every production parser risk. It does not define a streaming parser, a schema evolution policy, arbitrary nested types, or an adversarial sandbox. Use project-specific depth, resource, and compatibility policies where needed.

Behavior sources: [dataclasses and frozen instances](https://docs.python.org/3.14/library/dataclasses.html#frozen-instances), [typing constructs](https://docs.python.org/3.14/library/typing.html), [JSON compliance details](https://docs.python.org/3.14/library/json.html#standard-compliance-and-interoperability), [assert](https://docs.python.org/3.14/reference/simple_stmts.html#the-assert-statement). Limits, error codes, and the test matrix above are suite-authored example requirements.
