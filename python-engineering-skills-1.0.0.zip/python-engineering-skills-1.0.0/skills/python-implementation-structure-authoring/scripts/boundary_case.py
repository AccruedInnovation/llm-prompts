"""Bounded learning example: strict JSON, explicit validation, and owned values.

Run this file for local self-checks. It reads no external files, uses no network,
and writes no files. It is not a general-purpose validator or sandbox.
"""
from __future__ import annotations

from dataclasses import dataclass
import json
import math
from typing import Any

MAX_BYTES = 4096

class InvalidSnapshot(ValueError):
    def __init__(self, code: str):
        self.code = code
        super().__init__(code)

@dataclass(frozen=True)
class Snapshot:
    count: int
    readings: tuple[float, ...]
    note: str | None = None

    def __post_init__(self) -> None:
        if type(self.count) is not int:
            raise InvalidSnapshot('type:count')
        if not 1 <= self.count <= 1000:
            raise InvalidSnapshot('range:count')
        if type(self.readings) is not tuple:
            raise InvalidSnapshot('type:readings')
        if len(self.readings) != self.count:
            raise InvalidSnapshot('length:readings')
        if any(type(x) is not float or not math.isfinite(x) for x in self.readings):
            raise InvalidSnapshot('value:readings')
        if self.note is not None and type(self.note) is not str:
            raise InvalidSnapshot('type:note')
        if self.note is not None and len(self.note) > 80:
            raise InvalidSnapshot('length:note')


def unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise InvalidSnapshot('duplicate-key')
        result[key] = value
    return result


def reject_constant(value: str) -> None:
    raise InvalidSnapshot('nonfinite-constant')


def from_mapping(value: object) -> Snapshot:
    if type(value) is not dict:
        raise InvalidSnapshot('root-type')
    if set(value) - {'count', 'readings', 'note'}:
        raise InvalidSnapshot('unknown-field')
    for key in ('count', 'readings'):
        if key not in value:
            raise InvalidSnapshot('missing:' + key)
    count = value['count']
    if type(count) is not int:
        raise InvalidSnapshot('type:count')
    if not 1 <= count <= 1000:
        raise InvalidSnapshot('range:count')
    readings = value['readings']
    if type(readings) is not list:
        raise InvalidSnapshot('type:readings')
    if len(readings) != count:
        raise InvalidSnapshot('length:readings')
    normalized: list[float] = []
    for item in readings:
        if type(item) not in (int, float):
            raise InvalidSnapshot('value:readings')
        try:
            number = float(item)
        except (OverflowError, ValueError) as exc:
            raise InvalidSnapshot('value:readings') from exc
        if not math.isfinite(number):
            raise InvalidSnapshot('value:readings')
        normalized.append(number)
    return Snapshot(count, tuple(normalized), value.get('note'))


def parse_snapshot(raw: bytes) -> Snapshot:
    if type(raw) is not bytes:
        raise InvalidSnapshot('input-type')
    if len(raw) > MAX_BYTES:
        raise InvalidSnapshot('size')
    try:
        decoded = json.loads(raw.decode('utf-8'), object_pairs_hook=unique_object,
                             parse_constant=reject_constant)
    except InvalidSnapshot:
        raise
    except (UnicodeDecodeError, json.JSONDecodeError, RecursionError, ValueError) as exc:
        raise InvalidSnapshot('decode') from exc
    return from_mapping(decoded)


def expect(condition: bool, message: str) -> None:
    # Deliberately not assert: these checks must still run under python -O.
    if not condition:
        raise AssertionError(message)


def self_check() -> dict[str, object]:
    good = parse_snapshot(b'{"count":2,"readings":[1,2.5]}')
    expect(good == Snapshot(2, (1.0, 2.5)), 'normalization')
    expect(parse_snapshot(b'{"count":1,"readings":[0],"note":null}').note is None,
           'nullable note')
    expect(parse_snapshot(b'{"count":1,"readings":[0],"note":"ok"}').note == 'ok',
           'string note')
    cases: list[tuple[bytes, str]] = [
        (b'{"readings":[1]}', 'missing:count'),
        (b'{"count":1}', 'missing:readings'),
        (b'{"count":null,"readings":[1]}', 'type:count'),
        (b'{"count":true,"readings":[1]}', 'type:count'),
        (b'{"count":"1","readings":[1]}', 'type:count'),
        (b'{"count":0,"readings":[]}', 'range:count'),
        (b'{"count":1001,"readings":[]}', 'range:count'),
        (b'{"count":1,"count":2,"readings":[1]}', 'duplicate-key'),
        (b'{"count":1,"readings":[1],"extra":0}', 'unknown-field'),
        (b'{"count":1,"readings":[NaN]}', 'nonfinite-constant'),
        (b'{"count":1,"readings":[Infinity]}', 'nonfinite-constant'),
        (b'{"count":1,"readings":[-Infinity]}', 'nonfinite-constant'),
        (b'{"count":1,"readings":[1e999]}', 'value:readings'),
        (b'{"count":1,"readings":[true]}', 'value:readings'),
        (b'{"count":1,"readings":["1"]}', 'value:readings'),
        (b'{"count":2,"readings":[1]}', 'length:readings'),
        (b'{"count":1,"readings":null}', 'type:readings'),
        (b'{"count":1,"readings":[1],"note":3}', 'type:note'),
        (json.dumps({'count':1,'readings':[1],'note':'x'*81}).encode(), 'length:note'),
        (b'[]', 'root-type'),
        (b'\xff', 'decode'),
        (b'{', 'decode'),
        (b' ' * (MAX_BYTES + 1), 'size'),
    ]
    for raw, code in cases:
        try:
            parse_snapshot(raw)
        except InvalidSnapshot as exc:
            expect(exc.code == code, f'expected {code}, got {exc.code}')
        else:
            raise AssertionError(f'accepted input that should reject with {code}')
    caller = {'count': 1, 'readings': [1]}
    detached = from_mapping(caller)
    caller['readings'].append(2)
    expect(detached.readings == (1.0,), 'caller alias remains attached')
    try:
        Snapshot(1, [1.0])  # type: ignore[arg-type] -- deliberate runtime negative case
    except InvalidSnapshot as exc:
        expect(exc.code == 'type:readings', 'wrong direct-construction failure')
    else:
        raise AssertionError('direct construction accepted a mutable list')
    return {'status': 'PASS', 'valid_cases': 3, 'rejection_cases': len(cases),
            'ownership_cases': 2, 'optimized_execution': not __debug__}

if __name__ == '__main__':
    print(json.dumps(self_check(), sort_keys=True))
