"""Record selected environment facts. Explicit module imports EXECUTE their code.

The probe does not itself request network access, install packages, or dump
arbitrary environment variables. Imported modules can perform their own effects
and Python can create bytecode caches; use an authorized environment.
"""
from __future__ import annotations
import argparse
import importlib
from importlib import metadata
import json
import platform
import sys
import sysconfig


def gil_state() -> bool | None:
    probe = getattr(sys, '_is_gil_enabled', None)
    return bool(probe()) if callable(probe) else None


def inspect_environment(modules: list[str], distributions: list[str]) -> dict[str, object]:
    before = gil_state()
    origins: dict[str, object] = {}
    for name in modules:
        module = importlib.import_module(name)
        spec = getattr(module, '__spec__', None)
        locations = getattr(spec, 'submodule_search_locations', None)
        origins[name] = {'file': getattr(module, '__file__', None),
                         'origin': getattr(spec, 'origin', None),
                         'search_locations': list(locations) if locations is not None else []}
    versions = {name: metadata.version(name) for name in distributions}
    return {'implementation': platform.python_implementation(), 'version': sys.version,
            'executable': sys.executable, 'prefix': sys.prefix, 'base_prefix': sys.base_prefix,
            'platform': platform.platform(), 'machine': platform.machine(),
            'filesystem_encoding': sys.getfilesystemencoding(), 'sys_path': list(sys.path),
            'free_threaded_build': sysconfig.get_config_var('Py_GIL_DISABLED'),
            'gil_enabled_before_imports': before, 'gil_enabled_after_imports': gil_state(),
            'module_origins': origins, 'selected_distribution_versions': versions}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--module', action='append', default=[], help='Known module to import; may execute code.')
    parser.add_argument('--distribution', action='append', default=[], help='Installed distribution whose version to record.')
    args = parser.parse_args()
    try:
        record = inspect_environment(args.module, args.distribution)
    except Exception as exc:
        # Do not echo an arbitrary exception message that may contain private input.
        print(json.dumps({'status':'ERROR','exception_type':type(exc).__name__}), file=sys.stderr)
        return 1
    print(json.dumps({'status': 'PASS', 'facts': record}, sort_keys=True, indent=2))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
