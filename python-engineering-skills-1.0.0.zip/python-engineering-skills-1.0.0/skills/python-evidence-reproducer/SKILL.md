---
name: python-evidence-reproducer
description: "Reproduce a Python failure or bind a test result to its exact interpreter, inputs, installed code, dependencies, and attempts. Use for diagnosis or evidence repair, not routine reporting overhead."
---

# Python Evidence and Reproducer

Use evidence to prove one declared assertion against one exact subject.

## Minimum identity

Record:

- candidate identity and the versions of guidance or tools that materially affect the check;
- interpreter implementation, exact version, executable identity, ABI, GIL/free-threaded state;
- operating system, architecture, locale, timezone, encoding, and relevant environment;
- environment manager, lock/resolution digest, installed-distribution inventory digest;
- build backend and version;
- subject mode: source, editable, wheel, sdist-derived wheel, image, or service;
- selected extras, dependency groups, checker targets, process start method, and native toolchain where relevant;
- exact command, configuration, inputs, output, exit state, and time.

Redact secret values; record only necessary names, provenance, or digests.

## Special evidence

Preserve:

- property/state-machine seed, minimized example, and regression artifact;
- fuzz corpus digest, crash input, minimized reproducer, budget, and tool version;
- concurrency schedule controls, timeouts, task/process trace, and start method;
- every flaky retry and its environment;
- snapshot/golden predecessor, successor, and approval disposition;
- mutation operator, surviving mutant, timeout, equivalent-mutant rationale, and tool failure separately;
- migration initial state, data volume, forward result, rollback result, and interruption point;
- sdist/wheel digest, tags, file lists, installed files, and clean environment;
- benchmark workload, warmup, samples, variance, baseline, interpreter, flags, and resource conditions;
- native crash symbols, extension digest, platform, and sanitizer/debugger output.

## Reuse

Reuse a prior pass only when the assertion, candidate, interpreter, environment, lock, artifact, configuration, tool, fixture, and evidence semantics are unchanged. A source-only pass cannot be reused for an installed-wheel assertion.

## Dispositions

Keep `PASS`, `FAIL`, `BLOCKED`, `ERROR`, `INCONCLUSIVE`, `NOT_APPLICABLE`, and `SKIPPED_BY_POLICY` distinct. Retrying does not erase prior failures.

Return the assertion, subject, evidence identity, reproduction command, result, reuse decision, and residual gap.


## Reproducer procedure

Read [minimal reproducer and evidence limits](references/reproducer.md). First reproduce with the original environment and input. Reduce one factor at a time while preserving the failure; retain the original before minimizing. Capture import origins for suspect packages and actual GIL state after the relevant imports for a free-threaded claim. A successful import is not evidence that an extension preserved GIL-disabled execution.

Use [the environment probe](scripts/environment_probe.py) only with explicit module names in an authorized environment: importing a module executes its code. The probe reports selected facts, not a full lockfile, sandbox, provenance proof, or arbitrary environment variables. Do not treat a digest of a secret as safe to publish.

For planned-versus-actual work, record the agreed design and exact candidate. Separate missing evidence, harmless private changes, and a changed fixed decision. A comparison does not grant acceptance or release permission.


## Use and evidence limits

Use this guidance within the task’s scope and permitted effects. Examples define their own small contracts; adapt them only after establishing the project’s actual requirements. Review is read-only unless repair is requested. Local references belong to this skill; other skill names are optional further expertise. Keep checks not run, observed failures, environment failures, and passed assertions distinct.
