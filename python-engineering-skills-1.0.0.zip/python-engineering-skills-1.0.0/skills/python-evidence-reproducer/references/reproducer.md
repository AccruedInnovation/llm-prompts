# A small reproducer with honest evidence

## Reduce a failure without changing its cause

Start with the exact failing command, interpreter, candidate, environment, and input. Retain original output and exit status. Change one dimension at a time while minimizing: data, dependencies, caller path, scheduling, or package subject. Re-run the original before claiming the minimized version reproduces it.

A source reproduction is useful, but does not preserve an installed-only failure if it silently changes imports. Record actual origins. For a flaky failure preserve every attempt; a later success does not erase the earlier observation.

## Small ownership reproduction

```python
from dataclasses import dataclass

@dataclass(frozen=True)
class Snapshot:
    values: list[int]

values = [1]
result = Snapshot(values)
values.append(2)
print(result.values)  # [1, 2]
```

This proves shallow freezing and aliasing on the recorded interpreter. It does not prove an application's requirement was violated until the application promises detached stable values. Record the governing rule separately from this observation.

## Environment probe

Run [environment_probe.py](../scripts/environment_probe.py) using the interpreter under investigation. Pass only the module names required for the claim. It records interpreter/version, OS/architecture, selected paths and installed-distribution versions, selected module origins, and GIL state before and after imports when the interpreter provides that API.

Imports are execution. Only probe known modules in a permitted environment. The script neither scans all packages nor captures arbitrary environment variables or secrets. Review output paths before sharing; source paths and distribution names may themselves be sensitive. A hash of a low-entropy secret is not safe redaction.

Compare the selected origins against installed-file evidence for an installed-only claim. The probe records facts; it does not decide which origins are authorized. A GIL flag unavailable on an interpreter stays unavailable; do not invent `false`. A free-threaded build that enables the GIL after an extension import has not demonstrated that extension working without the GIL.

## Enough evidence, not a new reporting framework

A short result record may be sufficient:

```text
Claim: Snapshot construction detaches caller-owned values.
Subject: exact file hash or candidate revision plus relevant local changes.
Environment: interpreter executable/version and relevant dependencies.
Command and input: recorded argv and fixture bytes.
Expected: result stays unchanged after caller mutation.
Observed: result changes from [1] to [1, 2].
Disposition: FAIL for this ownership claim.
Limits: no concurrency, wheel, other-platform, or agent-performance claim.
```

Use the repository's existing records when available. Record child setup failure, timeout, missing tool, and application assertion failure separately. Never label a projection, package manifest, or successful schema check as evidence for an unexecuted consumer path.

Sources: [dataclasses](https://docs.python.org/3.14/library/dataclasses.html), [sys](https://docs.python.org/3.14/library/sys.html), [free threading](https://docs.python.org/3.14/howto/free-threading-python.html). The reproducer procedure and evidence record are suite-authored.
