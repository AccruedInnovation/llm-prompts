# Private variation versus ownership drift

## Harmless variation

Agreed design: public `sample.parse_snapshot(raw)` validates outside input and returns an owned immutable domain value; invalid input causes no writes. Private parsing layout is delegated.

Candidate: the public function delegates to `_decode.parse`, while the design sketch placed the helper in `_parse.py`.

Review the installed public import, accepted and rejected behavior, direct construction, nested ownership, and no-write property. If those match, the private module move is not material divergence. Do not require a shim for a helper with no public, plugin, serialized, or runtime consumer. Confirm that it truly is private before making that judgment.

## Material ownership change despite a matching file tree

Agreed design: construction detaches caller-owned mutable data.

Candidate:

```python
@dataclass(frozen=True)
class Snapshot:
    values: list[int]
```

The caller mutates its original list after construction; the snapshot changes. Matching filenames, class names, and frozen syntax do not establish the promised ownership. Reproduce the alias mutation and name the exact fixed invariant violated. Repair construction and reachable types within the design, then verify both alias independence and compatible public serialization.

A deliberate shared cache would be a different contract. Do not call its mutability a defect without the requirement for a stable value.

## Material lifetime change despite matching outputs

Agreed design: service shutdown waits for all accepted writes or records their unresolved operation IDs.

Candidate: a request creates a detached task, returns success, and discards its reference. The happy-path response stays identical, but no owner observes failure or joins the task during shutdown.

Hold the writer at a controlled event, close admission, and initiate shutdown. Inspect completion or unresolved-operation evidence. A passed response snapshot is not sufficient. A task registry or service-owned scope may be a small repair; a new distributed worker system is not implied.

## Reporting

Separate observed divergence from missing evidence. Name the governing behavior, actual path, reproducible observation, affected consumer, repair owner, and exact recheck. A design may permit private choices while fixing public imports or error codes; do not classify an explicit fixed decision as advisory merely because it is easy to change.

Sources for example mechanisms: [dataclasses](https://docs.python.org/3.14/library/dataclasses.html), [asyncio tasks](https://docs.python.org/3.14/library/asyncio-task.html). Design requirements in these cases are illustrative.
