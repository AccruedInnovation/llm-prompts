---
name: python-execution-slice-design
description: "Plan coherent Python implementation slices with a real consumer path, dependencies, failure checks, and cleanup. Use for explicit delivery planning, not every small code edit."
---

# Python Execution Slice Design

Use this skill for explicit implementation planning or when a material Python change needs early integrated feedback. Reuse supplied slices when present; otherwise define a small slice from the authorized goal. No workflow schema or work-unit registry is required.

## Slice discipline

1. Establish the goal, supplied plan or scope, fixed design, contributors, interfaces, assertions, integration owner, entry and exit conditions, failure containment, and temporary fixtures. Reuse existing IDs and revisions rather than inventing a second plan.
2. Preserve any supplied slice boundaries. Add only the Python-specific work and evidence needed for its consumer path; when planning from a goal, choose that path before splitting files or modules.
3. Prefer a vertical or otherwise integrated touchpoint:
   - import the public package from outside the checkout;
   - invoke a public API through its normal package subject;
   - execute a console entry point;
   - build and install a wheel, then exercise a consumer fixture;
   - discover and call a plugin entry point;
   - validate external JSON into a runtime domain form and reject invalid data;
   - observe async task ownership, cancellation, cleanup, and result propagation;
   - serialize a job or process message across the actual process boundary;
   - rehearse a migration and rollback against a bounded fixture;
   - run a protocol or package compatibility fixture.
4. Identify the minimum dependency closure. Include only the packages, modules, runtime schemas, adapters, fixtures, configuration, and work units required for the declared observation.
5. Treat a source-tree import, editable install, installed wheel, sdist-derived wheel, and deployed environment as different evidence subjects.
6. Name one integration owner. Several work units may contribute, but one owner is accountable for the integrated touchpoint and its evidence.
7. Define a candidate and validation cohort that preserve coherent repair and rollback. Do not merge unrelated work merely because it uses Python.
8. Record scaffolding explicitly: fake repository, temporary plugin, fixture queue, migration snapshot, compatibility adapter, generated sample, or test-only entry point. Every scaffold needs an owner and one of remove, replace, retain-as-fixture, or supersede.
9. A foundation-first slice is acceptable only when a vertical touchpoint is impossible or misleading, the foundation retires a named feasibility or safety risk, it has an inspectable touchpoint of its own, and it names the integrated slice enabled next.
10. Do not define atomicity by file count, function count, line count, or one-agent execution.

## Evidence vocabulary

Use assertions and evidence appropriate to the touchpoint:

- import and export inspection;
- clean installed-wheel consumer test;
- runtime validation positive and negative fixtures;
- type-checker output only for declared static contracts;
- async cancellation and cleanup trace;
- process start-method and message round trip;
- plugin discovery result;
- migration before/after and rollback state;
- sdist/wheel content and metadata inspection;
- exact candidate, interpreter, environment, dependency, and configuration identities.

## Return

Return the Python slice plan, touchpoint plan, exact dependency closure, selected skills and planned gates, likely candidate/validation boundary, scaffolding risks and disposition, horizontal-sequencing assessment, unsupported areas, blockers, and scope and effect limits. Planning does not execute the checks or authorize publication.

## Worked slice

Read [an installed CLI consuming validated data](references/consumer-slice.md) for a complete narrow slice: fixed behavior, inputs, integration order, accepted and rejected examples, package-origin checks, and fixture disposition. It also shows why a missing module is not the same as successful input rejection.


## Use and evidence limits

Use this guidance within the task’s scope and permitted effects. Examples define their own small contracts; adapt them only after establishing the project’s actual requirements. Review is read-only unless repair is requested. Local references belong to this skill; other skill names are optional further expertise. Keep checks not run, observed failures, environment failures, and passed assertions distinct.
