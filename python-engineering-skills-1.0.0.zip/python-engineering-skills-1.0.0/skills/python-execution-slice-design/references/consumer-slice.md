# One slice: an installed CLI consumes validated input

This is a worked design, not an instruction to change a project's CLI. Apply the same method to its actual consumer path.

## Outcome and fixed behavior

A user invokes an installed `snapshot-check` command with a UTF-8 JSON file. It validates `count`, `readings`, and optional `note`, returns a deterministic normalized summary, and exits zero. Invalid input yields the promised error code on stderr and exits two. Validation performs no writes. File-open failure has a separate error from invalid content.

A source import is not this outcome. The public API, runtime validator, package resource if required, entry point, and installed command all participate.

## Inputs and dependency order

Before implementation, establish the input and output rules, public import and command names, error mapping, supported interpreter, backend, runtime dependencies, and a runnable consumer-check method. A small task brief can hold them; do not demand a manifest for each helper.

Implement the parser and its accepted/rejected examples, connect the public API and CLI, declare the entry point, then build and install the exact wheel and exercise the consumer. Separate contributors can work after their shared input/output behavior is settled; one owner integrates the complete installed path.

The minimum scope includes the validator, public wrapper, command, backend metadata, relevant resource declarations, and consumer fixtures. Private helper placement stays open. A whole service framework, plugin registry, or database is outside this outcome.

## Example checks

| Case | Expected observation |
| --- | --- |
| `{"count":2,"readings":[1,2.5]}` | Exact normalized values, success exit, no writes |
| `{"count":true,"readings":[1]}` | Quantity type rejection, exit two, no writes |
| Missing input file | File-access error, not validator success or schema rejection |
| Installed command with no checkout on path | Correct behavior and installed code origins |
| Disposable wheel missing a required module | Import/content check fails for that missing module |
| Private helper renamed | Same public consumer behavior; no tree-equality failure |

First verify the good artifact so reject-everything and broken installation cannot satisfy the negative tests. Keep rejected input separate from an importer that never reached validation. Use the example's exact contract only when adopted; do not infer these error codes for another application.

## Failure containment and temporary files

Create build and consumer environments inside the permitted workspace. Preserve original input and final wheel identity. Stop before publishing or modifying global environments. Retain regression input and tests; remove task-owned temporary installs when they no longer carry evidence. Record any fixture package as test-only, not a production dependency.

Exit when the installed consumer and its failure cases pass for the named scope. Passing components alone does not close the integrated slice. Later deployment, other platforms, and a complete service remain separate outcomes.
