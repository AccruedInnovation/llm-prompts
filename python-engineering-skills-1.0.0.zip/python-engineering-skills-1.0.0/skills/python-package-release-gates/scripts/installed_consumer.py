"""Check the deliberately small skill-consumer-demo learning distribution.

Importing it executes its code. Use only the supplied harmless fixture in a
permitted disposable environment. Not a generic verifier for every package.
"""
from __future__ import annotations
from importlib import import_module, metadata, resources
import json
from pathlib import Path
import sys

class ConsumerFailure(RuntimeError):
    pass


def check() -> dict[str, object]:
    dist = metadata.distribution('skill-consumer-demo')
    if dist.version != '1.0.0':
        raise ConsumerFailure('wrong-version')
    installed = {Path(dist.locate_file(path)).resolve() for path in (dist.files or [])}
    module = import_module('skill_consumer_demo')
    origin = getattr(getattr(module, '__spec__', None), 'origin', None)
    file = getattr(module, '__file__', None)
    if not origin or not file:
        raise ConsumerFailure('missing-origin')
    # This fixture is a regular package, not a namespace or import-hook example.
    if Path(origin).resolve() not in installed or Path(file).resolve() not in installed:
        raise ConsumerFailure('foreign-origin')
    if Path(origin).resolve() != Path(file).resolve():
        raise ConsumerFailure('inconsistent-origin')
    root = resources.files(module)
    marker = root.joinpath('py.typed')
    if not marker.is_file():
        raise ConsumerFailure('missing-typing-marker')
    item = root.joinpath('defaults.json')
    if not item.is_file():
        raise ConsumerFailure('missing-resource')
    if item.read_bytes() != b'{"limit": 3}\n':
        raise ConsumerFailure('wrong-resource')
    if module.limit() != 3:
        raise ConsumerFailure('wrong-api-result')
    return {'status': 'PASS', 'distribution': dist.metadata['Name'], 'version': dist.version,
            'origin': origin, 'interpreter': sys.executable, 'resource_limit': 3}


def main() -> int:
    try:
        result = check()
    except ConsumerFailure as exc:
        print(json.dumps({'status':'FAIL','code':str(exc)}))
        return 2
    except Exception as exc:
        print(json.dumps({'status':'ERROR','exception_type':type(exc).__name__}))
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
