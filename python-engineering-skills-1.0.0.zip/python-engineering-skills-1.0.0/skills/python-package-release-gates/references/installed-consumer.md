# Installed-consumer verification

This is the suite's canonical full procedure. Other skills keep short reminders rather than separately maintained copies. No command below authorizes network access, builds, installs, or release; use the project's allowed effects and tools.

## Define the claim before choosing a command

Name the exact source candidate, build configuration, wheel or sdist-derived wheel, interpreter, platform, extras, runtime dependencies, and public consumer path. Distinguish a wheel built directly from the source tree from one built using only the sdist. Neither automatically proves the other contains the necessary source or resources.

Record whether the claim requires exact bytes, normalized contents, equivalent installed behavior, or merely a fresh build. Use the declared backend. Build-dependency isolation does not mean hostile-code containment.

## Build and inspect

Use the repository's build command in a permitted environment. Inspect filenames and metadata, dependency markers, package names, entry points, licences, required resources, and stubs or `py.typed` where promised. Preserve wheel and sdist hashes. Build the sdist-derived wheel without access to unlisted checkout inputs.

Do not use `pip install .` as an unrecorded replacement for installing the exact wheel. Do not upgrade the backend or create a second lock policy to make a fixture work.

## Install into a declared clean environment

Use a fresh environment without system site packages or editable installations. Install the exact wheel and only the declared runtime dependencies needed for the smoke test. If broader tests need test tools, separate that environment or explain the added dependencies and test for runtime-dependency leakage first. `--no-deps` is appropriate only after supplying all required dependencies deliberately; it is not a general install recipe.

An offline invocation, when the wheel has no unresolved dependencies, can be:

```text
<consumer-python> -m pip install --no-index --no-deps <exact-wheel-file>
```

This is a command template, not a substitute for the repository's dependency plan. Select the actual executable and wheel path; do not execute the angle-bracket placeholders.

## Prove imports and resources come from that install

Run a dedicated consumer from a directory outside the checkout. Inspect `PYTHONPATH`, pytest `pythonpath`, editable hooks, `.pth` files, `sitecustomize`, symlinks, inherited user packages, and test layout. Pytest's default import behavior can insert the repository root. `--import-mode=importlib` reduces pytest's own path changes but does not remove other injection sources.

For each relevant import, inspect its actual `__spec__.origin`, `__file__`, and namespace `submodule_search_locations`. Compare resolved locations to the intended installation and installed-file receipt. Namespace packages can have several contributing distributions; verify each allowed location instead of insisting on one `__file__`. A package name or version string alone is not proof.

Check imported extension paths and shared-library resolution when native code matters. Exercise the actual resource API, not a relative filesystem path that accidentally works from the checkout. Test CLI entry points through the installed executable, selected plugin discovery, public examples, error behavior, and type-consumer fixtures where promised.

Isolated mode (`-I`) can reduce environment and path leakage for a compatible consumer, but it is not an OS sandbox and cannot prove that authorized site hooks are harmless. Do not disable necessary project plugins or alter the deployment import model without disclosing that change.

## Prove the check rejects an incomplete distribution

Use a disposable copy or a fixture build, never mutate the delivery wheel in place. Omit one required resource, module, or typing artifact and give that bad fixture a separate identity. If rewriting a wheel fixture, update its `RECORD` as well so unrelated integrity errors do not hide the intended missing-file failure.

Install the good and incomplete fixture into separate fresh environments. The same consumer must pass the good wheel and reject the bad wheel for the intended missing item. Keep dependency errors and unrelated import failures distinct. Also try a checkout-contaminated environment and verify that the origin check rejects it.

The included [installed_consumer.py](../scripts/installed_consumer.py) targets the small `skill_consumer_demo` learning package created by the validation test. It verifies distribution version, installed-file origin, required resource bytes, and the typing marker. It has stable errors for those claims. Adapt the consumer to the real project; do not install that demonstration package into a product environment.

## Retain evidence and state limitations

Keep the wheel digest, interpreter, install command, dependency inventory, selected imports and origins, entry-point/resource outputs, and negative-control failure reason. A pass of this fixture establishes the consumer mechanism only. It does not establish the project's build backend, sdist completeness, every dependency range, reproducible bytes, Windows, native ABI, or a deployed service.

Sources: [pytest good practices](https://docs.pytest.org/en/stable/explanation/goodpractices.html), [pip local installs](https://pip.pypa.io/en/stable/topics/local-project-installs/), [pip build interface](https://pip.pypa.io/en/stable/reference/build-system/), [Python import system](https://docs.python.org/3.14/reference/import.html), [importlib metadata](https://docs.python.org/3.14/library/importlib.metadata.html), [importlib resources](https://docs.python.org/3.14/library/importlib.resources.html). The procedure and deliberately incomplete fixture are suite-authored.
