# Review method and worked cases

## From a broad survey to a supported finding

First draw a small textual map of the important inputs, package boundaries, state owners, and effects. Select a few flows according to consequence, exposure, change, and evidence gaps. Examples include a public parser, a retrying write, a migration, or an installed CLI. A list of files is not a flow map.

For each selected flow, record the required rule, inspect the actual caller-to-consumer path, and state a concrete failure hypothesis. Try the smallest safe reproduction that reaches the relevant decision. Check an alternative explanation before calling it a defect. Preserve exact inputs and observations, then identify the smallest repair and the test that would establish it. Stop widening the review when further inspection is unlikely to change a consequential conclusion.

A concise finding might read:

> `queue_worker.py:dispatch` creates one task for every input before any admission limit. The input source can yield an unbounded number of jobs. A fixture with 64 held jobs left 64 pending tasks despite the semaphore limit of two. This limits active calls, not retained tasks. Use bounded admission and test the full task/queue budget; no process or framework migration is needed.

This is a demonstrated mechanism plus a workload assumption. Verify that the real producer is actually unbounded before assigning production severity. An explicitly capped batch of 64 tiny jobs may make the pattern acceptable.

## Broad exceptions: defect and valid boundary

Flawed code when the caller treats `None` as an empty successful answer:

```python
try:
    return read_record(key)
except Exception:
    return None
```

The problem is not the broad catch by itself. A permission or storage failure can now look like a missing record. Test a genuine missing key and a storage failure separately; assert the promised result or error and that retries follow the intended classification.

A boundary may intentionally convert any ordinary job failure to a declared result:

```python
try:
    value = run_job(job)
except Exception as exc:
    record_failure(job.id, type(exc).__name__)
    raise
else:
    record_success(job.id)
    return value
```

This can be valid when logging policy, causal context, and failure propagation are correct. The example does not catch `BaseException` or promise recovery. If the logger itself can fail, test whether masking the original error violates the boundary's contract. Do not add a new exception hierarchy solely because the catch is broad.

## Small wrappers: inspect the responsibility

A three-line wrapper may be justified if it applies an authorization check, maps a stable public exception, isolates a changing vendor API, or gives a test control over time. A much larger class may be shallow if every method forwards calls and exposes vendor details. Judge the hidden responsibility and change isolation, not line count.

A wrapper that merely renames `list.append` without a boundary benefit may be removable. Before proposing removal, inspect downstream imports, plugin discovery, typing promises, and instrumentation. A public alias can be a compatibility commitment even when its implementation is small.

## Do not turn uncertainty into a defect

Use “not established” when a target platform, installed artifact, or failure path was not tested. Use “test gap” when a required behavior lacks adequate protection. Use “defect” when code or a valid reproduction contradicts the governing behavior. Report design debt separately from runtime failure.

Review output should retain inspected and omitted areas, exact evidence, confidence, consequence, and a bounded repair. Count neither findings nor reviewer agreement as a correctness score. A later agent trial should measure false positives as well as missed defects; these examples do not measure agent performance.

Language references: [exception handling](https://docs.python.org/3.14/tutorial/errors.html), [asyncio task ownership](https://docs.python.org/3.14/library/asyncio-task.html). The review procedure and examples are suite-authored guidance.
