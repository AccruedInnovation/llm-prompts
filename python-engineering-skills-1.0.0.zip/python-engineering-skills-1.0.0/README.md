# Python Engineering Skills

**Version 1.0.0 · 8 September 2026**

Fifteen generic Python engineering skills for local Codex use. Each skill contains a standard `SKILL.md`, optional Codex display metadata, its own references and any learning scripts, and the retained licence. There are no host-specific commands, language-profile schemas, adapters, hooks, package-manager dependencies, MCP requirements, or mandatory orchestration objects.

The entry skill is `python-engineering`. It replaces the source suite's host-specific entry point; the other 14 skill names remain unchanged. All 15 skill bodies were revised. The suite retains the original distinctions between static types and validation, package subjects, concurrency models, and compatibility surfaces, and adds worked failure and non-failure cases.

## Install into Codex

Extract this archive and run the installer from this directory. Python 3.11 or later is sufficient for the installer and included examples. Installing skill text requires no Python packages or network access.

### Windows PowerShell

```powershell
py -3 .\install.py --user --dry-run
py -3 .\install.py --user
```

### Linux, macOS, or WSL

```sh
python3 ./install.py --user --dry-run
python3 ./install.py --user
```

`--user` copies the skill directories to `~/.agents/skills` (`$HOME\.agents\skills` on Windows). Run the installer in the same Windows or WSL environment in which you use Codex; their home directories differ. The installer does not edit Codex configuration or shell profiles. It checks all conflicts before copying, skips byte-identical skills, and refuses to overwrite a different existing skill. It also refuses symlink/junction destinations. Use one installer at a time; concurrent destination edits are not supported.

For a repository-scoped install, give the actual repository path:

```sh
python3 ./install.py --destination /path/to/repository/.agents/skills
```

For a selected skill, repeat `--skill` as needed:

```sh
python3 ./install.py --user --skill python-runtime-correctness-review
```

Every skill's local references stay inside its own directory. Other skill names in the guidance point to optional further expertise, not hard dependencies. Do not copy just `SKILL.md` and leave its references behind.

For manual installation, copy the desired directories directly from `skills/` into the chosen `.agents/skills/` directory. The resulting shape must be `.agents/skills/<skill-name>/SKILL.md`, not an extra nested `skills/skills` layer. Keep each included licence. Do not blindly merge a directory over an older version; inspect or move an existing conflicting copy first. Avoid duplicate skill names across user and repository locations.

Codex's current local discovery paths and `$skill-name` invocation are documented in [OpenAI's skill guide](https://developers.openai.com/codex/skills). Codex detects changes automatically; restart it if a new skill does not appear. OpenAI also documents [user and repository customization](https://developers.openai.com/codex/customization/overview). These paths were checked on 2026-09-08; this archive does not install a marketplace plugin.

## Use

```text
$python-engineering Implement this Python change using the repository's conventions.

$python-runtime-correctness-review Review this worker's cancellation and shutdown behavior.

$python-package-release-gates Check whether the built wheel works without the checkout.

$comprehensive-analysis-python Review this inherited codebase and rank supported findings.
```

Choose focused skills from the actual task. Routine edits do not require every reviewer. Review skills stay read-only unless repair is requested. Skills do not grant permission to publish, install tools, run hostile code, or change the project's accepted design.

## Skill catalog

| Skill | Main purpose |
| --- | --- |
| `python-engineering` | Routine implementation and debugging; proportional selection of deeper guidance |
| `comprehensive-analysis-python` | Broad, risk-first codebase and architecture review |
| `python-api-package-boundary-review` | Public imports, runtime APIs, stubs, resources, and compatibility |
| `python-evidence-reproducer` | Exact-subject reproduction and selected environment evidence |
| `python-execution-slice-design` | Coherent delivery slices with an integrated consumer path |
| `python-implementation-structure-authoring` | Types, runtime validation, ownership, boundaries, and test seams |
| `python-implementation-structure-review` | Agreed-design comparison without private-tree equality rules |
| `python-native-extension-review` | FFI, ABI, callbacks, lifetimes, and interpreter-mode claims |
| `python-operational-readiness-review` | Startup, load, shutdown, outage, recovery, and rollback |
| `python-package-release-gates` | Wheel/sdist and installed-consumer verification |
| `python-runtime-correctness-review` | State, failure, cancellation, threads, processes, queues, and effects |
| `python-security-supply-chain-review` | Concrete input, build, subprocess, archive, and dependency risks |
| `python-test-strategy-review` | Reliable fixtures, precise failures, defect detection, and evidence |
| `python-typing-contract-review` | Static and runtime typing contracts and downstream consumers |
| `python-web-hypermedia-review` | HTTP and htmx representation, cache, and submission behavior |

## Content additions

The 21 reference files include the five adapted policy notes and new worked guidance. Nine optional Python files demonstrate value ownership, strict parsing, cancellation, task admission, environment observations, valid and invalid static consumers, fixture teardown, installed consumers, archive headers, and web response contracts.

Examples define small explicit contracts. They are not general production components. Native, version-specific, and web guidance applies only when the project uses that boundary. The skills do not force a new validator, checker, framework, backend, or environment manager.

## Validation and evidence

See [validation report](validation/REPORT.md), [machine-readable results](validation/results.json), and [change coverage](CHANGELOG.md). The report separates executed demonstrations from documentation checks and unexecuted platform or agent claims.

To rerun validation where the tools are already available:

```sh
python3 -m pytest -q -p no:cacheprovider validation/test_suite.py
```

The validation suite requires pytest and, for the wheel fixtures, an installed setuptools backend capable of building wheels and Python's venv/pip support. It does not install test tools or use the network. Wheel tests build harmless fixture packages in temporary directories, create temporary environments, and install local wheels. The build uses the existing backend environment, not isolated build-dependency resolution. This is a suite check, not a production package-release claim.

The static negative consumer is deliberately invalid. It is not executed by normal validation and must be checked separately with the project's declared type checker. Do not run a blanket type-check over negative fixture files and interpret the expected error as a defect in the suite.

## Attribution and contents

[ORIGIN.md](ORIGIN.md) identifies the supplied source and separates retained material, approved revisions, and outside technical references. [LICENSE](LICENSE) retains the original MIT notice. The original language-package implementation and review archive are not bundled.

`SHA256SUMS` identifies every final file except itself. The archive also has a detached checksum. No credentials, environment caches, virtual environments, compiled Python files, VCS metadata, or demonstration wheels are included.
