#!/usr/bin/env python3
"""Install selected local skill folders; never download or overwrite other files.

Uses Python's standard library. Target one user-owned directory with no concurrent
writers. Identical installed skills are skipped; changed-name conflicts stop the
whole preflight. There is deliberately no --force or automatic deletion option.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

SOURCE = Path(__file__).resolve().parent / 'skills'
IGNORED = {'__pycache__', '.pytest_cache'}


class InstallError(RuntimeError):
    pass


def linked(path: Path) -> bool:
    return path.is_symlink() or (hasattr(path, 'is_junction') and path.is_junction())


def safe_path(path: Path) -> None:
    for part in (path, *path.parents):
        if linked(part):
            raise InstallError(f'Refusing symlink or junction in destination: {part}')
        if os.path.lexists(part) and not part.is_dir():
            raise InstallError(f'Path component is not a directory: {part}')


def inventory(root: Path) -> dict[str, str]:
    if linked(root) or not root.is_dir():
        raise InstallError(f'Not an ordinary directory: {root}')
    result: dict[str, str] = {}
    for path in sorted(root.rglob('*')):
        relative = path.relative_to(root)
        if any(p in IGNORED for p in relative.parts) or path.suffix == '.pyc':
            continue
        if linked(path):
            raise InstallError(f'Refusing linked content: {path}')
        if path.is_file():
            result[relative.as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
        elif not path.is_dir():
            raise InstallError(f'Refusing non-file content: {path}')
    return result


def install(destination: Path, names: list[str] | None, *, dry_run: bool) -> dict[str, object]:
    available = sorted(p.name for p in SOURCE.iterdir() if (p/'SKILL.md').is_file())
    selected = available if names is None else sorted(set(names))
    unknown = set(selected) - set(available)
    if unknown or not selected:
        raise InstallError('Unknown or empty skill selection: ' + ', '.join(sorted(unknown)))
    target = Path(os.path.abspath(destination.expanduser()))
    safe_path(target)
    if target.resolve().is_relative_to(SOURCE.resolve()) or SOURCE.resolve().is_relative_to(target.resolve()):
        raise InstallError('Destination must not overlap the source skill tree.')
    planned: list[dict[str, str]] = []
    # Complete all conflict checks before creating the target or any skill.
    for name in selected:
        source_files = inventory(SOURCE/name)
        dest = target/name
        if os.path.lexists(dest):
            if inventory(dest) != source_files:
                raise InstallError(f'Existing skill differs; nothing copied: {dest}')
            action = 'unchanged'
        else:
            action = 'copy'
        planned.append({'name':name,'action':action})
    if not dry_run:
        target.mkdir(parents=True, exist_ok=True)
        for item in planned:
            if item['action'] == 'unchanged':
                continue
            dest = target/item['name']
            # Exclusive creation prevents replacing a destination created since preflight.
            dest.mkdir(exist_ok=False)
            try:
                shutil.copytree(SOURCE/item['name'], dest, dirs_exist_ok=True,
                                ignore=shutil.ignore_patterns('__pycache__', '.pytest_cache', '*.pyc'))
                if inventory(dest) != inventory(SOURCE/item['name']):
                    raise InstallError(f'Copied bytes differ: {dest}')
            except Exception:
                # This process created dest; no concurrent writers are supported.
                shutil.rmtree(dest)
                raise
    return {'status':'DRY_RUN' if dry_run else 'INSTALLED', 'destination':str(target),
            'skills':planned, 'count':len(planned),
            'note':'No Codex config, shell profile, dependency, or network changes.'}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    target = parser.add_mutually_exclusive_group()
    target.add_argument('--user', action='store_true', help='Install in ~/.agents/skills.')
    target.add_argument('--destination', type=Path, help='Explicit skills directory, e.g. REPO/.agents/skills.')
    parser.add_argument('--skill', action='append', help='Install only this named skill; repeat as needed.')
    parser.add_argument('--dry-run', action='store_true', help='Check and show the plan without writes.')
    parser.add_argument('--list', action='store_true', help='List available skill names without writes.')
    args = parser.parse_args()
    if args.list:
        print('\n'.join(sorted(p.name for p in SOURCE.iterdir() if (p/'SKILL.md').is_file())))
        return 0
    if not args.user and args.destination is None:
        parser.error('Choose --user or --destination, or use --list.')
    destination = Path.home()/'.agents'/'skills' if args.user else args.destination
    try:
        result = install(destination, args.skill, dry_run=args.dry_run)
    except (InstallError, OSError) as exc:
        print(f'Installation stopped: {exc}', file=sys.stderr)
        print('Earlier completed copies, if any, remain. Existing skills were not replaced.', file=sys.stderr)
        return 1
    print(json.dumps(result, indent=2))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
