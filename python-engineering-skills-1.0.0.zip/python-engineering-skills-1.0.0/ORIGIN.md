# Origin and source basis

## Supplied source

The user supplied `bbk-profile-python-0.1.0-alpha.3(2).zip` and accepted the eight recommendations in `python-skills-review-r1/review.md` from the prior content review. This version starts from its 15 skill bodies and five policy notes. It does not copy the language-package runtime, installer, schemas, adapter machinery, or bundled toolchain.

The one renamed entry is `bbk-python` → `python-engineering`. The other skill names remain unchanged. `validation/source-map.json` records that mapping and the input digest. File names here identify source lineage, not runtime dependencies.

The source carries an MIT licence attributed to “Blueprint Bootstrap Kit contributors.” That notice remains in the root licence and every installable skill directory. The generic conversion does not remove or replace that copyright attribution.

## Retained versus new content

Retained: the original review dimensions, concern lists, compatibility distinctions, proportional testing policy, exception and abstraction judgment, environment ownership, exact-subject evidence, and conditional native/web scope.

Revised: host-specific operations and prerequisites, entry routing, frozen-value wording, and skill descriptions.

Added under the user's approved update request: worked procedures, failure and non-failure cases, local references and learning scripts, import-origin consumer proof, version-sensitive checks, generic installation, and validation. These additions are authored guidance, not text recovered from the source archive.

## Outside technical basis

Technical references appear in the files where they apply. Official Python, pytest, pip, setuptools, htmx, HTTP RFC, and OpenAI documentation informed the additions. Documentation was checked on 2026-09-08; project support claims must use the actual selected versions rather than assume the documentation's latest patch applies.

OpenAI's current local skill guide supports ordinary skill directories with `SKILL.md` plus optional resources and display metadata, loaded from user or repository `.agents/skills` locations. The archive uses that local form, not the hosted API's skill-upload format or a marketplace plugin.

Local runtime evidence used CPython 3.13.5 on Linux. Documentation checks for Python 3.14 and free-threaded behavior are not runtime qualification of those environments. Likewise, illustrative native and browser scenarios are not reported as executed native or browser tests.

## Evidence independence

One assistant authored the revision and ran separated content and mechanical checks. No independent agent review, live Codex invocation, or before/after agent benchmark is claimed. The included agent evaluation cases are unexecuted prompts and expected behaviors for a later controlled evaluation, not fabricated evaluation results.
