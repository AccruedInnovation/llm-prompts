"""Distribution checks for this skill suite. Requires pytest; no network.

Use from the extracted archive. Set SKILLS_COMMAND_LOG to retain child command
receipts. All builds and installations use temporary directories, never user Codex.
The learning package is built with the already installed setuptools backend;
this is not isolated-backend or cross-platform qualification of another project.
"""
from __future__ import annotations
import ast
import hashlib
import importlib.util
from importlib.metadata import version
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import zipfile
import pytest

ROOT = Path(__file__).resolve().parents[1]
SKILLS = ROOT/'skills'


def execute(argv: list[str], *, cwd: Path, expected: int = 0, env_extra: dict[str,str] | None = None,
            timeout: int = 40) -> subprocess.CompletedProcess[str]:
    env = dict(os.environ)
    for name in ('PYTHONPATH','PYTEST_ADDOPTS','PYTHONHOME'):
        env.pop(name, None)
    env.update({'PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1','PYTHONDONTWRITEBYTECODE':'1',
                'PIP_NO_INDEX':'1','PIP_DISABLE_PIP_VERSION_CHECK':'1'})
    if env_extra:
        env.update(env_extra)
    result = subprocess.run(argv,cwd=cwd,env=env,text=True,capture_output=True,timeout=timeout)
    log = os.environ.get('SKILLS_COMMAND_LOG')
    if log:
        with Path(log).open('a',encoding='utf-8') as output:
            output.write(json.dumps({'argv':argv,'cwd':str(cwd),'exit_code':result.returncode,
                                     'stdout':result.stdout,'stderr':result.stderr})+'\n')
    assert result.returncode == expected, result.stdout + result.stderr
    return result


def script(skill: str, name: str) -> Path:
    return SKILLS/skill/'scripts'/name


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name,path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def test_skill_metadata_and_no_host_coupling() -> None:
    paths = sorted(SKILLS.glob('*/SKILL.md'))
    assert len(paths) == 15
    for path in paths:
        text = path.read_text(encoding='utf-8')
        front, body = text.split('---',2)[1:]
        name = re.search(r'^name: (.+)$',front,re.M)
        description = re.search(r'^description: (.+)$',front,re.M)
        assert name and name.group(1) == path.parent.name
        assert re.fullmatch('[a-z0-9]+(?:-[a-z0-9]+)*',name.group(1))
        assert description and 1 <= len(json.loads(description.group(1))) <= 1024
        assert len(body.splitlines()) < 500
        assert not re.search(r'\bBBK\b|bbk-|Wayfinder|Alpha\.4',body,re.I)
        assert (path.parent/'LICENSE.txt').is_file()
        ui = (path.parent/'agents'/'openai.yaml').read_text()
        assert 'dependencies:' not in ui
        assert '$'+path.parent.name in ui


def test_all_local_links_stay_inside_each_skill() -> None:
    for skill in sorted(SKILLS.iterdir()):
        for file in skill.rglob('*.md'):
            for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',file.read_text(encoding='utf-8')):
                if '://' in target or target.startswith('#'):
                    continue
                target = target.split('#',1)[0]
                resolved = (file.parent/target).resolve()
                assert resolved.is_relative_to(skill.resolve()), (file,target)
                assert resolved.is_file(), (file,target)


def test_python_files_parse() -> None:
    for file in ROOT.rglob('*.py'):
        if '__pycache__' not in file.parts:
            ast.parse(file.read_text(encoding='utf-8'),filename=str(file))


@pytest.mark.parametrize('optimized',[False,True])
def test_boundary_example(tmp_path: Path, optimized: bool) -> None:
    argv = [sys.executable] + (['-O'] if optimized else [])
    result = execute(argv+[str(script('python-implementation-structure-authoring','boundary_case.py'))],cwd=tmp_path)
    record = json.loads(result.stdout)
    assert record['status'] == 'PASS' and record['rejection_cases'] == 23
    assert record['optimized_execution'] is optimized


def test_async_examples(tmp_path: Path) -> None:
    result = execute([sys.executable,str(script('python-runtime-correctness-review','async_cases.py'))],cwd=tmp_path)
    record = json.loads(result.stdout)
    assert record['status'] == 'PASS' and len(record['cases']) == 5
    assert record['cases'][2]['trace'] == ['caller_observed_cancelled','worker_effect']
    assert record['cases'][3]['semaphore_pending_tasks'] == 64
    assert record['cases'][3]['bounded_work_tasks_at_hold'] == 3


def test_archive_and_web_examples(tmp_path: Path) -> None:
    for skill,name in [('python-security-supply-chain-review','archive_header_case.py'),
                       ('python-web-hypermedia-review','web_cache_case.py')]:
        result = execute([sys.executable,str(script(skill,name))],cwd=tmp_path)
        assert json.loads(result.stdout)['status'] == 'PASS'


def test_archive_member_budget_and_no_effects(tmp_path: Path) -> None:
    module = load(script('python-security-supply-chain-review','archive_header_case.py'),'suite_archive_case')
    members = [tarfile.TarInfo(f'item{n}') for n in range(9)]
    with pytest.raises(module.RejectedArchive,match='^member-count$'):
        module.validate_headers(members)
    before = list(tmp_path.iterdir())
    with pytest.raises(module.RejectedArchive,match='^unsafe-path$'):
        module.validate_headers(module.example_members('../outside'))
    assert list(tmp_path.iterdir()) == before


def test_environment_probe(tmp_path: Path) -> None:
    result = execute([sys.executable,str(script('python-evidence-reproducer','environment_probe.py')),
                      '--module','json'],cwd=tmp_path)
    record = json.loads(result.stdout)
    assert record['status'] == 'PASS'
    assert record['facts']['module_origins']['json']['origin']
    assert record['facts']['gil_enabled_after_imports'] in (True,False,None)
    failed = execute([sys.executable,str(script('python-evidence-reproducer','environment_probe.py')),
                      '--module','suite_intentionally_absent_module'],cwd=tmp_path,expected=1)
    assert json.loads(failed.stderr) == {'status':'ERROR','exception_type':'ModuleNotFoundError'}


def test_typing_runtime_limits() -> None:
    from typing import NewType, Protocol, TypedDict, cast, runtime_checkable
    UserId = NewType('UserId',int)
    raw = object()
    assert UserId(raw) is raw  # deliberately invalid statically, valid runtime behavior
    assert cast(int,raw) is raw
    class Request(TypedDict):
        count: int
    assert Request(count='bad')['count'] == 'bad'
    @runtime_checkable
    class Writer(Protocol):
        def write(self,value: str) -> int: ...
    class Wrong:
        def write(self) -> None:
            return None
    assert isinstance(Wrong(),Writer)


def test_frozen_alias_and_assert_semantics(tmp_path: Path) -> None:
    from dataclasses import dataclass
    @dataclass(frozen=True)
    class Bad:
        values: list[int]
    values = [1]
    bad = Bad(values)
    values.append(2); bad.values.append(3)
    assert bad.values == [1,2,3]
    result = execute([sys.executable,'-O','-c','assert False; print("removable")'],cwd=tmp_path)
    assert result.stdout.strip() == 'removable'


def test_fixture_and_guard_examples(tmp_path: Path) -> None:
    config = tmp_path/'pytest.ini'; config.write_text('[pytest]\n')
    result = execute([sys.executable,'-m','pytest','-q','-p','no:cacheprovider','-c',str(config),
                      str(script('python-test-strategy-review','test_failure_cases.py'))],cwd=tmp_path)
    assert '7 passed' in result.stdout


def test_installer_dry_run_and_selected_install(tmp_path: Path) -> None:
    target = tmp_path/'new-home'/'.agents'/'skills'
    command = [sys.executable,str(ROOT/'install.py'),'--destination',str(target),
               '--skill','python-runtime-correctness-review']
    dry = execute(command+['--dry-run'],cwd=tmp_path)
    assert json.loads(dry.stdout)['status'] == 'DRY_RUN' and not target.exists()
    first = execute(command,cwd=tmp_path)
    assert json.loads(first.stdout)['count'] == 1
    assert (target/'python-runtime-correctness-review'/'references'/'async-ownership.md').is_file()
    second = execute(command,cwd=tmp_path)
    assert json.loads(second.stdout)['skills'][0]['action'] == 'unchanged'


def test_installer_whole_suite_and_conflict(tmp_path: Path) -> None:
    target = tmp_path/'skills'
    command = [sys.executable,str(ROOT/'install.py'),'--destination',str(target)]
    result = execute(command,cwd=tmp_path)
    assert json.loads(result.stdout)['count'] == 15
    name = 'python-engineering'
    existing = target/name/'SKILL.md'
    existing.write_text('existing user edit',encoding='utf-8')
    # Force a potential new copy: conflict must be found before copying it.
    shutil.rmtree(target/'python-web-hypermedia-review')
    failed = execute(command,cwd=tmp_path,expected=1)
    assert 'Existing skill differs' in failed.stderr
    assert existing.read_text() == 'existing user edit'
    assert not (target/'python-web-hypermedia-review').exists()


def test_installer_unknown_name_and_source_overlap(tmp_path: Path) -> None:
    target = tmp_path/'skills'
    failed = execute([sys.executable,str(ROOT/'install.py'),'--destination',str(target),
                      '--skill','not-a-skill'],cwd=tmp_path,expected=1)
    assert 'Unknown' in failed.stderr and not target.exists()
    failed = execute([sys.executable,str(ROOT/'install.py'),'--destination',str(SKILLS/'nested')],
                     cwd=tmp_path,expected=1)
    assert 'overlap' in failed.stderr and not (SKILLS/'nested').exists()


def test_installer_refuses_symlink_target(tmp_path: Path) -> None:
    real = tmp_path/'real'; real.mkdir()
    link = tmp_path/'link'
    try:
        link.symlink_to(real,target_is_directory=True)
    except (OSError,NotImplementedError):
        pytest.skip('host does not permit test symlinks')
    result = execute([sys.executable,str(ROOT/'install.py'),'--destination',str(link)],
                     cwd=tmp_path,expected=1)
    assert 'symlink or junction' in result.stderr and list(real.iterdir()) == []


DEMO_CODE = '''from importlib.resources import files
import json

def limit():
    return json.loads(files(__package__).joinpath("defaults.json").read_text(encoding="utf-8"))["limit"]

def main():
    print(limit())
    return 0
'''


def make_project(path: Path, include_resource: bool) -> None:
    package = path/'skill_consumer_demo'; package.mkdir(parents=True)
    (package/'__init__.py').write_text(DEMO_CODE,encoding='utf-8')
    (package/'defaults.json').write_bytes(b'{"limit": 3}\n')
    (package/'py.typed').write_bytes(b'')
    data = '["defaults.json", "py.typed"]' if include_resource else '["py.typed"]'
    (path/'pyproject.toml').write_text(f'''[build-system]
requires = ["setuptools=={version('setuptools')}"]
build-backend = "setuptools.build_meta"
[project]
name = "skill-consumer-demo"
version = "1.0.0"
requires-python = ">=3.11"
[project.scripts]
skill-consumer-demo = "skill_consumer_demo:main"
[tool.setuptools]
packages = ["skill_consumer_demo"]
include-package-data = false
[tool.setuptools.package-data]
skill_consumer_demo = {data}
''',encoding='utf-8')
    (path/'README.md').write_text('Temporary skill learning fixture.\n',encoding='utf-8')


def build(path: Path, kind: str) -> Path:
    destination = path/'dist'; destination.mkdir(exist_ok=True)
    code = f'import setuptools.build_meta as b; print(b.build_{kind}({str(destination)!r}))'
    execute([sys.executable,'-c',code],cwd=path)
    matches = list(destination.glob('*.whl' if kind=='wheel' else '*.tar.gz'))
    assert len(matches) == 1
    return matches[0]


def install_demo(wheel: Path, root: Path) -> Path:
    execute([sys.executable,'-m','venv',str(root)],cwd=root.parent)
    python = root/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
    execute([str(python),'-m','pip','install','--no-index','--no-deps',str(wheel)],cwd=root.parent)
    return python


@pytest.fixture(scope='module')
def built_consumers(tmp_path_factory):
    work = tmp_path_factory.mktemp('wheel-consumers')
    good = work/'good'; bad = work/'bad'
    make_project(good,True); make_project(bad,False)
    wheel = build(good,'wheel')
    broken = build(bad,'wheel')
    source_dist = build(good,'sdist')
    unpack = work/'sdist-only'; unpack.mkdir()
    with tarfile.open(source_dist) as archive:
        archive.extractall(unpack,filter='data')  # trusted fixture generated above
    unpacked = next(unpack.iterdir())
    derived = build(unpacked,'wheel')
    python_good = install_demo(wheel,work/'venv-good')
    python_bad = install_demo(broken,work/'venv-bad')
    python_derived = install_demo(derived,work/'venv-derived')
    consumer_dir = work/'outside'; consumer_dir.mkdir()
    consumer = consumer_dir/'consumer.py'
    shutil.copy2(script('python-package-release-gates','installed_consumer.py'),consumer)
    return {'work':work,'good':python_good,'bad':python_bad,'derived':python_derived,
            'consumer':consumer,'wheels':[wheel,broken,derived],'sdist':source_dist}


def test_good_wheel_and_sdist_derived_consumer(built_consumers) -> None:
    data = built_consumers
    for kind in ('good','derived'):
        result = execute([str(data[kind]),'-I',str(data['consumer'])],cwd=data['consumer'].parent)
        record = json.loads(result.stdout)
        assert record['status']=='PASS' and record['resource_limit']==3
        origin = Path(record['origin']).resolve()
        assert origin.is_relative_to(data[kind].parent.parent.resolve())
        cli = data[kind].parent/('skill-consumer-demo.exe' if os.name=='nt' else 'skill-consumer-demo')
        result = execute([str(cli)],cwd=data['consumer'].parent)
        assert result.stdout.strip() == '3'
    for wheel in data['wheels']:
        with zipfile.ZipFile(wheel) as archive:
            assert archive.testzip() is None
            assert any(name.endswith('.dist-info/RECORD') for name in archive.namelist())


def test_incomplete_wheel_rejects_missing_resource(built_consumers) -> None:
    data = built_consumers
    result = execute([str(data['bad']),'-I',str(data['consumer'])],cwd=data['consumer'].parent,expected=2)
    assert json.loads(result.stdout) == {'status':'FAIL','code':'missing-resource'}


def test_checkout_contamination_is_rejected(built_consumers) -> None:
    data = built_consumers
    checkout = data['work']/'fake-checkout'; package = checkout/'skill_consumer_demo'
    package.mkdir(parents=True)
    (package/'__init__.py').write_text('def limit():\n    return 3\n')
    (package/'defaults.json').write_bytes(b'{"limit": 3}\n')
    (package/'py.typed').write_bytes(b'')
    # No -I here: deliberately exercise the otherwise hidden PYTHONPATH injection.
    result = execute([str(data['good']),str(data['consumer'])],cwd=data['consumer'].parent,expected=2,
                     env_extra={'PYTHONPATH':str(checkout)})
    assert json.loads(result.stdout) == {'status':'FAIL','code':'foreign-origin'}
