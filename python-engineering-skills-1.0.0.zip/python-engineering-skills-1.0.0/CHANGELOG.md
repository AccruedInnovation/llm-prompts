# Changes in 1.0.0

## Scope

Converted the supplied 15-skill Python suite into generic local Codex skill directories. Retained the original technical scope and five policy notes, and implemented the eight accepted review findings. Added local worked references rather than another set of specialist skill names.

Removed host-specific preflight/structure/slice commands, namespace requirements, profile digests, alpha-release headings, and workflow-only readiness dependencies from active skill instructions. A task brief, repository design, PRD, or existing contract can provide the design basis; a specific schema is not required. The upstream MIT notice remains intact.

## Accepted review coverage

| Review finding | Delivered change | Evidence scope |
| --- | --- | --- |
| PY-01: usable review procedures | Risk-first investigation; supported finding/non-finding pairs; concrete examples in each relevant skill | Structural/content review; agent evaluation cases supplied, not run |
| PY-02: validation and value ownership | Qualified frozen dataclasses; type selection limits; strict JSON parser; direct-construction checks; alias detachment; optimized-mode checks | Executed local examples and tests |
| PY-03: concurrency depth | Gather/task-group contrast; continuing thread effects; semaphore versus admission bounds; failed-worker producer cleanup; shutdown observations | Executed deterministic local schedules; no production service claim |
| PY-04: installed consumers | One canonical full recipe; import origins; missing-content and checkout-contamination tests; wheel and sdist-derived consumers | Executed fixture builds, installs, resources, and entry points |
| PY-05: version-sensitive behavior | Process context changes; deferred versus stringized annotations; post-import GIL evidence; queue shutdown limits | Primary-document checks; selected local GIL facts; no Python 3.14/free-threaded qualification |
| PY-06: meaningful failure tests | Fixture setup failure cleanup; guard-specific assertions; positive controls; known missing-guard detection; typing consumer expectations | Executed pytest and runtime demonstrations; static checker fixtures not run |
| PY-07: security precision | Build isolation versus containment; platform-specific argument interpretation; bounded hostile archive-header cases and explicit extractor limits | Header fixtures executed; no hostile build or Windows shell execution |
| PY-08: optional native and web depth | Ctypes signatures and callback lifetime; binding-specific checks; full-page/fragment cache and duplicate-submission cases | Local HTTP response-contract checks; no native compilation, browser, or cache integration claim |

## Per-skill changes

| Skill | Main revision |
| --- | --- |
| `python-engineering` | Renamed host entry; routine work sequence and task-based guidance selection |
| `comprehensive-analysis-python` | Preserved the 26 review dimensions and abstraction judgment; added a selective investigation method |
| `python-api-package-boundary-review` | Added import-origin and missing-resource consumer proof |
| `python-evidence-reproducer` | Removed host binding requirements; added an explicit-import probe and minimal reproducer |
| `python-execution-slice-design` | Generalized to supplied plans or direct goals; added an installed-CLI slice |
| `python-implementation-structure-authoring` | Corrected shallow-freeze wording; added owned domain construction and validation policy |
| `python-implementation-structure-review` | Accepted plain design briefs; added harmless variation versus ownership drift cases |
| `python-native-extension-review` | Added signature, lifetime, callback, and binding-specific review cases |
| `python-operational-readiness-review` | Added shutdown/outage rehearsal with accepted-work accounting |
| `python-package-release-gates` | Owns the detailed installed-consumer procedure and example consumer check |
| `python-runtime-correctness-review` | Added executable concurrency cases and a version-trigger reference |
| `python-security-supply-chain-review` | Added build/subprocess/archive cases with explicit containment limits |
| `python-test-strategy-review` | Added fixture-failure, correct-guard, and known-defect detection examples |
| `python-typing-contract-review` | Added runtime limits, downstream static examples, and annotation-consumer cases |
| `python-web-hypermedia-review` | Added representation-cache, validator, duplicate-submit, and disconnect cases |

## What this version does not claim

It does not prove better agent performance, Codex's live discovery behavior, every supported Python version, Windows or macOS runtime behavior, native memory safety, a production build sandbox, or actual web-cache/browser integration. Those claims need their own evidence. See the validation report for executed checks and development repairs.
