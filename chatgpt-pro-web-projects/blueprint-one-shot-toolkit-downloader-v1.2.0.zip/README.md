# Blueprint / BBK one-shot toolkit downloader

**Downloader version:** 1.2.0

This package builds a reusable **Linux x86_64 / Debian 13-compatible** tool bundle from a Windows machine. It resolves current stable upstream releases when it runs, verifies published SHA-256 metadata where available, records exact provenance and licences, retains the original release artifacts, and produces both:

1. one complete ZIP archive; and
2. a set of ordinary ZIP archives capped at 480 MiB each for upload to ChatGPT File Library.

The library-set files are not byte fragments. Each is a valid ZIP. Extract every member into the same parent directory to reconstruct the same `blueprint-one-shot-toolkit-linux-x86_64/` tree.

## Requirements

- Windows PowerShell 5.1 or PowerShell 7+
- HTTPS access to GitHub, Rust static distribution, SQLite, Anchore/Grype, and Debian repositories
- `tar.exe` available for `.tar.gz`, `.tar.xz`, and related archives; current Windows installations normally include it
- Enough local storage for the expanded bundle, retained upstream downloads, the complete ZIP, and the library ZIP set

A GitHub token is optional but useful when the unauthenticated GitHub API rate limit is too low for a complete run.

## Run

From the directory containing the script:

```powershell
Set-ExecutionPolicy -Scope Process Bypass

# Optional. Do not put a token directly in command history.
$env:GITHUB_TOKEN = '<token>'

.\Download-BlueprintOneShotToolkit.ps1
```

Custom output paths:

```powershell
.\Download-BlueprintOneShotToolkit.ps1 `
  -OutputDirectory 'D:\BlueprintToolkitBuild' `
  -ArchivePath 'D:\BlueprintToolkit\blueprint-one-shot-toolkit-linux-x86_64.zip' `
  -LibraryArchiveDirectory 'D:\BlueprintToolkit\library-set'
```

Build a smaller portable-only bundle:

```powershell
.\Download-BlueprintOneShotToolkit.ps1 `
  -SkipRust `
  -SkipGrypeDatabase `
  -SkipDebianPackages `
  -IncludeExtendedTools:$false
```

The extended workflow helpers are enabled by default. Omit them with:

```powershell
.\Download-BlueprintOneShotToolkit.ps1 -IncludeExtendedTools:$false
```

Require every GitHub release asset to have an upstream-published SHA-256 or a GitHub asset digest:

```powershell
.\Download-BlueprintOneShotToolkit.ps1 -RequireUpstreamChecksums
```

Strict checksum mode may reject legitimate projects that publish release binaries without a separately discoverable SHA-256. Normal mode still calculates and records the asset SHA-256 and emits a visible warning.

Disable the extra File Library ZIP set while retaining the complete ZIP:

```powershell
.\Download-BlueprintOneShotToolkit.ps1 -CreateLibraryArchiveSet:$false
```

Reuse verified downloads while still rebuilding the generated bundle from a clean state:

```powershell
.\Download-BlueprintOneShotToolkit.ps1 -KeepExistingOutput
```

This keeps `blueprint-one-shot-toolkit-build/.download-cache/`. A cached artifact is reused only when the current upstream metadata supplies an expected SHA-256 and the cached file matches it. The generated bundle and `.work` directory are always recreated, so stale output cannot leak into a new bundle.

## Included tools and payloads

### Portable Linux executables

- Beads: `bd`
- Dolt: `dolt`
- Jujutsu: `jj`
- `yq`
- `ast-grep`
- Difftastic: `difft`
- Gitleaks: `gitleaks`
- Syft: `syft`
- Grype: `grype`
- Hyperfine: `hyperfine`
- ShellCheck: `shellcheck`
- `shfmt`
- `typos`
- Lychee: `lychee`
- DuckDB CLI: `duckdb`
- SQLite tools: required `sqlite3`, plus `sqldiff`, `sqlite3_analyzer`, and `sqlite3_rsync` when present in the current upstream archive
- Extended helpers enabled by default: `actionlint`, `hadolint`, `just`, and `task`

### Offline or opt-in payloads

- Rust stable components for `x86_64-unknown-linux-gnu`: `rustc`, Cargo, standard library, rustfmt, Clippy, and, when available, rust-analyzer, LLVM tools, and Rust sources
- Current Grype schema-v6 vulnerability database snapshot
- Flat Debian 13 APT repository containing `strace`, `lsof`, `gdb`, `gdbserver`, and `valgrind`, plus the recursively captured dependency closure

## Generated output

Default output includes:

```text
blueprint-one-shot-toolkit-build/
  blueprint-one-shot-toolkit-linux-x86_64/   # expanded, inspectable bundle
  .work/                                      # disposable extraction work
  .download-cache/                            # retained only with -KeepExistingOutput

blueprint-one-shot-toolkit-linux-x86_64.zip
blueprint-one-shot-toolkit-linux-x86_64.zip.sha256

blueprint-one-shot-toolkit-library-set/
  blueprint-one-shot-toolkit-linux-x86_64-core-*.zip
  blueprint-one-shot-toolkit-linux-x86_64-rust-*.zip
  blueprint-one-shot-toolkit-linux-x86_64-grype-*.zip
  blueprint-one-shot-toolkit-linux-x86_64-debian-*.zip
  library-set-manifest.json
  SHA256SUMS
  README.md
```

The exact number of library ZIPs depends on current upstream artifact sizes. The configured size is checked after each ZIP is created; the script fails rather than emitting an oversized part.

## Linux-side use

After extracting either the complete ZIP or every ZIP in the library set:

```bash
cd blueprint-one-shot-toolkit-linux-x86_64
bash prepare.sh
source ./activate.sh
```

`prepare.sh` restores executable permissions that Windows ZIP creation cannot preserve and verifies the complete extracted tree against `SHA256SUMS`.

Optional payload activation:

```bash
# Rust into a bundle-local prefix
bash rust/install-rust-toolchain.sh
export PATH="$PWD/rust/toolchain/bin:$PATH"

# Grype database into a bundle-local cache
source ./activate.sh
bash data/grype/install-grype-db.sh
# Run explicitly through the offline wrapper when desired:
bash data/grype/grype-offline.sh dir:.

# Debian debugger/process tools; this is the only system-wide step
sudo bash debian-packages/install-debian-tools.sh
```

The Debian installer points APT only at the included trusted local `file:` repository and installs with `--no-install-recommends`.

## Integrity and provenance

The generated bundle retains:

- original upstream release archives;
- published checksum artifacts when available;
- locally calculated SHA-256 values for all artifacts and extracted binaries;
- per-tool release metadata;
- ELF format and Linux x86_64 architecture checks for extracted executables;
- Rust channel manifest and component hashes;
- Grype database build metadata and archive hash;
- Debian InRelease/index metadata and package hashes;
- licences or public-domain statements where available;
- a complete `manifest.json` and `SHA256SUMS`.

For GitHub release assets, the script prefers a GitHub-provided `sha256:` digest, then a publisher checksum file, and otherwise records a local SHA-256 with a warning unless strict checksum mode is enabled.

For Debian package capture, the package index digest is verified against the HTTPS-fetched `InRelease` metadata, and each `.deb` is verified against its index SHA-256. The script does **not** independently validate the OpenPGP signature on `InRelease`; that limitation is recorded in generated metadata.

The presence of a tool does not authorize network access, credentials, remote services, publication, deployment, destructive operations, or system-wide installation.

## Deliberate omissions

A universal bundle cannot reliably capture dependencies for an unknown future project. Supply project-specific offline dependency closure with each assignment when relevant, for example:

- Cargo `vendor/` or complete Cargo caches pinned to `Cargo.lock`;
- Python wheelhouse pinned to lock files;
- npm, pnpm, or Bun cache—or `node_modules`—pinned to the project lock;
- Go `vendor/` or module cache;
- generated SDKs, proprietary compilers, licences, credentials, and hardware tooling.

## File Library use

Store the complete ZIP when it fits. When it does not, store all ZIPs from `blueprint-one-shot-toolkit-library-set/` together, plus its manifest and checksum file. For an implementation task, make the complete archive or all required set members available to the active conversation/runtime so the tools can actually be extracted and executed.

## Local PowerShell syntax validation

Before downloading anything, Windows can parse the script without executing it:

```powershell
$tokens = $null
$errors = $null
[void][System.Management.Automation.Language.Parser]::ParseFile(
  (Resolve-Path '.\Download-BlueprintOneShotToolkit.ps1'),
  [ref]$tokens,
  [ref]$errors
)
$errors | Format-List
if ($errors.Count -eq 0) { 'PowerShell parser: PASS' }
```

A completely clean parse should produce no entries in `$errors`.
