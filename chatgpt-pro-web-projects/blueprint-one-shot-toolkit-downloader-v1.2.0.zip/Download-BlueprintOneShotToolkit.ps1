#requires -Version 5.1
<#
.SYNOPSIS
Builds a self-contained Linux x86_64 tooling bundle for one-shot Blueprint/BBK implementation work.

.DESCRIPTION
Run this script from Windows PowerShell 5.1 or PowerShell 7+. It downloads current stable
Linux x86_64 release artifacts from official project sources, verifies upstream SHA-256
metadata where available, extracts ready-to-use binaries, captures licences and provenance,
adds an offline Rust toolchain, optionally adds a current Grype vulnerability database,
includes optional workflow/container/task linters, constructs a local Debian 13 package repository for debugger utilities, creates one complete ZIP,
and optionally emits a size-bounded set of valid ZIP archives suitable for file-library upload.

The generated bundle does not install anything automatically. Linux-side preparation and
optional installation scripts are included in the archive.

.PARAMETER OutputDirectory
Parent working/output directory. The generated bundle and .work subdirectories are rebuilt cleanly. When
-KeepExistingOutput is used, verified downloads may be staged through a persistent .download-cache directory.

.PARAMETER ArchivePath
Final ZIP path.

.PARAMETER GitHubToken
Optional GitHub token. Supplying one avoids the unauthenticated API rate limit. The token is
used only for GitHub API requests and is never written to the bundle.

.PARAMETER SkipRust
Do not download the offline Rust components.

.PARAMETER SkipGrypeDatabase
Do not include a Grype vulnerability database snapshot.

.PARAMETER SkipDebianPackages
Do not construct the local Debian repository containing strace, lsof, gdb, gdbserver,
and valgrind plus their dependency closure.

.PARAMETER IncludeExtendedTools
Include actionlint, Hadolint, just, and Task. Enabled by default; pass
-IncludeExtendedTools:$false to omit them.

.PARAMETER RequireUpstreamChecksums
Fail when a GitHub release asset has neither a GitHub release digest nor a usable
published SHA-256 checksum artifact. Disabled by default because some upstreams do
not publish an independently discoverable SHA-256 for every asset.

.PARAMETER KeepExistingOutput
Preserve and reuse a task-local download cache where an expected upstream SHA-256 is available. The generated bundle
and .work directory are still rebuilt from a clean state so stale artifacts cannot leak into the new bundle.

.PARAMETER GrypeDatabaseSchema
Grype database distribution schema to capture. The current official production schema is 6.

.PARAMETER CreateLibraryArchiveSet
Also create a set of valid, independently uploadable ZIP files. Extract all set members into the
same parent directory to reconstruct the complete bundle.

.PARAMETER LibraryArchiveDirectory
Destination directory for the file-library ZIP set and its checksum/readme files.

.PARAMETER LibraryArchiveMaximumMB
Maximum permitted size of each file-library ZIP. The default leaves headroom below a 512 MB
per-file upload limit.

.EXAMPLE
.\Download-BlueprintOneShotToolkit.ps1

.EXAMPLE
.\Download-BlueprintOneShotToolkit.ps1 -GitHubToken $env:GITHUB_TOKEN

.EXAMPLE
.\Download-BlueprintOneShotToolkit.ps1 -SkipGrypeDatabase -SkipDebianPackages
#>

[CmdletBinding()]
param(
    [Parameter()]
    [string]$OutputDirectory = (Join-Path (Get-Location) "blueprint-one-shot-toolkit-build"),

    [Parameter()]
    [string]$ArchivePath = (Join-Path (Get-Location) "blueprint-one-shot-toolkit-linux-x86_64.zip"),

    [Parameter()]
    [string]$GitHubToken = $env:GITHUB_TOKEN,

    [Parameter()]
    [switch]$SkipRust,

    [Parameter()]
    [switch]$SkipGrypeDatabase,

    [Parameter()]
    [switch]$SkipDebianPackages,

    [Parameter()]
    [bool]$IncludeExtendedTools = $true,

    [Parameter()]
    [switch]$RequireUpstreamChecksums,

    [Parameter()]
    [switch]$KeepExistingOutput,

    [Parameter()]
    [ValidateRange(6, 99)]
    [int]$GrypeDatabaseSchema = 6,

    [Parameter()]
    [bool]$CreateLibraryArchiveSet = $true,

    [Parameter()]
    [string]$LibraryArchiveDirectory = "",

    [Parameter()]
    [ValidateRange(64, 511)]
    [int]$LibraryArchiveMaximumMB = 480
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
} catch {
    # PowerShell 7+ generally negotiates an appropriate TLS version without this setting.
}

$ScriptVersion = "1.2.0"
$BundleName = "blueprint-one-shot-toolkit-linux-x86_64"
$DebianSuite = "trixie"
$DebianArchitecture = "amd64"
$RustTarget = "x86_64-unknown-linux-gnu"
$TargetDescription = "Debian 13 (trixie), Linux x86_64, glibc-compatible; static/musl preferred where available"

$OutputDirectory = [IO.Path]::GetFullPath($OutputDirectory)
$ArchivePath = [IO.Path]::GetFullPath($ArchivePath)
if (-not $LibraryArchiveDirectory) {
    $LibraryArchiveDirectory = Join-Path (Split-Path -Parent $ArchivePath) "blueprint-one-shot-toolkit-library-set"
}
$LibraryArchiveDirectory = [IO.Path]::GetFullPath($LibraryArchiveDirectory)
if ([IO.Path]::GetExtension($ArchivePath) -ine ".zip") {
    throw "ArchivePath must end in .zip because the script uses Compress-Archive."
}
$BundleRoot = Join-Path $OutputDirectory $BundleName
$WorkRoot = Join-Path $OutputDirectory ".work"
$DownloadCacheDir = Join-Path $OutputDirectory ".download-cache"
$bundleRootPrefix = $BundleRoot.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
if ($ArchivePath.StartsWith($bundleRootPrefix, [StringComparison]::OrdinalIgnoreCase)) {
    throw "ArchivePath must be outside the bundle root to avoid recursively archiving the output ZIP."
}
$libraryArchivePrefix = $LibraryArchiveDirectory.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
if ($LibraryArchiveDirectory.StartsWith($bundleRootPrefix, [StringComparison]::OrdinalIgnoreCase) -or
    $bundleRootPrefix.StartsWith($libraryArchivePrefix, [StringComparison]::OrdinalIgnoreCase)) {
    throw "LibraryArchiveDirectory must be outside the bundle root and must not contain the bundle root."
}

$PortableBinDir = Join-Path $BundleRoot "bin"
$DownloadsDir = Join-Path $BundleRoot "downloads"
$LicencesDir = Join-Path $BundleRoot "licences"
$MetadataDir = Join-Path $BundleRoot "metadata"
$ScriptsDir = Join-Path $BundleRoot "scripts"
$DataDir = Join-Path $BundleRoot "data"
$RustDir = Join-Path $BundleRoot "rust"
$DebianRepoDir = Join-Path $BundleRoot "debian-packages"

$ManifestEntries = [System.Collections.Generic.List[object]]::new()
$Warnings = [System.Collections.Generic.List[string]]::new()

function Write-Stage {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "`n==> $Message" -ForegroundColor Cyan
}

function Write-Detail {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "    $Message"
}

function Add-WarningRecord {
    param([Parameter(Mandatory)][string]$Message)
    [void]$Warnings.Add($Message)
    Write-Warning $Message
}

function New-Directory {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Write-Utf8NoBom {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][AllowEmptyString()][string]$Content
    )
    $parent = Split-Path -Parent $Path
    if ($parent) { New-Directory $parent }
    $encoding = [System.Text.UTF8Encoding]::new($false)
    [IO.File]::WriteAllText($Path, $Content, $encoding)
}

function Get-Sha256 {
    param([Parameter(Mandatory)][string]$Path)
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}


function Get-LinuxBinaryInspection {
    param([Parameter(Mandatory)][string]$Path)

    $stream = [IO.File]::OpenRead($Path)
    try {
        $header = [byte[]]::new(64)
        $read = $stream.Read($header, 0, $header.Length)
    } finally {
        $stream.Dispose()
    }

    if ($read -ge 20 -and $header[0] -eq 0x7f -and $header[1] -eq 0x45 -and $header[2] -eq 0x4c -and $header[3] -eq 0x46) {
        $bits = if ($header[4] -eq 2) { 64 } elseif ($header[4] -eq 1) { 32 } else { 0 }
        $endianness = if ($header[5] -eq 1) { "little" } elseif ($header[5] -eq 2) { "big" } else { "unknown" }
        if ($endianness -eq "little") {
            $machine = [int]$header[18] + ([int]$header[19] -shl 8)
        } else {
            $machine = ([int]$header[18] -shl 8) + [int]$header[19]
        }
        if ($bits -ne 64 -or $machine -ne 62) {
            throw "Binary '$Path' is ELF but not Linux x86_64 (class=$bits, machine=$machine)."
        }
        return [ordered]@{
            format = "ELF"
            bits = $bits
            endianness = $endianness
            machine = "x86-64"
            machine_id = $machine
        }
    }

    if ($read -ge 2 -and $header[0] -eq 0x23 -and $header[1] -eq 0x21) {
        return [ordered]@{
            format = "script"
            bits = $null
            endianness = $null
            machine = "interpreter-dependent"
            machine_id = $null
        }
    }

    throw "Expected a Linux executable but '$Path' is neither an ELF binary nor a shebang script."
}

function Get-RelativePathCompat {
    param(
        [Parameter(Mandatory)][string]$BasePath,
        [Parameter(Mandatory)][string]$Path
    )
    $baseFull = [IO.Path]::GetFullPath($BasePath)
    $pathFull = [IO.Path]::GetFullPath($Path)
    if (-not $baseFull.EndsWith(([IO.Path]::DirectorySeparatorChar).ToString())) {
        $baseFull += [IO.Path]::DirectorySeparatorChar
    }
    $baseUri = [Uri]::new($baseFull)
    $pathUri = [Uri]::new($pathFull)
    return [Uri]::UnescapeDataString($baseUri.MakeRelativeUri($pathUri).ToString())
}

function Invoke-Retry {
    param(
        [Parameter(Mandatory)][scriptblock]$Operation,
        [int]$Attempts = 4,
        [int]$InitialDelaySeconds = 2,
        [string]$Description = "operation"
    )
    $delay = $InitialDelaySeconds
    for ($attempt = 1; $attempt -le $Attempts; $attempt++) {
        try {
            return & $Operation
        } catch {
            if ($attempt -eq $Attempts) {
                throw "Failed $Description after $Attempts attempts: $($_.Exception.Message)"
            }
            Write-Warning "$Description failed on attempt $attempt/$Attempts. Retrying in $delay seconds. $($_.Exception.Message)"
            Start-Sleep -Seconds $delay
            $delay = [Math]::Min($delay * 2, 20)
        }
    }
}

function Get-GitHubHeaders {
    $headers = @{
        "Accept" = "application/vnd.github+json"
        "User-Agent" = "Blueprint-OneShot-Toolkit-Bundler/$ScriptVersion"
        "X-GitHub-Api-Version" = "2022-11-28"
    }
    if ($GitHubToken) {
        $headers["Authorization"] = "Bearer $GitHubToken"
    }
    return $headers
}

function Invoke-JsonRequest {
    param(
        [Parameter(Mandatory)][string]$Uri,
        [hashtable]$Headers = @{}
    )
    return Invoke-Retry -Description "JSON request $Uri" -Operation {
        Invoke-RestMethod -Uri $Uri -Headers $Headers -Method Get
    }
}

function Invoke-TextRequest {
    param(
        [Parameter(Mandatory)][string]$Uri,
        [hashtable]$Headers = @{}
    )
    return Invoke-Retry -Description "text request $Uri" -Operation {
        $params = @{
            Uri = $Uri
            Headers = $Headers
            Method = "Get"
        }
        if ($PSVersionTable.PSVersion.Major -le 5) {
            $params["UseBasicParsing"] = $true
        }
        $response = Invoke-WebRequest @params
        return [string]$response.Content
    }
}

function Download-File {
    param(
        [Parameter(Mandatory)][string]$Uri,
        [Parameter(Mandatory)][string]$Destination,
        [string]$ExpectedSha256,
        [hashtable]$Headers = @{}
    )

    $parent = Split-Path -Parent $Destination
    if ($parent) { New-Directory $parent }

    $downloadRootPrefix = $DownloadsDir.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    $destinationFull = [IO.Path]::GetFullPath($Destination)
    $cacheCandidate = $null
    if ($KeepExistingOutput -and $destinationFull.StartsWith($downloadRootPrefix, [StringComparison]::OrdinalIgnoreCase)) {
        $relativeCachePath = (Get-RelativePathCompat -BasePath $DownloadsDir -Path $destinationFull).Replace('/', [IO.Path]::DirectorySeparatorChar)
        $cacheCandidate = Join-Path $DownloadCacheDir $relativeCachePath
        if ((-not (Test-Path -LiteralPath $Destination)) -and $ExpectedSha256 -and (Test-Path -LiteralPath $cacheCandidate)) {
            $cachedHash = Get-Sha256 $cacheCandidate
            if ($cachedHash -eq $ExpectedSha256.ToLowerInvariant()) {
                Copy-Item -LiteralPath $cacheCandidate -Destination $Destination -Force
                Write-Detail "Reusing verified cached download: $(Split-Path -Leaf $Destination)"
                return $Destination
            }
        }
    }

    if ((Test-Path -LiteralPath $Destination) -and $ExpectedSha256) {
        $existingHash = Get-Sha256 $Destination
        if ($existingHash -eq $ExpectedSha256.ToLowerInvariant()) {
            Write-Detail "Reusing verified download: $(Split-Path -Leaf $Destination)"
            return $Destination
        }
        Remove-Item -LiteralPath $Destination -Force
    }

    $partial = "$Destination.partial"
    if (Test-Path -LiteralPath $partial) { Remove-Item -LiteralPath $partial -Force }

    Invoke-Retry -Description "download $Uri" -Attempts 5 -Operation {
        if (Get-Command curl.exe -ErrorAction SilentlyContinue) {
            $arguments = @(
                "--fail", "--location", "--silent", "--show-error",
                "--retry", "5", "--connect-timeout", "30"
            )
            foreach ($headerName in $Headers.Keys) {
                $arguments += @("--header", "${headerName}: $($Headers[$headerName])")
            }
            $arguments += @("--output", $partial, $Uri)
            & curl.exe @arguments
            if ($LASTEXITCODE -ne 0) {
                throw "curl.exe exited with code $LASTEXITCODE"
            }
        } else {
            $params = @{
                Uri = $Uri
                OutFile = $partial
                Headers = $Headers
                Method = "Get"
            }
            if ($PSVersionTable.PSVersion.Major -le 5) {
                $params["UseBasicParsing"] = $true
            }
            Invoke-WebRequest @params | Out-Null
        }
    } | Out-Null

    Move-Item -LiteralPath $partial -Destination $Destination -Force

    if ($ExpectedSha256) {
        $actual = Get-Sha256 $Destination
        if ($actual -ne $ExpectedSha256.ToLowerInvariant()) {
            Remove-Item -LiteralPath $Destination -Force
            throw "SHA-256 mismatch for $Destination. Expected $ExpectedSha256, got $actual"
        }
    }

    if ($KeepExistingOutput -and $cacheCandidate) {
        $cacheParent = Split-Path -Parent $cacheCandidate
        if ($cacheParent) { New-Directory $cacheParent }
        Copy-Item -LiteralPath $Destination -Destination $cacheCandidate -Force
    }

    return $Destination
}

function Expand-Artifact {
    param(
        [Parameter(Mandatory)][string]$ArchivePath,
        [Parameter(Mandatory)][string]$Destination
    )
    if (Test-Path -LiteralPath $Destination) {
        Remove-Item -LiteralPath $Destination -Recurse -Force
    }
    New-Directory $Destination

    $name = (Split-Path -Leaf $ArchivePath).ToLowerInvariant()
    if ($name.EndsWith(".zip")) {
        Expand-Archive -LiteralPath $ArchivePath -DestinationPath $Destination -Force
        return
    }

    if ($name -match '\.(tar\.gz|tgz|tar\.xz|txz|tar\.bz2|tbz2|tar\.zst)$') {
        $tar = Get-Command tar.exe -ErrorAction SilentlyContinue
        if (-not $tar) { $tar = Get-Command tar -ErrorAction SilentlyContinue }
        if (-not $tar) {
            throw "tar is required to extract $ArchivePath. Windows 10/11 normally includes tar.exe."
        }
        & $tar.Source -xf $ArchivePath -C $Destination
        if ($LASTEXITCODE -ne 0) {
            throw "tar failed to extract $ArchivePath with exit code $LASTEXITCODE"
        }
        return
    }

    throw "Unsupported archive type: $ArchivePath"
}

function Get-GitHubLatestRelease {
    param([Parameter(Mandatory)][string]$Repository)
    $uri = "https://api.github.com/repos/$Repository/releases/latest"
    return Invoke-JsonRequest -Uri $uri -Headers (Get-GitHubHeaders)
}

function Test-AssetExcluded {
    param(
        [Parameter(Mandatory)][string]$Name,
        [string[]]$ExtraExcludePatterns = @()
    )
    $defaultExcludes = @(
        '(?i)(arm32|arm64|aarch64|ppc|powerpc|s390|riscv|i686|x86_32)',
        '(?i)(checksums?|sha256sums?|\.sha256|\.sig$|\.pem$|\.crt$|\.asc$|sbom)',
        '(?i)(\.deb$|\.rpm$|\.apk$|\.msi$|\.exe$|\.pkg$|\.dmg$)',
        '(?i)(source|src|symbols|debug|noopt|fxdependent)'
    )
    foreach ($pattern in @($defaultExcludes + $ExtraExcludePatterns)) {
        if ($Name -match $pattern) { return $true }
    }
    return $false
}

function Select-GitHubReleaseAsset {
    param(
        [Parameter(Mandatory)]$Release,
        [Parameter(Mandatory)][string[]]$PreferredPatterns,
        [string[]]$ExcludePatterns = @()
    )

    foreach ($pattern in $PreferredPatterns) {
        $matches = @($Release.assets | Where-Object {
            ($_.name -match $pattern) -and -not (Test-AssetExcluded -Name $_.name -ExtraExcludePatterns $ExcludePatterns)
        })
        if ($matches.Count -gt 0) {
            return $matches | Sort-Object @{ Expression = { $_.name.Length }; Ascending = $true }, name | Select-Object -First 1
        }
    }

    $assetList = ($Release.assets | ForEach-Object { $_.name }) -join "`n  - "
    throw "No matching Linux x86_64 asset was found. Available assets:`n  - $assetList"
}

function Get-UpstreamChecksumFromRelease {
    param(
        [Parameter(Mandatory)]$Release,
        [Parameter(Mandatory)]$Asset,
        [Parameter(Mandatory)][string]$ToolName
    )

    if (($Asset.PSObject.Properties.Name -contains "digest") -and $Asset.digest) {
        $digestText = [string]$Asset.digest
        if ($digestText -match '^(?i)sha256:([0-9a-f]{64})$') {
            return [pscustomobject]@{
                ExpectedSha256 = $Matches[1].ToLowerInvariant()
                Method = "github-release-asset-digest"
                ChecksumArtifact = $null
            }
        }
    }

    $exactNames = @(
        "$($Asset.name).sha256",
        "$($Asset.name).sha256sum",
        "$($Asset.name).sha256.txt"
    )

    $candidates = @($Release.assets | Where-Object {
        ($exactNames -contains $_.name) -or ($_.name -match '(?i)(checksums?|sha256sums?)')
    } | Sort-Object @{ Expression = { if ($exactNames -contains $_.name) { 0 } else { 1 } } }, name)

    foreach ($candidate in $candidates) {
        $checksumDir = Join-Path $MetadataDir "upstream-checksums/$ToolName"
        New-Directory $checksumDir
        $checksumPath = Join-Path $checksumDir $candidate.name
        Download-File -Uri $candidate.browser_download_url -Destination $checksumPath | Out-Null
        $content = [IO.File]::ReadAllText($checksumPath)
        $escapedName = [regex]::Escape($Asset.name)
        $patterns = @(
            "(?im)^\s*([0-9a-f]{64})\s+\*?$escapedName\s*$",
            "(?im)^\s*SHA256\s*\($escapedName\)\s*=\s*([0-9a-f]{64})\s*$",
            "(?im)^\s*$escapedName\s*[:=]\s*([0-9a-f]{64})\s*$"
        )
        if ($exactNames -contains $candidate.name) {
            $patterns += "(?im)^\s*([0-9a-f]{64})\s*$"
        }
        foreach ($pattern in $patterns) {
            $match = [regex]::Match($content, $pattern)
            if ($match.Success) {
                return [pscustomobject]@{
                    ExpectedSha256 = $match.Groups[1].Value.ToLowerInvariant()
                    Method = "published-checksum-file"
                    ChecksumArtifact = Get-RelativePathCompat -BasePath $BundleRoot -Path $checksumPath
                }
            }
        }
    }

    return [pscustomobject]@{
        ExpectedSha256 = $null
        Method = "locally-computed-only"
        ChecksumArtifact = $null
    }
}

function Copy-LicencesFromTree {
    param(
        [Parameter(Mandatory)][string]$SourceRoot,
        [Parameter(Mandatory)][string]$ToolName
    )
    if (-not (Test-Path -LiteralPath $SourceRoot)) { return 0 }
    $destination = Join-Path $LicencesDir $ToolName
    New-Directory $destination
    $licenceFiles = @(Get-ChildItem -LiteralPath $SourceRoot -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -match '^(?i)(LICENSE|LICENCE|COPYING|COPYRIGHT|NOTICE|UNLICENSE)(\..*|-.*)?$' } |
        Sort-Object FullName |
        Select-Object -First 12)
    $copied = 0
    foreach ($file in $licenceFiles) {
        $targetName = $file.Name
        $target = Join-Path $destination $targetName
        $suffix = 1
        while (Test-Path -LiteralPath $target) {
            $target = Join-Path $destination ("{0}-{1}" -f $targetName, $suffix)
            $suffix++
        }
        Copy-Item -LiteralPath $file.FullName -Destination $target -Force
        $copied++
    }
    return $copied
}

function Save-GitHubLicences {
    param(
        [Parameter(Mandatory)][string]$Repository,
        [Parameter(Mandatory)][string]$Tag,
        [Parameter(Mandatory)][string]$ToolName
    )
    $destination = Join-Path $LicencesDir $ToolName
    New-Directory $destination
    $encodedTag = [Uri]::EscapeDataString($Tag)
    $uri = "https://api.github.com/repos/$Repository/contents?ref=$encodedTag"
    try {
        $items = Invoke-JsonRequest -Uri $uri -Headers (Get-GitHubHeaders)
        $licenceItems = @($items | Where-Object {
            $_.type -eq "file" -and $_.name -match '^(?i)(LICENSE|LICENCE|COPYING|COPYRIGHT|NOTICE|UNLICENSE)(\..*|-.*)?$'
        } | Sort-Object name | Select-Object -First 12)
        foreach ($item in $licenceItems) {
            $target = Join-Path $destination $item.name
            Download-File -Uri $item.download_url -Destination $target | Out-Null
        }
        return $licenceItems.Count
    } catch {
        Add-WarningRecord "Could not retrieve licence files for $ToolName from $Repository at tag $Tag: $($_.Exception.Message)"
        return 0
    }
}

function Find-ExpectedBinary {
    param(
        [Parameter(Mandatory)][string]$ExtractRoot,
        [Parameter(Mandatory)][string]$BinaryName
    )
    $matches = @(Get-ChildItem -LiteralPath $ExtractRoot -Recurse -File -ErrorAction Stop |
        Where-Object { $_.Name -ieq $BinaryName })
    if ($matches.Count -eq 0) {
        $files = (Get-ChildItem -LiteralPath $ExtractRoot -Recurse -File | ForEach-Object { $_.FullName }) -join "`n  - "
        throw "Expected binary '$BinaryName' was not found after extraction. Files:`n  - $files"
    }
    return $matches | Sort-Object FullName | Select-Object -First 1
}

function Add-GitHubTool {
    param([Parameter(Mandatory)]$Spec)

    Write-Stage "Downloading $($Spec.DisplayName)"
    $release = Get-GitHubLatestRelease -Repository $Spec.Repository
    $asset = Select-GitHubReleaseAsset -Release $release -PreferredPatterns $Spec.AssetPatterns -ExcludePatterns $Spec.ExcludePatterns
    $checksum = Get-UpstreamChecksumFromRelease -Release $release -Asset $asset -ToolName $Spec.Name
    if (-not $checksum.ExpectedSha256) {
        $message = "$($Spec.DisplayName) has no SHA-256 available through the GitHub asset digest or published checksum assets; only the locally computed SHA-256 will be recorded."
        if ($RequireUpstreamChecksums) { throw $message }
        Add-WarningRecord $message
    }

    $toolDownloadDir = Join-Path $DownloadsDir "github/$($Spec.Name)"
    New-Directory $toolDownloadDir
    $downloadPath = Join-Path $toolDownloadDir $asset.name
    Download-File -Uri $asset.browser_download_url -Destination $downloadPath -ExpectedSha256 $checksum.ExpectedSha256 | Out-Null
    $archiveHash = Get-Sha256 $downloadPath

    $extractRoot = Join-Path $WorkRoot "extract-$($Spec.Name)"
    $isArchive = $asset.name -match '(?i)\.(zip|tar\.gz|tgz|tar\.xz|txz|tar\.bz2|tbz2|tar\.zst)$'

    if ($isArchive) {
        Expand-Artifact -ArchivePath $downloadPath -Destination $extractRoot
        $licenceCount = Copy-LicencesFromTree -SourceRoot $extractRoot -ToolName $Spec.Name
        foreach ($binaryName in $Spec.BinaryNames) {
            $binary = Find-ExpectedBinary -ExtractRoot $extractRoot -BinaryName $binaryName
            Copy-Item -LiteralPath $binary.FullName -Destination (Join-Path $PortableBinDir $binaryName) -Force
        }
    } else {
        if ($Spec.BinaryNames.Count -ne 1) {
            throw "Raw release asset for $($Spec.Name) must map to exactly one binary name."
        }
        $licenceCount = 0
        Copy-Item -LiteralPath $downloadPath -Destination (Join-Path $PortableBinDir $Spec.BinaryNames[0]) -Force
    }

    $repositoryLicenceCount = Save-GitHubLicences -Repository $Spec.Repository -Tag $release.tag_name -ToolName $Spec.Name
    if (($licenceCount + $repositoryLicenceCount) -eq 0) {
        Add-WarningRecord "No licence or notice file was captured for $($Spec.DisplayName); review upstream redistribution requirements before sharing the generated bundle."
    }

    $binaryRecords = @()
    foreach ($binaryName in $Spec.BinaryNames) {
        $binaryPath = Join-Path $PortableBinDir $binaryName
        $inspection = Get-LinuxBinaryInspection -Path $binaryPath
        $binaryRecords += [ordered]@{
            path = Get-RelativePathCompat -BasePath $BundleRoot -Path $binaryPath
            sha256 = Get-Sha256 $binaryPath
            bytes = (Get-Item -LiteralPath $binaryPath).Length
            executable = $inspection
        }
    }

    $releaseMetadata = [ordered]@{
        repository = $Spec.Repository
        release_tag = $release.tag_name
        release_name = $release.name
        published_at = $release.published_at
        release_url = $release.html_url
        asset_name = $asset.name
        asset_url = $asset.browser_download_url
        asset_sha256 = $archiveHash
        upstream_verification = $checksum.Method
        upstream_checksum_artifact = $checksum.ChecksumArtifact
        binaries = $binaryRecords
    }
    $releaseMetadataPath = Join-Path $MetadataDir "releases/$($Spec.Name).json"
    Write-Utf8NoBom -Path $releaseMetadataPath -Content ($releaseMetadata | ConvertTo-Json -Depth 8)

    [void]$ManifestEntries.Add([ordered]@{
        name = $Spec.Name
        display_name = $Spec.DisplayName
        kind = "portable-binary"
        version = $release.tag_name
        repository = $Spec.Repository
        source = $release.html_url
        release_asset = Get-RelativePathCompat -BasePath $BundleRoot -Path $downloadPath
        release_asset_sha256 = $archiveHash
        upstream_verification = $checksum.Method
        binaries = $binaryRecords
        licence_directory = "licences/$($Spec.Name)"
    })

    Write-Detail "Selected $($asset.name) from release $($release.tag_name)"
}

function Add-SqliteTools {
    Write-Stage "Downloading SQLite command-line tools"
    $downloadPage = "https://sqlite.org/download.html"
    $html = Invoke-TextRequest -Uri $downloadPage

    $matches = [regex]::Matches($html, '(?i)(?<path>(?:https://sqlite\.org/)?(?:\d{4}/)?sqlite-tools-linux-x64-(?<version>\d+)\.zip)')
    if ($matches.Count -eq 0) {
        throw "Could not locate sqlite-tools-linux-x64 on $downloadPage"
    }

    $selected = $matches | Sort-Object { [int64]$_.Groups["version"].Value } -Descending | Select-Object -First 1
    $pathText = [System.Net.WebUtility]::HtmlDecode($selected.Groups["path"].Value)
    if ($pathText.StartsWith("https://", [StringComparison]::OrdinalIgnoreCase)) {
        $url = $pathText
    } else {
        $url = "https://sqlite.org/$($pathText.TrimStart('/'))"
    }
    $archiveName = Split-Path -Leaf (([Uri]$url).AbsolutePath)
    $versionCode = $selected.Groups["version"].Value

    $officialSha3 = $null
    $position = $html.IndexOf($archiveName, [StringComparison]::OrdinalIgnoreCase)
    if ($position -ge 0) {
        $length = [Math]::Min(1500, $html.Length - $position)
        $snippet = $html.Substring($position, $length)
        $sha3Match = [regex]::Match($snippet, '(?i)SHA3-256:\s*([0-9a-f]{64})')
        if ($sha3Match.Success) { $officialSha3 = $sha3Match.Groups[1].Value.ToLowerInvariant() }
    }

    $toolDownloadDir = Join-Path $DownloadsDir "sqlite"
    New-Directory $toolDownloadDir
    $archivePath = Join-Path $toolDownloadDir $archiveName
    Download-File -Uri $url -Destination $archivePath | Out-Null
    $archiveSha256 = Get-Sha256 $archivePath

    $extractRoot = Join-Path $WorkRoot "extract-sqlite"
    Expand-Artifact -ArchivePath $archivePath -Destination $extractRoot
    $requiredBinaryNames = @("sqlite3")
    $optionalBinaryNames = @("sqldiff", "sqlite3_analyzer", "sqlite3_rsync")
    $binaryRecords = @()
    foreach ($binaryName in @($requiredBinaryNames + $optionalBinaryNames)) {
        try {
            $binary = Find-ExpectedBinary -ExtractRoot $extractRoot -BinaryName $binaryName
        } catch {
            if ($requiredBinaryNames -contains $binaryName) { throw }
            Add-WarningRecord "The current SQLite tools archive does not contain optional executable '$binaryName'."
            continue
        }
        $target = Join-Path $PortableBinDir $binaryName
        Copy-Item -LiteralPath $binary.FullName -Destination $target -Force
        $inspection = Get-LinuxBinaryInspection -Path $target
        $binaryRecords += [ordered]@{
            path = Get-RelativePathCompat -BasePath $BundleRoot -Path $target
            sha256 = Get-Sha256 $target
            bytes = (Get-Item -LiteralPath $target).Length
            executable = $inspection
        }
    }

    $sqliteLicenceDir = Join-Path $LicencesDir "sqlite"
    New-Directory $sqliteLicenceDir
    try {
        Download-File -Uri "https://sqlite.org/copyright.html" -Destination (Join-Path $sqliteLicenceDir "copyright.html") | Out-Null
    } catch {
        Add-WarningRecord "Could not download SQLite public-domain statement: $($_.Exception.Message)"
    }

    $metadata = [ordered]@{
        source = $downloadPage
        archive_url = $url
        version_code = $versionCode
        archive_name = $archiveName
        archive_sha256 = $archiveSha256
        upstream_sha3_256 = $officialSha3
        upstream_sha3_verified = $false
        note = "The official SQLite page publishes SHA3-256. This script always records a local SHA-256; SHA3 verification depends on local runtime support and is not required for bundle creation."
        binaries = $binaryRecords
    }
    Write-Utf8NoBom -Path (Join-Path $MetadataDir "releases/sqlite.json") -Content ($metadata | ConvertTo-Json -Depth 8)

    [void]$ManifestEntries.Add([ordered]@{
        name = "sqlite"
        display_name = "SQLite command-line tools"
        kind = "portable-binaries"
        version = $versionCode
        source = $downloadPage
        release_asset = Get-RelativePathCompat -BasePath $BundleRoot -Path $archivePath
        release_asset_sha256 = $archiveSha256
        upstream_sha3_256 = $officialSha3
        binaries = $binaryRecords
        licence_directory = "licences/sqlite"
    })

    Write-Detail "Selected $archiveName"
}

function Get-RustManifestSection {
    param(
        [Parameter(Mandatory)][string]$ManifestText,
        [Parameter(Mandatory)][string]$Component,
        [Parameter(Mandatory)][string]$Target
    )
    $componentEscaped = [regex]::Escape($Component)
    $targetEscaped = [regex]::Escape($Target)
    $targetPattern = '(?:' + $targetEscaped + '|"' + $targetEscaped + '")'
    $pattern = "(?ms)^\[pkg\.$componentEscaped\.target\.$targetPattern\]\s*(?<body>.*?)(?=^\[|\z)"
    $match = [regex]::Match($ManifestText, $pattern)
    if (-not $match.Success) { return $null }
    $body = $match.Groups["body"].Value
    $values = @{}
    foreach ($line in ($body -split "`r?`n")) {
        if ($line -match '^\s*([A-Za-z0-9_-]+)\s*=\s*"(.*)"\s*$') {
            $values[$Matches[1]] = $Matches[2]
        } elseif ($line -match '^\s*([A-Za-z0-9_-]+)\s*=\s*(true|false)\s*$') {
            $values[$Matches[1]] = [bool]::Parse($Matches[2])
        }
    }
    return $values
}

function Add-RustToolchain {
    Write-Stage "Downloading offline Rust stable components"
    $manifestUrl = "https://static.rust-lang.org/dist/channel-rust-stable.toml"
    $manifestShaUrl = "$manifestUrl.sha256"
    $rustMetadataDir = Join-Path $MetadataDir "rust"
    $componentDir = Join-Path $RustDir "components"
    New-Directory $rustMetadataDir
    New-Directory $componentDir

    $manifestPath = Join-Path $rustMetadataDir "channel-rust-stable.toml"
    $manifestShaPath = Join-Path $rustMetadataDir "channel-rust-stable.toml.sha256"
    Download-File -Uri $manifestShaUrl -Destination $manifestShaPath | Out-Null
    $manifestExpected = ([regex]::Match([IO.File]::ReadAllText($manifestShaPath), '(?i)([0-9a-f]{64})')).Groups[1].Value.ToLowerInvariant()
    if (-not $manifestExpected) { throw "Could not parse Rust channel manifest SHA-256" }
    Download-File -Uri $manifestUrl -Destination $manifestPath -ExpectedSha256 $manifestExpected | Out-Null
    $manifestText = [IO.File]::ReadAllText($manifestPath)

    $dateMatch = [regex]::Match($manifestText, '(?m)^date\s*=\s*"([^"]+)"')
    $rustDate = if ($dateMatch.Success) { $dateMatch.Groups[1].Value } else { $null }
    $rustPkgMatch = [regex]::Match($manifestText, '(?ms)^\[pkg\.rust\]\s*(?<body>.*?)(?=^\[|\z)')
    $rustVersion = $null
    if ($rustPkgMatch.Success) {
        $versionMatch = [regex]::Match($rustPkgMatch.Groups["body"].Value, '(?m)^version\s*=\s*"([^"]+)"')
        if ($versionMatch.Success) {
            $semverMatch = [regex]::Match($versionMatch.Groups[1].Value, '\d+\.\d+\.\d+')
            if ($semverMatch.Success) { $rustVersion = $semverMatch.Value }
        }
    }
    if (-not $rustVersion) { throw "Could not determine Rust stable version from channel manifest" }

    $components = @(
        [pscustomobject]@{ Name = "rustc"; Target = $RustTarget; Required = $true },
        [pscustomobject]@{ Name = "rust-std"; Target = $RustTarget; Required = $true },
        [pscustomobject]@{ Name = "cargo"; Target = $RustTarget; Required = $true },
        [pscustomobject]@{ Name = "clippy-preview"; Target = $RustTarget; Required = $true },
        [pscustomobject]@{ Name = "rustfmt-preview"; Target = $RustTarget; Required = $true },
        [pscustomobject]@{ Name = "rust-analyzer-preview"; Target = $RustTarget; Required = $false },
        [pscustomobject]@{ Name = "llvm-tools-preview"; Target = $RustTarget; Required = $false },
        [pscustomobject]@{ Name = "rust-src"; Target = "*"; Required = $false }
    )
    $componentRecords = @()
    $installArchiveNames = @()

    foreach ($componentSpec in $components) {
        $component = [string]$componentSpec.Name
        $componentTarget = [string]$componentSpec.Target
        $componentRequired = [bool]$componentSpec.Required
        $section = Get-RustManifestSection -ManifestText $manifestText -Component $component -Target $componentTarget
        if (-not $section) {
            $message = "Rust component '$component' is not present for target $componentTarget in the stable channel manifest."
            if ($componentRequired) { throw $message }
            Add-WarningRecord $message
            continue
        }
        if ($section.ContainsKey("available") -and -not $section["available"]) {
            $message = "Rust component '$component' is unavailable for target $componentTarget."
            if ($componentRequired) { throw $message }
            Add-WarningRecord $message
            continue
        }
        $url = if ($section.ContainsKey("xz_url")) { [string]$section["xz_url"] } elseif ($section.ContainsKey("url")) { [string]$section["url"] } else { $null }
        $hash = if ($section.ContainsKey("xz_hash")) { [string]$section["xz_hash"] } elseif ($section.ContainsKey("hash")) { [string]$section["hash"] } else { $null }
        if (-not $url -or -not $hash) {
            $message = "Rust component '$component' lacks a downloadable archive/hash pair."
            if ($componentRequired) { throw $message }
            Add-WarningRecord $message
            continue
        }
        $archiveName = Split-Path -Leaf (([Uri]$url).AbsolutePath)
        $archivePath = Join-Path $componentDir $archiveName
        Download-File -Uri $url -Destination $archivePath -ExpectedSha256 $hash | Out-Null
        $installArchiveNames += $archiveName
        $componentRecords += [ordered]@{
            component = $component
            target = $componentTarget
            archive = "components/$archiveName"
            sha256 = (Get-Sha256 $archivePath)
            source = $url
            bytes = (Get-Item -LiteralPath $archivePath).Length
        }
        Write-Detail "Rust component: $component"
    }

    $rustLicenceDir = Join-Path $LicencesDir "rust"
    New-Directory $rustLicenceDir
    foreach ($licenceName in @("LICENSE-APACHE", "LICENSE-MIT", "COPYRIGHT")) {
        try {
            Download-File -Uri "https://raw.githubusercontent.com/rust-lang/rust/$rustVersion/$licenceName" -Destination (Join-Path $rustLicenceDir $licenceName) | Out-Null
        } catch {
            Add-WarningRecord "Could not download Rust $licenceName at tag $rustVersion: $($_.Exception.Message)"
        }
    }

    $archiveLines = ($installArchiveNames | ForEach-Object { "  \"components/$_\"" }) -join "`n"
    $installTemplate = @'
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PREFIX="${1:-$ROOT/toolchain}"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$PREFIX"
archives=(
__ARCHIVE_LINES__
)
for rel in "${archives[@]}"; do
  rm -rf "$TMP"/*
  tar -xf "$ROOT/$rel" -C "$TMP"
  installer="$(find "$TMP" -mindepth 2 -maxdepth 4 -type f -name install.sh -print -quit)"
  if [[ -z "$installer" ]]; then
    echo "No install.sh found in $rel" >&2
    exit 1
  fi
  chmod +x "$installer"
  "$installer" --prefix="$PREFIX" --disable-ldconfig
done
for required_command in rustc cargo rustfmt clippy-driver; do
  if [[ ! -x "$PREFIX/bin/$required_command" ]]; then
    echo "Required Rust command was not installed: $required_command" >&2
    exit 1
  fi
done
"$PREFIX/bin/rustc" --version
"$PREFIX/bin/cargo" --version
"$PREFIX/bin/rustfmt" --version
"$PREFIX/bin/clippy-driver" --version
printf '\nRust toolchain installed at: %s\n' "$PREFIX"
printf 'Activate with: export PATH=%q/bin:$PATH\n' "$PREFIX"
'@
    $installScript = $installTemplate.Replace("__ARCHIVE_LINES__", $archiveLines)
    Write-Utf8NoBom -Path (Join-Path $RustDir "install-rust-toolchain.sh") -Content $installScript

    $rustReadmeTemplate = @'
# Offline Rust toolchain

Stable channel version: __RUST_VERSION__  
Channel date: __RUST_DATE__  
Target: __RUST_TARGET__

Install into a bundle-local prefix:

```bash
bash rust/install-rust-toolchain.sh
export PATH="$PWD/rust/toolchain/bin:$PATH"
```

The component archives and channel manifest are retained so their SHA-256 values can be rechecked.
'@
    $rustReadme = $rustReadmeTemplate.Replace("__RUST_VERSION__", $rustVersion)
    $rustReadme = $rustReadme.Replace("__RUST_DATE__", [string]$rustDate)
    $rustReadme = $rustReadme.Replace("__RUST_TARGET__", $RustTarget)
    Write-Utf8NoBom -Path (Join-Path $RustDir "README.md") -Content $rustReadme

    [void]$ManifestEntries.Add([ordered]@{
        name = "rust-toolchain"
        display_name = "Rust stable offline toolchain"
        kind = "offline-toolchain-components"
        version = $rustVersion
        channel_date = $rustDate
        target = $RustTarget
        source = $manifestUrl
        channel_manifest = "metadata/rust/channel-rust-stable.toml"
        channel_manifest_sha256 = Get-Sha256 $manifestPath
        components = $componentRecords
        installer = "rust/install-rust-toolchain.sh"
        licence_directory = "licences/rust"
    })
}

function Add-GrypeDatabase {
    Write-Stage "Downloading a current Grype vulnerability database snapshot"
    $metadataUrl = "https://grype.anchore.io/databases/v$GrypeDatabaseSchema/latest.json"
    $metadata = Invoke-JsonRequest -Uri $metadataUrl

    # Grype's v6+ listing format has evolved. Accept both the current nested archive
    # document and earlier flattened URL/path documents, while requiring a SHA-256.
    $archiveNode = $metadata
    if (($metadata.PSObject.Properties.Name -contains "archive") -and $metadata.archive) {
        $archiveNode = $metadata.archive
    }

    $archiveCandidates = @()
    if ($archiveNode.PSObject.Properties.Name -contains "url") { $archiveCandidates += $archiveNode.url }
    if ($archiveNode.PSObject.Properties.Name -contains "path") { $archiveCandidates += $archiveNode.path }
    if ($metadata.PSObject.Properties.Name -contains "url") { $archiveCandidates += $metadata.url }
    if ($metadata.PSObject.Properties.Name -contains "path") { $archiveCandidates += $metadata.path }

    $archiveReference = $null
    foreach ($candidate in $archiveCandidates) {
        if ($candidate) { $archiveReference = [string]$candidate; break }
    }

    $checksumCandidates = @()
    if ($archiveNode.PSObject.Properties.Name -contains "checksum") { $checksumCandidates += $archiveNode.checksum }
    if ($metadata.PSObject.Properties.Name -contains "checksum") { $checksumCandidates += $metadata.checksum }

    $checksumValue = $null
    foreach ($candidate in $checksumCandidates) {
        if ($candidate) { $checksumValue = [string]$candidate; break }
    }

    if (-not $archiveReference -or -not $checksumValue) {
        throw "Grype database metadata did not contain a usable archive path/URL and checksum: $metadataUrl"
    }
    if ($checksumValue -notmatch '^(?i)(?:sha256:)?([0-9a-f]{64})$') {
        throw "Grype database archive checksum is not a SHA-256 value: $checksumValue"
    }
    $expected = $Matches[1].ToLowerInvariant()

    $baseUri = [Uri]::new($metadataUrl)
    $dbUrl = if ($archiveReference.StartsWith("http", [StringComparison]::OrdinalIgnoreCase)) {
        $archiveReference
    } elseif ($archiveReference.StartsWith("/")) {
        ([Uri]::new($baseUri.GetLeftPart([UriPartial]::Authority) + $archiveReference)).AbsoluteUri
    } elseif ($archiveReference.StartsWith("databases/", [StringComparison]::OrdinalIgnoreCase)) {
        ([Uri]::new($baseUri.GetLeftPart([UriPartial]::Authority) + "/" + $archiveReference)).AbsoluteUri
    } else {
        ([Uri]::new($baseUri, $archiveReference)).AbsoluteUri
    }

    $dbDir = Join-Path $DataDir "grype"
    New-Directory $dbDir
    $latestPath = Join-Path $dbDir "latest.json"
    Write-Utf8NoBom -Path $latestPath -Content ($metadata | ConvertTo-Json -Depth 14)

    $dbName = Split-Path -Leaf (([Uri]$dbUrl).AbsolutePath)
    $dbPath = Join-Path $dbDir $dbName
    Download-File -Uri $dbUrl -Destination $dbPath -ExpectedSha256 $expected | Out-Null

    $builtCandidates = @()
    if ($metadata.PSObject.Properties.Name -contains "built") { $builtCandidates += $metadata.built }
    if ($archiveNode.PSObject.Properties.Name -contains "built") { $builtCandidates += $archiveNode.built }
    if (($archiveNode.PSObject.Properties.Name -contains "database") -and $archiveNode.database -and ($archiveNode.database.PSObject.Properties.Name -contains "built")) {
        $builtCandidates += $archiveNode.database.built
    }

    $built = $null
    foreach ($candidate in $builtCandidates) {
        if ($candidate) { $built = [string]$candidate; break }
    }

    $schemaVersion = if ($metadata.PSObject.Properties.Name -contains "schemaVersion") {
        [string]$metadata.schemaVersion
    } else {
        "v$GrypeDatabaseSchema"
    }

    $installTemplate = @'
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ARCHIVE="$ROOT/__DB_NAME__"
CACHE="$ROOT/cache"
if ! command -v grype >/dev/null 2>&1; then
  echo "grype is not on PATH; run 'source ./activate.sh' first." >&2
  exit 1
fi
mkdir -p "$CACHE"
export GRYPE_DB_CACHE_DIR="$CACHE"
export GRYPE_DB_AUTO_UPDATE=false
grype db import "$ARCHIVE"
grype db status
'@
    $installScript = $installTemplate.Replace("__DB_NAME__", $dbName)
    Write-Utf8NoBom -Path (Join-Path $dbDir "install-grype-db.sh") -Content $installScript

    $runScript = @'
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export GRYPE_DB_CACHE_DIR="$ROOT/cache"
export GRYPE_DB_AUTO_UPDATE=false
exec grype "$@"
'@
    Write-Utf8NoBom -Path (Join-Path $dbDir "grype-offline.sh") -Content $runScript

    [void]$ManifestEntries.Add([ordered]@{
        name = "grype-database"
        display_name = "Grype vulnerability database snapshot"
        kind = "time-sensitive-data-snapshot"
        distribution_schema = $GrypeDatabaseSchema
        schema_version = $schemaVersion
        built = $built
        source = $metadataUrl
        archive_source = $dbUrl
        archive = Get-RelativePathCompat -BasePath $BundleRoot -Path $dbPath
        archive_sha256 = Get-Sha256 $dbPath
        installer = "data/grype/install-grype-db.sh"
        warning = "Vulnerability data becomes stale. The build timestamp must be considered when interpreting scan results."
    })
    Write-Detail "Grype DB schema $schemaVersion, built $built"
}

function Expand-GzipToString {
    param([Parameter(Mandatory)][string]$Path)
    $fileStream = [IO.File]::OpenRead($Path)
    try {
        $gzip = [IO.Compression.GZipStream]::new($fileStream, [IO.Compression.CompressionMode]::Decompress)
        try {
            $reader = [IO.StreamReader]::new($gzip, [System.Text.UTF8Encoding]::new($false))
            try { return $reader.ReadToEnd() }
            finally { $reader.Dispose() }
        } finally {
            $gzip.Dispose()
        }
    } finally {
        $fileStream.Dispose()
    }
}

function Write-GzipText {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Content
    )
    $parent = Split-Path -Parent $Path
    if ($parent) { New-Directory $parent }
    $fileStream = [IO.File]::Create($Path)
    try {
        $gzip = [IO.Compression.GZipStream]::new($fileStream, [IO.Compression.CompressionLevel]::Optimal)
        try {
            $bytes = ([System.Text.UTF8Encoding]::new($false)).GetBytes($Content)
            $gzip.Write($bytes, 0, $bytes.Length)
        } finally {
            $gzip.Dispose()
        }
    } finally {
        $fileStream.Dispose()
    }
}

function Parse-DebianParagraph {
    param([Parameter(Mandatory)][string]$Paragraph)
    $fields = @{}
    $currentKey = $null
    foreach ($rawLine in ($Paragraph -split "`r?`n")) {
        if ($rawLine -match '^\s' -and $currentKey) {
            $fields[$currentKey] = [string]$fields[$currentKey] + "`n" + $rawLine
            continue
        }
        if ($rawLine -match '^([^:]+):\s?(.*)$') {
            $currentKey = $Matches[1]
            $fields[$currentKey] = $Matches[2]
        }
    }
    return $fields
}

function Add-DebianIndexToCatalog {
    param(
        [Parameter(Mandatory)][string]$PackagesGzPath,
        [Parameter(Mandatory)][string]$RepositoryBaseUrl,
        [Parameter(Mandatory)][hashtable]$Catalog,
        [Parameter(Mandatory)][hashtable]$Providers
    )
    $text = Expand-GzipToString -Path $PackagesGzPath
    $paragraphs = [regex]::Split($text.Trim(), "\r?\n\r?\n")
    foreach ($paragraph in $paragraphs) {
        if ($paragraph -notmatch '(?m)^Package:\s') { continue }
        $fields = Parse-DebianParagraph -Paragraph $paragraph
        if (-not $fields.ContainsKey("Package") -or -not $fields.ContainsKey("Filename")) { continue }
        $name = [string]$fields["Package"]
        $record = [pscustomobject]@{
            Name = $name
            Version = if ($fields.ContainsKey("Version")) { [string]$fields["Version"] } else { "" }
            Architecture = if ($fields.ContainsKey("Architecture")) { [string]$fields["Architecture"] } else { "" }
            Filename = [string]$fields["Filename"]
            Sha256 = if ($fields.ContainsKey("SHA256")) { [string]$fields["SHA256"] } else { $null }
            Size = if ($fields.ContainsKey("Size")) { [string]$fields["Size"] } else { $null }
            Depends = if ($fields.ContainsKey("Depends")) { [string]$fields["Depends"] } else { "" }
            PreDepends = if ($fields.ContainsKey("Pre-Depends")) { [string]$fields["Pre-Depends"] } else { "" }
            Provides = if ($fields.ContainsKey("Provides")) { [string]$fields["Provides"] } else { "" }
            Fields = $fields
            RepositoryBaseUrl = $RepositoryBaseUrl.TrimEnd('/')
        }
        # Indices are loaded base -> updates -> security. Later entries intentionally win.
        $Catalog[$name] = $record

        if ($record.Provides) {
            $providedNames = (($record.Provides -replace '\([^)]*\)', '') -split ',')
            foreach ($provided in $providedNames) {
                $virtualName = ($provided.Trim() -replace ':any$', '')
                if (-not $virtualName) { continue }
                if (-not $Providers.ContainsKey($virtualName)) {
                    $Providers[$virtualName] = [System.Collections.Generic.List[string]]::new()
                }
                if (-not $Providers[$virtualName].Contains($name)) {
                    [void]$Providers[$virtualName].Add($name)
                }
            }
        }
    }
}

function Get-DebianDependencyClauses {
    param([string]$DependencyText)
    if (-not $DependencyText) { return @() }
    $normalized = $DependencyText -replace "`r?`n\s*", " "
    $normalized = $normalized -replace '\([^)]*\)', ''
    $normalized = $normalized -replace '\[[^\]]*\]', ''
    $normalized = $normalized -replace '<[^>]*>', ''
    return @($normalized -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
}

function Resolve-DebianDependencyName {
    param(
        [Parameter(Mandatory)][string]$Clause,
        [Parameter(Mandatory)][hashtable]$Catalog,
        [Parameter(Mandatory)][hashtable]$Providers
    )
    foreach ($alternative in ($Clause -split '\|')) {
        $candidate = $alternative.Trim()
        $candidate = $candidate -replace ':any$', ''
        $candidate = $candidate -replace ':native$', ''
        $candidate = ($candidate -split '\s+')[0]
        if (-not $candidate) { continue }
        if ($Catalog.ContainsKey($candidate)) { return $candidate }
        if ($Providers.ContainsKey($candidate) -and $Providers[$candidate].Count -gt 0) {
            return $Providers[$candidate][0]
        }
    }
    return $null
}


function Get-DebianIndexSha256FromInRelease {
    param(
        [Parameter(Mandatory)][string]$InReleaseText,
        [Parameter(Mandatory)][string]$RelativePath
    )
    $inSha256 = $false
    foreach ($line in ($InReleaseText -split "`r?`n")) {
        if ($line -eq "SHA256:") {
            $inSha256 = $true
            continue
        }
        if ($inSha256 -and $line -match '^\s*([0-9a-fA-F]{64})\s+\d+\s+(.+?)\s*$') {
            if ($Matches[2] -eq $RelativePath) {
                return $Matches[1].ToLowerInvariant()
            }
            continue
        }
        if ($inSha256 -and $line -match '^[A-Za-z][A-Za-z0-9-]*:') {
            break
        }
    }
    throw "Could not find SHA-256 for '$RelativePath' in Debian InRelease metadata."
}

function Add-DebianOfflineRepository {
    Write-Stage "Building an offline Debian 13 repository for debugger utilities"
    $indexDir = Join-Path $MetadataDir "debian-indexes"
    New-Directory $indexDir

    $sources = @(
        [pscustomobject]@{
            Name = "debian-main"
            InReleaseUrl = "https://deb.debian.org/debian/dists/$DebianSuite/InRelease"
            IndexRelativePath = "main/binary-$DebianArchitecture/Packages.gz"
            IndexUrl = "https://deb.debian.org/debian/dists/$DebianSuite/main/binary-$DebianArchitecture/Packages.gz"
            BaseUrl = "https://deb.debian.org/debian"
        },
        [pscustomobject]@{
            Name = "debian-updates"
            InReleaseUrl = "https://deb.debian.org/debian/dists/$DebianSuite-updates/InRelease"
            IndexRelativePath = "main/binary-$DebianArchitecture/Packages.gz"
            IndexUrl = "https://deb.debian.org/debian/dists/$DebianSuite-updates/main/binary-$DebianArchitecture/Packages.gz"
            BaseUrl = "https://deb.debian.org/debian"
        },
        [pscustomobject]@{
            Name = "debian-security"
            InReleaseUrl = "https://security.debian.org/debian-security/dists/$DebianSuite-security/InRelease"
            IndexRelativePath = "main/binary-$DebianArchitecture/Packages.gz"
            IndexUrl = "https://security.debian.org/debian-security/dists/$DebianSuite-security/main/binary-$DebianArchitecture/Packages.gz"
            BaseUrl = "https://security.debian.org/debian-security"
        }
    )

    $catalog = @{}
    $providers = @{}
    $sourceRecords = @()
    foreach ($source in $sources) {
        $inReleasePath = Join-Path $indexDir "$($source.Name)-InRelease"
        Download-File -Uri $source.InReleaseUrl -Destination $inReleasePath | Out-Null
        $inReleaseText = [IO.File]::ReadAllText($inReleasePath)
        $expectedIndexSha256 = Get-DebianIndexSha256FromInRelease -InReleaseText $inReleaseText -RelativePath $source.IndexRelativePath

        $indexPath = Join-Path $indexDir "$($source.Name)-Packages.gz"
        Download-File -Uri $source.IndexUrl -Destination $indexPath -ExpectedSha256 $expectedIndexSha256 | Out-Null
        Add-DebianIndexToCatalog -PackagesGzPath $indexPath -RepositoryBaseUrl $source.BaseUrl -Catalog $catalog -Providers $providers
        $sourceRecords += [ordered]@{
            name = $source.Name
            inrelease_url = $source.InReleaseUrl
            inrelease_artifact = Get-RelativePathCompat -BasePath $BundleRoot -Path $inReleasePath
            inrelease_sha256 = Get-Sha256 $inReleasePath
            index_relative_path = $source.IndexRelativePath
            index_url = $source.IndexUrl
            index_artifact = Get-RelativePathCompat -BasePath $BundleRoot -Path $indexPath
            index_sha256 = Get-Sha256 $indexPath
            index_sha256_from_inrelease = $expectedIndexSha256
            repository_base_url = $source.BaseUrl
            signature_verification = "not-performed; InRelease and index were acquired over HTTPS, and the index digest was checked against InRelease"
        }
        Write-Detail "Indexed $($source.Name)"
    }

    $rootPackages = @("strace", "lsof", "gdb", "gdbserver", "valgrind")
    $selected = @{}
    $queue = [System.Collections.Generic.Queue[string]]::new()
    foreach ($rootPackage in $rootPackages) {
        if (-not $catalog.ContainsKey($rootPackage)) {
            throw "Required Debian package '$rootPackage' was not found in the $DebianSuite indexes."
        }
        $queue.Enqueue($rootPackage)
    }

    while ($queue.Count -gt 0) {
        $name = $queue.Dequeue()
        if ($selected.ContainsKey($name)) { continue }
        if (-not $catalog.ContainsKey($name)) {
            throw "Dependency '$name' is not available in the downloaded Debian indexes."
        }
        $record = $catalog[$name]
        $selected[$name] = $record
        $dependencyText = @($record.PreDepends, $record.Depends) -join ", "
        foreach ($clause in (Get-DebianDependencyClauses -DependencyText $dependencyText)) {
            $dependencyName = Resolve-DebianDependencyName -Clause $clause -Catalog $catalog -Providers $providers
            if (-not $dependencyName) {
                throw "Could not resolve Debian dependency clause '$clause' required by '$name'."
            }
            if (-not $selected.ContainsKey($dependencyName)) {
                $queue.Enqueue($dependencyName)
            }
        }
    }

    New-Directory $DebianRepoDir
    $packageRecords = @()
    $packageParagraphs = [System.Collections.Generic.List[string]]::new()
    $orderedNames = @($selected.Keys | Sort-Object)
    foreach ($name in $orderedNames) {
        $record = $selected[$name]
        $debName = Split-Path -Leaf $record.Filename
        $debPath = Join-Path $DebianRepoDir $debName
        $url = "$($record.RepositoryBaseUrl)/$($record.Filename.TrimStart('/'))"
        Download-File -Uri $url -Destination $debPath -ExpectedSha256 $record.Sha256 | Out-Null

        $fields = $record.Fields
        $fieldOrder = @(
            "Package", "Source", "Version", "Architecture", "Maintainer", "Installed-Size",
            "Pre-Depends", "Depends", "Recommends", "Suggests", "Conflicts", "Breaks", "Replaces",
            "Provides", "Multi-Arch", "Homepage", "Section", "Priority", "Description"
        )
        $lines = [System.Collections.Generic.List[string]]::new()
        foreach ($fieldName in $fieldOrder) {
            if ($fields.ContainsKey($fieldName) -and [string]$fields[$fieldName]) {
                $value = [string]$fields[$fieldName]
                $valueLines = $value -split "`n"
                [void]$lines.Add("$fieldName`: $($valueLines[0])")
                if ($valueLines.Count -gt 1) {
                    for ($i = 1; $i -lt $valueLines.Count; $i++) {
                        $continuation = $valueLines[$i]
                        if ($continuation -notmatch '^\s') { $continuation = " $continuation" }
                        [void]$lines.Add($continuation)
                    }
                }
            }
        }
        [void]$lines.Add("Filename: ./$debName")
        [void]$lines.Add("Size: $((Get-Item -LiteralPath $debPath).Length)")
        [void]$lines.Add("SHA256: $(Get-Sha256 $debPath)")
        [void]$packageParagraphs.Add(($lines -join "`n"))

        $packageRecords += [ordered]@{
            package = $name
            version = $record.Version
            architecture = $record.Architecture
            file = $debName
            sha256 = Get-Sha256 $debPath
            bytes = (Get-Item -LiteralPath $debPath).Length
            source = $url
        }
    }

    $packagesText = ($packageParagraphs -join "`n`n") + "`n"
    Write-Utf8NoBom -Path (Join-Path $DebianRepoDir "Packages") -Content $packagesText
    Write-GzipText -Path (Join-Path $DebianRepoDir "Packages.gz") -Content $packagesText

    $installScript = @'
#!/usr/bin/env bash
set -euo pipefail
if [[ "${EUID:-$(id -u)}" -ne 0 ]]; then
  echo "Run this installer as root." >&2
  exit 1
fi
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LIST="$(mktemp)"
trap 'rm -f "$LIST"' EXIT
# sources.list fields are space-delimited; percent-encode ordinary spaces in the file URI.
URI_ROOT="${ROOT// /%20}"
printf 'deb [trusted=yes] file:%s ./\n' "$URI_ROOT" > "$LIST"
export DEBIAN_FRONTEND=noninteractive
apt-get \
  -o Dir::Etc::sourcelist="$LIST" \
  -o Dir::Etc::sourceparts="-" \
  -o APT::Get::List-Cleanup="0" \
  -o Acquire::Languages="none" \
  update
apt-get \
  -o Dir::Etc::sourcelist="$LIST" \
  -o Dir::Etc::sourceparts="-" \
  -o APT::Get::List-Cleanup="0" \
  -o Acquire::Languages="none" \
  install -y --no-install-recommends strace lsof gdb gdbserver valgrind
'@
    Write-Utf8NoBom -Path (Join-Path $DebianRepoDir "install-debian-tools.sh") -Content $installScript

    $repoMetadata = [ordered]@{
        suite = $DebianSuite
        architecture = $DebianArchitecture
        roots = $rootPackages
        package_count = $packageRecords.Count
        sources = $sourceRecords
        packages = $packageRecords
    }
    Write-Utf8NoBom -Path (Join-Path $MetadataDir "debian-offline-repository.json") -Content ($repoMetadata | ConvertTo-Json -Depth 10)

    [void]$ManifestEntries.Add([ordered]@{
        name = "debian-debugger-tools"
        display_name = "Debian debugger and process-inspection tools"
        kind = "offline-flat-apt-repository"
        version = $DebianSuite
        architecture = $DebianArchitecture
        root_packages = $rootPackages
        package_count = $packageRecords.Count
        repository = "debian-packages"
        installer = "debian-packages/install-debian-tools.sh"
        metadata = "metadata/debian-offline-repository.json"
    })

    Write-Detail "Downloaded $($packageRecords.Count) Debian packages in the dependency closure."
}

function Write-BundleSupportFiles {
    Write-Stage "Writing bundle activation, preparation, and documentation files"

    $activateScript = @'
#!/usr/bin/env bash
# Source this file: source ./activate.sh
_BBK_TOOLKIT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export BBK_TOOLKIT_ROOT="$_BBK_TOOLKIT_ROOT"
export PATH="$BBK_TOOLKIT_ROOT/bin:$PATH"
if [[ -d "$BBK_TOOLKIT_ROOT/rust/toolchain/bin" ]]; then
  export PATH="$BBK_TOOLKIT_ROOT/rust/toolchain/bin:$PATH"
fi
if [[ -d "$BBK_TOOLKIT_ROOT/data/grype/cache" ]]; then
  export GRYPE_DB_CACHE_DIR="$BBK_TOOLKIT_ROOT/data/grype/cache"
  export GRYPE_DB_AUTO_UPDATE=false
fi
unset _BBK_TOOLKIT_ROOT
'@
    Write-Utf8NoBom -Path (Join-Path $BundleRoot "activate.sh") -Content $activateScript

    $prepareScript = @'
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
chmod -R a+rX "$ROOT"
find "$ROOT/bin" -maxdepth 1 -type f -exec chmod +x {} +
find "$ROOT" -type f -name '*.sh' -exec chmod +x {} +
cd "$ROOT"
sha256sum -c SHA256SUMS
cat <<EOF

Bundle prepared successfully.
Activate portable tools with:
  source "$ROOT/activate.sh"
EOF

echo
if [[ -f "$ROOT/rust/install-rust-toolchain.sh" ]]; then
  echo 'Optional Rust installation:'
  printf '  bash %q\n' "$ROOT/rust/install-rust-toolchain.sh"
fi
if [[ -f "$ROOT/data/grype/install-grype-db.sh" ]]; then
  echo 'Optional Grype database import:'
  printf '  bash %q\n' "$ROOT/data/grype/install-grype-db.sh"
fi
if [[ -f "$ROOT/debian-packages/install-debian-tools.sh" ]]; then
  echo 'Optional Debian debugger installation:'
  printf '  sudo bash %q\n' "$ROOT/debian-packages/install-debian-tools.sh"
fi
'@
    Write-Utf8NoBom -Path (Join-Path $BundleRoot "prepare.sh") -Content $prepareScript

    $verifyScript = @'
#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
sha256sum -c SHA256SUMS
'@
    Write-Utf8NoBom -Path (Join-Path $ScriptsDir "verify-bundle.sh") -Content $verifyScript

    $toolNames = @($ManifestEntries | ForEach-Object {
        if ($_.Contains("version")) { "- **$($_.display_name)** — $($_.version)" }
        else { "- **$($_.display_name)**" }
    }) -join "`n"

    $readmeTemplate = @'
# Blueprint / BBK one-shot implementation toolkit

This archive contains Linux x86_64 tools for a Debian 13-style ephemeral execution environment.
It was assembled on **__GENERATED_AT__** by generator version **__SCRIPT_VERSION__**.

Target: **__TARGET_DESCRIPTION__**

## Included material

__TOOL_LIST__

## First use in Linux

```bash
unzip blueprint-one-shot-toolkit-linux-x86_64.zip
cd blueprint-one-shot-toolkit-linux-x86_64
bash prepare.sh
source ./activate.sh
```

The portable binaries in `bin/` are usable after activation. The archive deliberately does not
modify the host automatically.

### Optional Rust installation

```bash
bash rust/install-rust-toolchain.sh
export PATH="$PWD/rust/toolchain/bin:$PATH"
```

### Optional Grype database import

```bash
source ./activate.sh
bash data/grype/install-grype-db.sh
```

The included vulnerability database is time-sensitive. Its exact build timestamp and digest are
recorded in `manifest.json`; stale data must be reported honestly.

### Optional Debian debugger installation

```bash
sudo bash debian-packages/install-debian-tools.sh
```

This uses only the flat `file:` repository contained in the bundle. It installs `strace`, `lsof`,
`gdb`, `gdbserver`, and `valgrind` plus the dependency closure captured for Debian 13.

## Integrity and provenance

- `SHA256SUMS` covers every generated file except itself.
- `manifest.json` records versions, release sources, asset hashes, binary hashes, and data dates.
- `metadata/` contains per-tool release and dependency records.
- `downloads/` retains the original release artifacts so upstream archive checksums remain auditable.
- `licences/` contains licence or public-domain statements where available.

Run `bash scripts/verify-bundle.sh` at any time to verify the extracted bundle.

## Deliberate exclusions

This is a generic execution-tool bundle. It does not contain project-specific Cargo crates, Python
wheels, npm packages, Go modules, generated SDKs, private dependencies, credentials, or licence
keys. Those must be supplied with the particular project or captured from its lockfiles. Git and the
ordinary Debian build/Unix utilities are assumed to be present in the execution environment.

## Authority note

The presence of a tool does not authorize network access, publication, deployment, credential use,
remote mutation, destructive operations, or system-wide installation. Those effects remain subject
to the assignment's explicit authority envelope.
'@
    $readme = $readmeTemplate.Replace("__GENERATED_AT__", (Get-Date).ToUniversalTime().ToString("o"))
    $readme = $readme.Replace("__SCRIPT_VERSION__", $ScriptVersion)
    $readme = $readme.Replace("__TARGET_DESCRIPTION__", $TargetDescription)
    $readme = $readme.Replace("__TOOL_LIST__", $toolNames)
    Write-Utf8NoBom -Path (Join-Path $BundleRoot "README.md") -Content $readme
}

function Write-ManifestAndChecksums {
    Write-Stage "Writing manifest and bundle checksums"
    $manifest = [ordered]@{
        schema_version = 1
        bundle_name = $BundleName
        generated_at = (Get-Date).ToUniversalTime().ToString("o")
        generator = [ordered]@{
            name = "Download-BlueprintOneShotToolkit.ps1"
            version = $ScriptVersion
            host = [ordered]@{
                powershell_version = $PSVersionTable.PSVersion.ToString()
                edition = if ($PSVersionTable.PSObject.Properties.Name -contains "PSEdition") { [string]$PSVersionTable.PSEdition } else { "Desktop" }
                platform = if ($PSVersionTable.PSObject.Properties.Name -contains "Platform") { [string]$PSVersionTable.Platform } else { "Win32NT" }
                os = if ($PSVersionTable.PSObject.Properties.Name -contains "OS") { [string]$PSVersionTable.OS } else { [Environment]::OSVersion.VersionString }
            }
        }
        invocation = [ordered]@{
            include_extended_tools = $IncludeExtendedTools
            skip_rust = [bool]$SkipRust
            skip_grype_database = [bool]$SkipGrypeDatabase
            skip_debian_packages = [bool]$SkipDebianPackages
            require_upstream_checksums = [bool]$RequireUpstreamChecksums
            create_library_archive_set = $CreateLibraryArchiveSet
            library_archive_maximum_mb = $LibraryArchiveMaximumMB
        }
        target = [ordered]@{
            os = "linux"
            architecture = "x86_64"
            distribution = "Debian 13 / trixie compatible"
            libc = "glibc-compatible; static or musl selected where available"
        }
        tools = @($ManifestEntries)
        warnings = @($Warnings)
    }
    $manifestPath = Join-Path $BundleRoot "manifest.json"
    Write-Utf8NoBom -Path $manifestPath -Content ($manifest | ConvertTo-Json -Depth 14)

    $checksumLines = [System.Collections.Generic.List[string]]::new()
    $files = @(Get-ChildItem -LiteralPath $BundleRoot -Recurse -File |
        Where-Object { $_.Name -ne "SHA256SUMS" } |
        Sort-Object FullName)
    foreach ($file in $files) {
        $relative = (Get-RelativePathCompat -BasePath $BundleRoot -Path $file.FullName).Replace('\', '/')
        [void]$checksumLines.Add("$(Get-Sha256 $file.FullName)  $relative")
    }
    Write-Utf8NoBom -Path (Join-Path $BundleRoot "SHA256SUMS") -Content (($checksumLines -join "`n") + "`n")
}

function New-BundleArchive {
    Write-Stage "Creating final ZIP archive"
    $archiveParent = Split-Path -Parent $ArchivePath
    if ($archiveParent) { New-Directory $archiveParent }
    if (Test-Path -LiteralPath $ArchivePath) { Remove-Item -LiteralPath $ArchivePath -Force }

    Compress-Archive -LiteralPath $BundleRoot -DestinationPath $ArchivePath -CompressionLevel Optimal -Force
    $archiveHash = Get-Sha256 $ArchivePath
    Write-Utf8NoBom -Path "$ArchivePath.sha256" -Content "$archiveHash  $(Split-Path -Leaf $ArchivePath)`n"

    Write-Host "`nBundle complete." -ForegroundColor Green
    Write-Host "Archive : $ArchivePath"
    Write-Host "SHA-256: $archiveHash"
    Write-Host "Size    : $([Math]::Round((Get-Item -LiteralPath $ArchivePath).Length / 1MB, 2)) MiB"
}

function New-ZipFromBundleFiles {
    param(
        [Parameter(Mandatory)][string]$DestinationPath,
        [Parameter(Mandatory)][object[]]$Files
    )

    Add-Type -AssemblyName System.IO.Compression -ErrorAction SilentlyContinue
    Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue

    $parent = Split-Path -Parent $DestinationPath
    if ($parent) { New-Directory $parent }
    if (Test-Path -LiteralPath $DestinationPath) { Remove-Item -LiteralPath $DestinationPath -Force }

    $fileStream = [IO.File]::Open($DestinationPath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try {
        $zip = [IO.Compression.ZipArchive]::new($fileStream, [IO.Compression.ZipArchiveMode]::Create, $false)
        try {
            foreach ($file in ($Files | Sort-Object FullName)) {
                $relative = (Get-RelativePathCompat -BasePath $BundleRoot -Path $file.FullName).Replace('\', '/')
                $entryName = "$BundleName/$relative"
                $entry = $zip.CreateEntry($entryName, [IO.Compression.CompressionLevel]::Optimal)
                try { $entry.LastWriteTime = [DateTimeOffset]$file.LastWriteTimeUtc } catch { }

                $inputStream = [IO.File]::OpenRead($file.FullName)
                try {
                    $entryStream = $entry.Open()
                    try { $inputStream.CopyTo($entryStream) }
                    finally { $entryStream.Dispose() }
                } finally {
                    $inputStream.Dispose()
                }
            }
        } finally {
            $zip.Dispose()
        }
    } finally {
        $fileStream.Dispose()
    }
}

function Split-FilesByTargetSize {
    param(
        [Parameter(Mandatory)][object[]]$Files,
        [Parameter(Mandatory)][long]$TargetBytes,
        [Parameter(Mandatory)][long]$MaximumBytes
    )

    $bins = [System.Collections.Generic.List[object]]::new()
    foreach ($file in ($Files | Sort-Object @{ Expression = { $_.Length }; Descending = $true }, FullName)) {
        if ($file.Length -gt $MaximumBytes) {
            throw "A single bundle file exceeds the file-library archive limit: $($file.FullName) ($([Math]::Round($file.Length / 1MB, 2)) MiB)"
        }

        $selectedBin = $null
        foreach ($bin in $bins) {
            if (($bin.Bytes + $file.Length) -le $TargetBytes) {
                $selectedBin = $bin
                break
            }
        }
        if (-not $selectedBin) {
            $selectedBin = [pscustomobject]@{
                Bytes = [long]0
                Files = [System.Collections.Generic.List[object]]::new()
            }
            [void]$bins.Add($selectedBin)
        }
        [void]$selectedBin.Files.Add($file)
        $selectedBin.Bytes = [long]($selectedBin.Bytes + $file.Length)
    }
    return @($bins)
}

function New-LibraryArchiveSet {
    Write-Stage "Creating size-bounded file-library ZIP set"

    if (Test-Path -LiteralPath $LibraryArchiveDirectory) {
        Remove-Item -LiteralPath $LibraryArchiveDirectory -Recurse -Force
    }
    New-Directory $LibraryArchiveDirectory

    $categories = [ordered]@{
        core = [System.Collections.Generic.List[object]]::new()
        rust = [System.Collections.Generic.List[object]]::new()
        grype = [System.Collections.Generic.List[object]]::new()
        debian = [System.Collections.Generic.List[object]]::new()
    }

    foreach ($file in (Get-ChildItem -LiteralPath $BundleRoot -Recurse -File | Sort-Object FullName)) {
        $relative = (Get-RelativePathCompat -BasePath $BundleRoot -Path $file.FullName).Replace('\', '/')
        $category = if ($relative -match '^(rust/|metadata/rust/)') {
            "rust"
        } elseif ($relative -match '^data/grype/') {
            "grype"
        } elseif ($relative -match '^(debian-packages/|metadata/debian-indexes/)' -or $relative -eq 'metadata/debian-offline-repository.json') {
            "debian"
        } else {
            "core"
        }
        [void]$categories[$category].Add($file)
    }

    $maximumBytes = [long]$LibraryArchiveMaximumMB * 1MB
    # Most payloads are already compressed. Use a conservative packing target to leave room
    # for ZIP metadata and any unexpectedly incompressible content.
    $targetBytes = [long][Math]::Floor($maximumBytes * 0.90)
    $partRecords = @()

    foreach ($category in $categories.Keys) {
        $categoryFiles = @($categories[$category])
        if ($categoryFiles.Count -eq 0) { continue }
        $bins = @(Split-FilesByTargetSize -Files $categoryFiles -TargetBytes $targetBytes -MaximumBytes $maximumBytes)
        $partIndex = 0
        foreach ($bin in $bins) {
            $partIndex++
            $archiveName = "{0}-{1}-{2:d2}.zip" -f $BundleName, $category, $partIndex
            $partPath = Join-Path $LibraryArchiveDirectory $archiveName
            New-ZipFromBundleFiles -DestinationPath $partPath -Files @($bin.Files | ForEach-Object { $_ })
            $actualBytes = (Get-Item -LiteralPath $partPath).Length
            if ($actualBytes -gt $maximumBytes) {
                throw "Generated library archive '$archiveName' is $([Math]::Round($actualBytes / 1MB, 2)) MiB, above the configured $LibraryArchiveMaximumMB MiB limit. Lower -LibraryArchiveMaximumMB or omit a large optional payload."
            }
            $partRecords += [ordered]@{
                file = $archiveName
                category = $category
                part = $partIndex
                file_count = $bin.Files.Count
                uncompressed_bytes = [long]$bin.Bytes
                archive_bytes = $actualBytes
                sha256 = Get-Sha256 $partPath
            }
            Write-Detail "$archiveName — $([Math]::Round($actualBytes / 1MB, 2)) MiB"
        }
    }

    $setManifest = [ordered]@{
        schema_version = 1
        bundle_name = $BundleName
        generated_at = (Get-Date).ToUniversalTime().ToString("o")
        maximum_archive_mb = $LibraryArchiveMaximumMB
        reconstruction = "Extract every ZIP into the same parent directory. Each archive contains paths beneath the same $BundleName root."
        parts = $partRecords
    }
    Write-Utf8NoBom -Path (Join-Path $LibraryArchiveDirectory "library-set-manifest.json") -Content ($setManifest | ConvertTo-Json -Depth 8)

    $checksumLines = @($partRecords | ForEach-Object { "$($_.sha256)  $($_.file)" })
    Write-Utf8NoBom -Path (Join-Path $LibraryArchiveDirectory "SHA256SUMS") -Content (($checksumLines -join "`n") + "`n")

    $setReadme = @'
# Blueprint / BBK toolkit file-library set

The complete toolkit was divided into valid ZIP archives to keep every uploaded file below the
configured per-file limit. These are not byte fragments: every member is an ordinary ZIP file.

To reconstruct the toolkit, place all ZIP files from this directory together and extract every one
into the same parent directory. They all write into the same
`blueprint-one-shot-toolkit-linux-x86_64/` root.

PowerShell:

```powershell
Get-ChildItem . -Filter '*.zip' | Sort-Object Name | ForEach-Object {
    Expand-Archive -LiteralPath $_.FullName -DestinationPath . -Force
}
```

Linux:

```bash
for archive in ./*.zip; do unzip -o "$archive"; done
cd blueprint-one-shot-toolkit-linux-x86_64
bash prepare.sh
source ./activate.sh
```

`library-set-manifest.json` and `SHA256SUMS` describe and authenticate the set members. The
reconstructed bundle's own `SHA256SUMS` then verifies every extracted payload file.
'@
    Write-Utf8NoBom -Path (Join-Path $LibraryArchiveDirectory "README.md") -Content $setReadme

    Write-Host "Library set: $LibraryArchiveDirectory"
}

$toolSpecs = @(
    [pscustomobject]@{
        Name = "beads"
        DisplayName = "Beads (bd)"
        Repository = "gastownhall/beads"
        BinaryNames = @("bd")
        AssetPatterns = @(
            '(?i)^beads_.*_linux_amd64\.tar\.gz$',
            '(?i)^(beads|bd).*linux.*(amd64|x86_64).*\.(tar\.gz|tgz|zip)$',
            '(?i).*linux.*(amd64|x86_64).*\.(tar\.gz|tgz|zip)$'
        )
        ExcludePatterns = @()
    },
    [pscustomobject]@{
        Name = "dolt"
        DisplayName = "Dolt CLI"
        Repository = "dolthub/dolt"
        BinaryNames = @("dolt")
        AssetPatterns = @(
            '(?i)^dolt-linux-amd64\.tar\.gz$',
            '(?i).*linux.*amd64.*\.(tar\.gz|tgz)$'
        )
        ExcludePatterns = @()
    },
    [pscustomobject]@{
        Name = "jujutsu"
        DisplayName = "Jujutsu (jj)"
        Repository = "jj-vcs/jj"
        BinaryNames = @("jj")
        AssetPatterns = @(
            '(?i)^jj-v?.*-x86_64-unknown-linux-musl\.tar\.gz$',
            '(?i)^jj-v?.*-x86_64-unknown-linux-gnu\.tar\.gz$',
            '(?i).*x86_64.*linux.*\.(tar\.gz|tgz|zip)$'
        )
        ExcludePatterns = @()
    },
    [pscustomobject]@{
        Name = "yq"
        DisplayName = "yq"
        Repository = "mikefarah/yq"
        BinaryNames = @("yq")
        AssetPatterns = @('(?i)^yq_linux_amd64$')
        ExcludePatterns = @()
    },
    [pscustomobject]@{
        Name = "ast-grep"
        DisplayName = "ast-grep"
        Repository = "ast-grep/ast-grep"
        BinaryNames = @("ast-grep")
        AssetPatterns = @(
            '(?i)^(app|ast-grep)-x86_64-unknown-linux-musl\.zip$',
            '(?i)^(app|ast-grep)-x86_64-unknown-linux-gnu\.zip$',
            '(?i).*x86_64.*linux.*\.(zip|tar\.gz)$'
        )
        ExcludePatterns = @()
    },
    [pscustomobject]@{
        Name = "difftastic"
        DisplayName = "Difftastic (difft)"
        Repository = "Wilfred/difftastic"
        BinaryNames = @("difft")
        AssetPatterns = @(
            '(?i)^difft-x86_64-unknown-linux-musl\.tar\.gz$',
            '(?i)^difft-x86_64-unknown-linux-gnu\.tar\.gz$',
            '(?i).*x86_64.*linux.*\.(tar\.gz|tgz)$'
        )
        ExcludePatterns = @()
    },
    [pscustomobject]@{
        Name = "gitleaks"
        DisplayName = "Gitleaks"
        Repository = "gitleaks/gitleaks"
        BinaryNames = @("gitleaks")
        AssetPatterns = @(
            '(?i)^gitleaks_.*_linux_x64\.tar\.gz$',
            '(?i)^gitleaks_.*_linux_amd64\.tar\.gz$',
            '(?i).*linux.*(x64|amd64).*\.tar\.gz$'
        )
        ExcludePatterns = @()
    },
    [pscustomobject]@{
        Name = "syft"
        DisplayName = "Syft"
        Repository = "anchore/syft"
        BinaryNames = @("syft")
        AssetPatterns = @(
            '(?i)^syft_.*_linux_amd64\.tar\.gz$',
            '(?i).*linux.*amd64.*\.tar\.gz$'
        )
        ExcludePatterns = @()
    },
    [pscustomobject]@{
        Name = "grype"
        DisplayName = "Grype"
        Repository = "anchore/grype"
        BinaryNames = @("grype")
        AssetPatterns = @(
            '(?i)^grype_.*_linux_amd64\.tar\.gz$',
            '(?i).*linux.*amd64.*\.tar\.gz$'
        )
        ExcludePatterns = @()
    },
    [pscustomobject]@{
        Name = "hyperfine"
        DisplayName = "Hyperfine"
        Repository = "sharkdp/hyperfine"
        BinaryNames = @("hyperfine")
        AssetPatterns = @(
            '(?i)^hyperfine-v?.*-x86_64-unknown-linux-musl\.tar\.gz$',
            '(?i)^hyperfine-v?.*-x86_64-unknown-linux-gnu\.tar\.gz$',
            '(?i).*x86_64.*linux.*\.tar\.gz$'
        )
        ExcludePatterns = @()
    },
    [pscustomobject]@{
        Name = "shellcheck"
        DisplayName = "ShellCheck"
        Repository = "koalaman/shellcheck"
        BinaryNames = @("shellcheck")
        AssetPatterns = @(
            '(?i)^shellcheck-v?.*\.linux\.x86_64\.tar\.xz$',
            '(?i).*linux.*x86_64.*\.(tar\.xz|tar\.gz)$'
        )
        ExcludePatterns = @()
    },
    [pscustomobject]@{
        Name = "shfmt"
        DisplayName = "shfmt"
        Repository = "mvdan/sh"
        BinaryNames = @("shfmt")
        AssetPatterns = @('(?i)^shfmt_v?.*_linux_amd64$')
        ExcludePatterns = @()
    },
    [pscustomobject]@{
        Name = "typos"
        DisplayName = "typos"
        Repository = "crate-ci/typos"
        BinaryNames = @("typos")
        AssetPatterns = @(
            '(?i)^typos-v?.*-x86_64-unknown-linux-musl\.tar\.gz$',
            '(?i)^typos-v?.*-x86_64-unknown-linux-gnu\.tar\.gz$',
            '(?i).*x86_64.*linux.*\.tar\.gz$'
        )
        ExcludePatterns = @()
    },
    [pscustomobject]@{
        Name = "lychee"
        DisplayName = "Lychee"
        Repository = "lycheeverse/lychee"
        BinaryNames = @("lychee")
        AssetPatterns = @(
            '(?i)^lychee-x86_64-unknown-linux-musl\.tar\.gz$',
            '(?i)^lychee-x86_64-unknown-linux-gnu\.tar\.gz$',
            '(?i).*x86_64.*linux.*\.tar\.gz$'
        )
        ExcludePatterns = @()
    },
    [pscustomobject]@{
        Name = "duckdb"
        DisplayName = "DuckDB CLI"
        Repository = "duckdb/duckdb"
        BinaryNames = @("duckdb")
        AssetPatterns = @(
            '(?i)^duckdb_cli-linux-amd64\.zip$',
            '(?i)^duckdb_cli-linux-amd64.*\.zip$',
            '(?i).*linux.*amd64.*\.zip$'
        )
        ExcludePatterns = @()
    }

)

if ($IncludeExtendedTools) {
    $toolSpecs += @(
        [pscustomobject]@{
            Name = "actionlint"
            DisplayName = "actionlint"
            Repository = "rhysd/actionlint"
            BinaryNames = @("actionlint")
            AssetPatterns = @(
                '(?i)^actionlint_.*_linux_x86_64\.tar\.gz$',
                '(?i).*linux.*x86_64.*\.(tar\.gz|tgz)$'
            )
            ExcludePatterns = @()
        },
        [pscustomobject]@{
            Name = "hadolint"
            DisplayName = "Hadolint"
            Repository = "hadolint/hadolint"
            BinaryNames = @("hadolint")
            AssetPatterns = @(
                '(?i)^hadolint-Linux-x86_64$',
                '(?i)^hadolint.*linux.*x86_64$'
            )
            ExcludePatterns = @()
        },
        [pscustomobject]@{
            Name = "just"
            DisplayName = "just"
            Repository = "casey/just"
            BinaryNames = @("just")
            AssetPatterns = @(
                '(?i)^just-.*-x86_64-unknown-linux-musl\.tar\.gz$',
                '(?i)^just-.*-x86_64-unknown-linux-gnu\.tar\.gz$',
                '(?i).*x86_64.*linux.*\.(tar\.gz|tgz)$'
            )
            ExcludePatterns = @()
        },
        [pscustomobject]@{
            Name = "task"
            DisplayName = "Task"
            Repository = "go-task/task"
            BinaryNames = @("task")
            AssetPatterns = @(
                '(?i)^task_linux_amd64\.tar\.gz$',
                '(?i).*linux.*amd64.*\.(tar\.gz|tgz)$'
            )
            ExcludePatterns = @()
        }
    )
}

try {
    Write-Stage "Preparing build directories"
    if ($KeepExistingOutput -and (Test-Path -LiteralPath $DownloadsDir)) {
        New-Directory $DownloadCacheDir
        Get-ChildItem -LiteralPath $DownloadsDir -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
            $relativeCachePath = (Get-RelativePathCompat -BasePath $DownloadsDir -Path $_.FullName).Replace('/', [IO.Path]::DirectorySeparatorChar)
            $cachePath = Join-Path $DownloadCacheDir $relativeCachePath
            $cacheParent = Split-Path -Parent $cachePath
            if ($cacheParent) { New-Directory $cacheParent }
            Copy-Item -LiteralPath $_.FullName -Destination $cachePath -Force
        }
    }
    foreach ($generatedPath in @($BundleRoot, $WorkRoot)) {
        if (Test-Path -LiteralPath $generatedPath) {
            Remove-Item -LiteralPath $generatedPath -Recurse -Force
        }
    }
    if (-not $KeepExistingOutput -and (Test-Path -LiteralPath $DownloadCacheDir)) {
        Remove-Item -LiteralPath $DownloadCacheDir -Recurse -Force
    }
    if ($KeepExistingOutput) {
        New-Directory $DownloadCacheDir
    }
    foreach ($dir in @($BundleRoot, $WorkRoot, $PortableBinDir, $DownloadsDir, $LicencesDir, $MetadataDir, $ScriptsDir, $DataDir)) {
        New-Directory $dir
    }

    if ($PSCommandPath) {
        $generatorDir = Join-Path $BundleRoot "generator"
        New-Directory $generatorDir
        Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $generatorDir "Download-BlueprintOneShotToolkit.ps1") -Force
    }

    foreach ($spec in $toolSpecs) {
        Add-GitHubTool -Spec $spec
    }

    Add-SqliteTools

    if (-not $SkipRust) {
        Add-RustToolchain
    } else {
        Add-WarningRecord "Rust toolchain components were omitted by -SkipRust."
    }

    if (-not $SkipGrypeDatabase) {
        Add-GrypeDatabase
    } else {
        Add-WarningRecord "The Grype vulnerability database snapshot was omitted by -SkipGrypeDatabase."
    }

    if (-not $SkipDebianPackages) {
        Add-DebianOfflineRepository
    } else {
        Add-WarningRecord "The Debian debugger package repository was omitted by -SkipDebianPackages."
    }

    Write-BundleSupportFiles
    Write-ManifestAndChecksums
    New-BundleArchive
    if ($CreateLibraryArchiveSet) {
        New-LibraryArchiveSet
    }
} catch {
    Write-Error -ErrorRecord $_ -ErrorAction Continue
    Write-Host "`nThe partial working directory was retained for inspection: $OutputDirectory" -ForegroundColor Yellow
    exit 1
}
