# CODESYS generic skills for Codex

**Version 1.0.0 · 2026-09-08**

23 standalone skills for CODESYS Structured Text authoring, technical review, tests, automation, and operations. Each skill contains its own required references and examples. Install all of them or select individual folders. No language-pack runtime, package manager, repository convention, or extra skill is required.

This revision replaces the supplied 22-skill set with deeper technical guidance and adds `codesys-short-circuit-review`. See [CHANGELOG.md](CHANGELOG.md) for the changes and original-to-new coverage. It includes 18 reference topics, four example groups, and 34 review cases with expected findings and false-positive rules.

## Install

Extract this archive. From the extracted `codesys-generic-skills-1.0.0` directory, run one of the following with Python 3.8 or newer. The installer uses only the Python standard library and does not contact the network or run Codex/CODESYS.

**Windows, user-wide:**

```powershell
py -3 install.py --user
```

**Linux or macOS, user-wide:**

```sh
python3 install.py --user
```

**Only for a repository:**

```powershell
py -3 install.py --repo "C:\work\my-project"
```

```sh
python3 install.py --repo /path/to/my-project
```

Choose user or repository scope rather than installing duplicate names in both. The installer targets `~/.agents/skills` for user-wide use, or `<repo>/.agents/skills` for repository use. These are the current documented local Codex skill locations. [OpenAI skill locations](https://developers.openai.com/codex/build-skills)

Install just selected skills by repeating `--skill`:

```powershell
py -3 install.py --user --skill codesys-short-circuit-review --skill codesys-st-authoring
```

Add `--dry-run` to check selection and existing-name conflicts without creating files. The installer refuses to overwrite or merge any existing same-name skill and reports all conflicts before copying. It preserves unrelated folders. Back up and deliberately remove or move an older same-name folder before installing its replacement; there is no force-overwrite mode.

**Manual installation needs no Python.** Copy any desired folder from `skills/` into the appropriate skills directory, preserving its full contents. For example:

```text
~/.agents/skills/codesys-short-circuit-review/SKILL.md
~/.agents/skills/codesys-short-circuit-review/references/short-circuit.md
~/.agents/skills/codesys-short-circuit-review/assets/guards/...
```

Copy the skill folders themselves, not this bundle's parent folder or its `skills` directory as another nesting level. On Windows, `~` corresponds to the home of the account running Codex, normally `%USERPROFILE%`. In WSL, use the Linux home of the account running Codex there. The local installer has been exercised on Linux; Windows/macOS execution was not available in this delivery.

Codex discovers `SKILL.md` metadata and loads the body and supporting material when needed. Use `/skills` or a `$skill-name` mention in Codex CLI/IDE; restart Codex if a newly copied skill does not appear. [OpenAI skill discovery and invocation](https://developers.openai.com/codex/build-skills)

## Use

Examples of explicit requests:

```text
$codesys-short-circuit-review Review these methods for unsafe dependent
Boolean evaluation. Preserve calls that must execute every scan.

$codesys-st-authoring Implement this FB using the project's existing contracts.
Include bounds, reset, and second-run tests. Do not perform controller actions.

$codesys-scan-cycle-state-review Trace these two tasks and identify shared-state
and command-delivery defects. Distinguish actual calls from queued requests.

$codesys-counit-test-design Add a real multi-invocation test for this interface.

$codesys-testmanager-ci-review Check that this run executed every selected test
and that the report belongs to the current candidate.
```

Use `codesys` when the task needs routing. It does not force a broad review or require all the other skills to be installed. Each specialist is usable on its own. Project rules and tool availability remain project-specific; these skills do not provide an MCP server, native IDE, compiler, test library, or controller connection.

## Skills

| Skill | Main use |
|---|---|
| `codesys` | Select the relevant scope and references |
| `codesys-short-circuit-review` | AND_THEN, OR_ELSE, guarded access, effectful operands |
| `codesys-st-authoring` | Write bounded, testable ST with complete examples |
| `codesys-st-correctness-review` | Numeric, guard, call/state, bounds, and lifetime defects |
| `codesys-reference-pointer-varinout-review` | Bindings, aliases, mutability, and valid actual arguments |
| `codesys-scan-cycle-state-review` | Task context, invocation traces, shared data, commands |
| `codesys-inheritance-interface-review` | Base behavior, dispatch, public contracts, lifecycle exceptions |
| `codesys-counit-test-design` | CoUnit tests and multi-invocation fixtures |
| `codesys-counit-harness-review` | CoUnit registration, completion, reports, repeated runs |
| `codesys-testmanager-test-design` | Test Manager test POUs and complete lifecycle examples |
| `codesys-testmanager-ci-review` | Test Manager execution, reports, selection, cleanup |
| `codesys-test-provider-selection` | Choose or assess a provider without imposing a default |
| `codesys-mcp-development` | Work through the actual available tool schemas |
| `codesys-ci-scriptengine-review` | ScriptEngine build/analysis/test automation and failure handling |
| `codesys-mcp-roundtrip-review` | Preserve objects through edit/read-back workflows |
| `codesys-plcopenxml-package-review` | Import closure, conflicts, topology, semantic preservation |
| `codesys-static-analysis-campaign` | Complete analysis scope and behavior-preserving repairs |
| `codesys-target-operational-review` | Authorized controller checks, faults, recovery, timing |
| `codesys-implementation-structure` | Coherent FB/interface/DUT/task ownership |
| `codesys-implementation-structure-review` | Check a proposed structure against actual caller obligations |
| `codesys-execution-slicing` | Small complete changes and their integration checks |
| `codesys-evidence-reproducer` | Minimal source/call/environment reproductions |
| `comprehensive-analysis-codesys-st` | Broad, risk-led review of inherited code or major changes |

The entry files stay focused; larger explanations live in local `references/` and source examples in `assets/`. Some files repeat across installed skills so selecting one does not create a missing sibling dependency. Copies agree byte for byte in this release. If maintaining this bundle as a set, update all copies of a shared reference together. `catalog.json` inventories the copies; it is not required by Codex.

## Examples

| Group | Contents and claim |
|---|---|
| `guards` | Observable call-count tests for eager/short-circuit AND/OR, guarded null access, and stale-output regression |
| `bounded-job` | Enum, configuration, interface, FB and methods, cyclic program, bounded array function, widened arithmetic, and a nine-invocation scenario |
| `counit` | Complete positive suite/runner plus separate deliberate-failure and timeout probe |
| `testmanager` | Positive and negative test POUs with Setup, Execute, Abort, Teardown, discovery attributes, and cleanup |

Each example group contains a README and `objects.json`. The JSON is a human/tool source index, **not a native CODESYS import file**. Declaration and implementation files map to the corresponding object editor sections. Do not concatenate them into one FB. The provider examples reference the included `bounded-job` group.

The examples have explicit behavior and expected observations. They have not been compiled or run in CODESYS here. Exact CoUnit fork and Test Manager library builds were not supplied, so the provider examples target the documented API shapes and require comparison with installed declarations/templates. These qualifications do not mean the examples are pseudocode: the source objects and bodies are present, but native qualification remains separate.

## Validation and limitations

Run the offline checks from the extracted directory:

```powershell
py -3 -B -m unittest discover -s tests -v
```

```sh
python3 -B -m unittest discover -s tests -v
```

[VALIDATION.md](VALIDATION.md) records actual checks and limits. The suite checks skill structure, local dependency closure, matching reference copies, object source inventories, bounded text properties, installer behavior, and the ScriptEngine edit helper using fake document objects. It is not a CODESYS parser/compiler or proof of native test execution. The installer expects a trusted local destination with no concurrent writer. Abrupt process termination can leave a partial install; nothing in these skills grants external effect authority.

[evaluation/README.md](evaluation/README.md) explains the separate 34-case agent trial set. These are authored expected results, not completed agent runs or measured improvement claims. A before/after agent comparison, native CODESYS compilation, CoUnit/Test Manager runtime trials, and actual Codex discovery/trigger trials were not run.

Language/API facts cite official documentation in the references. New rules for examples are marked as example contracts rather than universal CODESYS policies. [SOURCE-NOTES.md](SOURCE-NOTES.md) distinguishes supplied material, corrections, new examples, and external verification.
