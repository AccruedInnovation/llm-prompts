# Validation record

## Actual scope

The deliverable is the written skill set, references, source examples, optional installer, source-edit helper, and authored evaluation cases. Native CODESYS compilation/runtime qualification and model-performance measurements are not claimed.

Environment: Linux x86_64, CPython 3.13.5. The installer and test suite use only the Python standard library. Python 3.8+ compatibility follows from source/API selection; other Python versions, Windows, macOS, and native IronPython execution were not run. No `codex`, `codesys`, or `pwsh` executable was found on PATH. No production project, controller, or user skill directory was changed.

## Checks run

Command from the bundle root:

```sh
python3 -B -m unittest discover -s tests -v
```

**35 tests passed, with no failures or skips.** The raw final workspace run appears in [validation/offline-tests.log](validation/offline-tests.log). The final ZIP was also extracted into a separate directory and the same tests rerun there; the detached archive-validation record identifies that exact ZIP and result.

| Check group | What it establishes |
|---|---|
| Skill metadata and inventory | 23 unique skill folders, matching names/descriptions, 22 original subjects plus new short-circuit skill |
| Local dependency closure | Every Markdown file link used inside a skill resolves inside that same skill; no mandatory sibling install |
| Shared-copy agreement | Same relative reference/asset/script paths agree byte for byte across skills |
| Standalone content | No BBK command/runtime dependency, private mounted paths, or symlinks in installed skills |
| Example object inventory | Declaration/body files exist, parent IDs resolve, method owners and source coverage agree |
| Bounded ST text checks | Balanced variable-declaration blocks, complete named interface/lifecycle members, explicit guard operations and stateful test phases |
| Evaluation inventory | 34 unique authored cases with context, expected findings, repair criteria, and false-positive rules; no fabricated agent/native results |
| Edit-helper unit tests | Preimage rejection, no-op, LF normalization, successful write/read-back, partial-mutation exception, mismatched read-back, and invalid input handling using fake document objects |
| Installation tests | All/selected skills, user/repo destination selection, dry-run, existing-name refusal, no preflight partial copy, unrelated-file preservation, invalid names, links, copy failure, rollback after publication failure, and another working directory |

The helper tests use a fake document and do not establish the actual ScriptEngine overload binding or native host behavior. The text checks are deliberately not represented as a full ST parser, compiler, type checker, or execution engine. Installation tests verify file placement and preservation, not Codex's actual skill selection behavior.

## Content review and repairs

Author self-review covered the skill routing, reference closure, repeated copies, technical distinctions, example contracts, declaration/body ownership, positive/negative provider separation, and evidence language. The review corrected a misleading skipped-call sentence, made the loop-counter type explicit, removed a reference to nonexistent bundled host models, changed scenario failure reporting to preserve its actual entry phase, and included hashes for the supplied provider guides referenced in provenance.

Native examples were inspected against their stated call traces and official/supplied API shapes. This is a source-level self-review, not independent model review or native proof. Deliberately defective review snippets remain clearly outside recommended executable example groups.

## Not run

| Check | Status and limit |
|---|---|
| CODESYS import/build/Static Analysis of bundled ST | NOT_RUN — native IDE/compiler unavailable |
| CoUnit and Test Manager execution | NOT_RUN — native runtime and exact installed provider builds unavailable |
| ScriptEngine helper in CODESYS/IronPython | NOT_RUN — real host unavailable |
| Controller timing, online change, reset/power-loss behavior | NOT_RUN — no controller used or authorized |
| Codex discovery and trigger trial | NOT_RUN — no Codex executable/session used for a trial |
| Baseline versus revised agent comparison | NOT_RUN — cases supplied; no measured improvement claim |
| Independent agent review | NOT_RUN — review was author self-review |

Before reusing an example in a project, compile its actual dependency/object closure in that project's pinned environment and run its stated positive, reset/repeat, and relevant negative checks. Before trusting a new test provider, establish discovery, failure detection, timeout, report binding, cleanup, and a subsequent clean run. No live-target action follows from installing these skills.
