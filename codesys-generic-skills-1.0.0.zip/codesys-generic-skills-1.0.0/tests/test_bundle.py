"""Offline delivery checks; deliberately not a CODESYS compiler or agent trial."""
import ast
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
from urllib.parse import unquote, urlsplit

ROOT = Path(__file__).resolve().parents[1]
SKILLS = ROOT / "skills"


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


installer = load_module("codesys_installer", ROOT / "install.py")
helper = load_module("codesys_body_helper", SKILLS / "codesys-mcp-development" /
                     "scripts" / "replace_method_body.py")


class BundleTests(unittest.TestCase):
    def test_catalog_and_frontmatter(self):
        catalog = json.loads((ROOT / "catalog.json").read_text(encoding="utf-8"))
        self.assertEqual(len(catalog["skills"]), 23)
        names = [s["name"] for s in catalog["skills"]]
        self.assertEqual(len(names), len(set(names)))
        self.assertEqual(set(names), {p.name for p in SKILLS.iterdir()})
        for item in catalog["skills"]:
            with self.subTest(skill=item["name"]):
                text = (SKILLS / item["name"] / "SKILL.md").read_text(encoding="utf-8")
                header, body = text[4:].split("\n---\n", 1)
                lines = header.splitlines()
                self.assertEqual(lines[0], "name: " + item["name"])
                description = json.loads(lines[1].split(": ", 1)[1])
                self.assertEqual(description, item["description"])
                self.assertLessEqual(len(description), 1024)
                self.assertLess(len(text.splitlines()), 500)
                self.assertGreater(len(body.split()), 100)
                self.assertRegex(item["name"], r"^[a-z0-9]+(?:-[a-z0-9]+)*$")

    def test_every_skill_has_local_reference_closure(self):
        links = re.compile(r"\[[^\]]*\]\(([^\s)]+)\)")
        for skill in SKILLS.iterdir():
            for page in skill.rglob("*.md"):
                for link in links.findall(page.read_text(encoding="utf-8")):
                    uri = urlsplit(link)
                    if uri.scheme or not uri.path:
                        continue
                    target = (page.parent / unquote(uri.path)).resolve()
                    with self.subTest(page=str(page.relative_to(ROOT)), link=link):
                        self.assertTrue(target.is_file(), str(target))
                        self.assertIn(skill.resolve(), target.parents)

    def test_shared_reference_and_asset_copies_agree(self):
        seen = {}
        for skill in SKILLS.iterdir():
            for p in skill.rglob("*"):
                if p.is_file() and p.name != "SKILL.md" and "__pycache__" not in p.parts:
                    key = p.relative_to(skill).as_posix()
                    if key in seen:
                        self.assertEqual(p.read_bytes(), seen[key], key)
                    else:
                        seen[key] = p.read_bytes()

    def test_no_links_or_packaging_dependency(self):
        for p in SKILLS.rglob("*"):
            self.assertFalse(p.is_symlink(), str(p))
            if p.is_file() and p.suffix in (".md", ".py", ".json", ".st"):
                text = p.read_text(encoding="utf-8")
                self.assertNotRegex(text, r"(?i)\bbbk(?:[ -]|$)|\.bbk/")
                self.assertNotRegex(text, r"/mnt/data/|C:\\Users\\")

    def test_object_indexes_and_ownership(self):
        for index in SKILLS.rglob("objects.json"):
            data = json.loads(index.read_text(encoding="utf-8"))
            self.assertFalse(data["native_import_format"])
            self.assertEqual(data["native_compile"], "NOT_RUN")
            objects = data["objects"]
            ids = {o["id"] for o in objects}
            self.assertEqual(len(ids), len(objects))
            indexed = set()
            for obj in objects:
                with self.subTest(index=str(index), obj=obj["id"]):
                    if obj["parent"]:
                        self.assertIn(obj["parent"], ids)
                    for part in ("declaration", "implementation"):
                        if part in obj:
                            p = index.parent / obj[part]
                            self.assertTrue(p.is_file())
                            self.assertEqual(p.parent, index.parent)
                            self.assertGreater(p.stat().st_size, 0)
                            indexed.add(p.name)
                    if obj["kind"] == "method":
                        self.assertIsNotNone(obj["parent"])
            self.assertEqual(indexed, {p.name for p in index.parent.glob("*.st")})

    def test_st_declarations_variable_block_balance(self):
        # Deliberately bounded text checks, NOT a parser/compiler.
        for p in SKILLS.rglob("*.decl.st"):
            text = re.sub(r"\(\*.*?\*\)", "", p.read_text(), flags=re.S)
            starts = re.findall(r"(?m)^\s*VAR(?:_INPUT|_OUTPUT|_IN_OUT|_INST|_TEMP)?(?:\s+CONSTANT)?\s*$", text)
            ends = re.findall(r"(?m)^\s*END_VAR\s*$", text)
            self.assertEqual(len(starts), len(ends), str(p))
            self.assertNotIn("TODO", text)
            self.assertNotIn("...", text)

    def test_complete_job_interface(self):
        base = SKILLS / "codesys-st-authoring" / "assets" / "bounded-job"
        index = json.loads((base / "objects.json").read_text())
        interface = {o["name"] for o in index["objects"] if o["parent"] == "I_Job"}
        implementation = {o["name"] for o in index["objects"] if o["parent"] == "FB_BoundedJob"}
        self.assertEqual(interface, {"Start", "Step", "Reset", "Abort", "GetState", "GetCompleted"})
        self.assertEqual(interface, implementation)
        body = (base / "FB_JobScenario.body.st").read_text()
        self.assertIn("CASE uiPhase OF", body)
        self.assertIn("uiCalls > 16", body)
        self.assertIn("xReset", body)
        self.assertIn("xCancel", body)
        self.assertIn("8:", body)

    def test_both_short_circuit_operators_and_six_observable_counts(self):
        p = SKILLS / "codesys-short-circuit-review" / "assets" / "guards" / "PRG_GuardChecks.body.st"
        body = p.read_text()
        for operator in (" AND ", " AND_THEN ", " OR ", " OR_ELSE "):
            self.assertIn(operator, body)
        self.assertEqual(body.count("probe.Reset();"), 6)
        self.assertEqual(body.count("probe.Visit("), 6)
        self.assertIn("pValue := 0;", body)
        self.assertIn("xReject", body)

    def test_provider_separation_and_complete_lifecycle(self):
        base = SKILLS / "codesys-testmanager-test-design" / "assets" / "testmanager"
        for case in ("TC_JobImmediate", "TC_JobScenario", "TC_HarnessFailure", "TC_HarnessTimeout"):
            for method in ("Setup", "Execute", "Abort", "Teardown"):
                self.assertTrue((base / (case + "." + method + ".decl.st")).is_file())
                self.assertTrue((base / (case + "." + method + ".body.st")).is_file())
            self.assertEqual((base / (case + ".body.st")).read_text().strip(), "SUPER^();")
        self.assertIn("SkillsExamples", (base / "TC_JobScenario.decl.st").read_text())
        self.assertIn("SkillsHarnessNegative", (base / "TC_HarnessFailure.decl.st").read_text())
        self.assertIn("Execute := FALSE", (base / "TC_HarnessTimeout.Execute.body.st").read_text())
        co = SKILLS / "codesys-counit-test-design" / "assets" / "counit"
        self.assertEqual((co / "PRG_CoUnitExamples.body.st").read_text().strip(), "CoUnit.RUN();")
        self.assertNotIn("suite();", (co / "PRG_CoUnitExamples.body.st").read_text())

    def test_evaluation_cases_are_explicit_expectations(self):
        data = json.loads((ROOT / "evaluation" / "cases.json").read_text())
        cases = data["cases"]
        self.assertEqual(len(cases), 34)
        self.assertEqual(len({c["id"] for c in cases}), 34)
        self.assertGreaterEqual(sum(c["expected_verdict"] == "SOUND" for c in cases), 10)
        self.assertIn("NOT_AGENT_RESULTS", data["status"])
        for c in cases:
            for key in ("source", "context", "expected_finding", "acceptable_response", "false_positive_or_unsafe_repair_to_avoid"):
                self.assertTrue(c[key].strip())
            self.assertEqual(c["agent_trial"], "NOT_RUN")
            self.assertEqual(c["native_execution"], "NOT_RUN")

    def test_source_mapping_covers_all_original_skills(self):
        data = json.loads((ROOT / "source-provenance.json").read_text())
        mapping = data["old_to_new"]
        self.assertEqual(len(mapping), 22)
        replacements = {m["replacement"] for m in mapping}
        self.assertEqual(replacements | {data["added_skill"]}, {p.name for p in SKILLS.iterdir()})
        self.assertTrue(all(re.fullmatch(r"[a-f0-9]{64}", m["source_sha256"]) for m in mapping))

    def test_python_syntax(self):
        for p in ROOT.rglob("*.py"):
            if "__pycache__" not in p.parts:
                ast.parse(p.read_text(encoding="utf-8"), filename=str(p))


class FakeDoc:
    def __init__(self, text="old\n", mode="normal"):
        self.text = text
        self.mode = mode
        self.calls = 0

    def replace(self, *, new_text):
        self.calls += 1
        self.text = new_text
        if self.mode == "raise_after":
            raise RuntimeError("after edit")
        if self.mode == "mismatch":
            self.text += "changed"


class FakeMethod:
    has_textual_implementation = True
    def __init__(self, doc=None):
        self.textual_implementation = doc or FakeDoc()


class HelperTests(unittest.TestCase):
    def test_success(self):
        m = FakeMethod()
        self.assertTrue(helper.replace_method_body(m, "old\n", "new\n")["changed"])
        self.assertEqual(m.textual_implementation.text, "new\n")
        self.assertEqual(m.textual_implementation.calls, 1)

    def test_preimage_mismatch_does_not_edit(self):
        m = FakeMethod()
        with self.assertRaises(helper.BodyEditError) as ctx:
            helper.replace_method_body(m, "stale", "new")
        self.assertFalse(ctx.exception.mutation_attempted)
        self.assertEqual(m.textual_implementation.calls, 0)

    def test_idempotent_noop(self):
        m = FakeMethod()
        self.assertFalse(helper.replace_method_body(m, "old\n", "old\n")["changed"])
        self.assertEqual(m.textual_implementation.calls, 0)

    def test_line_endings(self):
        m = FakeMethod(FakeDoc("old\r\n"))
        helper.replace_method_body(m, "old\n", "new\r\nline\r")
        self.assertEqual(m.textual_implementation.text, "new\nline\n")

    def test_mutating_exception_is_not_rollback(self):
        m = FakeMethod(FakeDoc(mode="raise_after"))
        with self.assertRaises(helper.BodyEditError) as ctx:
            helper.replace_method_body(m, "old\n", "new\n")
        self.assertTrue(ctx.exception.mutation_attempted)
        self.assertEqual(m.textual_implementation.text, "new\n")
        self.assertEqual(m.textual_implementation.calls, 1)

    def test_readback_mismatch(self):
        m = FakeMethod(FakeDoc(mode="mismatch"))
        with self.assertRaises(helper.BodyEditError) as ctx:
            helper.replace_method_body(m, "old\n", "new\n")
        self.assertTrue(ctx.exception.mutation_attempted)
        self.assertEqual(m.textual_implementation.text, "new\nchanged")

    def test_no_implementation(self):
        m = FakeMethod()
        m.has_textual_implementation = False
        with self.assertRaises(helper.BodyEditError):
            helper.replace_method_body(m, "old", "new")
        self.assertEqual(m.textual_implementation.calls, 0)

    def test_nontext_rejected(self):
        for value in (None, 42, b"bytes"):
            with self.assertRaises(TypeError):
                helper.normalized_text(value)


class InstallTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.dest = self.base / "installed"

    def tearDown(self):
        self.tmp.cleanup()

    def test_all_skills(self):
        result = installer.install(self.dest)
        self.assertEqual(len(result["skills"]), 23)
        self.assertTrue(result["changed"])
        for p in SKILLS.rglob("*"):
            if p.is_file() and "__pycache__" not in p.parts:
                self.assertEqual(p.read_bytes(), (self.dest / p.relative_to(SKILLS)).read_bytes())

    def test_selected_skill_is_self_contained(self):
        installer.install(self.dest, ["codesys-short-circuit-review"])
        self.assertEqual(len(list(self.dest.iterdir())), 1)
        skill = self.dest / "codesys-short-circuit-review"
        self.assertTrue((skill / "references" / "short-circuit.md").is_file())
        self.assertTrue((skill / "assets" / "guards" / "PRG_GuardChecks.body.st").is_file())

    def test_dry_run_does_not_create_destination(self):
        result = installer.install(self.dest, dry_run=True)
        self.assertFalse(self.dest.exists())
        self.assertFalse(result["changed"])

    def test_conflict_preflight_writes_nothing(self):
        self.dest.mkdir()
        (self.dest / "codesys").mkdir()
        marker = self.dest / "codesys" / "user.txt"
        marker.write_text("preserve")
        with self.assertRaises(installer.InstallError):
            installer.install(self.dest)
        self.assertEqual(marker.read_text(), "preserve")
        self.assertEqual([p.name for p in self.dest.iterdir()], ["codesys"])

    def test_existing_file_conflicts(self):
        self.dest.mkdir()
        (self.dest / "codesys").write_text("preserve")
        with self.assertRaises(installer.InstallError):
            installer.install(self.dest, ["codesys"])
        self.assertEqual((self.dest / "codesys").read_text(), "preserve")

    def test_invalid_name_no_write(self):
        for name in ("../escape", "not-a-skill", "/tmp/out", "codesys/../../escape"):
            with self.assertRaises(installer.InstallError):
                installer.install(self.dest, [name])
        self.assertFalse(self.dest.exists())

    def test_preserves_unrelated_content(self):
        self.dest.mkdir()
        (self.dest / "other-skill").mkdir()
        (self.dest / "other-skill" / "mine").write_text("mine")
        installer.install(self.dest, ["codesys"])
        self.assertEqual((self.dest / "other-skill" / "mine").read_text(), "mine")

    def test_destination_link_rejected(self):
        real = self.base / "real"
        real.mkdir()
        try:
            self.dest.symlink_to(real, target_is_directory=True)
        except (OSError, NotImplementedError):
            self.skipTest("Symlinks not available")
        with self.assertRaises(installer.InstallError):
            installer.install(self.dest, ["codesys"])
        self.assertEqual(list(real.iterdir()), [])

    def test_parent_link_rejected(self):
        real = self.base / "real"
        real.mkdir()
        linked = self.base / "linked"
        try:
            linked.symlink_to(real, target_is_directory=True)
        except (OSError, NotImplementedError):
            self.skipTest("Symlinks not available")
        with self.assertRaises(installer.InstallError):
            installer.install(linked / "skills", ["codesys"])

    def test_staging_failure_preserves_destination(self):
        with mock.patch.object(installer.shutil, "copytree", side_effect=OSError("copy failed")):
            with self.assertRaises(OSError):
                installer.install(self.dest, ["codesys"])
        self.assertEqual(list(self.dest.iterdir()), [])

    def test_publish_failure_rolls_back_only_new_skills(self):
        self.dest.mkdir()
        (self.dest / "unrelated").write_text("preserve")
        original_rename = Path.rename
        calls = []
        def fail_second(path, target):
            calls.append(target)
            if len(calls) == 2:
                raise OSError("publication failed")
            return original_rename(path, target)
        with mock.patch.object(Path, "rename", fail_second):
            with self.assertRaises(OSError):
                installer.install(self.dest, ["codesys", "codesys-short-circuit-review"])
        self.assertEqual([p.name for p in self.dest.iterdir()], ["unrelated"])

    def test_cli_works_from_another_cwd(self):
        result = subprocess.run([sys.executable, str(ROOT / "install.py"), "--dest", str(self.dest),
                                 "--skill", "codesys"], cwd=str(self.base), text=True, capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["skills"], ["codesys"])
        self.assertTrue((self.dest / "codesys" / "SKILL.md").is_file())

    def test_repo_scope(self):
        result = subprocess.run([sys.executable, str(ROOT / "install.py"), "--repo", str(self.base),
                                 "--skill", "codesys"], text=True, capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertTrue((self.base / ".agents" / "skills" / "codesys" / "SKILL.md").is_file())

    def test_user_scope_dry_run_uses_agents_path(self):
        with mock.patch.object(installer.Path, "home", return_value=self.base):
            with mock.patch("builtins.print") as output:
                self.assertEqual(installer.main(["--user", "--dry-run", "--skill", "codesys"]), 0)
            data = json.loads(output.call_args[0][0])
        self.assertEqual(data["destination"], str(self.base / ".agents" / "skills"))
        self.assertFalse((self.base / ".agents").exists())

    def test_missing_repo_fails_without_creating_it(self):
        missing = self.base / "missing"
        result = subprocess.run([sys.executable, str(ROOT / "install.py"), "--repo", str(missing)],
                                text=True, capture_output=True)
        self.assertEqual(result.returncode, 2)
        self.assertFalse(missing.exists())


if __name__ == "__main__":
    unittest.main()
