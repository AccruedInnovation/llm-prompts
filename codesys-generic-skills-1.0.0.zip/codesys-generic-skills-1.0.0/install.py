#!/usr/bin/env python3
"""Install local skill folders without overwriting existing content.

Python 3.8+ standard library only. No network, native IDE, or Codex invocation.
Use --user, --repo PATH, or --dest PATH. With no --skill, install all skills.
This installer expects a trusted local destination under single-writer control;
it is not a security boundary against another process changing paths mid-copy.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile
from typing import List, Optional, Sequence

BUNDLE = Path(__file__).resolve().parent
NAME = re.compile(r"[a-z0-9]+(?:-[a-z0-9]+)*\Z")


class InstallError(RuntimeError):
    pass


def reject_links(path: Path) -> None:
    """Reject existing symlink/junction components rather than following them."""
    for part in (path,) + tuple(path.parents):
        is_junction = getattr(part, "is_junction", lambda: False)
        if part.is_symlink() or is_junction():
            raise InstallError("Refusing linked destination component: " + str(part))


def skill_sources(names: Optional[Sequence[str]] = None) -> List[Path]:
    source = BUNDLE / "skills"
    available = {p.name: p for p in source.iterdir() if p.is_dir()}
    chosen = sorted(set(names)) if names else sorted(available)
    if not chosen:
        raise InstallError("No skills selected")
    result = []
    for name in chosen:
        if not NAME.fullmatch(name) or name not in available:
            raise InstallError("Unknown or invalid skill name: " + name)
        folder = available[name]
        for p in (folder,) + tuple(folder.rglob("*")):
            if p.is_symlink() or getattr(p, "is_junction", lambda: False)():
                raise InstallError("Refusing linked source: " + str(p))
            if not p.is_file() and not p.is_dir():
                raise InstallError("Unsupported source entry: " + str(p))
        if not (folder / "SKILL.md").is_file():
            raise InstallError("Missing SKILL.md: " + name)
        result.append(folder)
    return result


def install(destination: Path, names: Optional[Sequence[str]] = None,
            dry_run: bool = False) -> dict:
    """Preflight all conflicts; stage copies; publish new folders only.

    No overwrite/update mode exists. On an ordinary exception, remove only the
    new folders published by this call; process termination can leave a partial
    install or a .codesys-install-* staging folder. Do not run concurrent writes
    to the destination. Existing parent directories are never deleted.
    """
    destination = Path(os.path.abspath(str(destination.expanduser())))
    reject_links(destination)
    if destination.exists() and not destination.is_dir():
        raise InstallError("Destination is not a directory: " + str(destination))
    sources = skill_sources(names)
    conflicts = [destination / p.name for p in sources
                 if os.path.lexists(str(destination / p.name))]
    if conflicts:
        raise InstallError("Existing skills were not changed. Resolve these names first: " +
                           ", ".join(p.name for p in conflicts))
    result = {"destination": str(destination), "skills": [p.name for p in sources],
              "dry_run": dry_run, "changed": False}
    if dry_run:
        return result
    destination.mkdir(parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix=".codesys-install-", dir=str(destination)))
    published = []
    try:
        for source in sources:
            shutil.copytree(str(source), str(stage / source.name),
                            ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo"))
        # Recheck all names after staging; never merge into an existing skill.
        if any(os.path.lexists(str(destination / p.name)) for p in sources):
            raise InstallError("Destination changed during staging; nothing published")
        for source in sources:
            target = destination / source.name
            if os.path.lexists(str(target)):
                raise InstallError("Destination changed during publication: " + source.name)
            (stage / source.name).rename(target)
            published.append(target)
    except Exception:
        for target in reversed(published):
            shutil.rmtree(str(target))
        raise
    finally:
        shutil.rmtree(str(stage))
    result["changed"] = True
    return result


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    scope = parser.add_mutually_exclusive_group(required=True)
    scope.add_argument("--user", action="store_true", help="Install to ~/.agents/skills")
    scope.add_argument("--repo", type=Path, help="Install under an existing project root")
    scope.add_argument("--dest", type=Path, help="Explicit skill-directory destination")
    parser.add_argument("--skill", action="append", help="Select a skill; may repeat")
    parser.add_argument("--dry-run", action="store_true", help="Check and list; write nothing")
    args = parser.parse_args(argv)
    try:
        if args.user:
            dest = Path.home() / ".agents" / "skills"
        elif args.repo is not None:
            repo = args.repo.expanduser().absolute()
            if not repo.is_dir():
                raise InstallError("Project root must already exist: " + str(repo))
            dest = repo / ".agents" / "skills"
        else:
            dest = args.dest
        result = install(dest, args.skill, args.dry_run)
    except (InstallError, OSError, ValueError) as exc:
        print("Install failed: " + str(exc), file=sys.stderr)
        return 2
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
