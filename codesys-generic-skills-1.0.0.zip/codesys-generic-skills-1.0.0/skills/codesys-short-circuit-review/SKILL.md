---
name: codesys-short-circuit-review
description: "Review CODESYS ST Boolean evaluation: AND_THEN, OR_ELSE, eager AND/OR, unsafe dereferences, array and division guards, skipped method/property effects, and stale outputs. Use when a condition depends on earlier operands being safe."
---

# Short-circuit and guard review

Read [Boolean guards](references/short-circuit.md); use [probe objects](assets/guards/README.md) for exact positive checks. Do not replace all AND/OR tokens.

## Procedure

1. Read the full expression, operand declarations, called methods/properties, and any task that can change them. Mark every dereference, dependent index, division, and effectful call.
2. Identify the first unsafe evaluation. Determine whether the expression's actual operator/parentheses protect it. A later AND_THEN cannot repair an eager unsafe inner expression.
3. Use AND_THEN for a required true precondition followed by a dependent condition. Use OR_ELSE for a reject/fallback condition that is already true before the dependent condition. Check the Boolean result's meaning; a missing pointer must not accidentally grant a permissive.
4. Determine which calls must run every invocation. Move required effects into explicit ordered statements, then combine stored Boolean results. Keep bit-mask AND/OR operations unchanged.
5. Check ownership and stability between test and access. A non-null check is not proof of lifetime or concurrent safety. Guarded data must remain valid throughout use.
6. Check the false path and the next invocation: update outputs according to the contract rather than leaving a prior TRUE result set.

## Example

```iecst
xPositive := (pValue <> 0) AND_THEN (pValue^ > 0);
xReject := (pValue = 0) OR_ELSE (pValue^ <= 0);
```

For stable live storage, null yields FALSE/TRUE without dereference; live 7 yields TRUE/FALSE. Both forms must update their result again when the pointer next becomes null. See the reference for bounds, division, mixed expressions, and side effects.

## Evidence and result

Test both branches of each guard and required/skipped operand call counts. The included harmless probe expects counts 1,0,1,1,0,1 for eager/short-circuit cases. Keep its source-level expected result distinct from native execution. Do not run intentional null-dereference failures on a production controller.

A finding names the exact expression, missing precondition or skipped effect, triggering input/call order, wrong outcome, scoped repair, and regression. Preserve sound eager operations and supported short-circuit code as negative controls for false positives.
