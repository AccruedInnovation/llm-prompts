# Short-circuit probe objects

Status: source-complete teaching objects, not native-compiled or run in this delivery. Create the object sections listed in objects.json in a disposable offline project. FB_GuardProbe owns a bounded counter; Visit is the only mutating method.

Run PRG_GuardChecks in a simulator test task after an application reset. Expected final `xRan=TRUE` and `xAllPassed=TRUE`. It uses variable left operands and an instrumented harmless method, not a deliberately invalid dereference. It checks eager AND/OR calls, skipped AND_THEN/OR_ELSE calls, the opposite branches that must execute, null/live guarded reads, and stale-output clearing. The same invocation performs these independent evaluation checks; this is deliberately not a multi-cycle timing test.

The expected predicate counts are 1,0,1,1,0,1 in order. Counter arithmetic is bounded by these resets/calls. Do not use this probe as an unbounded production counter. Rerun through a supported fresh application/reset path, not by randomly editing private flags on a live controller.
