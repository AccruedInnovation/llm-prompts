---
name: comprehensive-analysis-codesys-st
description: "Survey an inherited CODESYS ST codebase or major change for high-value correctness, task/state, API, test, automation, and operational review areas. Use for broad assessment, not as a prerequisite to every focused fix."
---

# Broad CODESYS analysis

Read [working rules](references/working-rules.md). Survey representative actual source before proposing process or architectural changes. Identify the current project/library/source representation, generated boundaries, task/IO ownership, public interfaces, tests/providers, automation, and native evidence.

Prioritize concrete risk: unsafe dependent evaluation, bad lifetime, lost inherited behavior, mixed-task data, unbounded work, ambiguous reset/retention, omitted tests, stale reports, or lossy imports. Distinguish a documented requirement from observed code and a suspected issue from a reproduced defect.

Use a compact map such as:

| Area | Source observation | Needed focused check |
|---|---|---|
| Input guard | Pointer read under eager AND | Null branch and exact expression review |
| Shared status | Two tasks share a structure | Publication/read protocol and slow-reader trace |
| Tests | Completion flag without inventory | Missing-test and stale-report probe |
| Import | Parent replacement edits children | Child/property round-trip map |

These rows are examples, not findings about the user's project. Replace them with actual source evidence. Select specialist skills only for distinct needed checks; a large repository does not require every reviewer, a fixed reviewer count, or a new planning system.

Use [task/state reasoning](references/tasks-state.md), [structure](references/structure-and-slices.md), and [report evidence](references/report-evidence.md) to separate design gaps, implementation defects, harness defects, and missing evidence. Recommend the smallest correction with a direct caller/test observation.

Return ranked findings, source coverage/omissions, cross-object dependencies, proposed order, and unverified native or operational claims. Avoid broad style cleanup or provider migration without a named benefit and scope authority.
