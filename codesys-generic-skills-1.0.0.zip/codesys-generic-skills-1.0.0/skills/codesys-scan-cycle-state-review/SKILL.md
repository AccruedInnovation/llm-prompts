---
name: codesys-scan-cycle-state-review
description: "Review CODESYS task call order, cyclic state machines, timers, pulses, reset/abort, retention, shared data, and multicore access. Use when correctness spans invocations or more than one task."
---

# Scan-cycle, task, and state review

Read [per-task review](references/tasks-state.md) and [lifecycle](references/lifecycle.md). Use [numeric/time rules](references/numeric-arrays-time.md) for duration arithmetic and bounded work.

## Build the actual execution model

Identify every calling task, period/trigger, priority/core, ordered programs and method/FB calls, I/O update path, and shared writer/reader. An ordinary direct method call executes in the caller; its object's folder does not queue work on another task. Do not describe arbitrary application state as atomically committed at scan end.

For each state list entry conditions, per-call action, visible outputs, valid transitions, reset/abort/timeout precedence, and terminal behavior. Trace first, repeated, skipped, double, and re-entry calls. A CASE change does not fall through; a later independent IF can observe the new state immediately. Check pulse clearing before all relevant early returns.

For timing, distinguish cycle duration, monotonic timestamp, elapsed duration, and call count. Two calls in one scan do not prove two scans elapsed. Keep timer/edge updates out of skippable conditions unless intentional. Do not wait for a device or another task inside an unbounded loop.

## Shared-state analysis

Use the reference's mixed-version structure trace. Identify the consistency protocol protecting data and metadata together. One writer, atomic individual fields, a local struct copy, a plain flag, or two buffers alone is not a complete protocol. Establish bounded wait/copy cost, publication ordering, ownership return, full/empty behavior, and no buffer reuse before release. Select actual supported primitives rather than inventing APIs.

## Evidence

Use [the complete job scenario](assets/bounded-job/README.md) as an example of progress and reset across distinct invocations. Its explicit call-count model does not prove wall-clock timing. Require native task traces for scheduling, multicore, I/O, deadlines, and restart claims that depend on the real environment.

Return the call/ownership map, failing trace, required behavior, repair, and tests. Name unresolved scheduling/storage assumptions without turning routine future qualification into a speculative impossibility.
