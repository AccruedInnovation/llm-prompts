# Arithmetic, arrays, time, and bounded work

## Range proof before conversion

Write the source range, intermediate range, destination range, unit, and invalid-input response. A cast after an overflowing operation cannot repair that operation. CODESYS temporary widths depend on the target; narrow inputs do not reliably imply narrow intermediate wraparound.

For two signed DINT values whose mathematical product must fit LINT:

```iecst
liProduct := DINT_TO_LINT(diA) * DINT_TO_LINT(diB);
```

**Defective portability assumption:** `liProduct := DINT_TO_LINT(diA * diB);` assumes the multiply is already wide enough on every target. Test `diA=50000`, `diB=50000`, expected `2500000000`, on each supported target. Also test a negative operand. Widen *before* arithmetic and still establish the wide result's range. Do not add casts merely to silence diagnostics.

For an integer-to-unsigned conversion, reject negative and too-large values before conversion. Do not assume out-of-range conversion saturates. Explicitly choose rejection, clamp, or modular arithmetic only when the contract allows it. For floating-point values define finite-input policy, bounds, rounding, and tolerance in physical units. Exact equality can be right for an exact discrete value; tolerance must not hide a specification violation.

## Array inspection

Get both declared bounds; zero is not always the first index. Trace index arithmetic and conversions before every access. A BOOL bound result computed from an earlier index is stale if the index later changes. Use [short-circuit guards](short-circuit.md) or explicit branches.

Variable-length `ARRAY[*]` formal parameters belong in the documented `VAR_IN_OUT` section. Discover bounds with `LOWER_BOUND`/`UPPER_BOUND`; do not infer length from a caller-specific constant. A corrected bounded summation function is supplied in the authoring examples. It allows arbitrary declared lower bounds, but rejects lengths above its explicit work limit.

A loop's last *access* and last *increment* need separate checks. **Defective:** `FOR uiIndex := 0 TO 255 DO` with `uiIndex : USINT`; the end equals the counter's maximum. Use a wider counter, or exit before incrementing the final representable index. Reducing the end to 254 silently drops data and is not a repair.

For a DINT upper bound that may itself be DINT_MAX, this pattern avoids a final overflow. The caller must separately bound the element count and execution cost:

```iecst
diIndex := diLower;
WHILE TRUE DO
    lrTotal := lrTotal + aValues[diIndex];
    IF diIndex = diUpper THEN
        EXIT;
    END_IF;
    diIndex := diIndex + 1;
END_WHILE;
```

This loop is acceptable only after proving `diLower <= diUpper`, valid bounds, and a finite allowed count. A `WHILE TRUE` token alone is neither proof of a defect nor proof of bounded execution. Also consider floating-point accumulation error and range.

## Per-invocation work

A task must not wait in a loop for another task, network reply, sensor edge, or elapsed timer. Such a wait can prevent the awaited task from running or overrun a watchdog. Use state carried between invocations, a finite amount of work per call, a defined timeout, and a busy/overload outcome.

For a queue drain, define the maximum count processed per invocation and what happens to remaining items. "Drain the queue" is bounded only when capacity, concurrent producer behavior, and per-item cost establish the bound. Do not silently change ordering or drop commands to improve measured timing.

## Time is a contract, not a variable name

| Input | Meaning | Correct test advancement |
|---|---|---|
| `tCycle : TIME` | Duration represented by one call | Pass constant T#10ms for each nominal 10ms step |
| `tElapsed : TIME` | Accumulated elapsed duration | Increase by the chosen step with defined overflow handling |
| Timestamp from monotonic clock | Current time | Advance the fake clock or wait in real runtime |
| Invocation count | Number of calls | Never label it milliseconds without an explicit schedule contract |

**Defective duration test:** pass 10ms, then 20ms, then 30ms into a cycle-duration input while intending three 10ms calls; it models 60ms, not 30ms. Test a time boundary immediately before, at, and after expiry, and test zero/large intervals. Define whether time spent suspended counts.

Do not assume calling `TON` twice advances wall time by two scans. A skipped timer/edge FB call changes its update schedule. Call it in a defined place, then use its output. Derive elapsed time from an appropriate clock; wall-clock corrections and timestamp wrap must not silently change duration semantics. Verify exact TIME/LTIME units, ranges, and library conversions for the target API; a numeric cast alone does not explain units.

## Source basis

Language/API claims use the sources below, consulted 2026-09-08. Examples and review procedures are newly authored; they are not copied vendor tests or evidence of native execution.

- [CODESYS: operators and intermediate results](https://content.helpme-codesys.com/en/CODESYS%20Development%20System/_cds_struct_reference_operators.html)
- [CODESYS: FOR](https://content.helpme-codesys.com/en/CODESYS%20Development%20System/_cds_st_instruction_for.html)
- [CODESYS: ARRAY OF](https://content.helpme-codesys.com/en/CODESYS%20Development%20System/_cds_datatype_array.html)
