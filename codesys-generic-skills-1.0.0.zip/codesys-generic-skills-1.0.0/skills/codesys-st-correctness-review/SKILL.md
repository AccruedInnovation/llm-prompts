---
name: codesys-st-correctness-review
description: "Review changed CODESYS ST for language, range, array, reference, evaluation-order, state, reset, and failure-path defects. Use for a concrete candidate; not for broad code-style cleanup."
---

# ST correctness review

Bind one exact candidate and its required behavior. Read [working rules](references/working-rules.md), then only the relevant technical references below.

| Concern | Method |
|---|---|
| Dependent Boolean expression | [Short-circuit review](references/short-circuit.md): first unsafe evaluation, both branches, effects |
| Arithmetic, indices, time | [Numeric review](references/numeric-arrays-time.md): ranges before/after each operation, units, finite work |
| Aliases and parameters | [References](references/references-parameters.md): owner, binding, actual argument, lifetime |
| Scan behavior | [Task/state traces](references/tasks-state.md): actual callers, repeated/skipped calls, shared state |
| Initialization and reset | [Lifecycle](references/lifecycle.md): storage duration, re-entry, relocation |
| Derived behavior | [Inheritance](references/inheritance-interfaces.md): parent obligations and public caller view |

## Review in this order

Establish the inputs and expected outputs. Trace the first invalid input or missing dependency with every unrelated precondition valid. Check output/state updates before early returns. Test the boundary below/at/above each threshold and a formerly valid input becoming invalid.

Trace numeric types through intermediates, not just destinations. Check both array bounds and final counter increment. A loop ending at its counter maximum can fail to terminate; silently dropping the last element is not a repair. A time-like variable needs an explicit duration/timestamp/call-count meaning.

Trace every reachable state through reset, abort, timeout, and another run. Locate actual task/call owners; no application-wide commit or cross-task call dispatch may be assumed. Check false positives too: ordinary method locals are right for stateless work, VAR_INST can be right for instance state, eager Boolean/bitwise operations can be intentional, and read-only string literal in-out-constant calls can be valid.

## Result

For each defect, name severity by consequence, object/method/expression, requirement, triggering input or trace, wrong result/effect, proposed repair, and cheapest sufficient test. Keep unverified hypotheses separate. Do not restyle unrelated code or infer multi-cycle correctness from compilation. Cite exact source paths/lines and the applicable reference/API where material.
