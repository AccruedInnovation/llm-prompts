# Ownership, structure, and coherent increments

## A compact structure record

State the public result, object/type/interface owners, task/call order, configuration/state/output ownership, reset/failure behavior, external effects, and test seam. Link existing design contracts rather than copying them into a second editable specification. A private calculation change may need only a short inline note.

For the bundled bounded-job example:

| Concern | Example decision |
|---|---|
| API | `I_Job` owns Start/Step/Abort/Reset/state/count contracts |
| State | One `FB_BoundedJob` instance owns phase, target, and completed count |
| Config | Caller supplies a count; accepted Start copies that value |
| Execution | One owning task calls Step exactly once per intended update |
| Wiring | Interface variable refers to the task-owned FB; no foreign writer |
| Failure | Invalid config faults Idle; busy Start rejects without changing work |
| Test | Public interface plus one-phase-per-invocation scenario |
| Persistence | None; no physical output and no automatic resume |

The full source is a teaching choice, not a required architecture for all projects. Preserve a simpler existing design where it already meets the contract.

## Planned versus actual

A private helper rename conforms unless an exact consumer depends on it. Moving the same public Step call into a different task changes ownership/timing and needs review even when signatures compile. Removing the parent's status update is behavioral divergence. Replacing a queued Start with a direct foreign-task call changes the concurrency contract. Keeping config bytes but dropping their units/version changes their meaning.

Report the exact obligation and code path, not a similarity score. Classify as conforming, permitted local choice, material divergence, or evidence gap. An object inventory cannot establish actual scan timing or controller recovery.

## A coherent increment

For a bounded new FB: implement the public type/interface and full state behavior together with a real caller/test; import/build the exact closure; check relevant analysis; run the selected provider; capture the source read-back and results. The useful result is observable accepted/rejected commands, progress, completion, and reset—not just a directory of declarations.

For a small guard repair: edit the expression, add null/non-null and stale-output cases, compile, and run the affected tests. Do not require a full architectural campaign. For cross-task publication: settle the shared protocol before independent writer/reader changes; integrate both sides and test a slow reader, concurrent publication, and overload.

Reuse a warm native session where it reduces startup/import cost, while keeping build, analysis, test, report, and cleanup results separate. One serialized project owner avoids conflicting IDE edits; it does not provide database-style rollback. Temporary test runners, generated applications, and test-only wiring need removal or an explicit retained role.
