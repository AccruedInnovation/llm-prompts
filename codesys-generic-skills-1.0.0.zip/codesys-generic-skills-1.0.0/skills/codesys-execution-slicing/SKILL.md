---
name: codesys-execution-slicing
description: "Organize CODESYS implementation into small complete behavior increments with caller/tests and efficient native validation. Use for multi-object work; avoid turning every method or FB into a separate process step."
---

# Coherent CODESYS implementation increments

Read [worked increments](references/structure-and-slices.md) and [evidence boundaries](references/working-rules.md). Preserve any supplied scope/dependency plan.

Group work around an observable result: a command accepted/rejected and completed/reset; a guarded read with both valid and invalid cases; a shared-data exchange proven coherent. Include the required FB/interface/DUT/children, caller/task, tests, and import closure. A collection of declarations is not a complete behavior increment unless that is the assigned foundation outcome.

Name the canonical source, public contract, owner, prerequisite, required output, exact observation, and temporary state/cleanup. Settle shared semantics before independent writer/reader work. Allow a local guard fix to stay one small edit/test rather than generating a full planning packet.

Reuse a serialized native project session for compatible build/analysis/test work when it saves overhead. Preserve separate outcomes and fresh evidence for each stage; one session does not make mutations transactional. Do not launch a new IDE per FB merely to match file ownership.

Progress only when the next dependent work has actual usable prerequisites. Continue independent safe work when a particular native environment is unavailable. Do not claim a missing physical target or a future test already exists. Return completed/remaining increments, actual observed behavior, candidate/evidence, and retained temporary artifacts.
