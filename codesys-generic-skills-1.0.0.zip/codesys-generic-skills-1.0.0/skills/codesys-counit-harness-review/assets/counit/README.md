# CoUnit complete examples

Status: authored against the supplied CoUnit API documentation shape, not compiled/run or assigned an invented fork version. Install the project's actual CoUnit dependency under namespace CoUnit and verify its signatures and automatic suite registration.

Load the bounded-job object group first, then create FB_JobSuite and its two child methods and PRG_CoUnitExamples from objects.json. Assign only PRG_CoUnitExamples to one cyclic test task in an authorized disposable application. Its suite instance registration plus CoUnit.RUN() follow the supplied guide; do not also call suite() manually without checking the fork. Keep the negative runner out of that application.

Expected selected/executed normal inventory: JobImmediate and JobScenario, each once in FB_JobSuite, zero failures. Immediate completes in one suite call. Scenario initializes on its first call, then advances through nine separate calls. Both scenario state and test completion flags live in the suite FB, not in method-local variables.

To prove failure reporting, create a separate disposable application containing FB_HarnessNegative and PRG_CoUnitNegative, with xTimeoutProbe left FALSE in its source. Expected: exactly one failed testcase. To prove host timeout handling, change that declaration to TRUE in a separately identified negative candidate. The test then keeps returning but never calls TEST_FINISHED. Configure a finite external run timeout (for this harmless example, 5 seconds is a chosen probe limit, not a library default). Preserve partial reports and stop/reset only the authorized test application. The default negative source does not hang.

This guide does not invent a CoUnit abort hook or XML path. For cancellation of a real running scenario, route the project harness's supported cancellation mechanism to `scenario(xReset := FALSE, xCancel := TRUE)`, observe cancellation, then finish/report through its actual API. Native failure/timeout qualification must exercise the installed fork and writer.

For a second whole harness run, use the fork's documented runner reset or a fresh application/reset path. Do not just reset the product while leaving registered tests marked finished. Reconcile exact report IDs and selection after each run; a successful CoUnit.RUN call is not test PASS.
