# Bounded-job source example

Status: newly authored teaching source; not compiled or executed in CODESYS by this delivery. No physical I/O, required online connection, or nonvolatile storage.

## Load into an offline CODESYS project

`objects.json` lists each object, kind, parent, declaration section, and implementation section. It is a source index for a person or an existing project importer, **not** a CODESYS/PLCOpenXML import format. Create the DUTs and interface, its child methods, the FB and child methods, then functions/scenario/program. Paste `.decl.st` into the object's declaration editor and `.body.st` into its implementation editor. Do not paste all child methods into one FB body. Interface methods have no bodies.

Follow the installed compiler's object editor and generated signatures. Resolve any compiler-specific issue against the example's stated behavior, not by silently changing expectations. CODESYS 3.x extension support and LINT/LREAL support on the actual target must be checked. No vendor/test-library dependency is required for this group.

## Job contract

`Start(config)` accepts only in Idle with `uiSteps` from 1 through 1000. A busy/terminal Start returns FALSE and leaves the existing state untouched. Invalid config in Idle returns FALSE and sets Fault. Accepted Start copies the count, clears completed count, and enters Running. `Step` performs one count increment while Running and reaches Done on the target count. Step does nothing in every other state. Abort changes Running to Aborted and preserves progress. Reset sets Idle and clears both count and target from every state. Getters have no side effects.

Invariants: completed <= accepted target <= 1000 while a job exists; Done means completed equals target; Reset clears all state; rejected busy Start does not alter target/count. These are choices for this example, not rules imposed on equipment FBs.

## Cyclic caller

Assign `PRG_JobExample` to one task in a disposable project. It binds the interface and starts once; later calls invoke Step once. Expected observed counts over the first four invocations: 0,1,2,3; states: Running,Running,Running,Done. It does not call both `fbJob()` and `itfJob.Step()` in the same invocation. The FB body also delegates to Step, so doing both would advance twice. This one-task example does not solve cross-task synchronization or automatic online-change rebinding.

## Test scenario

Reset `FB_JobScenario` once with `xReset := TRUE`. Then call it once per runner invocation with both inputs FALSE until xFinished. The normal trace takes nine invocations after reset. It checks rejected busy Start, three-step progress, terminal idempotency, reset, abort, invalid config, and a second completed run. Getters are side-effect-free, so eager Boolean combination of their results is intentional.

Call with `xCancel := TRUE` to abort/reset the harmless testee and finish with xCancelled=TRUE and xPassed=FALSE. Reset again to rerun. A 16-invocation bound detects a nonprogress defect in a modified scenario; a host timeout is still needed if invocations stop entirely. A returned xPassed before xFinished is not a final result.

## Functions

`F_WidenProduct` widens DINT operands before multiplying. Expected for 50000 and 50000: LINT#2500000000; for -50000 and 50000: LINT#-2500000000.

`F_BoundedSum` accepts a writable actual LREAL array with arbitrary lower bound, reads but does not mutate it, and rejects lengths outside 1..1024 via xValid=FALSE and result=0. It exits before the final DINT index increment. Its numeric input contract requires finite elements whose accumulation stays representable; it does not implement a NaN/overflow policy. For [-2..0] containing 1.0,2.0,3.0 expect 6.0 and xValid=TRUE. For a 1025-element array expect rejection. No concurrent writer may change the array during the call.

These source expectations and offline text checks do not establish native compilation, timer accuracy, task deadlines, or library/runtime behavior.
