# CoUnit authoring and harness details

## API basis and limits

The supplied source guides describe `CoUnit.FB_TestSuite`, `TEST`, `TEST_FINISHED`, `CoUnit.RUN`, `AssertTrue`, and typed/ANY assertions. No exact fork version accompanies those guide pages. The bundled examples target that **documented API shape**, not an invented version or a guarantee about every CoUnit fork. Check the installed library declarations, automatic suite registration, and result writer before running them. Do not substitute similarly named TcUnit APIs by assumption.

The original guide's method-local testee is suitable for a one-call pure case, but not for a multi-call testee. The new examples keep the stateful fixture in the suite FB. This is ordinary FB-owned storage, not `PERSISTENT` data.

## Complete examples and runner

[CoUnit objects](../assets/counit/README.md) include a two-test positive suite, methods, and a runner program. Its program declares one suite instance and calls `CoUnit.RUN()` cyclically, relying on the supplied guide's registration model. It does not also call the suite manually; that could double-run it in a fork that already invokes registered suites.

Each active test calls `TEST` before its assertions. The immediate test checks widened multiplication. The scenario test invokes `FB_JobScenario` once per method call, returns while unfinished, and calls `TEST_FINISHED` only after observing the complete trace. Per-test completion state prevents repeated stimulation. The tests use distinct storage, so one active test cannot reset another's testee.

The folder also contains a separate deliberate-failure suite/program. Load only the intended runner into the test task. Do not include the negative suite in the positive application's registration inventory. The failure probe must produce a failed assertion; its expected failure does not make a normal suite pass.

For a timeout probe, use the provided negative suite mode: after registering the case, it omits completion but keeps control returning to the cyclic runner. Bound the test with an external watchdog and recover the disposable application. No generic CoUnit abort callback is assumed; the scenario has an explicit cancel path, while host cleanup must use the actual fork's supported stop/restart/reset protocol.

## Discovery and lifecycle checks

Record selected suite/test names independently of the report. Verify at least one intended executed test, exact selected identities, and no hidden skip. Check how the installed fork discovers an instance with no direct ST body call, and whether linker/exclusion settings can remove it. Bind the result writer location and completion variable to the exact fork rather than guessing a common symbol.

Run clean-start, warm/repeated, selected-only, and aggregate cases. If a fork requires a full runtime reset or fresh application for suite registration, follow that supported path; do not claim a product Reset re-registers the harness.

## Harness failures

Distinguish an assertion failure, PLC exception, execution timeout, writer timeout, absent report, malformed report, stale report, and connection/launcher failure. A completed test process with an old XML file is not a valid result. Preserve partial output and every attempt. Stable file size alone does not prove report completeness; reconcile parsed identity, inventory, and terminal status too.

Pin any local fork patch to a small regression: duplicate registration, an omitted suite, a failed assertion, interrupted writing, and a second run are useful cases. Do not let a wrapper convert all failures into a single normal FALSE value.

## Supplied source provenance

The API basis comes from `sources/user-supplied/repository/CoUnit/CoUnit-API-Summary.md`, `CoUnit-API-Method-Details.md`, and `Create-CoUnit-test-suites-and-run-them.md` in the reviewed input. Their content hashes appear in the delivery's provenance record. This reference summarizes only relevant API facts; it does not impose that repository's provider policy on another project.
