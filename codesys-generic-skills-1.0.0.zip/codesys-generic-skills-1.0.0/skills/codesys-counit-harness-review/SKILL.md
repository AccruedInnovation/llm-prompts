---
name: codesys-counit-harness-review
description: "Review a CODESYS CoUnit fork, registration, cyclic runner, result writer, polling, fresh reports, failures, and rerun cleanup. Use for harness reliability or CI changes rather than product test logic alone."
---

# CoUnit harness review

Read [CoUnit details](references/counit.md) and [report evidence](references/report-evidence.md). Identify the exact fork/library, runtime, runner source, writer, completion protocol, selected inventory, and launcher.

Trace registration through runner invocation to the raw report. Verify that the intended suite instance cannot be excluded or run twice. Check completion flags, writer lag, polling bounds, output-directory ownership, and stale previous files. Use the stale-report example: a normal launcher return and old passing XML must not satisfy the new run.

Exercise positive results, a deliberate failed assertion, omitted selected test, execution timeout, writer timeout, missing/malformed/partial/stale report, PLC exception, interrupted host, and a second clean run. These need not all repeat for every product edit; they qualify the harness behavior affected by the change. Use the provided negative examples only in an isolated authorized test application.

Check that failures reach the intended stage with other prerequisites valid. Preserve known assertion failures when later capture becomes incomplete. Capture every diagnostic or record a capture failure; do not swallow exceptions. Verify supported framework reset rather than mutating private global state to force a pass.

Review cleanup separately from assertions, including stopped test processes, project copies, online handles, writer ownership, and next-run registration. Never erase earlier failed attempts after a passing retry. Return concrete failure classifications, exact reproduction, patch regression coverage, and remaining native evidence gaps.
