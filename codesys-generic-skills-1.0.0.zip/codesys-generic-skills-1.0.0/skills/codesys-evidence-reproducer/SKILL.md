---
name: codesys-evidence-reproducer
description: "Create a minimal CODESYS defect reproducer and preserve exact source, environment, call/task trace, expected/actual result, report freshness, and failure history. Use for disputed behavior or hard-to-repeat failures."
---

# Evidence and minimal reproduction

Read [the reproducer example](references/reproducer.md) and [test-report rules](references/report-evidence.md).

Identify whether the claim concerns syntax, runtime value, alias/lifetime, task timing, import preservation, test harness, or physical operation. Preserve the original candidate. Reduce to the smallest source and dependency set that still reaches the relevant behavior, retaining any required caller/task or prior lifecycle state.

Record declarations/bodies, input/config, binding owner/lifetime, exact call sequence or task interleaving, explicit time model, required output/effect, observed trace/diagnostic, and repeat/cleanup procedure. State compile/runtime/library/tool versions actually known; do not invent missing ones. Include test selection and raw report/source identity where relevant.

Use negative inputs that satisfy unrelated guards so the intended defect is reachable. Include the prior successful call for stale-output defects and prior run/reset for lifecycle defects. For a stale report, preserve both run identities and the fresh launch's missing output rather than only the passing XML.

Keep authored expectations, host-model results, compiler results, simulator observations, and controller measurements separate. A model trace does not become a native failure log. Preserve earlier failures when the repaired candidate passes, and distinguish an unsupported hypothesis from a demonstrated defect.

Return a runnable or complete source-level reproducer, exact expected/actual difference, evidence location, and smallest confirming check not yet available. Do not invent native validation or grant target effects through the reproducer itself.
