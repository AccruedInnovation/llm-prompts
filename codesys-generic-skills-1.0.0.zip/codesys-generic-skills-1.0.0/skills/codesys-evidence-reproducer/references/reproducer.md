# A minimal useful reproducer

Keep the smallest source and environment that reaches the intended defect. Do not remove a dependency whose presence is necessary for the behavior. Preserve the original before changing the reproducer.

## Example: reference assignment mistaken for rebinding

Subject: a method using `r := b` where the required operation changes the reference binding. Prerequisites: `a=10`, `b=20`, `r REF= a`; no concurrent access. Calls: perform the candidate operation, then assign `r := 30`.

Required result for rebind: `a=10`, `b=30`. Actual result for the defective copy operation: `a=30`, `b=20`. The distinction does not need a large production project. A native reproduction must still record compiler/runtime version and exact source. The stated trace is the authored expectation, not a run performed by this bundle.

## Reproducer record

Include object declarations and bodies, dependencies and versions, source identity, initial values/bindings, ordered calls or task configuration, explicit time source, required output and forbidden effects, actual trace, diagnostic/report paths, repeat instructions, and cleanup. Name whether the failure is compile-time, runtime, timing, harness, or evidence mismatch.

For an evaluation-order defect use null/non-null or in/out-of-range conditions with every earlier unrelated guard satisfied. For a lifecycle defect include the prior run and the reset/restart event; a fresh-start trace may hide it. For a cross-task defect include the relevant interleaving and runtime assumptions. For stale XML include both the prior and current run identities.

Do not claim a synthetically modeled failure is an observed controller failure. Keep failed attempts, not just the final passing version. Give an unverified concern the exact confirming check instead of fabricating a reproduction log.
