# Controller, I/O, restart, and recovery review

Do not infer physical safety or deployment authority from source quality. Identify the approved controller, device/firmware/runtime/libraries, task configuration, I/O mapping, network/bus cycle, and operator procedure. Preserve the actual project's safe-response definition; de-energizing every output is not universally safe.

## Worked operational test design

This is an **illustrative test for a simulated conveyor drive**, not an approved machine safety procedure. Example-specific contract: loss of valid drive feedback inhibits the run command on the next owning-task update; the application does not rearm on communication recovery alone; an explicit operator reset is required. The independently designed safety system is outside this software example.

Before the test, identify the permitted test environment, observed command output, feedback quality flag, state/fault output, task period, physical observation path if any, and deadline from the actual requirement. Do not invent a numerical safety deadline from a generic skill.

| Step | Stimulus | Required observation |
|---|---|---|
| 1 | Start from reset with valid config/feedback | No stale run command; Ready only after prerequisites |
| 2 | Issue an authorized run request | Command and reported state agree with contract |
| 3 | Invalidate feedback between task calls | Next defined control update inhibits run; fault records reason |
| 4 | Restore feedback without reset | No automatic rearm |
| 5 | Reset with prerequisites satisfied | Defined return to Ready; no implicit new run request |
| 6 | Repeat after restart | No leaked test override, old command, or stale binding |

Measure the required path: task entry, detected fault, logical output assignment, bus transfer, and actuator feedback are different times. A simulator variable becoming FALSE proves neither bus latency nor physical stopping distance. Measure maxima/jitter under representative load and define overrun/watchdog behavior. Do not use average cycle time as deadline proof.

## Lifecycle and degradation

Use [the lifecycle matrix](lifecycle.md) for warm/cold/origin reset, stop/start, download, online change, and power interruption. Check incompatible retained config, invalid references, device loss, stale input quality, timeout, and re-entry from each reachable state. Confirm the runtime/project versions after the change, not only before it.

## Change and cleanup

For an authorized download/online change, preserve the known working project/configuration, exact changed candidate, expected compatibility, rollback procedure, and operator limits. Verify the installed source identity and actual task/I/O settings. Do not claim rollback is safe merely because an old archive exists; check whether it can consume the current retained data and restore the required behavior.

Record login/logout, forced values, temporary overrides, generated test programs, and any running test process. Clear only task-owned temporary effects through the permitted procedure. If cleanup cannot establish the target's state, report that uncertainty and follow the approved stop/escalation procedure rather than assuming recovery.

## Output

Report the tested scenario, intended and observed outputs/states, timing method, exact environment/candidate, failures, cleanup state, and untested operating limits. Unit tests, simulator tests, real I/O observations, and safety-system qualification remain distinct claims.
