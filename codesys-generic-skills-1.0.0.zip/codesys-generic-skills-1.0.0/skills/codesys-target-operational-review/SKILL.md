---
name: codesys-target-operational-review
description: "Review CODESYS controller/runtime/I/O behavior, task deadlines, startup/reset, online change, degradation, rollback, and cleanup. Use for operational claims; source review alone never grants deployment or physical-target authority."
---

# Target and operational review

Read [operational test design](references/operations.md) and [lifecycle](references/lifecycle.md). Establish the requested claim and the exact permitted controller/test environment before any online effect.

Identify runtime/device/firmware/libraries, task periods/priorities/cores, bus-cycle and I/O mapping, stored config, public status, and independent safety boundaries. Define required outputs, faults, timing, rearm/recovery, and operator actions for the actual equipment. Do not substitute a generic "all outputs off" rule.

Trace normal startup, invalid config/binding, communication/device loss, abort/timeout, warm/cold/origin reset, power interruption, and online change as applicable. Inspect the entire physical path: logical assignment, bus update, device command, and observed plant effect have different evidence and deadlines.

Use the reference's conveyor example only as an illustration of an explicit fault/rearm contract. Select the real project's expected states and deadlines. Measure worst-case exposure and jitter under relevant load; an average task time is not a deadline proof. A simulator result is not power-loss durability or real I/O timing.

For authorized changes, preserve the known working artifact/configuration and a compatible rollback procedure. Check that the rollback can handle current retained data. Verify the installed candidate, target settings, absence of unintended forces/overrides, and cleanup of only owned temporary effects. An interrupted operation needs a real state check, not an assumption of rollback.

Return scenario-by-scenario expected/observed states and outputs, timing method, exact environment/candidate, failures, recovery/cleanup, and untested limits. A software skill, compile, or test report does not provide safety certification or permission for motion/plant effects.
