# Designing tests that span invocations

## Start with the behavior, not the provider

A test needs inputs, initial state, call sequence, expected outputs/state, forbidden effects, time source, completion rule, and a wait bound. Test a command through the public interface when that interface is the consumer contract. Testing a private helper alone can miss caller/dispatch defects.

Single-call assertions are appropriate for pure calculations. Stateful tests need FB-owned state or supported `VAR_INST`. Two calls followed by completion in one invocation test two logical calls, not two PLC scans. Record which claim the fixture supports.

## Shared complete fixture

[Bounded job and scenario](../assets/bounded-job/README.md) supplies a source-complete, provider-neutral testee and test scenario. Each call to `FB_JobScenario` performs one phase and returns. It does not sleep, poll in a loop, or read a hidden clock. The normal sequence is:

| Invocation | Stimulation | Required result |
|---|---|---|
| 1 | Reset; start 3-step job | Accepted, Running, completed=0 |
| 2 | Step | Running, completed=1 |
| 3 | Step | Running, completed=2 |
| 4 | Step | Done, completed=3 |
| 5 | Step again; reset; start 1-step job | Terminal step unchanged; reset clears; new start accepted |
| 6 | Abort; reset | Aborted, then Idle with completed=0 |
| 7 | Start invalid zero config; reset | Rejected, Fault, then Idle |
| 8 | Start 1-step job | Accepted, Running, completed=0 |
| 9 | Step; reset | Done with completed=1; then clean Idle |

The fixture records the first failed phase and keeps failure sticky. An upper invocation limit detects unintended nonprogress when the fixture still runs. Provider/host timeouts catch a fixture that no longer receives calls. Cancel resets the harmless testee and reports cancellation, not success.

For a real time-based FB, use a controlled monotonic clock or explicit duration input. Keep logical-clock tests distinct from real scheduler/timer tests. A task period configured to 10ms does not prove every call occurred exactly 10ms apart.

## More than the positive case

Run invalid dependencies while other guards are satisfied. Check the correct rejection reason and unchanged state/effects. Deliberately fail one assertion to establish the report path. Omit a selected test to establish inventory checking. Hang a harmless test until timeout and confirm cleanup/next-run state. An exception may stop the PLC before in-PLC cleanup can run; verify the external recovery path separately.

The normal fixtures do not operate physical outputs. Use a specifically approved test environment for exception and timeout probes; never insert fault probes into a live machine's production task.

## Reset and repeated runs

Reset product state and test phase separately. A product `Reset` is not a framework reset; a framework completion flag is not a product reset. Capture the final result before cleanup destroys testee state. Run a second test execution after cleanup and compare both selection and initial state. Do not zero arbitrary internal framework globals to make reruns appear supported.

## Assertions and evidence

Use typed assertions matching actual types. For a generic `ANY` assertion, verify how the installed API compares type identity, strings, arrays, padding, and floating-point values. Use tolerances from the contract rather than from a failing observed result. A report may log only failures; zero recorded assertion errors does not by itself prove an assertion executed.

Use [report evidence](report-evidence.md) to keep process, completion, inventory, report, and assertion claims separate. Provider-specific wrappers teach two alternatives; do not maintain duplicate production suites without a migration/comparison need.
