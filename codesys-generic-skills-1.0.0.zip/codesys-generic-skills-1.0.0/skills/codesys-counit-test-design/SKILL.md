---
name: codesys-counit-test-design
description: "Write CODESYS CoUnit tests and multi-invocation suites using the installed FB_TestSuite, TEST, assertion, completion, and runner APIs. Use for CoUnit test authoring; not for silently changing the project test provider."
---

# CoUnit test design

Read [CoUnit API guidance](references/counit.md), [test design](references/test-design.md), and [complete CoUnit source](assets/counit/README.md). The examples use a supplied API shape with no exact fork version claim; verify the installed library.

Define input, initial state, public call sequence, expected output/state, prohibited effects, time source, and completion/timeout rule before writing assertions. Follow the project's suite naming and runner pattern. Use existing CoUnit for an existing CoUnit suite unless an authorized migration says otherwise; do not impose it on unrelated projects.

Keep a multi-call testee and phase in the suite FB or supported VAR_INST. An ordinary method-local testee is appropriate only for a truly one-call case. Use TEST to establish the case context before assertions. Return between phases, and call TEST_FINISHED only after the final required observation. Reset product and test state independently; do not reuse a completed registration by merely resetting the product.

The supplied positive suite declares its instance and calls CoUnit.RUN cyclically under the documented automatic registration model. Verify that model for the fork and avoid also invoking the suite manually. Prevent two active tests from resetting the same fixture. Use exact typed assertion arguments and contract-backed floating-point tolerances.

Add accepted/rejected command, reset-plus-second-run, and guard-failure cases where relevant. For harness changes, run the separate failed-assertion and finite-host-timeout probes. CoUnit has no universal abort API assumed by this skill; use the actual fork/host recovery path and the fixture's explicit cancellation hook.

Reconcile expected/executed inventory and preserve complete fresh report evidence. Completion, process exit, and XML existence do not establish assertion PASS. Return source objects, selected cases, observed results, and version/environment limits.
