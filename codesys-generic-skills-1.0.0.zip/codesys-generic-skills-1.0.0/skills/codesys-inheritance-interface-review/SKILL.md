---
name: codesys-inheritance-interface-review
description: "Review CODESYS EXTENDS and IMPLEMENTS, overridden FB bodies/methods/properties, interface callers, public DUT changes, and lifecycle base calls. Use when a change can affect derived or downstream behavior."
---

# Inheritance and interface review

Read [behavioral examples](references/inheritance-interfaces.md) and [special lifecycle rules](references/lifecycle.md).

Read parent and child declarations and bodies, all relevant method/property overrides, implemented interfaces, and public callers. Write the obligations inherited by the child: output/status updates, command acceptance, fault flags, cleanup, reset, and timing. Match signatures before reviewing behavior, but do not stop there.

Check whether the child body invokes required parent behavior exactly once, or implements an explicitly permitted equivalent. The reference shows a child updating its own lamp while forgetting the inherited active status. Calling SUPER^() blindly can also be wrong when it duplicates or contradicts intended effects.

Trace an operation through the public base/interface view of the derived instance, then its cyclic call. Test status changes in both directions, rejection, reset, and a second run. Preserve property Get/Set semantics and actual nested ownership; same names or shape are not substitutability proof. Check exact type compatibility for shared DUTs and in-out parameters.

Treat FB_Init, FB_Reinit, and FB_Exit separately from ordinary methods. Do not add SUPER^.FB_Init. Do not assume initialization hooks run for an implementation-only online change. The Test Manager base-body/Execute rules are specific to its template, not a rule for all inherited FBs.

Report structural, behavioral, timing, and operational compatibility separately. A material finding names the parent/public obligation, changed child, calling view, trace, and broken output/effect. Private helper or folder changes are not compatibility defects without an actual fixed dependency. State native checks not run.
