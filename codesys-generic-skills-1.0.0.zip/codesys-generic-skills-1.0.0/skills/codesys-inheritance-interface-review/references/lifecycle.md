# State lifetime, reset, retention, and online change

## Storage duration

Ordinary method-local variables are reinitialized on method entry. A phase variable in ordinary method `VAR` cannot track a multi-call operation. Place it in the owning FB, or use method `VAR_INST` where supported. Both refer to state held with the FB instance; neither means power-loss retention.

```iecst
(* Defective for a three-invocation operation: METHOD Advance : BOOL *)
VAR
    uiPhase : UINT;
END_VAR
uiPhase := uiPhase + 1;
Advance := uiPhase >= 3;
```

An FB-owned `uiPhase`, or the same method declaration using `VAR_INST`, advances across calls. Reset it deliberately. A stateless helper's ordinary method-local variable is sound and should not be moved to instance state by blanket rule.

| Storage | Across method calls | Across application reset/power loss |
|---|---|---|
| Method `VAR` | No state guarantee beyond invocation; normal locals reinitialize | Not a retention mechanism |
| Method `VAR_INST` | With the owning FB instance | Same lifetime rules as that instance, not automatically retained |
| FB `VAR` | With that FB instance | Ordinary application-state rules unless explicitly remanent |
| `RETAIN` | While instance/storage survives | Target-backed remanence with reset-specific limits |
| `PERSISTENT` configuration | Versioned persistence rules of the application | Requires supported persistence and compatible declarations/storage |

## Reset and runtime-event matrix

The reset rows below summarize documented CODESYS categories. The other rows are review obligations, not blanket guarantees. Bind them to the project's runtime, storage method, and declaration changes.

| Event | Ordinary variables | RETAIN | PERSISTENT | Required check |
|---|---|---|---|---|
| Another cyclic invocation | Keep instance state | Keep | Keep | Clear pulse outputs deliberately; do not rerun startup accidentally |
| Application stop/start without reset | Distinct from reset; inspect actual state | Inspect | Inspect | Timer elapsed-time behavior, outputs and rearming |
| Reset warm | Reinitialize | Keep | Keep | Transient commands cleared; retained config revalidated |
| Reset cold | Reinitialize | Reinitialize | Keep | No stale progress resumes from ordinary state |
| Reset origin | Reinitialize/remove application context | Reinitialize | Reinitialize | Restore only approved config and application |
| New download | Ordinary state reinitialized | Do not assume preserved | May survive under configured persistence compatibility | Declaration/name/type changes and migration |
| Implementation-only online change | Code may change without replacing data | As applicable | As applicable | Do not rely on lifecycle hooks running |
| Declaration-changing online change | Affected instance data may be copied | As applicable | As applicable | Rebind raw aliases; reconcile state/invariants |
| Power interruption/restart | Startup path | Depends on target-backed storage | Depends on persistence mechanism | Abrupt loss, partial writes, checksums/version, physical outputs |

Keeping bytes is not proof that those bytes remain valid. Store configuration identity/version, validate loaded values, and define migration or rejection. Avoid retaining pending commands, raw memory addresses, or a "safe" Boolean as a substitute for establishing the new runtime state. The correct startup output depends on the equipment and its safety design.

## Three different kinds of base calls

An FB-body `SUPER^()` invokes the base body. An ordinary `SUPER^.Reset()` invokes a base method when the behavior contract calls for it. Special methods `FB_Init`, `FB_Reinit`, and `FB_Exit` follow system lifecycle rules; do not copy an ordinary constructor convention into them.

CODESYS specifically forbids `SUPER^.FB_Init` because implicit initialization has already run. For an affected declaration-changing online change, reason about old exit, new initialization, old-to-new copy, and reinitialization after copy. New initialization work can be overwritten by copying. Interface values receive special compiler handling; raw pointers and references may require rebinding. A code-only online change may not invoke these hooks at all.

Do not use `FB_Init` as a routine operator reset. Supply a public reset/abort contract that handles subordinate timers, edge state, pending commands, outputs, and fixtures. A lifecycle method returning BOOL does not mean the system interprets that result like an ordinary command result.

## Review procedure

Pick each reachable state and apply reset, abort, interruption, and re-entry. Record input, owned state, visible output, borrowed resource, and required next state. Include a second complete run after reset. For a pointer-bearing object, change the underlying binding and check that no old address remains active. For retained configuration, test a compatible value and an invalid/incompatible one.

Separate source proof, compiler evidence, simulator behavior, controller restart behavior, and actual power-loss storage evidence. A soft runtime stop cannot establish abrupt power-loss durability.

## Source basis

Language/API claims use the sources below, consulted 2026-09-08. Examples and review procedures are newly authored; they are not copied vendor tests or evidence of native execution.

- [CODESYS: Object Method](https://content.helpme-codesys.com/en/CODESYS%20Development%20System/_cds_obj_method.html)
- [CODESYS: VAR_INST](https://content.helpme-codesys.com/en/CODESYS%20Development%20System/_cds_vartypes_var_inst.html)
- [CODESYS: resetting applications](https://content.helpme-codesys.com/en/CODESYS%20Development%20System/_cds_reset_application.html)
- [CODESYS: preserving retain data](https://content.helpme-codesys.com/en/CODESYS%20Development%20System/_cds_preserve_data_with_retain_variables.html)
- [CODESYS: FB_Init, FB_Reinit, FB_Exit](https://content.helpme-codesys.com/en/CODESYS%20Development%20System/_cds_method_fb_init_fb_reinit.html)
