# Inheritance and interface behavior

Read the parent body, every overridden method/property, and the caller's expected behavior. An interface match establishes callable shape, not state transitions, output updates, reset, timing, or substitutability.

## Derived body loses parent behavior

Assume `FB_Base` defines input `xCommand`, output `xActive`, and this body:

```iecst
xActive := xCommand;
```

A child adds an output `xLamp`:

```iecst
FUNCTION_BLOCK FB_Child EXTENDS FB_Base
VAR_OUTPUT
    xLamp : BOOL;
END_VAR
(* Defective child body for this contract: *)
xLamp := xCommand;
```

The child's own body does not establish the required base update. The corrected body for this example is:

```iecst
SUPER^();
xLamp := xActive;
```

An explicit equivalent implementation can be valid when the governing contract permits it, but it must preserve all parent obligations. Do not require `SUPER^()` mechanically where the base behavior is intentionally replaced. Calling it twice may duplicate effects.

Test TRUE then FALSE through the derived instance and check *both* `xActive` and `xLamp`. Also test any command/reset methods through an interface-valued reference to the child, then run the child's cyclic body. A test of the parent alone does not cover the child. The complete bounded-job example offers a separate interface-driven state contract for this style of test.

## Public behavior checklist with concrete outputs

For each method/property, list exact return type, parameter directions/types, read/write behavior, allowed call states, success/rejection effects, and lifetime. Check all getters and setters of a property, not just its declaration. Test callers holding a base/interface view, not only callers with the concrete child type.

Do not assume a derived DUT or a similarly shaped structure can substitute for an exact in-out parameter type. Matching field names do not prove type compatibility. Preserve library namespaces, strict enum meanings, and downstream callers when changing shared declarations.

CODESYS dispatch depends on the actual call form and declaration. Inspect the relevant documentation and compiler result rather than importing assumptions from C++/Java. A property read can call code; repeated reads need not be a coherent snapshot.

## Lifecycle exceptions

Use [lifecycle rules](lifecycle.md) for FB initialization and online change. In particular, do not add `SUPER^.FB_Init`. The supplied Test Manager pattern also distinguishes its required base-body call from its `Execute` override; it is a provider API rule, not a global inheritance rule.

## Review result

A useful finding names the base obligation, child location, calling view, input/call trace, wrong output or effect, and a regression that observes it. Do not report private renames as compatibility failures unless an actual consumer or fixed contract depends on them.

## Source basis

Language/API claims use the sources below, consulted 2026-09-08. Examples and review procedures are newly authored; they are not copied vendor tests or evidence of native execution.

- [CODESYS: calling a method](https://content.helpme-codesys.com/en/CODESYS%20Development%20System/_cds_method_call.html)
- [CODESYS: Object Method](https://content.helpme-codesys.com/en/CODESYS%20Development%20System/_cds_obj_method.html)
- [CODESYS: FB_Init, FB_Reinit, FB_Exit](https://content.helpme-codesys.com/en/CODESYS%20Development%20System/_cds_method_fb_init_fb_reinit.html)
