---
name: codesys-plcopenxml-package-review
description: "Review CODESYS PLCOpenXML generation/import and source-object closure: DUTs, FBs, nested methods/properties, libraries, conflicts, skipped objects, and round-trip semantics. This concerns PLC objects, not an agent language package."
---

# PLCOpenXML and source-object review

Read [object-preserving import](references/plcopenxml.md). Determine the actual XML dialect, generator, CODESYS importer/version, canonical source, and requested dependency closure.

Verify declarations/bodies and each nested method/property belong to the right object. Include required interfaces, types, libraries, callers/tests, and task/program dependencies. Do not assume all CODESYS extensions or device/visualization objects survive plain PLCOpenXML; use the project's supported export path and record unsupported coverage.

Check unique identity, deterministic source assembly where required, explicit same-name conflict handling, and complete import errors/warnings/skips. A skipped stale object is not a successful update. Reject different content with the same identity unless an explicit replace contract governs it.

Import into a fresh authorized offline project, reacquire handles, enumerate actual objects, and compare the worked before/after map. Compare signatures, bodies, children/accessors, attributes, and relevant wiring, not just object counts. Build the full intended closure and test the changed behavior.

Classify byte identity, permitted normalization, structural preservation, compiler acceptance, and runtime behavior separately. No generic source index in this bundle claims to be a native import format. DEC/IMP is one optional repository convention.

Return exact inputs/generated/imported artifacts, comparison, diagnostics, unexpected omissions or changes, and native evidence gaps. Do not edit generated XML alone when canonical source remains unchanged, or allow import to change live devices without permission.
