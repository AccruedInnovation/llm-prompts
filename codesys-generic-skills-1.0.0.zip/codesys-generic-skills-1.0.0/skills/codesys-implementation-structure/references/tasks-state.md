# Per-task state and concurrency review

## Build the actual call map

For each task identify period/event trigger, priority, core affinity, ordered program calls, input mapping, output owner, bus-cycle relationship, shared state, and callers outside the task. Treat the documented input/process/output behavior as per-task. Do not invent one atomic application-wide end-of-scan commit for arbitrary variables.

An ordinary call `fbOther.Publish(value := sample)` executes in the caller's context. The object's folder or use by a different program does not dispatch the call to that program's task. Only an explicit queue/scheduler interface creates that boundary. If another task also accesses the same FB, review concurrent access to its fields and its methods.

## Mixed-version structure: concrete failure

Suppose a writer publishes `{sequence, pressure}` and each pair must describe one sample. Initial state is `(10,100)`. The following interleaving is possible without a consistency protocol:

| Step | Writer task | Reader task |
|---|---|---|
| 1 | Write sequence = 11 | |
| 2 | | Read sequence = 11 |
| 3 | | Read pressure = 100 |
| 4 | Write pressure = 110 | |

The reader observes `(11,100)`, neither complete sample. Atomic scalar fields, one writer, or copying the structure locally does not alone fix a concurrent multi-field read. A lower task priority on another core is not exclusion.

### Complete solution at the design level

For a small publication object, use the environment's documented synchronization primitive. Both participants follow the same protocol: producer builds a task-local sample; producer acquires exclusive publication access, copies the bounded structure, and releases; consumer acquires that same access, copies to task-local storage, and releases; consumer then works only on the local copy. Protect publication metadata as well as payload.

This design requires bounded copy time, a defined lock wait/try-failure policy, no blocking I/O while held, and an acceptable priority-inversion analysis. A hard-deadline task should use an approved bounded/try-acquire strategy or a qualified queue with a specified busy/drop behavior. Do not invent a function name or implement a spin lock in ST from a plain BOOL. Select the actual documented primitive supported by the runtime and test its timing.

An ownership-transferring buffer/queue can avoid lock waiting, but needs capacity, full/empty handling, ownership return, publication ordering, and a no-reuse-before-release rule. A double buffer alone permits reuse while a slow reader still reads. An ST sequence counter alone does not prove atomicity or memory ordering. Reuse a proven implementation rather than presenting one as lock-free without evidence.

## Commands across different rates

A 1ms producer can emit and clear a one-call pulse before a 10ms consumer runs. Either keep the pulse entirely within one task's ordered calls or use a command mailbox/queue with a defined consumption and acknowledgment rule. Decide whether repeated commands collapse, queue, reject, or overwrite; do not silently turn edge-triggered commands into level-triggered requests. Sequence IDs need a wrap policy.

## Same-task traces

A stateful FB advances when called, not simply because a PLC scan exists. Two calls to the same instance in one task invocation can advance it twice. Skipping a call can leave the instance's last outputs unchanged, including a pulse that then remains asserted longer in wall time. Review all paths, including conditional calls and early returns.

| Case | Required reasoning |
|---|---|
| First call | Binding and config valid before use; no unintended command |
| Running call | One defined unit of progress, bounded work |
| Terminal call | No unexpected repeated effect or pulse |
| Reset + start in one invocation | Defined precedence and acceptance |
| Abort + completion together | One explicit winner, no double result |
| Invalid dependency | Output and fault updates still occur as required |
| Skipped call | Defined held-output and clock behavior |
| Same instance called twice | Intentional behavior or a call-graph defect |

A CASE branch selected on entry does not execute a later CASE branch merely because it assigns a new state. Separate IF statements can observe a just-changed state later in the same invocation. Use a trace to decide whether immediate transitions meet the contract.

## Evidence

Use deterministic invocation traces for state logic and explicit-clock tests for elapsed behavior. Use task/runtime observations for scheduling, multicore synchronization, I/O update timing, jitter, and watchdog exposure. Keep units and maxima, not just average cycle time. A Python event model can expose an interleaving; it cannot prove the actual runtime memory model.

## Source basis

Language/API claims use the sources below, consulted 2026-09-08. Examples and review procedures are newly authored; they are not copied vendor tests or evidence of native execution.

- [CODESYS: multicore](https://content.helpme-codesys.com/en/CODESYS%20Development%20System/_cds_multi_core.html)
- [CODESYS: synchronization of concurrent execution](https://content.helpme-codesys.com/en/LibDevSummary/synchronization.html)
- [CODESYS: calling a method](https://content.helpme-codesys.com/en/CODESYS%20Development%20System/_cds_method_call.html)
