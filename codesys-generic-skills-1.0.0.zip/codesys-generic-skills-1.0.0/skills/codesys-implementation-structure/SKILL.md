---
name: codesys-implementation-structure
description: "Define a compact CODESYS object, interface, task, state, and I/O ownership design before shared or stateful changes. Use when design authority is delegated; reuse any existing fixed contract rather than creating a competing one."
---

# CODESYS implementation structure

Read [structure and increments](references/structure-and-slices.md) and relevant [task/state rules](references/tasks-state.md).

Identify the outcome and fixed project contracts. Inspect actual project/library/application/POU topology, nested methods/properties, DUTs/interfaces/GVLs, tasks, I/O and test callers, source/export format, and generated artifacts. No external planning system or prescribed contract schema is required.

Define one owner for each public contract, state set, configuration, and physical output. Identify command source, acceptance, execution, completion, rejection, fault, reset/abort, and any acknowledgment. State units/ranges, parameter directions, alias lifetime, task call order, retention, and error precedence where they affect correctness.

Use the bounded-job example's structure table to make these decisions concrete. Do not require its interface abstraction for a simpler existing FB. Shared-state designs need a consistency protocol, not just a GVL and a single writer. Private helper and folder choices stay local unless a real consumer depends on them.

Provide the smallest complete caller/test path for the change. Keep native compile, analysis, provider tests, simulator behavior, and physical-target claims separate. Identify temporary runners/wiring and cleanup. For shared interfaces, settle the contract before independent implementation on both sides; reuse existing tested libraries and tooling.

Return a compact ownership/call map, public signatures or exact references, state/error behavior, evidence plan, and only genuinely unresolved decisions. A local method repair often needs no separate design artifact. Do not expand authority into target operations or unrequested architecture changes.
