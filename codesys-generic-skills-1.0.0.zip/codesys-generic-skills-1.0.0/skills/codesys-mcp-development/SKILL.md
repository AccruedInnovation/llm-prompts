---
name: codesys-mcp-development
description: "Use an available CODESYS MCP server for project-aware ST inspection, library lookup, bounded edits, diagnostics, and canonical-source read-back. Use only discovered tool schemas; never assume a custom ScriptEngine extension exists."
---

# MCP-assisted CODESYS development

Read [edit/read-back and recovery](references/automation-roundtrip.md). Discover the current server schemas, exact project/application, object tree, child methods/properties, library declarations, and relevant callers. Tool names from another installation are examples, not an available API contract.

Resolve uncertain signatures from the current project/library before editing. Use cheap/precompile diagnostics where appropriate, but run a full build when the claim needs one. Tool output or library documentation informs actual behavior; it does not override the requested contract or local source ownership.

For an authorized edit, preserve the preimage and use an unambiguous object path. Change the narrow child/section. Read it back, enumerate affected siblings, check declarations and properties, and transfer the result into the project's canonical source. Do not force DEC/IMP storage onto a project whose native file is canonical.

Treat one script call as one invocation, not rollback-capable atomicity. A script exception or timeout may follow partial changes. Inspect stopped/running process state and actual object content before retrying. The reference supplies a complete child-edit and mixed-state recovery procedure. Do not overwrite unrelated work with a whole-project rollback.

Custom scripts need verified argument/path/polling contracts. A script that polls internally needs no second agent-side polling loop unless its actual protocol calls for one. Never infer compile/test success from the script returning.

Complete the matching source comparison, required build/analysis/test checks, and cleanup. Return exact changed objects, before/after content or hashes, evidence, and uncertainty. Source inspection/editing does not authorize project deletion, dependency changes, physical-target operations, or credential use outside the task.
