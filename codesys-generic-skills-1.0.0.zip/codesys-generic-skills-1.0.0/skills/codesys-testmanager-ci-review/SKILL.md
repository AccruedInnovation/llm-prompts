---
name: codesys-testmanager-ci-review
description: "Review CODESYS Test Manager discovery, category/name selection, generated applications, CI reporting, timeout/abort, restoration, and repeat runs. Use for provider integration or migration evidence."
---

# Test Manager CI review

Read [Test Manager execution](references/testmanager.md) and [report evidence](references/report-evidence.md). Bind the installed IDE/compiler, Test Manager/test library, runtime, gateway, script, selected project/libraries/categories/names, and candidate.

Follow discovery into generated test applications and actual executed cases. A category filter, excluded library, or generated-application split can remove a required case. Compare exact identities rather than only totals. Preserve compile, process, report, assertion, and cleanup states separately.

Test one positive selected run, a complete aggregate run, repeated execution, failed assertion, timeout with Abort, missing/partial/stale report, interrupted download/host, and restoration as relevant to the change. Do not interpret Execute TRUE, process zero, or an HTML report as PASS without the required case results. Preserve the first failure when later stages also fail.

Review application backup, generated test code, controller removal/restoration, and whether cleanup can actually run after the specific failure. A test command may perform download/start/stop effects; confirm the allowed target before execution. Check that no production I/O or existing application gets modified outside permission.

For a provider comparison, bind the same behavior/candidate and comparable environment, then compare inventory, assertion outcomes, exception/timeout handling, report freshness, cleanup, and next-run state. Two equally broken providers are not a qualified migration. Keep the existing provider policy unless an authorized decision changes it.

Return source/selection bindings, actual reports and failures, environment limits, and a concrete missing check. No package installation or template alone proves runtime reliability.
