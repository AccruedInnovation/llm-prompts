---
name: codesys-implementation-structure-review
description: "Compare actual CODESYS object ownership, signatures, task/state flow, lifetime, and effects against a supplied design. Use for conformance review while preserving permitted private implementation choices."
---

# Implementation-structure conformance

Read [worked structural comparisons](references/structure-and-slices.md). Bind the actual candidate and the supplied design's fixed obligations. Do not invent a required external contract format.

Compare public object/signature ownership, parent/interface behavior, nested children, task/call paths, state/config/output authority, references/in-out lifetime, retention/reset, I/O effects, generated/source boundaries, and test consumer. Use exact source evidence and native results where available.

Distinguish a permitted helper rename from moving execution into a different task. The former can preserve all obligations; the latter can change timing, concurrency, and output semantics despite identical signatures. Likewise, lost inherited status or replacing a queued command with a direct foreign-task method call is behavioral, not cosmetic.

Classify each material difference as conforming, permitted local choice, material divergence, or evidence gap. Name the changed obligation, code path, and consequence. Do not use directory similarity, line counts, or type counts as a correctness score.

Check integration and cleanup of temporary runners, test applications, aliases, and wiring. A repository inventory does not prove compiler acceptance, deadlines, restart durability, or target safety. Keep those evidence gaps visible.

Return only meaningful findings with source location, controlling design, expected/actual behavior, allowed repair or decision route, and regression evidence. Do not redesign an accepted structure because another style would be more familiar.
