---
name: codesys-testmanager-test-design
description: "Write CODESYS Test Manager IEC unit tests based on the installed TM.Testcase template, including Setup, repeated Execute, Abort, Teardown, assertions, categories, and finite timeouts."
---

# Test Manager test design

Read [provider guidance](references/testmanager.md), [test design](references/test-design.md), and [complete Test Manager source](assets/testmanager/README.md). Confirm the actual generated method signatures and library namespace before adapting examples.

Define the behavioral case independently of the provider. Add a test FB derived from TM.Testcase with the required discovery attributes. Preserve the installed template's required SUPER^() body call. Implement Execute itself; do not call SUPER^.Execute in the supplied template pattern.

Setup prepares the testee and test state once. Execute calls the testee once per intended phase and returns FALSE while unfinished. Keep phase in instance storage, not ordinary method-local VAR. Return TRUE only after the required observation and assertion/error state are ready. Do not clear an earlier failure before completion. Setup/Teardown return values in the supplied template do not make those methods multi-scan waits.

Abort resets or releases the test's resources and returns TRUE only when cleanup completes; bound any asynchronous cleanup. Teardown leaves the next test a known initial state. A PLC exception or lost connection may prevent either method from running, so keep external recovery evidence separate.

The positive example category is SkillsExamples; deliberate-failure and noncompletion cases use SkillsHarnessNegative. Keep those selections distinct and verify the exact discovered/executed names. Test reset and a second run. The shared scenario's count describes invocations, not elapsed time.

The IEC Unit Test workflow may generate, download, start, and remove applications. Authoring these source files does not authorize controller effects. Use an explicitly authorized disposable environment. Return complete source and selection, raw/parsed result evidence, cleanup state, and checks not run; do not promote the provider from template conformance alone.
