# PLCOpenXML and object-preserving round trips

XML well-formedness is only the first check. Identify the exported schema/dialect, generator version, CODESYS import behavior, libraries, device types, and nested objects. CODESYS-specific constructs may need extension content or native export; do not assume plain PLCOpenXML represents every project object losslessly.

## Minimal import closure

For the changed FB include its interface, DUTs/enums, required libraries, relevant children, callers/test wrapper, and any required task/program configuration. Each object needs one canonical owner. A split declaration/body representation is optional repository practice; use the project's actual assembly rules.

A same-name conflict must have an explicit outcome: replace the intended object, reject, or a documented rename. Silently skipping the incoming object can leave stale behavior while import reports no exception. Byte-identical duplicates can be deduplicated when the contract allows it; same identity/different content must not use last-writer-wins by accident.

## Worked object inventory

Example before/after export map:

| Object | Before | Intended after |
|---|---|---|
| `FB_Filter` declaration/body | Known content | Unchanged |
| `FB_Filter.Validate` | Original body | New body only |
| `FB_Filter.Reset` | Present | Same declaration/body |
| `FB_Filter.Value/Get` | Present | Same declaration/body |
| `FB_Filter.Value/Set` | Present | Same declaration/body |
| Task call and library references | Known identities | Unchanged |

Export, import into a fresh offline project, capture every import warning/error/skip/conflict, reacquire handles, enumerate the actual tree, and compare this map. A count of five objects alone does not prove the right five objects survived. Compare method parameter direction/types and property accessors as well as names.

## Comparison levels

Use byte comparison where exact text is required; permit declared line-ending/metadata normalization only where it preserves meaning. Then check object topology/signatures, full compile, and behavior for the affected public contract. XML attribute ordering can be irrelevant to semantics; a missing pragma is not. Native-generated IDs may legitimately differ; define the accepted mapping rather than dropping every identity check.

Keep deterministic source-to-export generation separate from the question of whether a native importer reorders metadata. Do not edit only generated XML when source remains canonical. If the native project is canonical, export and version the actual project according to its policy rather than forcing a plaintext repository format.

## Source basis

Language/API claims use the sources below, consulted 2026-09-08. Examples and review procedures are newly authored; they are not copied vendor tests or evidence of native execution.

- [CODESYS ScriptingEngine: ScriptProject](https://content.helpme-codesys.com/en/ScriptingEngine/ScriptProject.html)
