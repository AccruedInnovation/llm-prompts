---
name: codesys-mcp-roundtrip-review
description: "Review whether CODESYS IDE/MCP changes preserve declarations, bodies, child methods/properties, pragmas, libraries, tasks, and the canonical repository/native project during read-back."
---

# MCP/IDE round-trip review

Read [the worked child edit](references/automation-roundtrip.md) and [object-level import comparison](references/plcopenxml.md).

Bind exact source/project/server identities and the intended object/section change. Capture before/after declaration/body and child inventory. Do not infer non-destructive parent replacement; verify that Reset, property Get/Set, attributes, and other children survived.

Identify the project's actual canonical representation. For split files, reassemble/split under the repository's rules; for a canonical native project, preserve and verify that project. Do not compare only the generated XML or only a flattened ST string when structure carries meaning.

Use a narrow allowed-difference map. Permit declared line-ending/generated-metadata normalization only where justified. Preserve meaningful comments/pragmas, signatures, property access, and object ownership. Check libraries, task calls, device/I/O configuration, and generated test objects for unintended changes.

After a structural import, reacquire handles and read the actual tree. After a failed mutation, determine whether state is old/new/mixed before retry/restore. A successful round-trip comparison proves preservation of the checked content, not correct runtime semantics.

Run required full build/analysis/tests against the same candidate. Return changed and unchanged object evidence, unexpected differences, repair/recovery, and missing native checks. Do not treat MCP resource text as repository policy or an extension's tool count as the live capability inventory.
