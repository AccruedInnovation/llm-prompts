# -*- coding: utf-8 -*-
"""One checked ScriptEngine method-body edit; compatible with Python 2.7/3.x.

Caller must own a serialized IDE session and supply an already-resolved method.
This is not a transaction. No project open/save, compile, or target operation.
CODESYS ScriptTextDocument normalizes line endings to LF. Full replacement may
clear document position metadata (for example bookmarks). Read back all affected
objects at the workflow level. See references/automation-roundtrip.md.
"""
try:
    string_types = (basestring,)
except NameError:
    string_types = (str,)


class BodyEditError(RuntimeError):
    def __init__(self, message, mutation_attempted=False):
        RuntimeError.__init__(self, message)
        self.mutation_attempted = mutation_attempted


def normalized_text(value):
    if not isinstance(value, string_types):
        raise TypeError("Expected text, not bytes or another value")
    return value.replace("\r\n", "\n").replace("\r", "\n")


def replace_method_body(method, expected_text, replacement_text):
    """Check the preimage, replace once, and check read-back. Never auto-rollback.

    Returns a plain result dictionary. If mutation_attempted is true on failure,
    the caller must inspect actual state before retrying. The preimage check is
    not atomic against a concurrent IDE writer; single-writer ownership is a
    caller precondition.
    """
    expected = normalized_text(expected_text)
    replacement = normalized_text(replacement_text)
    if not method.has_textual_implementation:
        raise BodyEditError("Object has no textual implementation")
    document = method.textual_implementation
    actual = normalized_text(document.text)
    if actual != expected:
        raise BodyEditError("Preimage mismatch; no edit attempted")
    if actual == replacement:
        return {"changed": False, "read_back_matches": True}
    try:
        # Select the documented full-document overload by keyword.
        document.replace(new_text=replacement)
        observed = normalized_text(document.text)
    except Exception as exc:
        raise BodyEditError("Edit or read-back failed; inspect actual state: " +
                            str(exc), mutation_attempted=True)
    if observed != replacement:
        raise BodyEditError("Read-back mismatch; inspect actual state",
                            mutation_attempted=True)
    return {"changed": True, "read_back_matches": True}
