# Working rules and scope

## Required behavior and observed behavior answer different questions

Requirements, accepted public contracts, authorized design choices, and applicable repository rules say what the program must do. The current implementation, vendor documentation, compiler messages, and runtime traces help establish what it does. Do not silently change the first to match the second. A conflict calls for a concrete finding: expected behavior, observed behavior, exact scope, and the smallest proposed repair or contract change.

Classify a consequential claim as a language rule, CODESYS-specific rule, library/API contract, repository convention, new example choice, or unconfirmed observation. Do not treat a local naming rule or a simulator anecdote as a universal compiler rule. Keep the user's existing interfaces, intended behavior, files, and dependencies unless the assignment authorizes change.

## Use only the context needed

For a local method, read its declaration and body, owner FB, relevant parent/interface, callers, and tests. For a shared-state or lifecycle change, include all task writers/readers and initialization paths. A focused change does not need a new planning document, all specialist skills, or a full-codebase campaign.

Identify the canonical source format in this project. A native project, exported source, or a repository's split declaration/body files can each be canonical by project policy. `DEC/IMP` is one repository convention, not a required CODESYS language or native storage format. Do not install an instruction file into the project root or impose an external code style.

## Match evidence to the claim

| Evidence | Establishes | Does not establish |
|---|---|---|
| Source inspection or text check | The checked property of the supplied text | Compiler acceptance or runtime safety |
| Successful compile | Acceptance by that compiler with that dependency set | Task timing, safe aliases, correct behavior |
| Static Analysis results | Findings under that scope/ruleset with known capture completeness | Absence of all defects |
| Provider completion | The runner reached its reported completion state | Assertions passed or all intended tests ran |
| Parsed complete test report | Results for the matched candidate and selected cases | Behavior outside those cases |
| Simulator trace | Observed behavior in that simulator | Hardware I/O, real deadlines, nonvolatile storage |
| Controller observation | The measured scenario and environment | Unmeasured operating conditions or safety certification |

Report observations as `NOT_RUN`, `PASS`, `FAIL`, or `INCONCLUSIVE`; record unavailable/blocked/inapplicable reasons separately. Keep a known failed assertion even when the rest of a run is incomplete. Never erase prior failures because a retry passed.

## Effects

Offline source work does not authorize controller login, download, start/stop, reset, force/write, online change, drive motion, or I/O mutation. Verify the actual allowed environment before such actions. A test tool may download an application even when its name only says "test". Use a disposable offline project or a specifically authorized simulator for examples. Do not infer that "off" is safe for the actual equipment.

## Example status

The bundled ST is source-level teaching material with complete declared object boundaries. It has not been compiled or run in CODESYS as part of this delivery. Compile and exercise it in the target project's pinned environment before adoption. Negative examples are explicitly marked; never deploy them. A Python model or a text validator is not a CODESYS compiler.
