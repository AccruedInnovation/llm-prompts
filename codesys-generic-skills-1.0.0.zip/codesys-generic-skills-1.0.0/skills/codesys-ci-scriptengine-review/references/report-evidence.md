# Test reports, selection, and failure classification

## A passing run needs several independent facts

Identify the source candidate, compiler/libraries/runtime, test provider/fork, run ID, selected test inventory, and output path before execution. Use a new run-owned directory. Hashes identify content; they do not prove it works. When the native report lacks candidate/run metadata, bind it through a controlled launch/output record and preserve the raw report hash.

Treat these as separate observations: process completion, compile, Static Analysis, runtime test completion, report completeness, selected-test execution, assertions, and cleanup. Do not infer all from an exit code, a completion flag, or an XML file's existence.

| Condition | Appropriate result |
|---|---|
| Complete fresh report; all selected cases executed and passed | Assertion PASS for those cases |
| Complete report containing a failed assertion | Assertion FAIL even if process exit is zero |
| Missing report after completion | Report INCONCLUSIVE/absent; no test PASS |
| Partial or malformed report | Capture/parse failure; preserve bytes |
| Selected A and B, executed A only | Selection mismatch; no suite PASS |
| Zero executed tests | No proof, even if totals say zero failures |
| Old run ID or wrong candidate | Stale/mismatched evidence; reject |
| Runtime timeout with one known failed case | Keep that FAIL; overall run remains incomplete |
| Tests passed but controller cleanup failed | Assertion PASS may stand; cleanup FAIL remains |
| A second attempt passed | Keep both attempts and report the initial failure |

An optional skipped test needs a documented reason and scope. A required skipped test blocks the required claim. Do not flatten provider-specific states or assume every XML export follows JUnit semantics.

## Worked stale-report case

A previous run R41 wrote two passing cases. R42 starts but its writer fails; the launcher returns normally and a generic `results.xml` still exists. Checking only existence and failure count would accept R41 as R42. Repair with a unique output directory, a known launch/output binding, complete parse, and exact selected/executed comparison. File modification time alone is not robust candidate identity.

A delayed writer may continue after the PLC's completion variable changes. Wait under a finite protocol for a complete, stable, valid report; do not report PASS merely because a poll timed out without an explicit error. Preserve a late result as late evidence, not as proof that the original timeout never occurred.

## Minimal evidence record

For a small run a table or JSON object is enough: run/candidate, environment, requested cases, actual cases with outcomes, raw report path/hash, process exit or timeout, diagnostics, and cleanup. Include case identity and attempt number. Do not build a new reporting service for a small local edit.

## Qualification probes

Inject a harmless failed assertion, omitted selected test, stale report, malformed/partial file, no file, timeout, and interrupted run with the other preconditions valid. Demonstrate each failure reaches its intended check. A parser rejecting malformed XML does not prove it detects a well-formed report for the wrong run.

The delivery includes review cases for these scenarios. Those fixtures are authored evaluation inputs, not evidence that any provider ran them.
