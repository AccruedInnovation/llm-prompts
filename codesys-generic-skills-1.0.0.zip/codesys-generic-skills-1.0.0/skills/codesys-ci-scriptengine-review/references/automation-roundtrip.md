# MCP, ScriptEngine, import, and read-back

## Discover the actual tool surface

Inspect the connected server's current schemas and exact project/application identity. Query the object, child methods/properties, callers, library declarations, and diagnostics before editing. Tool names such as `run_codesys_script` or `get_structured_text_content` may belong to one extension; never assume every CODESYS MCP server exposes them. Preserve explicit script argument, path, polling, and timeout contracts only when verified for that installation.

One tool invocation is a sequencing boundary, not an all-or-nothing mutation. A script can change several objects and fail after the first. A timeout can leave a process and project mutation in progress. Do not blindly retry a mutation that may already have succeeded.

## Worked edit/read-back workflow

Example goal: change only `FB_Filter.Validate` implementation, preserving the FB's other children and library/task wiring.

1. In an authorized offline project copy, record project identity, canonical source revision, the parent declaration/body, and the names/types/declarations/bodies of its `Validate`, `Reset`, and `Value` property Get/Set children.
2. Read the exact old Validate body. Check the expected text/hash and one unambiguous object path. Do not edit the first global name match.
3. Replace only that child's implementation through the discovered API. Do not replace the parent FB to change a method.
4. Reacquire object handles after imports or structural replacements. Re-read Validate and every potentially affected sibling/parent. Compare before and after with a narrow allowlist.
5. Export/read back into the project's canonical format. Compare semantically meaningful content; normalize line endings only under an explicit rule. Preserve pragmas, attributes, comments, properties, and method ownership as required.
6. Build the candidate and capture fresh diagnostics; run relevant tests. Save/freeze the matching canonical source and project identity. A live IDE buffer alone is not a reproducible handoff.

## Partial failure: explicit recovery

Suppose a script changes Validate, then fails while updating a property. Stop dependent mutation. Determine whether the script/process has stopped, reacquire the project, and read all affected objects. Record actual old/new/mixed state. If only the disposable copy changed, discard that copy and recreate it from the preserved baseline, or apply a verified narrow repair. Never assume an exception rolled back changes or restore a full project over unrelated user edits.

A network timeout after a successful change is ambiguous acknowledgment: inspect before retrying. For a read-only query, a bounded retry may be harmless; for add/remove/replace, first determine actual state. A rollback must itself be read back and checked.

## ScriptEngine text example

The API's text document exposes `text`/`get_text()` and replacement operations. The bundled [replace_method_body.py helper](../scripts/replace_method_body.py) takes an already-resolved method object and checks the preimage and read-back of one body edit, with documented LF normalization. Full-document replacement can clear bookmarks/position metadata; use a narrower documented operation when preserving them is required. Its preimage check is not atomic against a concurrent writer. It does not open/save projects, discover an object, compile, roll back automatically, or touch a controller. The host workflow still owns all those obligations.

Use the exact installed ScriptEngine interpreter. An IronPython-hosted script is not ordinary host Python; CPython 3 syntax and libraries may not run there. Verify Python language/runtime compatibility and paths from actual launch scripts rather than copying a machine-specific executable path.

## Native build/analysis sequence

Use one writer/session for a shared project. Open a copy or verified template, import the exact dependency closure, reacquire handles, isolate or clear diagnostic categories, explicitly build/rebuild, explicitly invoke required Static Analysis, and collect complete typed messages. Some commands add rather than replace messages; prove freshness for each stage.

Keep enumerated/serialized/skipped counts and message-capture errors. Never use `except: continue` to lose diagnostics silently. Scope and filter are different: filtering displayed messages cannot recover findings already lost to a cap.

Run tests only after their prerequisites hold. Save raw reports and candidate/environment identity, then dispose owned online objects, logout/stop only where authorized, and verify project/runner restoration. An error during cleanup must not erase the earlier failure or produce a fabricated clean result.

## Source basis

Language/API claims use the sources below, consulted 2026-09-08. Examples and review procedures are newly authored; they are not copied vendor tests or evidence of native execution.

- [CODESYS ScriptingEngine: ScriptTextualObject](https://content.helpme-codesys.com/en/ScriptingEngine/ScriptTextualObject.html)
- [CODESYS ScriptingEngine: ScriptProject](https://content.helpme-codesys.com/en/ScriptingEngine/ScriptProject.html)
- [CODESYS ScriptingEngine: ScriptApplication](https://content.helpme-codesys.com/en/ScriptingEngine/ScriptApplication.html)
- [CODESYS ScriptingEngine: ScriptSystem](https://content.helpme-codesys.com/en/ScriptingEngine/ScriptSystem.html)
