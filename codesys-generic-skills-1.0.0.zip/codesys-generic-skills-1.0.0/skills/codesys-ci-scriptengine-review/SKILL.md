---
name: codesys-ci-scriptengine-review
description: "Review CODESYS ScriptEngine/IronPython CI scripts and launchers for explicit environment binding, partial mutations, stale handles, fresh complete diagnostics, timeouts, test reports, and cleanup."
---

# ScriptEngine and CI review

Read [automation workflow](references/automation-roundtrip.md) and [report evidence](references/report-evidence.md). Inspect the actual installed API/stubs and launcher, not just pseudocode.

Check executable/profile/compiler/library/add-on selection, interpreter compatibility, project/template identity, working directory, path/quoting, arguments, and finite timeouts. A helper for an IronPython host must not silently depend on CPython-only syntax. Configure machine bindings explicitly rather than preserving another workstation's path constants.

Trace open/import/edit/build/analysis/test/capture/cleanup. Reacquire handles after an import or structural replacement where they may be stale. Do not retain an old object reference just because its name still exists. Verify imported ownership and actual compiler input before using messages as candidate evidence.

Clear or isolate each diagnostic stage through the actual supported API, explicitly invoke the stage, and capture all enumerated messages. Keep enumerated/serialized/skipped/error counts. Never suppress failures with broad except/continue. A timeout must not become an ordinary FALSE or leave an untracked process changing the project.

Inspect partial failure: which mutations already happened, what cleanup is still permitted, and whether retry would repeat effects. The supplied text-edit helper rejects a stale preimage and verifies read-back; it is not a transaction or complete launcher.

Check run-specific reports and exact selection. Preserve assertion versus harness/capture failures. Dispose owned online resources and verify project/runner restoration without clobbering user state. Bound retries and preserve attempts. Prefer a narrow change plus regression fixtures rather than rewriting protected legacy scripts without authorization.

Return concrete failure paths, source/API evidence, safe repairs, and test results. Local unit tests of a helper do not qualify the native ScriptEngine host or controller.
