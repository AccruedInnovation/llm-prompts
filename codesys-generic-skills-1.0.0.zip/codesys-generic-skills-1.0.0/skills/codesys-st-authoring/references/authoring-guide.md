# Author a complete ST change

## Read and design

Find the full object: declaration, implementation, parent/interface, child methods and properties, referenced types, callers, wiring, and tests. Read only the relevant closure. Determine which files are canonical and which tools generate/import them. Never replace a parent object while assuming its children survive.

Before changing a public FB or method, state valid inputs, units/ranges, ownership, allowed call states, outputs, error precedence, reset, and timing. A small private edit may state these inline. Use an existing type/interface when it fits; do not add abstractions only to imitate another language.

## Practical rules

Use `:=` for assignment and `=` for comparison. Close each declaration block. Keep declarations out of an implementation-only field. A CODESYS method lives under its owning object; an exported text format that concatenates declarations and bodies does not prove that pasting that concatenation into one IDE body creates the child objects.

Use [Boolean guards](short-circuit.md), [reference/parameter rules](references-parameters.md), and [numeric checks](numeric-arrays-time.md) whenever the change contains dependent evaluation, aliases, casts, or indices. Follow [lifecycle rules](lifecycle.md) for state beyond one call. Read [task/state review](tasks-state.md) before sharing state across tasks.

Initialize outputs on every path required by the contract, including a guard failure. A method-local default does not reset FB-owned outputs. Define one-call pulses separately from latched results. A terminal result should not trigger repeated external actions on every subsequent call unless that is intentional.

Put stable configuration, live state, and observed output in distinct fields with one owner each. Ordinary local variables remain appropriate for temporary arithmetic; moving everything into an FB does not improve correctness. Do not persist raw references or addresses as configuration.

## Complete worked example

[Bounded job object set](../assets/bounded-job/README.md) includes an interface, enum, configuration type, FB, public start/reset/abort/step/getter methods, a cyclic program, a bounded variable-length array function, and a widened multiplication function. Each object has separate declaration/body files and an explicit parent record.

The job accepts a count of 1..1000 while Idle, advances exactly one unit per Step call, preserves its terminal result, and returns to Idle on Reset. Invalid configuration faults an idle job; an attempted Start outside Idle rejects without changing the existing job. This is an example contract for a pure processing object, not a universal equipment-control policy. It has no physical I/O.

The linked scenario fixture tests the actual public interface and advances between invocations. Its count is a call count, not elapsed milliseconds. Provider examples supply the complete runner/wrapper behavior instead of implying that two calls in one method equal two task cycles.

## Verify and finish

Check exact-typed calls, false/true guard branches, bounds, state transitions, reset plus a second run, and non-mutating rejection. Build/import in a disposable project for the pinned compiler/libraries. Run the selected provider and reconcile the intended versus executed test inventory. Preserve compiler, analysis, assertion, and report outcomes separately.

Read back direct IDE edits into the project's canonical source. Include all changed child objects, dependencies, and generated source required by the project. State checks not run; never label these bundled source examples native-qualified merely because they look complete.
