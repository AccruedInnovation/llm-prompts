---
name: codesys-st-authoring
description: "Author or repair CODESYS Structured Text functions, FBs, methods, interfaces, DUTs, and cyclic callers. Use for ST implementation changes requiring concrete type, guard, state, reset, or call-contract guidance."
---

# Structured Text authoring

Read [the authoring guide](references/authoring-guide.md) and [working rules](references/working-rules.md). It routes to detailed rules only when relevant. Use [complete source objects](assets/bounded-job/README.md) as examples, not a forced architecture.

## Before editing

Read the object declaration/body, relevant children, parent/interface, types, callers, and tests. Identify the canonical source and generated/imported representations. Query actual library declarations or the connected IDE where available; do not invent signatures. A split declaration/body file format is optional repository practice.

State the change's observable behavior: valid inputs/ranges/units, ownership, allowed call states, acceptance/rejection, error precedence, reset/abort, and required timing. Retain fixed public contracts. Choose private details within the task's authority without requiring unnecessary planning artifacts.

## Implement

Use exact types and direction-correct parameters. Distinguish REF= from value assignment, raw pointer dereference from reference access, and in-out arguments from owned state. Widen before risky arithmetic; establish bounds including the final loop increment. Use AND_THEN/OR_ELSE for dependent guards, but keep required calls out of skippable conditions.

Keep state across calls in the owning FB or supported VAR_INST, not ordinary method-local VAR. Clear outputs/pulses on the required paths. Define what repeated, skipped, terminal, reset, and aborted calls do. Calling a method does not dispatch it to another object's task. Never wait indefinitely for another task or device inside a cyclic call.

Preserve required parent behavior; special lifecycle methods do not follow ordinary base-call rules. Treat retained data as a separate configuration/lifecycle design, not a fix for a method-local variable.

## Check and deliver

Add tests for the changed contract and a failed precondition that reaches the intended guard. Include a second run after reset for stateful changes. Compile/import the exact object/dependency closure when the environment permits, capture fresh analysis, and reconcile selected versus executed tests. Read back any direct IDE edit into the project's canonical source.

Return actual source changes, checks/results, and exact native evidence not obtained. The included examples have complete editor sections but no native compiler/runtime qualification from this delivery.
