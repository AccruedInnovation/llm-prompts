# References, pointers, parameters, and interface values

## Mechanisms are not interchangeable

| Mechanism | Bind/pass | Access and mutability | Review limit |
|---|---|---|---|
| `REFERENCE TO T` | `r REF= value` or a compatible reference | Implicit value access; `r := value` writes through it | Nonzero is not a lifetime proof |
| `POINTER TO T` | `p := ADR(value)` | `p^` explicitly accesses pointee | Type casts can conceal bad storage/size |
| `VAR_IN_OUT` | Pass a compatible writable variable to the call | Caller storage can change during the call | Not a synchronization or ownership transfer |
| `VAR_IN_OUT CONSTANT` | Documented STRING/WSTRING variable or literal case | Read-only within callee | Do not generalize literal support to every type/version |
| Interface variable | Assign an FB implementing that interface | Call only the exposed behavior | Reference to an instance, not an owned FB copy |

For each binding, record the storage owner, point of binding, lifetime, possible writers, unbind/reset behavior, and relocation handling. Method-local storage generally does not live beyond the method. Storing its address in a longer-lived FB creates a separate lifetime defect even when the address is nonzero.

## Rebind versus copy

```iecst
(* Declaration: a,b : INT; r : REFERENCE TO INT; *)
a := 10;
b := 20;
r REF= a;
r := b;       (* a becomes 20; r still refers to a. *)
r REF= b;     (* r now refers to b; neither value is copied. *)
r := 30;      (* b becomes 30. *)
```

Required trace: after these statements `a=20`, `b=30`. A defect that uses `r := b` intending to rebind leaves future writes targeting `a`. Guard use with `__ISVALIDREF(r)` where binding can be absent:

```iecst
xPositive := __ISVALIDREF(r) AND_THEN (r > 0);
xReject := (NOT __ISVALIDREF(r)) OR_ELSE (r <= 0);
```

Do not use `r <> 0` to test the binding; that reads its referenced value. Do not add `^` as though `r` were a pointer. `__ISVALIDREF` applies to reference variables, not as a universal interface/pointer validity operator. A reference variable cannot be the base type of an array, pointer, or another reference in the documented dialect; use a supported representation rather than inventing reference arrays.

## Actual arguments and false positives

Ordinary in-out parameters need writable storage; literals, expressions, bit-addressed variables, and properties are not interchangeable with such storage. Require compatible type and, for writable strings, appropriate buffer length. A valid byte-sized BOOL variable is not the same as a bit address merely because both display TRUE/FALSE.

A complete read-only string function can use:

```iecst
(* Declaration of FUNCTION F_HasText : BOOL *)
VAR_IN_OUT CONSTANT
    sText : STRING(80);
END_VAR
(* Body *)
F_HasText := LEN(sText) > 0;
```

Its declaration includes `FUNCTION F_HasText : BOOL` before the variable block. Calling `F_HasText(sText := 'ready')` is a supported read-only string use, not an automatic writable-storage error. Keep the installed compiler's constant options in scope. A method may have input and output parameters; a repository's restriction is a style/API policy, not a universal CODESYS prohibition.

Generic `ANY` assertion APIs and `VAR_IN_OUT` APIs are also different. Inspect the exact signature. Exact-typed local expected/actual variables make types explicit when an assertion rejects mixed types, but do not claim that all `ANY` inputs universally require writable arguments.

## Aliasing, shared data, and online change

Two aliases can reach the same cell even when names differ. Trace overlapping input/output arrays and buffers, not just identical variable names. For in-place operations, establish permitted overlap before proposing a copy-eliding optimization.

Binding once to a stable FB-owned variable does not create a cross-task lock. A check followed by use can race with another task that changes the binding or content. Capture values only through a coherent access protocol; copying a concurrently modified structure can copy a mixture of versions.

Raw pointers/references may need repair after online relocation. Reconstruct addresses from stable owners; do not preserve addresses in retained configuration. The compiler handles interface variables separately during online change; do not describe that as a guarantee for raw pointers or external handles. Keep invocation lifetime distinct from nonvolatile retention.

## Known faults

Record a suspected forwarding/runtime problem as: exact construct, compiler/runtime/library versions, smallest source, expected trace, observed fault, and bounded workaround. This bundle makes no general claim that chained in-out forwarding is broken. A missing reproduction cannot justify banning valid language constructs.

See [Boolean guards](short-circuit.md) for evaluation rules and [state lifecycle](lifecycle.md) for reset and relocation review.

## Source basis

Language/API claims use the sources below, consulted 2026-09-08. Examples and review procedures are newly authored; they are not copied vendor tests or evidence of native execution.

- [CODESYS: REFERENCE TO](https://content.helpme-codesys.com/en/CODESYS%20Development%20System/_cds_datatype_reference.html)
- [CODESYS: VAR_IN_OUT](https://content.helpme-codesys.com/en/CODESYS%20Development%20System/_cds_vartypes_var_in_out.html)
- [CODESYS: Object Method](https://content.helpme-codesys.com/en/CODESYS%20Development%20System/_cds_obj_method.html)
- [CODESYS: FB_Init, FB_Reinit, FB_Exit](https://content.helpme-codesys.com/en/CODESYS%20Development%20System/_cds_method_fb_init_fb_reinit.html)
