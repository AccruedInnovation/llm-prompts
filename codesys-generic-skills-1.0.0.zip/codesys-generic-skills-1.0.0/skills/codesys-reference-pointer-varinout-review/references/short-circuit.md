# Boolean guards: AND_THEN and OR_ELSE

## Choose the operator from the evaluation contract

For Boolean ST expressions, CODESYS `AND` and `OR` evaluate their operands; do not use them to protect an unsafe operand. `AND_THEN` skips later operands after FALSE. `OR_ELSE` skips later operands after TRUE. These are CODESYS extensions for Boolean/bit conditions, not substitutes for bit-mask `AND`/`OR` on words. Verify portability before sharing source with another IEC implementation.

| Intent | Suitable form | Earlier condition establishes |
|---|---|---|
| Read only when pointer exists | `(p <> 0) AND_THEN predicate(p^)` | Non-null pointer |
| Reject missing pointer or invalid value | `(p = 0) OR_ELSE invalid(p^)` | A missing pointer already rejects |
| Index only within bounds | `inRange AND_THEN predicate(a[i])` | Index in declared range |
| Divide only with valid denominator | `(den <> 0) AND_THEN predicate(num / den)` | Nonzero denominator |
| Run two updates every invocation | Separate calls, then combine stored results | Both updates have run |
| Combine word flags | `wFlags AND wMask` | Bitwise operation, no guard |

A null guard does not prove lifetime, alignment, ownership, or freedom from concurrent rebinding. This reference assumes stable, live storage for the duration of each expression.

## Paired pointer examples

Declaration for these fragments:

```iecst
VAR
    iValue : INT := 7;
    pValue : POINTER TO INT;
    xPositive : BOOL;
    xReject : BOOL;
END_VAR
```

**Defective:** the dereference still runs when `pValue = 0`.

```iecst
xPositive := (pValue <> 0) AND (pValue^ > 0);
xReject := (pValue = 0) OR (pValue^ <= 0);
```

**Correct for the stated null-guard contract:**

```iecst
xPositive := (pValue <> 0) AND_THEN (pValue^ > 0);
xReject := (pValue = 0) OR_ELSE (pValue^ <= 0);
```

Both assignments update their outputs every invocation. An `IF` that writes TRUE only on success may retain a stale TRUE when its guard later fails. Also keep the meaning of `xReject`: renaming it to `xCanRun` without negating the condition would approve a missing dependency.

Expected results:

| Pointer / value | xPositive | xReject | Dereference |
|---|---|---|---|
| Null | FALSE | TRUE | None |
| Live / -1 | FALSE | TRUE | Yes |
| Live / 0 | FALSE | TRUE | Yes |
| Live / 7 | TRUE | FALSE | Yes |

## Bounds and division

Assume `aValues : ARRAY[-2..2] OF INT`, `diIndex : DINT`, `lrNum`, `lrDen`, `lrLimit : LREAL` and Boolean result variables. No writer may change the index/denominator between the guard and use.

```iecst
xFound := (diIndex >= -2) AND_THEN (diIndex <= 2)
          AND_THEN (aValues[diIndex] > 0);
xRejectIndex := (diIndex < -2) OR_ELSE (diIndex > 2)
               OR_ELSE (aValues[diIndex] <= 0);
xWithinLimit := (lrDen <> 0.0) AND_THEN (lrNum / lrDen <= lrLimit);
```

The division guard addresses zero only. For an external floating-point input, define finite-value, range, and near-zero policy separately. A true lower-bound check alone does not establish the upper bound. An index converted from an unsigned type must remain representable in the comparison type.

## Parentheses and evaluation boundaries

**Defective**, even though it contains `AND_THEN`:

```iecst
xPositive := ((pValue <> 0) AND (pValue^ > 0)) AND_THEN xEnabled;
```

The eager inner expression can already fault. Move the guard to the boundary that actually protects the dereference. Make mixed conditions explicit; do not rely on the reader remembering relative precedence. For a complex dependent sequence, nested `IF` statements are often clearer.

## Do not skip required effects

Assume both methods update independent status every call and return BOOL. This edit changes behavior:

```iecst
(* Defective replacement when both updates are required. *)
xReady := fbA.Update() AND_THEN fbB.Update();
```

When A returns FALSE, B no longer updates. The same error occurs with `OR_ELSE` after a TRUE left result. Use explicit ordering:

```iecst
xA := fbA.Update();
xB := fbB.Update();
xReady := xA AND xB;
```

Do not call timers, edge detectors, diagnostics, acknowledgment handlers, or watchdog services inside a skippable condition unless skipping is intentional and tested. A property getter can also have effects or a changing value; inspect it before treating it as a pure field read.

## Review and test method

Locate every dereference, index, division, reference/interface access, and stateful call inside Boolean expressions. Identify the *first unsafe evaluation*, not just whether a short-circuit token appears. Trace both left-result branches and the exact result/side-effect count. Test both outcomes of each guard with unrelated prerequisites valid. Test a formerly TRUE output on the next invalid input.

Use instrumented harmless predicates to show skipped versus executed operands; null-dereference negative probes belong only in an isolated test runtime with a recovery plan. A successful non-null case cannot prove the null guard. Preserve sound eager expressions over already-computed values and bit masks rather than replacing every AND/OR by search-and-replace.

## Source basis

Language/API claims use the sources below, consulted 2026-09-08. Examples and review procedures are newly authored; they are not copied vendor tests or evidence of native execution.

- [CODESYS: AND_THEN](https://content.helpme-codesys.com/en/CODESYS%20Development%20System/_cds_operator_and_then.html)
- [CODESYS: OR_ELSE](https://content.helpme-codesys.com/en/CODESYS%20Development%20System/_cds_operator_or_else.html)
- [CODESYS: ST expressions](https://content.helpme-codesys.com/en/CODESYS%20Development%20System/_cds_st_expressions.html)
