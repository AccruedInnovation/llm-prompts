---
name: codesys-reference-pointer-varinout-review
description: "Review CODESYS REFERENCE TO, POINTER TO, ADR, REF=, dereferencing, VAR_IN_OUT, VAR_IN_OUT CONSTANT, interface bindings, aliasing, and storage lifetime. Use for wiring, buffer, parameter, and reference-bearing changes."
---

# References, pointers, and parameter review

Read [mechanisms and examples](references/references-parameters.md), [Boolean guards](references/short-circuit.md), and [lifecycle](references/lifecycle.md) as needed.

## Build a binding record

For each alias name the storage owner, base type/size, bind point, required lifetime, permitted readers/writers, and reset/relocation behavior. Track actual storage, not names. Two arguments can alias the same buffer or overlap partially. A pointer to a method-local value must not outlive that call.

Trace REF= and := separately. Reference assignment copies through the current binding; rebinding changes its address. Use implicit reference access, not pointer syntax. __ISVALIDREF checks a reference's nonzero binding; it does not prove lifetime or apply to every interface-valued variable.

Use AND_THEN and OR_ELSE where a later dereference depends on an earlier condition. Inspect nested eager operators and changing properties. Establish stability for the entire check/use, including other tasks; a null guard cannot repair concurrent rebinding.

For each actual argument inspect the installed formal parameter signature. Writable in-out storage, read-only string constants, generic ANY values, raw pointers, and interface values have different rules. Preserve valid VAR_IN_OUT CONSTANT STRING/WSTRING literal calls. Do not pass a bit address, property, temporary, or literal where an ordinary in-out requires writable compatible storage.

## Checks

Use the worked rebind/copy trace; exercise absent and valid bindings, alias overlap where permitted, invalid-index branches, rebind/reset, and an online-change scenario where required. Verify shared-data consistency separately from pointer validity. Treat a forwarding-fault anecdote as unconfirmed until an exact reproduction and version exist.

Return concrete findings with owner, expected lifetime, failing operation/call trace, supported fix, and required compiler/runtime evidence. Do not ban all references, all in-out forwarding, or all method-local variables to avoid reasoning about a specific defect.
