---
name: codesys-test-provider-selection
description: "Select an existing CODESYS test provider or plan a bounded CoUnit/Test Manager comparison. Use when choosing, adding, or migrating a provider; preserve project policy and behavioral test semantics."
---

# Test provider selection

Read [test design](references/test-design.md), [CoUnit](references/counit.md), and [Test Manager](references/testmanager.md) only as relevant. Do not impose the source repository's CoUnit-default policy on a generic project.

Identify the current suite/provider, available licences and runtime, supported lifecycle, CI/report format, known defects, and requested change. For an ordinary regression, use the existing qualified provider. For new tests, use the project's established choice. A missing native installation is an evidence gap, not permission to fabricate passing tests.

Example: a project already runs CoUnit and needs one reference-guard regression. Add that test to its current suite rather than changing frameworks. A project choosing its first harness may compare one pure case, one multi-call/reset case, failed assertion, timeout, report freshness, and repeated run through both available candidates.

Keep behavioral inputs, expected outputs, allowed effects, candidate, and selection equivalent. Record discovery, completion, assertions, report quality, cleanup, environment limits, and maintenance cost. Matching empty, failed, or inconclusive runs do not prove either provider usable.

Select one normal provider unless a real integration/migration requirement needs more. Migrate in bounded groups with the same public behavior and preserved failed-case evidence. Do not maintain duplicate production suites merely because both example providers exist here.

Return the selected provider and reason, unchanged behavioral contract, exact environment/policy basis, and missing checks. A tool being installed does not grant authority to download to a controller or change project policy.
