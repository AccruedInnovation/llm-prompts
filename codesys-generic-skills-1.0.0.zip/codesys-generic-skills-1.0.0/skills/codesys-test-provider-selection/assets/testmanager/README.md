# Test Manager complete examples

Status: source-complete examples; native build and provider execution NOT_RUN. They use the supplied TM.Testcase template's protected BOOL lifecycle methods and Execute VAR_OUTPUT iErrorCode. Verify that shape against the installed wizard/library; no exact library build was identified in the supplied template.

Create the bounded-job objects first. Use Add Unit Test with TM.Testcase and optional methods, then apply the corresponding declaration/body sections listed in objects.json. Keep the base FB-body call `SUPER^()` and do not add a base Execute call. Setup and Teardown return TRUE only as a defined return value; the supplied template does not use their result to schedule repeated work. Abort may repeat but these harmless examples finish cleanup immediately.

Configure an IEC Unit Test element for exactly category SkillsExamples and the intended project/library set. Expected cases are JobImmediate and JobScenario, both PASS. The runner generates/owns its test application; do not manually add a second driver for the same cases. Scenario advances once per Execute invocation and asserts only after the final observation. It tests public interface behavior, reset, abort, invalid input, and a second completed job. It is an invocation-count test, not a wall-clock timing proof.

Select category SkillsHarnessNegative separately to test the harness. DeliberateFailure must FAIL an assertion. DeliberateTimeout returns FALSE without waiting in a blocking loop, and its finite 500ms testcase attribute should cause a timeout/abort in the verified provider. Also configure an outer timeout so a broken provider cannot wait indefinitely. The 500ms and 5000ms values are explicit example probe choices, not claimed library defaults.

Observe xCleanupComplete on Abort/Teardown through the provider's supported trace/report hook before it removes the generated application. A template returning TRUE does not prove cleanup ran after a runtime exception or host crash. Preserve actual cleanup and report results, and verify a new positive run after the negative run.

These tests contain no physical outputs, but Test Manager itself may download/start/remove an application. Run only in a specifically authorized simulator/test runtime with no unintended I/O. Do not use an active production application as the disposable test subject.
