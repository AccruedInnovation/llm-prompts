# CODESYS Test Manager test design and execution

## Choose the installed API, not a guessed one

Use the installed Add Unit Test wizard and inspect the generated `TM.Testcase` template. The complete examples here target the supplied template shape: protected BOOL methods Setup, Execute, Abort, Teardown; Execute output `iErrorCode : INT`; FB body `SUPER^()`; and `TM.Assert_Bool_IsTrue(context := THIS^, actualValue := ..., wsErrorMsg := ...)`. The supplied snapshot does not identify an exact Test Manager library build. Compile against the local generated signature before use.

Official documentation confirms one setup, repeated Execute until TRUE, normal teardown, and repeated Abort until TRUE on cancellation. The supplied template explicitly prohibits a base Execute call. These are provider-specific lifecycle obligations, not general rules for every FB.

## Complete examples

[Test Manager objects](../assets/testmanager/README.md) provide an immediate assertion case, a multi-invocation job scenario, a deliberate failed assertion, and a deliberate noncompleting case with bounded runner timeout. All cases include complete declaration/body/method source and discovery attributes. Setup clears test-owned state; Execute stimulates one phase per call; Abort and Teardown return the harmless testee to Idle.

Normal test selection uses category `SkillsExamples`. The negative cases use `SkillsHarnessNegative` and must be selected separately. Expected normal inventory is exactly `JobImmediate` and `JobScenario`; reconcile actual names in the installed report rather than assuming attributes bypass category/library filters.

Do not call Execute manually from a second task or also stimulate the same testee in PLC_PRG. Let the generated test application own the test-case lifecycle. The test fixture contains its own ordinary FB-owned job and phase; it does not share a live production instance.

## Completion and failure

`Execute := TRUE` says the case finished. It does not imply success. Evaluate assertions and the installed template's error output/report together. Do not set a nonzero error and later overwrite it with zero before the runner consumes completion. For a multi-cycle test, either assert only on final observation or keep failed state sticky across calls.

Setup and Teardown are not indefinite asynchronous work loops in this template; their return value is not an invitation to wait over scans. Abort may span calls, but needs its own bound and cleanup result. A lost connection or halted runtime may prevent PLC cleanup; the host must record that uncertainty and restore only the authorized test environment.

## Generated application and operation boundary

The IEC Unit Test element can generate code, back up the application, download and start test applications, collect results, remove test applications, and restore project state. Review the installed workflow and allowed target before invoking it. An offline authoring request does not authorize these controller effects.

Configure the exact project, libraries-to-test, category/name selection, task settings, gateway/runtime, retry limits, and finite testcase/host timeouts. Capture generated applications/selection when needed to explain a missing case. Check project and target cleanup after both success and failure; do not trust an assumed automatic restoration after interruption.

## Qualification and migration

Use existing repository policy. Test Manager is neither automatically experimental nor automatically the default in an unrelated project. For adoption or migration, exercise repeated clean and interrupted runs with the same behavior and candidate as the existing provider. Compare selection, results, runtime exceptions, timeout/abort, complete reports, cleanup, and next-run state. Two matching failures or two empty reports do not establish a usable provider.

See [report evidence](report-evidence.md) and [test design](test-design.md) for result/inventory and phase rules.

## Source basis

Language/API claims use the sources below, consulted 2026-09-08. Examples and review procedures are newly authored; they are not copied vendor tests or evidence of native execution.

- [CODESYS Test Manager: implementing a single test POU](https://content.helpme-codesys.com/en/CODESYS%20Test%20Manager/_tm_create_unit_test_with_test_blocks.html)
- [CODESYS Test Manager: Add Unit Test](https://content.helpme-codesys.com/en/CODESYS%20Test%20Manager/_tm_dlg_test_progress-1055780.html)
- [CODESYS Test Manager: assert functions](https://content.helpme-codesys.com/en/CODESYS%20Test%20Manager/_tm_assert_functions.html)
- [CODESYS Test Manager: IEC Unit Test element](https://content.helpme-codesys.com/en/CODESYS%20Test%20Manager/_tm_elem_unit_test.html)
