---
name: codesys
description: "Choose the relevant CODESYS skill for Structured Text authoring, review, tests, automation, import, or controller behavior. Use for a CODESYS task whose review scope is not yet clear; do not launch every specialist for a small edit."
---

# CODESYS task routing

Read [working rules](references/working-rules.md). Identify the requested outcome and the canonical project/source format. Inspect the exact IDE/compiler/runtime/library versions only to the extent the task needs them; do not invent an installed MCP tool or a provider preference.

## Select the smallest useful route

| Task | Skill when installed |
|---|---|
| Write or repair ST | `codesys-st-authoring` |
| AND/OR guards, skipped method calls | `codesys-short-circuit-review` |
| General correctness of a changed object | `codesys-st-correctness-review` |
| Pointer/reference/in-out/interface binding | `codesys-reference-pointer-varinout-review` |
| Tasks, state machines, timing, resets | `codesys-scan-cycle-state-review` |
| EXTENDS, IMPLEMENTS, public API changes | `codesys-inheritance-interface-review` |
| CoUnit tests or harness | `codesys-counit-test-design`, `codesys-counit-harness-review` |
| Test Manager tests or CI | `codesys-testmanager-test-design`, `codesys-testmanager-ci-review` |
| Choose or migrate test provider | `codesys-test-provider-selection` |
| MCP/ScriptEngine edits and CI | `codesys-mcp-development`, `codesys-ci-scriptengine-review` |
| Read-back or XML import | `codesys-mcp-roundtrip-review`, `codesys-plcopenxml-package-review` |
| Analysis campaign | `codesys-static-analysis-campaign` |
| Shared design or coherent increments | `codesys-implementation-structure`, `codesys-implementation-structure-review`, `codesys-execution-slicing` |
| Reproduce a defect | `codesys-evidence-reproducer` |
| Controller/I/O/operational proof | `codesys-target-operational-review` |
| Inherited codebase survey | `comprehensive-analysis-codesys-st` |

These are optional peer skills, not hard dependencies. The selected specialist carries its own references and assets. This router can still scope a task without the peers; do not pretend a missing skill ran.

For a local change, inspect the object, relevant children/parents/types, callers, and tests. For a shared-state change, inspect every writer and reader task. Separate required behavior from observed behavior. Use existing repository naming, test, and source conventions; no external package preflight or coordination service is required.

Do useful offline work when native tools are unavailable. Report the exact missing compiler/runtime evidence rather than claiming a source review proves it. Before any target effect, establish the authorized controller and procedure. End with changed/reviewed scope, concrete findings or result, checks actually run, and remaining evidence gaps.
