# Static Analysis: scope, complete findings, and safe repairs

## Establish what ran

Record the exact source, compiler/dependencies, installed analysis version, ruleset, excluded objects, rule severity/options, and evidence capture path. Build success is not proof that Static Analysis ran. Preserve native diagnostics and their object identities.

An editor/output filter only changes presentation. Removing libraries or callers to reduce warnings can change the analysis itself, especially for call graph, recursion, unused code, and cross-task rules. Prefer complete analysis with partitioned export where supported. If actual analysis scope must shrink, retain required dependencies and state the lost coverage; finish with the relevant integrated pass.

Probe the known cap and capture API. Results at a cap, explicit truncation, or unknown completeness are incomplete until resolved. Partition by library or coherent ownership, then by smaller object groups only when necessary. Do not launch a separate IDE for every FB solely because findings have FB owners.

## SA0001: unreachable code

**Defective method body:**

```iecst
IF NOT xValid THEN
    RETURN;
    xFault := TRUE;
END_IF;
```

SA0001 concerns code that cannot execute. Deleting `xFault := TRUE` removes the warning but may remove the required invalid-input indication. For a contract requiring xFault on invalid input, set it before return, and clear or preserve it on valid input according to its latch policy. Test a valid call followed by an invalid one and the recovery call. Do not impose a new fault policy merely from the diagnostic.

## SA0009: unused return value

If `Start()` reports whether a request was accepted, discarding its return may let the caller assume rejected work has started. Assigning the result to a throwaway variable is not a behavioral repair. Handle rejection or provide a contract-backed reason why that result is immaterial. Test rejection while the FB is busy, not only an idle accepted start.

A function used for an allowed effect may legitimately have an unused informational result under project policy. Check the API/requirement before marking every ignored return as a product defect.

## SA0160: recursive calls

For a getter that calls itself, resolve the actual call graph. Example `GetValue := THIS^.GetValue();` recurses rather than reading stored state. A correction can return the intended backing field, but only after confirming that field represents the public value and needs no required computation. Calls through interfaces or virtual methods require context; do not ignore possible recursion solely because no direct self-name appears.

Do not adopt the overbroad claim that all recursion is nondeterministic. The actionable concerns are finite recursion depth, stack, execution bound, the actual call graph, and the project's permitted coding rules. A bounded algorithm can still violate a local no-recursion rule.

## Sound code and finding identity

Preserve a short-circuit guard that safely skips a read-only predicate. Preserve eager bitwise operations. Preserve a local variable in a truly stateless method. A style warning can merit a scoped change without implying the original algorithm is wrong.

Track findings by rule, owning object/child, normalized message, and structural location; line numbers alone drift. Record the environment/ruleset alongside the identity. Accepted debt needs exact dispositions, not only an unchanged count. Re-run affected analysis and tests after semantic repairs. A suppressed warning is not proof that the risk disappeared.

## Source basis

Language/API claims use the sources below, consulted 2026-09-08. Examples and review procedures are newly authored; they are not copied vendor tests or evidence of native execution.

- [CODESYS Static Analysis: SA0001](https://content.helpme-codesys.com/en/CODESYS%20Static%20Analysis/_san_rule_sa0001.html)
- [CODESYS Static Analysis: SA0009](https://content.helpme-codesys.com/en/CODESYS%20Static%20Analysis/_san_rule_sa0009.html)
- [CODESYS Static Analysis: SA0160](https://content.helpme-codesys.com/en/CODESYS%20Static%20Analysis/_san_rule_sa0160.html)
