---
name: codesys-static-analysis-campaign
description: "Plan or execute a CODESYS Static Analysis cleanup with complete diagnostics, correct analysis scope, stable findings, and semantic repairs. Use for multi-object analysis campaigns, not every one-line edit."
---

# Static Analysis campaign

Read [rule examples and scope](references/static-analysis.md). Bind one candidate, environment, ruleset, exclusions, and the actual native analysis invocation/capture path.

Start with a whole-project completeness probe. Keep a warm project where practical. Partition export or ownership by library, then smaller groups when caps or ambiguous attribution require it. Do not remove dependencies or callers without considering how that changes analysis. A displayed-message filter is not analysis scope and cannot recover diagnostics already truncated upstream.

Record cap/truncation, enumerated/captured/skipped/error counts, and freshness. Treat unknown completeness as unresolved. Preserve exact finding fingerprints plus environment/ruleset; counts alone are not an accepted-debt baseline.

Repair by rule within an ownership boundary when that reduces repeated work. SA0001 unreachable cleanup may need moving before return, not deletion. SA0009 ignored acceptance results may need handling rejection, not assigning a dummy. SA0160 recursion needs the actual call graph and bounded-execution analysis. Read the reference's safe/unsafe repairs and sound-code cases.

Apply mechanical changes only after proving their scope. Reference, inheritance, interface, state, timing, or safety-relevant findings require contextual review and relevant tests. Never hide warnings by suppressing rules, dropping the last array element, or weakening expected behavior.

Run cheap checks after repairs, then required native analysis/build/tests. Finish with the integrated context needed for affected rules. Keep prior failures, dispositions, and remaining debt. Return coverage/completeness, concrete repaired or unresolved findings, exact candidate, and checks not run; no fixed reviewer count or separate IDE process per FB is required.
