# Changes in 1.0.0

This is a substantive content revision of the supplied 22-skill CODESYS set. All 22 subjects remain covered. The generic router is named `codesys`; `codesys-short-circuit-review` is new. Skill text, references, source examples, and evaluation cases have changed, not just metadata.

## Technical changes

**Short-circuit evaluation.** Add AND_THEN and OR_ELSE rules with safe and defective examples for pointers, arrays, and division. Explain TRUE-means-reject conditions, stale outputs, nested eager evaluation, and false assumptions about lifetime/concurrency. Teach why required method/property/timer effects must not disappear when replacing an eager operator. Supply harmless observable predicate-call counts and preserve sound bitwise/eager expressions.

**References and parameters.** Distinguish REF= rebinding from := writes through a reference; pointer/reference/interface lifetime and validity; ordinary writable VAR_IN_OUT from documented VAR_IN_OUT CONSTANT string calls; exact storage/type requirements and aliases. Remove vague simulator-fault prohibitions unless backed by a concrete reproduction and version.

**Task/state reasoning.** Replace the implied application-wide atomic scan model with actual per-task call context. Include a mixed-version structure interleaving, a complete synchronization design with bounded waiting obligations, slow-reader buffer reuse, missed pulses, repeated/skipped calls, and CASE versus independent IF transitions. Do not invent a runtime synchronization API.

**Lifetime and online change.** Separate method locals, VAR_INST, FB instance state, RETAIN, and PERSISTENT. Add warm/cold/origin reset and runtime-event treatment, data compatibility, pointer rebinding, code-only versus declaration-changing online change, and the prohibition on SUPER^.FB_Init. Keep ordinary base-body and base-method calls distinct.

**Numeric and bounded execution.** Add widen-before-arithmetic examples, a target-portability counterexample, lower/upper bounds, ARRAY[*] in VAR_IN_OUT, the loop-counter final increment, bounded queue/work obligations, and cycle-duration versus elapsed-time traces.

**Complete authoring and tests.** Add a small processing-job interface/FB, configuration and state types, public methods, actual cyclic caller, bounded array and arithmetic functions, and a stateful scenario that returns between invocations. Both provider examples include an immediate test, genuine multi-invocation test, reset/second run, a failed assertion probe, and timeout/cleanup instructions. Native compilation and runtime qualification remain explicitly NOT_RUN.

**Automation and operations.** Add edit/read-back and partial-failure workflows, full child/property preservation, a preimage/read-back text-edit helper, concrete Static Analysis repair cases, report/current-candidate reconciliation, and equipment-specific fault/recovery reasoning instead of undefined “fail-safe” approval.

**Evidence and authority.** Retain the source set's separation of build, analysis, runner completion, report completeness, and assertions. Separate what a program does from what it must do. Do not weaken expectations to match a failed implementation. Keep source review, native checks, physical measurements, and agent trials distinct.

## Disposition of every original skill

| Original skill | Result | Main content change |
|---|---|---|
| `bbk-codesys` | Renamed `codesys` | Generic routing, no workflow/package dependency, authority/evidence separation |
| `codesys-st-authoring` | Rewritten | Full example with interface, state, ownership, caller, functions, tests |
| `codesys-st-correctness-review` | Rewritten | Concrete defect/repair rules with false-positive exceptions |
| `codesys-reference-pointer-varinout-review` | Rewritten | Binding/value semantics, lifetime, aliasing, parameter exceptions |
| `codesys-scan-cycle-state-review` | Rewritten | Per-task model, concurrency interleaving, command and invocation traces |
| `codesys-inheritance-interface-review` | Rewritten | Lost base behavior, public dispatch checks, lifecycle exceptions |
| `codesys-counit-test-design` | Rewritten | Complete stateful suite/runner and separate negative probes |
| `codesys-testmanager-test-design` | Rewritten | Complete test POUs, lifecycle, selection, failure/timeout cleanup |
| `codesys-counit-harness-review` | Expanded | Registration, rerun, expected inventory, report/writer failure cases |
| `codesys-testmanager-ci-review` | Expanded | Native test lifecycle, generated app effects, current complete reports |
| `codesys-test-provider-selection` | Revised | Project-specific choice; no imposed provider/migration policy |
| `codesys-mcp-development` | Expanded | Actual schema discovery, bounded edits, read-back, partial failures |
| `codesys-ci-scriptengine-review` | Expanded | Native script semantics, checked helper, diagnostic capture and cleanup |
| `codesys-mcp-roundtrip-review` | Expanded | Child/accessor preservation and nontransactional recovery |
| `codesys-plcopenxml-package-review` | Expanded | Exact dependency closure, conflicts, object topology and behavior checks |
| `codesys-static-analysis-campaign` | Expanded | SA0001, SA0009, SA0160 examples; scope/cap/filter distinction |
| `codesys-target-operational-review` | Expanded | Specific outputs, triggers, timing evidence, lifecycle and rollback |
| `codesys-implementation-structure` | Revised | Generic public contract/task ownership; no prescribed repository format |
| `codesys-implementation-structure-review` | Revised | Contract-to-caller checks, behavior-preserving structure alternatives |
| `codesys-execution-slicing` | Revised | Complete small increments, actual dependencies, session reuse |
| `codesys-evidence-reproducer` | Expanded | Complete source/state/call/environment reproduction method |
| `comprehensive-analysis-codesys-st` | Revised | Risk-led broad review without mandatory campaigns for local edits |
| — | Added `codesys-short-circuit-review` | Focused dependent evaluation and skipped-effect review |

## Corrected inherited guidance

The new recommended examples do not repeat the supplied ARRAY[*]-under-VAR_INPUT error. They do not call two straight-line calls followed by completion a multi-scan test. They do not classify repository restrictions on method parameters as language restrictions. They do not call ordinary FB-owned fixture state PERSISTENT. They do not treat one script invocation as an all-or-nothing transaction, or current runtime behavior as authority to change the requirement.

Original files remain in the supplied archive; this bundle does not modify them or ship their contradictory examples as active guidance. `source-provenance.json` preserves source paths/hashes and the 22-to-23 mapping.

## Generic delivery changes

Each skill uses ordinary SKILL.md metadata and local references/assets. There are no language-package manifests, runtime hooks, fixed custom MCP schemas, mandatory DEC/IMP layouts, pinned private machine paths, or extra installer dependencies. A small optional standard-library installer supports all/selected skills and refuses existing-name collisions. Folder copying works without it.
