# Review and false-positive trial cases

`cases.json` contains 34 authored cases, including defective and sound code. They are not compiler fixtures or completed agent trials. Context fields are part of the case: do not omit ownership, lifetime, target range, or required behavior when testing a reviewer.

For an agent comparison, give the subject only each case's ID, context, and source, not the expected verdict or repair. Keep model/version, settings, task, tools, case order, and permitted native access the same across compared runs. Compare the supplied baseline skill content with this revision without exposing the answer key to either run. Reset conversation context between independent cases or record deliberate grouping.

Judge separately: intended defect found, unsupported finding avoided, repair preserves the contract, repair is technically correct, and the proposed verification reaches the defect. Accept equivalent safe repairs; do not score phrasing. Preserve raw answers and disputed cases. Use `NOT_RUN`, `PASS`, `FAIL`, or `INCONCLUSIVE` per dimension. Inspect sound cases for false positives rather than maximizing finding count.

Native compilation and behavior are separate checks of actual repaired code. The snippets are scoped source fragments, sometimes deliberately invalid, not native import objects. Use the complete `assets/guards` and `assets/bounded-job` examples inside relevant skills for native starting material. Do not execute deliberate null-dereference defects or an unbounded loop on a live controller.

Report case counts, omissions, failed repairs, false positives, interventions, and evidence limits. A JSON inventory check does not measure agent quality. This delivery does not claim a baseline-versus-revision performance improvement.
