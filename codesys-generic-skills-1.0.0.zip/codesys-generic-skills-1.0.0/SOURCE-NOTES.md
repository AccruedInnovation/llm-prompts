# Source notes and confidence

## Supplied basis

The input was `bbk-profile-codesys-0.1.0-alpha.5.zip`, together with the preceding content review and source excerpts. The user approved those review recommendations and specifically requested AND_THEN/OR_ELSE coverage and generic Codex installation.

All 22 original skill subjects were retained, while technical content was rewritten or expanded. The source archive also supplied curated references, repository guidance, CoUnit API notes, and a Test Manager test template. The exact original skill paths/hashes, supporting source paths/hashes, available review hashes, and input archive digest are recorded in `source-provenance.json`.

Useful retained ideas include proportional scope, preserving public behavior and inherited outputs, complete diagnostic capture, precise test-provider lifecycle, separate result fields, repeat-run checks, and honest limits on native/operational evidence. Repository conventions and installation-specific defaults do not become language rules.

## New and corrected material

The guard programs, processing-job objects, scenario, provider fixtures, review cases, and edit helper are newly authored. Their contracts and expected results are explicit example choices. The package does not claim vendor authorship, certification, a native import schema, or actual execution of the ST. The example object index describes source files and editor ownership only.

Corrections to inherited material are intentional, authorized by the user's request, and recorded in CHANGELOG.md. The original material is not silently overwritten. In particular, the replacement changes variable-length array parameter placement, false multi-cycle test claims, method-parameter rule scope, ordinary instance-state terminology, and the mixing of observations with requirements.

The original CoUnit guides describe the API shape but do not establish an exact installed fork version. The supplied Test Manager template likewise does not establish the target library build. The examples therefore preserve the documented shape and require comparison with the installed provider's actual declarations/template. No missing version has been invented. The bundle contains no CoUnit/Test Manager library binary.

## External verification

Language and API statements use official CODESYS documentation, cited next to each technical reference. Current skill layout, local install locations, and explicit invocation use official OpenAI documentation. `source-provenance.json` records the consulted URLs and date, 2026-09-08. These sources establish documented behavior within their applicability, not successful operation on the user's controller.

The references paraphrase relevant rules and add new examples/review procedures; they do not bundle full vendor manuals. CODESYS's extension behavior must not be generalized to every IEC 61131-3 implementation. No licence or permission to redistribute the original third-party libraries or manuals is conferred by this archive.

## Evidence boundary

The offline test suite verifies the written delivery's structure and specific host-code behavior. Native CODESYS compilation, ScriptEngine execution in its real host, controller operation, provider execution, and Codex/model trials did not run. A fake ScriptEngine document tests the helper's branching and failure reporting, not the native host's overload binding or side effects.

The 34 review cases include sound cases to expose false positives. They provide a repeatable future comparison method, but no measured model-quality improvement is claimed. Review during authoring was a self-review, not an independent model review.
