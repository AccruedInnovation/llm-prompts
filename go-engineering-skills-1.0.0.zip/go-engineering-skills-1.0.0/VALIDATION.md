# Validation — Go Engineering Skills 1.0.0

**Date:** September 8, 2026. **Result:** the stated content, helper, and available example checks passed. Three newer-API files remain unexecuted. No live Codex efficacy or discovery trial was performed.

## Tested environment

The execution host was Linux/amd64, with Go **1.23.2**, Python **3.13.5**, GCC **14.2.0**, and cgo enabled. Example runs used the local Go toolchain, `GOWORK=off`, and disabled module/toolchain downloads. The detailed reports retain the relevant settings and commands. Go 1.23 is an example compatibility baseline, not a current production-version recommendation.

## Content and delivery helpers

| Check | Observation |
| --- | --- |
| Skill inventory | Fifteen unique names; thirteen generic names retained, one project-specific router removed, two focused skills added. |
| YAML frontmatter | All fifteen headers parsed with a YAML parser during authoring. The bundled standard-library validator separately checks this collection's restricted header form. |
| References | Each skill's required local Markdown links resolve within its own directory. Optional cross-skill routing uses names rather than required relative links. Collection-level document links were checked separately. |
| Generic content | No BBK/runtime/profile-contract instructions remain in the active skill documents or their references. Original source/license names remain only in delivery/provenance material and license notices. |
| License preservation | Each independent skill contains the unchanged supplied MIT notice. |
| Formatting and syntax | All 21 Go files passed `gofmt` formatting checks, including version-gated syntax. All four helper Python files parsed. This does not type-check excluded Go APIs. |
| Helper tests | All 12 passed, with no skips: full/selected copy, duplicate selection, collision preflight, unknown names, source-contained target rejection, injected-copy-failure cleanup, source symlink refusal, valid content, missing links/license, invalid header, and external local dependency. |

The optional installer makes local copies only. Its tests cover a trusted local directory with no concurrent writer, not arbitrary hostile filesystem changes or an atomic cross-directory transaction. The helper does not modify the user's actual installed skills during this delivery.

## Go examples

Final race-enabled test and vet results appear in [go-tests.json](validation/go-tests.json). Counts below are Go JSON **pass events**, including subtests and fuzz seed events; they are not counts of independent test functions.

| Example module | Race-enabled pass events | Vet |
| --- | ---: | --- |
| Public API/methods/errors | 3 | PASS |
| Bounded concurrency and ownership | 7 | PASS |
| States, transitions, typed nil | 3 | PASS |
| I/O and JSON | 34 | PASS |
| Real loopback HTTP serving/shutdown | 4 | PASS |
| Performance correctness | 1 | PASS |
| Test lifetime and assertions | 9 | PASS |
| Synchronous cgo callback owner | 4 | PASS |
| HTML/HTMX response contracts | 6 | PASS |
| Version-gated rooted filesystem access | NOT_RUN — no test selected by Go 1.23 | PASS for the selected documentation-only package; not a filesystem behavior check |

All nine runnable suites passed. The final run used `go test -json -count=1 -timeout=20s -race ./...` and `go vet ./...` within each applicable module. Ordinary tests also passed during development. Tests use real loopback sockets for the HTTP examples and the local C implementation for the native example, rather than stubbing those paths.

[Repeated tests](validation/repeated-tests.json) reran concurrency, HTTP lifecycle, and synchronous native ownership with `-race -shuffle=on -count=20`; all three runs passed. Repeated success does not prove every schedule or foreign memory access race-free.

## Additional checks

[additional-checks.json](validation/additional-checks.json) records two separate successful native runs: `-gcflags=all=-d=checkptr=2` and build-time `GOEXPERIMENT=cgocheck2`. These complement Go race checks; they do not replace the pointer rules or qualify an asynchronous foreign library.

The same report records a short successful benchmark smoke run and a bounded three-second JSON fuzz request (the runner completed after its normal reporting/cleanup interval). The fuzz run used the current local fuzz cache, whose discovered cases are not shipped. These are bounded observations, not an exhaustive input proof, a speed claim, or reproducible benchmark statistics.

[mutations.json](validation/mutations.json) records four wrong versions made only in temporary copies: removed duplicate-field rejection, removed trailing-input rejection, removed repeated-start rejection, and lost wrapped-error identity. Each selected baseline test passed; each modified version failed a named behavior test. A compiler failure or zero selected tests cannot count as successful detection.

The [initial mutation attempt](validation/mutation-initial.json) used the wrong test selector for the error-identity case. The probe rejected that zero-test run rather than claiming detection. The selector was corrected to the existing test name and all four cases reran successfully; neither code behavior nor expected results were weakened. An earlier aggregate validation call exceeded the execution-tool time limit; it was not counted as a passing run. The completed reports supersede that incomplete attempt.

Helper results are in [helper-tests.txt](validation/helper-tests.txt). The checks above are local execution and same-author review, not independent model review.

## Explicitly unexecuted examples

| File | Required API baseline | Actual treatment |
| --- | --- | --- |
| `skills/go-performance-review/examples/benchmark_go124_test.go` | Go 1.24 `testing.B.Loop` | Parsed/formatted only; excluded by Go 1.23. |
| `skills/go-security-supply-chain-review/examples/root_go124_test.go` | Go 1.24 `os.Root` | Parsed/formatted only; no rooted-access runtime test here. |
| `skills/go-test-strategy-review/examples/synctest_go125_test.go` | Go 1.25 stable `testing/synctest` | Parsed/formatted only; no virtual-time runtime test here. |

A newer toolchain was not available for execution. Relevant API guidance was checked against official documentation, and the source build constraints prevent older-toolchain runs from pretending to exercise it. Use a compatible local Go version to run those files; the validator reports what the active toolchain actually selects. A platform that cannot create symlinks may additionally skip that rooted-access subtest, which must remain visible.

## Consumer and artifact checks

The final transferable ZIP is checked separately after archive creation: safe entry names, file contents against this source tree, fresh extraction, copy-helper installation into a temporary `.agents/skills` directory, same-name refusal, installed-file equality, and tests from the installed example directories. The detached `go-engineering-skills-1.0.0.archive-validation.json` reports those actual results and the final ZIP digest. It is not embedded in the archive it identifies. The detached `.zip.sha256` is an optional transfer check.

These checks do not exercise a live Codex parser or skill-selection session. The installation layout follows the official OpenAI documentation linked in the README; actual Codex discovery and model behavior remain untested.

## Scope not established

No Windows/macOS runtime tests, real database engine/isolation tests, real browser/history-cache tests, registry publication, minimum-version matrix beyond the recorded host, sanitizer qualification, arbitrary asynchronous native callback tests, or production load study ran. SQL and errgroup worked cases are source-backed analysis, not executed integrations. The 17 prompt cases and their separate answer key are prepared evaluation material; they do not establish that Codex finds more defects or produces better code than with the original skills.

The collection is complete as a set of generic skill instructions with bounded supporting examples. Its validation claims remain limited to the checks and environments above.
