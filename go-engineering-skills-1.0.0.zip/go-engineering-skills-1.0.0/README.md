# Go Engineering Skills 1.0.0

Fifteen standalone skills for implementing, reviewing, testing, and releasing Go software. Revised from the supplied Go skill collection after its content review. Each skill has its own `SKILL.md`, local references and examples where useful, and license notice. **This is not a BBK language profile, Codex plugin, or agent runtime.**

The set keeps the original emphasis on clear ownership, narrow interfaces, proportionate checks, and evidence. It adds exact API rules, faulty and valid examples, and tests that distinguish them. Focused references keep routine work from loading the whole set.

## Install into Codex

Extract this archive first. Copy the **individual directories inside `skills/`**, not the outer archive directory, into one of these locations:

| Scope | Destination |
| --- | --- |
| Your user account | `$HOME/.agents/skills/` |
| One repository | `<repository>/.agents/skills/` |

These locations and the `SKILL.md` format follow [OpenAI's skills documentation](https://developers.openai.com/codex/skills), checked on September 8, 2026. This delivery checks the file layout and copy operation; it does not claim a live Codex discovery test.

### Optional copy helper

The helper needs Python 3.10 or newer and no third-party Python packages. Run it from the extracted `go-engineering-skills-1.0.0` directory.

Linux/macOS shell:

```sh
python3 tools/install.py --target "$HOME/.agents/skills"
```

Windows PowerShell:

```powershell
py -3 tools/install.py --target "$HOME\.agents\skills"
```

For one project, set `--target` to that repository's `.agents/skills` directory. To install only selected skills:

```sh
python3 tools/install.py --target "$HOME/.agents/skills" \
  --only go-skills go-correctness-concurrency-review go-test-strategy-review
```

`python3 tools/install.py --list` lists the available names without copying. On Windows, use `py -3` in place of `python3` for these commands.

The helper preflights name conflicts and **refuses to overwrite an existing skill**. It copies complete skill directories and no collection-level tools, reports, or evaluation material. It does not edit Codex configuration, create hooks, install a toolchain, download dependencies, or publish anything. Use it against a trusted local directory with no competing installer; it is not a hardened hostile-filesystem transaction.

Manual copying works without Python. Keep each skill's `LICENSE`, `references/`, and `examples/` with its `SKILL.md`. No skill has a required link to another skill or to a collection-level file.

### Existing copies, updates, and removal

Before replacing a same-named skill, inspect and back up that specific old directory **outside all scanned skills roots**, then copy the new complete directory. Do not merge old references with the new version or keep conflicting same-named copies at both user and project scope. The helper deliberately has no automatic overwrite or uninstall mode. Remove only the named directories installed from this collection when uninstalling.

### Use

In Codex CLI or the IDE extension, select a skill through `/skills` or name it in the request, for example:

```text
$go-skills Implement the requested change and run the relevant tests.

$go-correctness-concurrency-review Review the worker shutdown and buffer ownership.

$go-io-boundary-review Check this JSON endpoint and its transaction behavior.
```

Codex can also select skills by their descriptions. Use the core skill for an ordinary change and only the focused skills that address a real concern. No instruction requires a full fifteen-skill audit for each task. If a newly installed skill does not appear, restart Codex and inspect the directory nesting and any duplicate names. Consult the official documentation above for host-specific behavior.

## Contents

| Skill | Use |
| --- | --- |
| [go-skills](skills/go-skills/SKILL.md) | Everyday implementation, repair, and version-sensitive Go rules. |
| [comprehensive-analysis-go](skills/comprehensive-analysis-go/SKILL.md) | Broad review with concrete defects and justified opportunities. |
| [go-implementation-structure](skills/go-implementation-structure/SKILL.md) | Package/type ownership, domain invariants, interfaces, and design choices. |
| [go-implementation-structure-review](skills/go-implementation-structure-review/SKILL.md) | Check an implementation against its actual structural and behavioral contract. |
| [go-correctness-concurrency-review](skills/go-correctness-concurrency-review/SKILL.md) | Cancellation, joining, synchronization, queues, ownership, and failure. |
| [go-io-boundary-review](skills/go-io-boundary-review/SKILL.md) | Readers/writers, bounded JSON, HTTP bodies, SQL, files, and subprocesses. |
| [go-test-strategy-review](skills/go-test-strategy-review/SKILL.md) | Meaningful assertions, correct Go test lifetime, integration, and fuzzing. |
| [go-api-module-boundary-review](skills/go-api-module-boundary-review/SKILL.md) | Methods, errors, modules, language minimums, and consumer compatibility. |
| [go-performance-review](skills/go-performance-review/SKILL.md) | Profiles, traces, benchmarks, allocations, contention, and resource use. |
| [go-operational-readiness-review](skills/go-operational-readiness-review/SKILL.md) | Real service startup, HTTP shutdown, health, limits, and recovery. |
| [go-security-supply-chain-review](skills/go-security-supply-chain-review/SKILL.md) | Trust boundaries, filesystem access, processes, SSRF, and dependency risk. |
| [go-unsafe-cgo-assembly-review](skills/go-unsafe-cgo-assembly-review/SKILL.md) | Pointers, pinning, callbacks, allocation, ABI, and native checks. |
| [go-web-htmx-review](skills/go-web-htmx-review/SKILL.md) | HTML/fragment responses, history, caching, escaping, and browser contracts. |
| [go-evidence-reproducer](skills/go-evidence-reproducer/SKILL.md) | Small reproductions, failure-sensitive tests, exact observations, and limits. |
| [go-package-release-gates](skills/go-package-release-gates/SKILL.md) | Actual Go module/binary releases and downstream/install checks. |

The last skill reviews ordinary Go software releases. It does not restore the removed BBK packaging protocol. Source names may remain in license and provenance notices only.

## Examples and checks

Ten skills contain an independent `examples/go.mod`. The example code is instructional, not a production library to import. Read its contract and limits before adapting it. Deliberately faulty comparators are labeled; passing tests may prove that those comparators are wrong.

The examples use a **Go 1.23 language baseline**, not a recommendation to deploy that old release. Newer-API test files have version build constraints: `os.Root` and `B.Loop` require Go 1.24; stable `testing/synctest` requires Go 1.25. A Go 1.23 run excludes those files. Their formatting does not prove they type-check or run under a newer compiler.

No external Go modules or downloaded tools are required by the examples. The native callback module additionally needs a working local C compiler and enabled cgo. The collection does not bundle any compiler, analyzer, database, browser, or external service. A Go installation is not required merely to install or read the skills.

From this extracted collection, run only the checks needed:

```sh
python3 tools/validate.py
python3 -m unittest discover -s tools -p 'test_*.py' -v
python3 tools/validate.py --tests --race --report /tmp/go-skills-tests.json
python3 tools/validate.py --native-checks --only go-unsafe-cgo-assembly-review
python3 tools/validate.py --benchmarks --fuzz-seconds 3
python3 tools/probe_mutations.py --report /tmp/go-skills-mutations.json
```

Use a writable report path for your system; `/tmp/` above is an example for Unix-like hosts. The validation helper uses the installed Go toolchain and disables module/toolchain downloads. It selects the host target, records the actual Go/C environment, reports build-excluded files as `NOT_RUN`, and does not count an empty suite as a pass. `--only <names...>` limits Go execution, not the all-skill document checks. Its content check recognizes this collection's deliberately narrow, valid YAML-header form; it is not a general YAML validator or a Codex parser.

The helper does not bypass sandbox restrictions. Loopback networking is needed for the HTTP examples. Race, cgo, symlink, and newer-API checks depend on platform capabilities. Benchmark smoke runs establish that a benchmark executes, not a performance conclusion. The mutation probe changes disposable copies only and requires a passing baseline plus a behavior-test failure; compilation failure or zero selected tests does not count as detection.

See [VALIDATION.md](VALIDATION.md) for actual results and unrun checks. [Evaluation prompts](evals/prompts.md) and the separate [answer key](evals/answer-key.md) support a later Codex trial; no such efficacy trial is claimed here. [CHANGELOG.md](CHANGELOG.md) maps the content changes. [NOTICE.md](NOTICE.md) records the source and license treatment.
