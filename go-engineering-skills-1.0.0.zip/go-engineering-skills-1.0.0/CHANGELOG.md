# Changelog

## 1.0.0 — September 8, 2026

First standalone Go Engineering Skills release. This is a revised successor to the supplied skills, not a repackaging of its BBK language profile.

### Corrected rules

- Distinguished a `go` directive's required minimum from main-module/workspace toolchain selection. A dependency's `toolchain` suggestion is not an equivalent downstream minimum.
- Replaced “reuse response bodies” with reuse of clients/transports, closing each body, and bounded consumption rules.
- Replaced “enforce invariants once” with one authoritative meaning and consistent protection at every required trust or transaction boundary.
- Explained that typed constants do not close a Go enum, exported zero values remain constructible, and typed-nil errors differ from nil interfaces.
- Qualified cancellation guarantees: cancel does not join, ready select cases have no cancellation priority, and extra checks do not serialize acceptance or commit.
- Distinguished Go 1.22 loop-variable semantics, Go 1.23 timers, Go 1.24 `B.Loop`/`os.Root`, and Go 1.25 `WaitGroup.Go`/stable `synctest`.

### Deeper content and examples

| Accepted review topic | Applied content |
| --- | --- |
| Worked examples and valid alternatives | Focused references plus ten small example modules; ordinary valid designs remain valid. |
| Concurrency | Bounded worker implementation, cancel-and-join tests, select rule, buffer aliasing/copy choices, errgroup cancellation and bounded nested-submission analysis. |
| I/O, JSON, HTTP, SQL | New `go-io-boundary-review`; data-plus-EOF, short writes, size rejection, narrow duplicate-aware decoder, body lifecycle, and transaction/pool examples. |
| Type and invariant design | Named-state and zero-value examples, checked transitions, typed nil, consistent application/storage enforcement, and distinction between types and runtime facts. |
| Test correctness | Parent-owned worker failures; parallel-child `t.Cleanup`; serial `t.Setenv`; separate guard, precedence, and prohibited-effect assertions; version-gated synctest example. |
| Public API and versions | Consumer-package method-set/error/loop tests; module and workspace leakage checks; exact `go`/`toolchain` distinction. |
| Operations | Real loopback HTTP serving lifecycle; held-request draining; timeout/forced close; joined serving owner; explicit hijacked/background-worker exclusions. |
| Security | Filesystem threat choices and version-gated `os.Root` cases; argument versus option injection; SSRF policy; decompression and guard-specific tests. |
| Native boundaries | Separate unsafe/KeepAlive/Pinner/Handle roles; runnable synchronous C callback lifetime; close/emit tests; checkptr and cgocheck2 instructions. |
| Performance | New `go-performance-review`; measurement-to-tool choices, statistical limits, equivalent-work benchmarks, guarded `B.Loop`, and resource/PGO considerations. |
| Optional HTMX | Full/fragment/history behavior, Vary/cache rules, escaped response example, and explicit browser-test limits. |
| Test sensitivity | Four temporary code mutations plus a separate prompt/rubric corpus containing defect and no-defect cases. |

### Preserved and removed

Retained thirteen generic skill names and their useful coverage. Removed the BBK-specific router (`bbk-go`) and its runtime/profile rules. Moved useful ordinary implementation routing into `go-skills`. Added two focused skills, for fifteen total. Replaced shared root references with local references inside the skill that uses them, so selected installation does not leave required links broken.

Kept the broad review's attention to cohesion, ownership, errors, observability, performance, compatibility, documentation, and unnecessary abstraction. No rewrite imposes a framework, a fixed reviewer count, or every available analyzer on a small change.

Removed mandatory profile identities, BBK schemas, executor-specific contracts, orchestration rules, and per-change metadata ceremony from active skill instructions. Kept genuine Go module, binary, installed-artifact, and release review where those are the task.

### Delivery and limits

Added an optional non-overwriting copy helper, local content/example checks, helper tests, and a small mutation probe. The skills themselves require none of those collection-level tools. Preserved the supplied MIT notice both at collection root and in each independently installable skill.

Validation proves the stated document, example, and copy checks only. It does not prove improved Codex task performance, live skill discovery, a real SQL transaction against an engine, browser behavior, asynchronous foreign callbacks, or unexecuted platforms/APIs. See the validation report for the exact boundary.
