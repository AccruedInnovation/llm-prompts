package worker

import (
	"context"
	"errors"
	"reflect"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func TestMapSuccessAndBound(t *testing.T) {
	var active, peak atomic.Int32
	got, err := Map(context.Background(), []int{1, 2, 3, 4, 5, 6}, 2, func(_ context.Context, n int) (int, error) {
		now := active.Add(1)
		defer active.Add(-1)
		for old := peak.Load(); now > old; old = peak.Load() {
			if peak.CompareAndSwap(old, now) {
				break
			}
		}
		return n * 2, nil
	})
	if err != nil || !reflect.DeepEqual(got, []int{2, 4, 6, 8, 10, 12}) {
		t.Fatalf("%v, %v", got, err)
	}
	if peak.Load() > 2 || active.Load() != 0 {
		t.Fatal("worker bound or join violated")
	}
}
func TestMapFailureJoinsPeers(t *testing.T) {
	boom := errors.New("callback failure")
	var active atomic.Int32
	got, err := Map(context.Background(), []int{1, 2, 3, 4}, 2, func(ctx context.Context, n int) (int, error) {
		active.Add(1)
		defer active.Add(-1)
		if n == 1 {
			return 0, boom
		}
		<-ctx.Done()
		return 0, ctx.Err()
	})
	if !errors.Is(err, boom) || got != nil || active.Load() != 0 {
		t.Fatalf("got=%v err=%v active=%d", got, err, active.Load())
	}
}
func TestMapCancellationJoins(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	entered := make(chan struct{})
	var once sync.Once
	var active atomic.Int32
	done := make(chan error, 1)
	go func() {
		_, err := Map(ctx, []int{1, 2, 3}, 2, func(ctx context.Context, n int) (int, error) {
			active.Add(1)
			defer active.Add(-1)
			once.Do(func() { close(entered) })
			<-ctx.Done()
			return 0, ctx.Err()
		})
		done <- err
	}()
	select {
	case <-entered:
	case <-time.After(3 * time.Second):
		t.Fatal("worker did not start")
	}
	cancel()
	select {
	case err := <-done:
		if !errors.Is(err, context.Canceled) || active.Load() != 0 {
			t.Fatalf("err=%v active=%d", err, active.Load())
		}
	case <-time.After(3 * time.Second):
		t.Fatal("canceled work did not join")
	}
}
func TestMapInvalidEmptyAndPreCanceled(t *testing.T) {
	f := func(_ context.Context, n int) (int, error) { return n, nil }
	if _, err := Map(context.Background(), []int{1}, 0, f); !errors.Is(err, ErrInvalid) {
		t.Fatal(err)
	}
	if _, err := Map[int, int](context.Background(), nil, 1, nil); !errors.Is(err, ErrInvalid) {
		t.Fatal(err)
	}
	if got, err := Map(context.Background(), []int{}, 1, f); err != nil || len(got) != 0 {
		t.Fatalf("%v %v", got, err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if _, err := Map(ctx, []int{1}, 1, f); !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
}
func TestSliceSendCopiesHeaderNotData(t *testing.T) {
	original := []byte("abc")
	ch := make(chan []byte, 1)
	ch <- original
	shared := <-ch
	original[0] = 'x'
	if string(shared) != "xbc" {
		t.Fatal("expected shared backing array")
	}
	copied := append([]byte(nil), original...)
	ch <- copied
	original[0] = 'y'
	if string(<-ch) != "xbc" {
		t.Fatal("copy did not isolate data")
	}
}
func TestValidUnbufferedHandoff(t *testing.T) {
	ch := make(chan int)
	done := make(chan struct{})
	go func() { defer close(done); ch <- 42 }()
	if got := <-ch; got != 42 {
		t.Fatal(got)
	}
	<-done
}
func TestCancellationSelectAllowsEitherReadyOutcome(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	for i := 0; i < 100; i++ {
		jobs := make(chan int, 1)
		// Both cases are ready; either result satisfies this cooperative contract.
		select {
		case <-ctx.Done():
		case jobs <- 1:
		}
		if len(jobs) > 1 {
			t.Fatal("impossible queue size")
		}
	}
	// No assertion that a random selection must show both outcomes.
}
