module example.com/go-skill-examples/go-correctness-concurrency-review

go 1.23.0
