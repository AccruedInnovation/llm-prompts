// Package worker demonstrates cooperative cancellation with bounded workers.
package worker

import (
	"context"
	"errors"
	"sync"
)

var ErrInvalid = errors.New("positive worker count and non-nil callback required")

// Map joins every worker. It returns no results on error, but cannot undo callback effects.
// The first observed callback error wins. Callbacks must return, honor context,
// and not panic. Inputs must not be changed concurrently by the caller.
func Map[T, R any](ctx context.Context, input []T, workers int, fn func(context.Context, T) (R, error)) ([]R, error) {
	if workers < 1 || fn == nil {
		return nil, ErrInvalid
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	result := make([]R, len(input))
	if len(input) == 0 {
		return result, nil
	}
	if workers > len(input) {
		workers = len(input)
	}
	child, cancel := context.WithCancel(ctx)
	defer cancel()
	type item struct {
		index int
		value T
	}
	jobs := make(chan item)
	var wg sync.WaitGroup
	var once sync.Once
	var firstErr error
	wg.Add(workers)
	for i := 0; i < workers; i++ {
		go func() {
			defer wg.Done()
			for {
				select {
				case <-child.Done():
					return
				case task, ok := <-jobs:
					if !ok {
						return
					}
					if child.Err() != nil {
						return
					}
					value, err := fn(child, task.value)
					if err != nil {
						once.Do(func() { firstErr = err; cancel() })
						return
					}
					result[task.index] = value
				}
			}
		}()
	}
produce:
	for i, value := range input {
		select {
		case <-child.Done():
			break produce
		case jobs <- item{i, value}:
		}
	}
	close(jobs)
	wg.Wait()
	if firstErr != nil {
		return nil, firstErr
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	return result, nil
}
