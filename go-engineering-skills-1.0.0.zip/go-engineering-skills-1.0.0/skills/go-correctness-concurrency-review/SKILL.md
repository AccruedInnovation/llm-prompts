---
name: go-correctness-concurrency-review
description: "Find Go correctness, goroutine, channel, cancellation, synchronization, and recovery defects. Use for concrete lifecycle or concurrent-state risks, not a stylistic preference for channels over locks."
---

# Go Correctness and Concurrency Review

Review the invariant and all relevant exits, not just the happy path. Start with the supported toolchain/language version, build context, state owner, expected result, and permitted partial effects.

## Trace one operation completely

Follow acceptance, work, commit, result delivery, cancellation, and cleanup. For each goroutine record its owner, creation trigger, maximum count, stop signal, wait/join, error destination, and resources. A short inline table is enough. Include producers and result collectors; bounding workers alone does not bound the queue or result storage.

For each channel, identify senders, receivers, close owner, buffer rationale, and what happens when a peer stops. A nil channel disables a select case; reading a closed channel yields its zero value immediately. Use the `ok` result or another explicit protocol when end-of-stream matters. A sender must not race with close. Neither a buffer nor an unbuffered channel is inherently correct or wrong.

## Cancellation and completion are different

A cancel function requests stopping and releases context resources; it does not join work or undo a commit. Call derived cancel functions on successful early returns too. A goroutine blocked in an operation that ignores context still needs a way to unblock, such as closing an owned connection or an API-specific interrupt.

Use this order when ownership requires it: request stop, unblock pending work, join, then release resources still used by workers. Waiting before the required unblock can deadlock. Returning before joining can create use-after-close or detached effects. `context.WithoutCancel` deliberately detaches cancellation and therefore needs another lifetime owner; do not use it as an error workaround.

```go
select {
case <-ctx.Done():
    return ctx.Err()
case jobs <- job:
    return nil
}
```

This waits for either cancellation or a send. It does not give cancellation priority when both are ready. A preceding `ctx.Err()` check improves early exit but does not close the race. For “no acceptance after shutdown,” coordinate state checking and acceptance under one owner or lock and define the acceptance point. For “no commit after shutdown,” coordinate the commit itself; acceptance control alone is insufficient.

## Ownership and synchronization

A channel send copies a value, not the backing storage of a slice or map. Choose a copy, a transfer protocol after which the sender stops using it, or synchronized shared access. Test sender buffer reuse. Appending may or may not allocate depending on capacity, so accidental success with one buffer size is not proof.

Protect related state together. A map of individually atomic fields does not make a multi-field transition atomic. For an immutable snapshot, publish only after full initialization and never mutate the published object. Keep lock ordering clear, avoid calling unknown user code while holding a lock, and put `sync.Cond.Wait` in a predicate loop.

Add positive `WaitGroup` counts before starting work when the group can be empty. Do not copy used locks, atomics, `Once`, or wait groups. A panicking `Once.Do` still counts as having run; do not assume it retries initialization. Check `WaitGroup.Go` version and panic contract before adopting it.

When the project uses `errgroup`, review its exact dependency version. Its derived context ends when `Wait` returns, even on success; use the parent for later independent work. `SetLimit` can make `Go` block. All active tasks recursively submitting into a full group can deadlock, and cancellation does not automatically free a blocked submission. Do not change the limit while tasks run. See [worked concurrency cases](references/concurrency-cases.md).

## Time, retries, and effects

Give timers and tickers an owner and stop condition. Stopping a ticker does not close its channel. Use the selected Go version's timer rules; do not paste old stop/drain recipes into a new version or rely on timer-channel length.

Bound retry count/time and concurrency. Retry only when the operation's error and effect rules allow it. Cancellation or a lost acknowledgement may leave the result unknown, not definitely absent. A race-free deduplication map does not provide durable duplicate suppression after restart. Match retention to the allowed replay window.

For transactions, files, and external operations, check commit ambiguity, partial output, recovery observations, and release order. Choose real database, filesystem, subprocess, or transport tests when mocks omit the property.

## Test the guarantee

Use deterministic coordination for critical interleavings, the race detector for exercised accesses, repetition for schedule variation, and state/transition tests for logical ordering. Preserve failing schedules, inputs, and traces. A passing race run does not prove deadlock freedom, termination, or correct state transitions.

The [bounded worker example](examples/worker.go) and [its tests](examples/worker_test.go) cover success, worker failure, cancellation, bounds, and joining. They define cooperative cancellation, not strict cancellation priority. Do not copy the example when the callback cannot stop or when the input needs streaming rather than a bounded in-memory slice.

## Return

State the invariant, faulty interleaving or observed failure, exact location, effect on callers, evidence, and smallest repair. Separate confirmed defects, unresolved assumptions, and untested concerns. Preserve flaky attempts and missing target coverage. Do not invent a finding because a valid design uses locks or an unbuffered channel.

## Sources

[Context](https://pkg.go.dev/context), [select semantics](https://go.dev/ref/spec#Select_statements), [memory model](https://go.dev/ref/mem), [sync](https://pkg.go.dev/sync), [errgroup](https://pkg.go.dev/golang.org/x/sync/errgroup), [timer changes](https://go.dev/doc/go1.23).
