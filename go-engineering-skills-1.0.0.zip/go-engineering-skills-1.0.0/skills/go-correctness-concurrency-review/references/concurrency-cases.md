# Worked concurrency cases

## Cancel without joining

**Trigger:** A function starts owned work, then returns on cancellation while closing a shared resource.

**Fault:** `defer conn.Close(); go use(conn); <-ctx.Done(); return` provides no completion guarantee. The worker may still use the connection or perform an effect after the caller reports completion.

**Repairs:** Let the worker own and close its resource, or cancel/unblock it and wait before the owner returns. Document bounded termination assumptions. Do not add a timeout around a wait and call the remaining goroutine “cleaned up.” A forced-return policy must state who retains ownership and what may still happen.

**Test:** Hold a worker at a known point, cancel, allow its cleanup to finish, and assert that the function has joined it before returning. Use an event channel rather than a sleep as the correctness signal. A test timeout only bounds a failure.

## Bounded worker example

[worker.go](../examples/worker.go) takes a finite input slice and a worker count. It uses one producer (the calling goroutine), an unbuffered work channel, a fixed number of workers, and one result slot per input. Workers write distinct slots; the caller reads them only after `Wait`.

The first observed callback error cancels peers. Errors have no deterministic precedence when several callbacks fail together. If a callback fails, the function returns that error and no results. If the parent is canceled before the final check, it returns the parent error and no results. Successful return immediately before later cancellation is valid. Side effects already performed by callbacks are not rolled back.

Workers may begin a task while cancellation races with receipt. The contract allows this. Every callback must return and honor cancellation for bounded shutdown. No worker limit can fix a callback that ignores cancellation forever. The input and output remain O(n); this example is not a streaming-memory bound.

## Slice ownership

**Fault:** Send `buf[:n]`, then overwrite `buf` for the next read. Both values refer to the same array.

**Repair choices:** Clone the used bytes before send; transfer the buffer and allocate/borrow a different one; or wait for explicit return before reuse. A pool does not supply ownership automatically.

**Test:** Receive the slice, mutate the sender's original buffer in a coordinated sequence, and check that a copied payload stays unchanged. This can expose aliasing without a data race. Also run real concurrent use under `-race`.

## Strong acceptance rule

A mutex can protect both a `closed` flag and appending to an owned bounded queue. `Close` sets the flag under the same lock. Define “accepted” as the append under the lock and “shutdown starts” as the flag update under that lock. An operation ordered before close may succeed; one ordered after must reject. Do not claim the order follows wall-clock entry into the functions. Capacity waiting must release the lock and recheck state on wake.

This rule concerns acceptance. In-flight work may still commit after close unless a separate commit/drain rule governs it. Test both sides of the actual ordering point.

## Existing errgroup use

**Fault:** Use the derived group context for a request after a successful `g.Wait()`. That context is already canceled.

**Repair:** Use the parent context for later work when its lifetime is correct. Do not remove cancellation from all requests.

**Fault:** Set a limit of one, run one task, and have that task synchronously call `g.Go` before it can finish. The nested submission cannot obtain a slot.

**Repairs:** Submit from an external producer, use an explicit queue, or run a nested operation synchronously when that fits the intended bound. `TryGo` allows a chosen overload response; a fallback unbounded `go` statement defeats the limit. These errgroup cases are analytical examples; this collection does not add that dependency just to run them.

## Valid counterexamples

An unbuffered one-shot handoff with a guaranteed receiver and clear shutdown can be correct. A mutex may be the best way to protect two fields. A caller may intentionally own work longer than one request, provided another explicit lifetime owns cancellation, errors, and shutdown. Do not reject these patterns without a concrete failed guarantee.
