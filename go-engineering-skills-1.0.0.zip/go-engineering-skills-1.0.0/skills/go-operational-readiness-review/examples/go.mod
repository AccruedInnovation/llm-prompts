module example.com/go-skill-examples/go-operational-readiness-review

go 1.23.0
