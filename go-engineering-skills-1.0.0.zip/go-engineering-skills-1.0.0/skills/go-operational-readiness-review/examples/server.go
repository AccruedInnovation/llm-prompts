// Package service demonstrates ordinary HTTP serving-loop ownership.
package service

import (
	"context"
	"errors"
	"net"
	"net/http"
	"time"
)

var ErrConfig = errors.New("server, listener, and positive grace period required")

func serveError(err error) error {
	if errors.Is(err, http.ErrServerClosed) {
		return nil
	}
	return err
}

// RunHTTP owns the serving lifecycle. No other caller may start/stop srv.
// It does not own arbitrary background workers or hijacked connections.
func RunHTTP(ctx context.Context, srv *http.Server, ln net.Listener, grace time.Duration) error {
	if srv == nil || ln == nil || grace <= 0 {
		return ErrConfig
	}
	served := make(chan error, 1)
	go func() { served <- srv.Serve(ln) }()
	select {
	case err := <-served:
		return errors.Join(serveError(err), srv.Close())
	case <-ctx.Done():
	}
	shutdownCtx, cancel := context.WithTimeout(context.Background(), grace)
	shutdownErr := srv.Shutdown(shutdownCtx)
	cancel()
	var closeErr error
	if shutdownErr != nil {
		closeErr = srv.Close()
	}
	err := <-served
	return errors.Join(shutdownErr, closeErr, serveError(err))
}
