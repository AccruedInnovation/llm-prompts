package service

import (
	"context"
	"errors"
	"io"
	"net"
	"net/http"
	"sync"
	"testing"
	"time"
)

func start(t *testing.T, h http.Handler, grace time.Duration) (string, context.CancelFunc, <-chan error, <-chan struct{}) {
	t.Helper()
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	srv := &http.Server{Handler: h, ReadHeaderTimeout: time.Second}
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan error, 1)
	stopped := make(chan struct{})
	shutdownStarted := make(chan struct{})
	srv.RegisterOnShutdown(func() { close(shutdownStarted) })
	t.Cleanup(func() {
		cancel()
		_ = srv.Close()
		select {
		case <-stopped:
		case <-time.After(5 * time.Second):
			t.Error("serving owner did not stop during cleanup")
		}
	})
	go func() { defer close(stopped); done <- RunHTTP(ctx, srv, ln, grace) }()
	return "http://" + ln.Addr().String(), cancel, done, shutdownStarted
}
func await(t *testing.T, done <-chan error) error {
	t.Helper()
	select {
	case err := <-done:
		return err
	case <-time.After(5 * time.Second):
		t.Fatal("server did not finish")
		return nil
	}
}
func TestHTTPResponseAndShutdown(t *testing.T) {
	url, cancel, done, _ := start(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { _, _ = io.WriteString(w, "ok") }), time.Second)
	client := &http.Client{Timeout: 2 * time.Second}
	resp, err := client.Get(url)
	if err != nil {
		t.Fatal(err)
	}
	body, readErr := io.ReadAll(resp.Body)
	closeErr := resp.Body.Close()
	if readErr != nil || closeErr != nil || string(body) != "ok" {
		t.Fatalf("%q %v %v", body, readErr, closeErr)
	}
	cancel()
	if err := await(t, done); err != nil {
		t.Fatal(err)
	}
}
func TestHTTPActiveRequestDrains(t *testing.T) {
	entered := make(chan struct{})
	release := make(chan struct{})
	var once sync.Once
	url, cancel, done, shutdownStarted := start(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		close(entered)
		<-release
		_, _ = io.WriteString(w, "complete")
	}), 2*time.Second)
	// Release the held handler before the serving-owner cleanup waits.
	t.Cleanup(func() { once.Do(func() { close(release) }) })
	response := make(chan error, 1)
	go func() {
		resp, err := (&http.Client{Timeout: 4 * time.Second}).Get(url)
		if err != nil {
			response <- err
			return
		}
		data, readErr := io.ReadAll(resp.Body)
		closeErr := resp.Body.Close()
		if string(data) != "complete" {
			response <- errors.New("incomplete response")
			return
		}
		response <- errors.Join(readErr, closeErr)
	}()
	select {
	case <-entered:
	case <-time.After(3 * time.Second):
		t.Fatal("handler not entered")
	}
	cancel()
	select {
	case <-shutdownStarted:
	case <-time.After(3 * time.Second):
		t.Fatal("shutdown did not begin")
	}
	select {
	case err := <-done:
		t.Fatalf("returned with request still held: %v", err)
	default:
	}
	once.Do(func() { close(release) })
	if err := await(t, done); err != nil {
		t.Fatal(err)
	}
	if err := await(t, response); err != nil {
		t.Fatal(err)
	}
}
func TestHTTPGraceExpiryForcesClose(t *testing.T) {
	entered := make(chan struct{})
	handlerDone := make(chan struct{})
	url, cancel, done, _ := start(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		close(entered)
		defer close(handlerDone)
		<-r.Context().Done()
	}), 30*time.Millisecond)
	requestDone := make(chan error, 1)
	go func() {
		resp, err := (&http.Client{Timeout: 3 * time.Second}).Get(url)
		if resp != nil {
			_ = resp.Body.Close()
		}
		requestDone <- err
	}()
	select {
	case <-entered:
	case <-time.After(3 * time.Second):
		t.Fatal("handler not entered")
	}
	cancel()
	if err := await(t, done); !errors.Is(err, context.DeadlineExceeded) {
		t.Fatalf("want grace deadline, got %v", err)
	}
	select {
	case <-handlerDone:
	case <-time.After(3 * time.Second):
		t.Fatal("forced close did not cancel handler")
	}
	if err := await(t, requestDone); err == nil {
		t.Fatal("held response unexpectedly completed")
	}
}
func TestHTTPRejectsInvalidConfig(t *testing.T) {
	if err := RunHTTP(context.Background(), nil, nil, 0); !errors.Is(err, ErrConfig) {
		t.Fatal(err)
	}
}
