# Shutdown scenarios and a bounded HTTP example

## Early process exit

**Fault:** The main goroutine calls `Serve`; a signal goroutine calls `Shutdown`. As soon as `Serve` returns `ErrServerClosed`, main returns and ends the process before shutdown has completed.

**Repair choices:** Main owns shutdown and joins the serving goroutine, or main waits for an explicit shutdown-complete result. Create the grace context from an uncanceled parent such as `context.Background`, with a chosen deadline. Do not pass the canceled signal context to `Shutdown`.

## What the example guarantees

[RunHTTP](../examples/server.go) owns serving on a supplied listener. The caller configures the server and must not call competing lifecycle methods. On parent cancellation, the function calls `Shutdown` with a fresh grace context. If graceful shutdown fails, it calls `Close`, then joins the serving goroutine and returns the shutdown error. Normal `ErrServerClosed` is not treated as a serving fault.

This joins the serving loop; it does not prove all arbitrary handler goroutines have finished after forced close. Normal graceful shutdown waits for ordinary active connections to finish. An application that needs a stronger guarantee must own and join its handler/worker work, with cancellation and a bounded completion contract. The example does not support hijacked connections, WebSockets, HTTP protocol upgrades, or application-specific background workers. Do not claim it does merely because it calls `Shutdown`.

[The tests](../examples/server_test.go) use a real loopback server and a handler that signals entry. They cover successful response, cancellation, a held active request released during grace, and grace expiry with forced close. Control channels establish the important ordering; timeout budgets contain a broken test rather than serving as evidence of ordering.

## Hijacked and upgraded connections

**Fault:** Call `Shutdown` and report that all WebSocket clients disconnected.

**Repair:** Register each connection with an explicit owner, stop new upgrades, initiate protocol close, enforce a deadline, close remaining owned connections, and join the serving work. Follow the selected library's concurrency rules for reads, writes, and close. A shutdown callback can initiate this but must not be mistaken for a waited join.

**Test plan:** Keep a client connected over the actual protocol, signal shutdown, observe close semantics, and inspect the owned registry/task count after completion. This collection includes the plan, not a WebSocket library or executed WebSocket test.

## Useful negative and positive controls

A canceled shutdown context should make a test detect failed drain. A handler that honors cancellation should finish. A stream may legitimately require a distinct longer-lived policy than a small JSON request. An explicitly accepted bounded-abandonment policy can return with a visible incomplete outcome; do not report it as complete cleanup or call every such policy a defect without its requirements.
