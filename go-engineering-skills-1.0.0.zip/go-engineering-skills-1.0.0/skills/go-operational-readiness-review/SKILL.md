---
name: go-operational-readiness-review
description: "Review Go command and service startup, configuration, shutdown, migration, observability, and resource limits. Use for process or deployment behavior that package tests cannot establish."
---

# Go Operational Readiness

Review the actual command or service and its environment. Establish its supported target, configuration, dependency requirements, process manager, resource budget, and permitted operational effects. A local package pass does not establish deployment readiness.

## Startup and configuration

Trace configuration precedence across defaults, files, environment, and flags. Reject invalid required values before accepting work. Make effective settings and version inspectable without logging secrets. Decide missing, deprecated, and incompatible setting behavior. Include relevant runtime flags, build tags, CGO/native dependencies, and PGO when they affect operation.

Keep partial startup reversible: close listeners, pools, files, and workers already acquired when a later step fails. Avoid starting goroutines in constructors before a caller can own their shutdown. Liveness means the process can make progress; readiness means it can accept the intended work. Dependency failure need not trigger a restart loop when temporary unavailability should only remove readiness.

## Shutdown is a process contract

State what stops accepting work, what drains, what gets canceled, what may be abandoned, who waits, and the maximum grace period. Use a fresh bounded shutdown context rather than the already-canceled request/signal context. Process termination must wait for cleanup; `os.Exit` bypasses deferred calls.

For HTTP, `Server.Shutdown` closes listeners and idle connections and waits for active connections to become idle, subject to its context. A serving loop returns `http.ErrServerClosed` before all shutdown work necessarily finishes. Do not exit main just because `Serve` returned. `Shutdown` neither closes nor waits for hijacked connections such as WebSockets; track and stop those through their own lifecycle. `RegisterOnShutdown` can initiate protocol-specific stopping, but does not itself join that work.

When grace expires, define an explicit fallback. `Server.Close` can close ordinary active connections, but still does not clean up arbitrary owned workers, hijacked connections, or every external operation. Report incomplete cleanup rather than promising it happened. Handlers must respond to cancellation for a bounded drain when they own blocking work.

Read [shutdown scenarios](references/shutdown.md) and [the ordinary-HTTP example](examples/server.go). It covers no hijacked connections or application-specific background workers.

## HTTP, resources, and overload

Set header, request, idle, and client timeout policies appropriate to normal requests or streaming. Bound bodies, queues, concurrent requests/jobs, connection pools, retained data, file descriptors, and output buffering. Choose reject, block, drop, or shed behavior under overload and make it visible. A worker bound without a queue bound can still exhaust memory.

Inspect CPU/memory limits, GC behavior, native memory, disk capacity, connection churn, and container-specific runtime defaults on the actual Go version. Do not infer a container's effective parallelism or hard memory bound from host CPU count or a runtime setting alone. Test a representative overload/failure case.

## Persistence, rollout, and recovery

Define migration locking, compatible mixed versions, partial migration, backup/restore when needed, forward recovery, rollback, and who may run each step. Rolling back a binary does not necessarily roll back data or external effects. Exercise restart with partially completed work and determine whether retry can repeat an effect.

Test the shipped binary from a clean installation path with missing/invalid config, expected startup, signals, grace expiry, exit status, and native dependencies. Keep target compile checks distinct from execution on that target. Check working-directory assumptions and required runtime assets.

## Observe what matters

Logs, metrics, and traces should show which operation failed, relevant version/configuration, what may have changed, retry safety, recovery owner, and whether work progresses. Keep cardinality bounded in metric labels; put needed high-cardinality IDs in controlled logs/traces. Redact credentials and sensitive payloads, including in profiles and crash files. Test diagnostic behavior on failures, not only successful requests.

## Return

Provide operational assertion, real process/target evidence, failure and recovery scenarios, resource/observability gaps, and release implications. Distinguish planned checks from observed results. A readiness recommendation is not permission to deploy, migrate, or publish.

## Sources

[net/http](https://pkg.go.dev/net/http), [os/signal](https://pkg.go.dev/os/signal), [os.Exit](https://pkg.go.dev/os#Exit), [runtime](https://pkg.go.dev/runtime), [GC guide](https://go.dev/doc/gc-guide).
