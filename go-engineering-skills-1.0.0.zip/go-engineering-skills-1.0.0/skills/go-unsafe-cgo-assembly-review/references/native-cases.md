# Native lifetime cases

## KeepAlive is not a pointer repair

**Fault:** Convert a Go pointer to an integer, store the integer across other operations, then convert back and add `runtime.KeepAlive` afterward as a blanket fix.

**Repair:** Use a supported conversion pattern with a live owner and valid bounds, or redesign the boundary around a C allocation or `cgo.Handle`. `KeepAlive` can protect a real reachability/finalizer lifetime; it does not validate arbitrary integer-pointer round trips or synchronize explicit Close.

Do not execute knowingly invalid pointer patterns as ordinary passing examples. Test valid layouts and pointer lifetimes under appropriate dynamic checks; isolate intentional crash cases when needed.

## Handle lifetime and synchronous callbacks

[The C source](../examples/bridge.c) allocates a subscription containing an integer handle and calls an exported Go function synchronously from emit. [The Go owner](../examples/callback.go) serializes each call and close. No foreign thread stores or uses a raw Go pointer; the handle lookup recovers a Go sink while the handle is alive.

`Close` waits for any emit holding the lock, frees the C subscription, deletes the handle, and marks the subscription closed while still holding the lock. Later emits return `ErrClosed`. The callback only updates a sink; it cannot call emit or close recursively. That restriction is necessary because the lock remains held during the callback.

This example's native API has no async event source and creates no native threads. For a real asynchronous API, holding this Go lock does not stop foreign callbacks by itself. The adapter must use the library's stop/unregister/join rules, retain the handle until all in-flight callbacks finish, and handle reentrancy explicitly. A `Delete` immediately after a best-effort unregister can cause a late callback to resolve a dead handle.

## Pinning is a separate design

A handle keeps an association to a Go value; it does not mean C may interpret the integer as that value's memory address. `runtime.Pinner` supplies explicit pinning for permitted objects, not arbitrary retention of Go pointer graphs. C-owned buffers plus a documented copy may be simpler than prolonged pinning. Validate nested pointers, allocator pairing, asynchronous completion, and unpin only when no native access remains.

## Evidence boundary

Run ordinary native tests, race-enabled tests, checkptr, and `GOEXPERIMENT=cgocheck2` as separate evidence where supported. Passing all four for this example proves only its tested synchronous protocol and target. It does not establish another native library, signal interaction, asynchronous callback API, sanitizer support, or binary ABI compatibility.
