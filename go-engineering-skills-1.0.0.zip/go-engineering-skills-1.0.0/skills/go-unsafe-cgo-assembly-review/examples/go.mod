module example.com/go-skill-examples/go-unsafe-cgo-assembly-review

go 1.23.0
