#ifndef GO_SKILLS_BRIDGE_H
#define GO_SKILLS_BRIDGE_H
#include <stdint.h>
typedef struct subscription subscription;
subscription *subscription_new(uintptr_t handle);
void subscription_emit(subscription *s, int value);
void subscription_free(subscription *s);
#endif
