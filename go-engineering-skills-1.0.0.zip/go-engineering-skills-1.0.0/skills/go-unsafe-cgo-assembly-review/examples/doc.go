// Package callback demonstrates a retained C handle with synchronous callbacks.
// Callback tests require CGO_ENABLED=1 and a supported C compiler.
package callback
