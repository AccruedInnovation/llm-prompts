//go:build cgo

package callback

/*
#include "bridge.h"
*/
import "C"
import (
	"errors"
	"runtime/cgo"
	"sync"
	"sync/atomic"
)

var ErrClosed = errors.New("subscription closed")
var ErrSink = errors.New("non-nil sink required")
var ErrAllocate = errors.New("C subscription allocation failed")

type Sink struct {
	last  atomic.Int64
	calls atomic.Int64
}

func (s *Sink) Last() int64  { return s.last.Load() }
func (s *Sink) Calls() int64 { return s.calls.Load() }

// Subscription must not be copied. Its callback is synchronous and cannot reenter it.
type Subscription struct {
	mu     sync.Mutex
	ptr    *C.subscription
	handle cgo.Handle
}

func New(sink *Sink) (*Subscription, error) {
	if sink == nil {
		return nil, ErrSink
	}
	h := cgo.NewHandle(sink)
	ptr := C.subscription_new(C.uintptr_t(h))
	if ptr == nil {
		h.Delete()
		return nil, ErrAllocate
	}
	return &Subscription{ptr: ptr, handle: h}, nil
}
func (s *Subscription) Emit(value int32) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.ptr == nil {
		return ErrClosed
	}
	C.subscription_emit(s.ptr, C.int(value))
	return nil
}
func (s *Subscription) Close() {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.ptr == nil {
		return
	}
	C.subscription_free(s.ptr)
	s.ptr = nil
	s.handle.Delete()
	s.handle = 0
}

//export goValue
func goValue(h C.uintptr_t, value C.int) {
	sink := cgo.Handle(h).Value().(*Sink)
	sink.last.Store(int64(value))
	sink.calls.Add(1)
}
