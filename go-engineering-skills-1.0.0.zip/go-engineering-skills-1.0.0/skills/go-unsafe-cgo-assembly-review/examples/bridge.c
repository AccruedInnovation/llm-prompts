//go:build cgo

#include "bridge.h"
#include <stdlib.h>
_Static_assert(sizeof(int) == 4, "example requires 32-bit C int");
extern void goValue(uintptr_t handle, int value);
struct subscription { uintptr_t handle; };
subscription *subscription_new(uintptr_t handle) {
 subscription *s = malloc(sizeof(*s));
 if (s != NULL) { s->handle = handle; }
 return s;
}
void subscription_emit(subscription *s, int value) { goValue(s->handle, value); }
void subscription_free(subscription *s) { free(s); }
