//go:build cgo

package callback

import (
	"errors"
	"sync"
	"testing"
)

func TestCallbackLifetime(t *testing.T) {
	sink := &Sink{}
	s, err := New(sink)
	if err != nil {
		t.Fatal(err)
	}
	defer s.Close()
	if err := s.Emit(42); err != nil {
		t.Fatal(err)
	}
	if sink.Last() != 42 || sink.Calls() != 1 {
		t.Fatal("callback not delivered")
	}
	s.Close()
	s.Close()
	if err := s.Emit(7); !errors.Is(err, ErrClosed) {
		t.Fatal(err)
	}
	if sink.Last() != 42 || sink.Calls() != 1 {
		t.Fatal("callback after close")
	}
}
func TestConcurrentEmitAndClose(t *testing.T) {
	sink := &Sink{}
	s, err := New(sink)
	if err != nil {
		t.Fatal(err)
	}
	defer s.Close()
	var wg sync.WaitGroup
	errCh := make(chan error, 8)
	for i := 0; i < 8; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := 0; j < 100; j++ {
				err := s.Emit(int32(j))
				if err != nil && !errors.Is(err, ErrClosed) {
					errCh <- err
					return
				}
			}
		}()
	}
	s.Close()
	wg.Wait()
	close(errCh)
	for err := range errCh {
		t.Fatal(err)
	}
	before := sink.Calls()
	if err := s.Emit(9); !errors.Is(err, ErrClosed) {
		t.Fatal(err)
	}
	if sink.Calls() != before {
		t.Fatal("late callback")
	}
}
func TestNilSinkRejected(t *testing.T) {
	if _, err := New(nil); !errors.Is(err, ErrSink) {
		t.Fatal(err)
	}
}
func TestZeroSubscriptionClosed(t *testing.T) {
	var s Subscription
	s.Close()
	if err := s.Emit(1); !errors.Is(err, ErrClosed) {
		t.Fatal(err)
	}
}
