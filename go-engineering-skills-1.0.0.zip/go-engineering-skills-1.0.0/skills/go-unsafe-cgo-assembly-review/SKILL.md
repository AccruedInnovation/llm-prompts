---
name: go-unsafe-cgo-assembly-review
description: "Review Go unsafe pointers, cgo callbacks, native memory, ABI, assembly, and compiler directives. Use only when these boundaries exist; verify lifetime rules and exact target-specific evidence."
---

# Go Unsafe, cgo, Assembly, and ABI Review

Start with a concrete native boundary and its invariants. Ordinary Go tests do not establish pointer lifetime or ABI safety. Do not introduce unsafe or cgo merely to use this skill.

## Inventory the actual boundary

Find unsafe conversions, C preambles and generated bindings, C/C++/assembly sources, libraries, exported/imported symbols, callbacks, build modes, and material `//go:` directives. Record exact Go/C toolchains, flags, target, CGO mode, native versions, and calling conventions. Distinguish generated declarations from authoritative headers and generation inputs.

## Separate the mechanisms

| Mechanism | What it does | What it does not prove |
| --- | --- | --- |
| `unsafe.Pointer` | Allows the documented pointer conversion patterns | That a stored integer remains a live pointer, memory is in bounds, or a lifetime is valid |
| `runtime.KeepAlive` | Keeps an object reachable until a point in Go code | Pinning, synchronization, delayed explicit Close, or validity of an otherwise illegal conversion |
| `runtime.Pinner` | Explicitly pins allowed Go objects until unpinned | That every object reachable from them may be retained by C or that C has stopped using them |
| `runtime/cgo.Handle` | Refers to a Go value through an integer token usable across C | Automatic deletion or safety after Delete while callbacks remain possible |

Read the documented conversion rules. Storing `uintptr(p)` and converting it back later can lose GC/lifetime guarantees. `unsafe.Add` can avoid an intermediate integer but does not make out-of-bounds arithmetic valid. Review alignment, backing allocation, string immutability, slice bounds, and aliasing explicitly. Do not use `reflect` headers as a general-purpose way to manufacture live strings or slices from integers.

C may retain a Go pointer only under the applicable pointer/pinning rules. Do not assume a slice/string header can be retained because its data address looks stable. Check any Go pointers reachable in passed memory and when pinning begins/ends. Prefer C-owned buffers or opaque handles where they simplify the actual lifetime.

## Own allocation and callback shutdown

For every resource, name allocator/free pair, transfer/borrow rule, synchronization, release point, and error path. Native memory referenced by a Go slice must not be freed or reallocated while readers remain. A finalizer or cleanup facility is not timely lifecycle control.

For callbacks with retained state, use this order as the required outcome: prevent new callbacks; unregister/stop the native source; prove in-flight callbacks are done; delete the Go handle; free remaining native state in the API's required order. The exact sequence may need adaptation if the API requires some native state during callback completion. Document it rather than assuming unregister joins callbacks.

[The callback example](examples/callback.go) uses a C-owned subscription retaining only a handle token. A Go mutex serializes emit and close; callbacks run synchronously and never reenter the subscription. [Its tests](examples/callback_test.go) check live delivery, concurrent emit/close, close idempotence, and rejection after close. This is not a model for an asynchronous native library without an additional unregister-and-join mechanism. See [native cases](references/native-cases.md).

## Panic, thread, signal, and ABI rules

Do not allow an ordinary Go panic or a C++ exception to cross a boundary that cannot support it. Recover only where a defined callback error/result policy can safely contain failure; do not continue with corrupted native state. Document thread affinity, TLS, callbacks from foreign threads, blocking foreign calls, process signals, and cancellation limits. Context alone cannot interrupt an arbitrary C call.

Check size, alignment, padding, endian order, widths, packing, unions, bitfields, enum representation, generated layout drift, and supported targets. A Go struct that resembles a C struct is not proof of layout. Keep translated package-local C types out of public Go APIs unless that coupling is deliberate.

Assembly requires the exact Go ABI, register/stack conventions, pointer maps, and runtime constraints. `//go:linkname`, `//go:nosplit`, and `//go:noescape` are not harmless optimization hints; validate their asserted invariants and version dependence. Do not claim a stable cross-release Go ABI without the actual contract.

## Select complementary checks

Use focused native integration and lifetime tests; Go race checks; `-gcflags=all=-d=checkptr=2` when supported; build-time `GOEXPERIMENT=cgocheck2` for stronger cgo pointer checks; ABI/layout fixtures; and supported native sanitizers/leak tests. `GODEBUG=cgocheck=2` is not a replacement for the build-time experiment on versions that reject it.

Verify supported target and compiler combinations before sanitizer runs. Race/checkptr/cgo checks have distinct coverage and miss unexecuted paths; Go race instrumentation does not prove arbitrary foreign memory accesses race-free. Fuzz malformed boundary inputs only within bounded disposable conditions.

## Return

Report each invariant, concrete failure trace, exact tools and target, executed checks, unsupported/unrun cases, severity/confidence, and smallest repair. Do not call a syntax check an ABI test or a synchronous callback test proof of asynchronous shutdown.

## Sources

[unsafe](https://pkg.go.dev/unsafe), [runtime](https://pkg.go.dev/runtime), [cgo pointer rules](https://pkg.go.dev/cmd/cgo#hdr-Passing_pointers), [cgo.Handle](https://pkg.go.dev/runtime/cgo#Handle), [Go assembly](https://go.dev/doc/asm).
