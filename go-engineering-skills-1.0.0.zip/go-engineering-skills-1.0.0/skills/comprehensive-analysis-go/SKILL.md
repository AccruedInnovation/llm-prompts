---
name: comprehensive-analysis-go
description: "Survey a Go codebase for high-impact architectural, correctness, module, testing, operational, and maintainability opportunities, then route only material concerns to focused Go reviews."
---

# Comprehensive Go Analysis

Act as an expert software architect and Go reviewer. Produce a prioritized, evidence-based survey—not a generic style audit and not an automatic request for every specialist reviewer.

## Core philosophy

Evaluate the code through deep-module architecture: simple, stable public surfaces hiding meaningful implementation complexity. Flag shallow abstractions only when they increase indirection, change amplification, or hidden coupling. Do not add layers, interfaces, packages, services, or frameworks unless they materially improve responsibility, testability, change locality, or failure containment.

## Establish context first

Record:

- module and `go.work` topology;
- `go`/`toolchain` directives and effective Go version;
- commands, libraries, generated code, build tags, targets, CGO, and release shape;
- repository-owned format, lint, test, generation, integration, and release commands;
- changed scope and whether this is a whole-codebase survey or candidate review.

Do not infer support for tags, targets, CGO variants, minimum Go, or standalone modules merely because one local configuration builds.

## Survey dimensions

1. **Outcome and responsibility:** Does each package or component own a coherent capability? Are boundaries deep, narrow, and independently testable?
2. **Change amplification:** Which domain changes require edits across unrelated packages, generated artifacts, handlers, persistence, tests, and configuration?
3. **Dependency direction:** Do dependencies point toward stable domain concepts? Identify cycles, infrastructure leakage, package graph workarounds, and shared mutable authority.
4. **Domain integrity:** Does each invariant have one authoritative meaning and owner, with consistent enforcement at every required trust or transaction boundary? Preserve complementary request validation and database constraints; remove competing definitions, not necessary protection.
5. **Abstraction ROI:** For packages, interfaces, repositories, services, middleware, helpers, generics, and wrappers, ask whether the abstraction hides volatility or merely relocates complexity.
6. **API and module evolution:** Review exported surface, method sets, implicit interface satisfaction, errors, zero values, module paths, minimum Go, build tags, wire formats, and downstream compatibility.
7. **Correctness and failure:** Review nil/zero-value behavior, slice aliasing, map order, partial results, retries, idempotency, persistence, transactions, cleanup, panic boundaries, and recovery.
8. **Concurrency:** Review goroutine ownership, cancellation, joins, channels, backpressure, timers, synchronization, races, deadlocks, leaks, and logically invalid interleavings.
9. **Testability and evidence:** Identify hidden I/O, globals, time, randomness, process state, and over-mocking. Assess realistic success, failure, cancellation, restart, platform, and consumer coverage.
10. **Module and supply chain:** Review `go.mod`, `go.sum`, `go.work`, `replace`, vendor, private-module policy, generators, native dependencies, and known-vulnerability process.
11. **Security:** Review trust boundaries, input bounds, paths, archives, templates, subprocesses, network destinations, HTTP proxy/redirect behavior, secrets, authorization, and unsafe/native code.
12. **Operations:** Review startup, configuration resolution, health/readiness, signals, shutdown, drain, migration, rollback, observability, resource limits, and release artifacts.
13. **Performance:** Identify only evidence-supported algorithmic, allocation, contention, I/O, database, GC, or PGO opportunities. Avoid folklore-based pointer or preallocation findings.
14. **Documentation and onboarding:** Identify missing contracts, domain assumptions, examples, runbooks, generation instructions, and release procedures that materially affect future change.
15. **Pattern drift:** Report competing implementations only when inconsistency increases cognitive load, changes behavior, or weakens contracts.

## Go-specific review rules

- “Consumer defines the interface” is a strong default, not an absolute law. Public extension points and shared contracts may justify provider-owned interfaces.
- Prefer concrete return types ordinarily, but judge the actual public contract.
- Use `%w` only when underlying error identity should be caller-visible.
- Judge pointer/value semantics through mutation, identity, method sets, aliasing, copy safety, and evidence—not size folklore.
- An unbuffered channel is not inherently a deadlock. Review the complete communication and cancellation protocol.
- Context carries cancellation, deadlines, and genuinely request-scoped metadata. Ordinary domain data stays explicit.
- Require timely resource cleanup, but do not prescribe `defer` when explicit closure is needed for loops, order, or error handling.
- Derive severity from consequence and reachability. Do not label every leak High or every concurrency issue Critical.
- Separate handler-only tests from transport, streaming, TLS, cancellation, connection, and shutdown tests.

## Optional stack lens

HTMX, Alpine.js, and server-driven UI conventions are **not universal Go rules**. When the repository intentionally uses that architecture, route to `go-web-htmx-review` and inspect fragment contracts, OOB swaps, selector stability, template boundaries, and client/server state ownership. Do not flag JSON, full pages, or Alpine network calls solely because they exist outside that declared architecture.

## Routing

Use this survey to identify hotspots. Recommend focused skills only for material assertions:

- API/module → `go-api-module-boundary-review`
- correctness/concurrency → `go-correctness-concurrency-review`
- I/O, JSON, HTTP, SQL, files, processes → `go-io-boundary-review`
- measured performance → `go-performance-review`
- test strategy → `go-test-strategy-review`
- operations → `go-operational-readiness-review`
- security/supply chain → `go-security-supply-chain-review`
- unsafe/`cgo`/assembly → `go-unsafe-cgo-assembly-review`
- HTMX/Alpine → `go-web-htmx-review`

For large repositories, split only into disjoint responsibility areas or assertion sets. Deduplicate findings and retain reviewer attribution. Do not create one reviewer per package automatically.

## Finding format

Return findings ordered by consequence and confidence. Use:

- **Finding ID**
- **Category and location**
- **Issue**
- **Evidence and applicability**
- **Severity:** Critical / High / Medium / Low
- **Confidence:** High / Medium / Low
- **Impact**
- **Compatibility dimensions:** source API, module/import, behavior, wire, persistence, database schema, HTTP/RPC, configuration, CLI, operations
- **Refactor cost:** Low / Medium / High
- **Proposed refactor**
- **Verification required to close**
- **Focused skill or owner**, when escalation is warranted

Also return:

- repository and configuration coverage;
- important scopes not inspected;
- evidence reused;
- residual uncertainty;
- up to three supported architecture opportunities; do not invent a quota;
- focused reviews actually warranted.

## Do not recommend

- an abstraction with no demonstrated volatility, substitution, or testing value;
- package splitting solely for size;
- microservices without strong operational and ownership evidence;
- dependency-injection frameworks where constructors suffice;
- a universal repository pattern;
- channels instead of mutexes as a slogan;
- generics merely to remove trivial duplication;
- broad rewrites when a contained correction resolves the issue;
- tool installation or a new dependency without explicit project authority.

## Concrete survey checks

Trace a representative request from validation to state change and real consumer. Try a cancellation during the effect, a duplicate after restart, and two concurrent attempts at the same invariant when relevant. Distinguish an executed observation from an analytical counterexample. Check both faulty and valid patterns; finding a mutex, an unbuffered channel, a concrete return type, or repeated validation is not a defect by itself.

For large repositories, keep a small coverage note per responsibility area and explicitly revisit shared interfaces. Load supporting skill references only for the concern they address. Stop when the scoped survey and material findings are supported; do not fill the context with unrelated package inventories. No specific contract schema, work graph, or package metadata is required.

## Sources

[Go specification](https://go.dev/ref/spec), [Go memory model](https://go.dev/ref/mem), [Effective Go](https://go.dev/doc/effective_go), [module reference](https://go.dev/ref/mod). Findings must cite the actual repository code and promised behavior, not these general references alone.
