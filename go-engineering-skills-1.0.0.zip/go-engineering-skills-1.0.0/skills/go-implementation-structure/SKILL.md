---
name: go-implementation-structure
description: "Design Go packages, types, interfaces, state ownership, and test boundaries for a new feature or substantial refactor. Use for design work, not as a mandatory plan for a small private edit."
---

# Go Implementation Structure

Design enough to remove consequential guesses, then implement. No specific planning framework, contract schema, work graph, or separate agent is required. A small change may need only a short note and a regression test.

## Establish the design boundary

Read the goal, fixed interfaces and decisions, current packages, tests, module/workspace layout, generated sources, and supported build configurations. Separate observed behavior from the requested change. Preserve existing requirements and harmless private design freedom.

For a material design, state the result, non-goals, important invariant, owner, public contract, failure behavior, and how a real consumer will test it. Use a table or existing design note rather than a new document system.

## Choose packages and abstractions

Give each package a coherent responsibility, with a small public surface hiding meaningful work. Show the import direction. Break cycles by changing responsibilities, not by adding a shared package containing unrelated types.

Before adding a type, interface, generic, wrapper, options system, or service layer, name what it prevents or makes easier to change. A named ID prevents accidental mixing at checked call sites; a mutex-owning type can keep all related state updates together; a consumer-owned interface can isolate a real I/O boundary. A wrapper that just repeats another API may add no value.

Use explicit constructor arguments for dependencies. A single concrete implementation and easy direct tests do not require an interface. Public extension points may need provider-owned interfaces. Keep generality limited to a present need. Do not require a repository abstraction for every database table.

## State exactly what types enforce

Named types do not validate external data, constants do not close enums, and private fields do not prevent a caller from declaring an exported zero value. Separate representable values from valid values, then define construction, validation, and transitions.

```go
type State uint8
const (
    Idle State = iota
    Running
)
// This still compiles:
var unknown State = 255
```

For a state machine, choose a useful zero state or make every public operation reject invalid/uninitialized state. Hide mutable representation when callers should not bypass transitions. Do not expose a writable state field and claim that a constructor enforces all transitions.

Use one authoritative meaning and owner for an invariant, not necessarily one enforcement point. Request validation may provide good errors, package methods may protect in-memory state, and database constraints may protect concurrent writes. Keep these definitions aligned. An “unused name” precheck cannot replace a uniqueness constraint when concurrent inserts can both pass it.

See [types and invariant examples](references/types-and-invariants.md) and [the tested state type](examples/state.go).

## Define ownership and failure before splitting work

Name who mutates state and who owns each goroutine, channel close, cancellation function, timer, lock, file, connection, transaction, process, and retry loop. State whether inputs are copied, borrowed, transferred, or shared. Explain how work ends and when resources become safe to release.

Distinguish requested, accepted, executing, completed, failed, partially completed, and unknown results when those states change caller behavior. Choose the point at which a state change commits. Define retry safety, duplicate handling, cancellation, restart, and recovery only where the feature needs them. Go's type checker does not prove these runtime properties.

Separate deterministic decisions from I/O where that reduces test cost without building a framework. Keep clocks, IDs, random sources, environment, and external services explicit when tests need control over them.

## Deliver a buildable sequence

Choose coherent steps that deliver a consumer-visible result or establish a necessary foundation with its own test and a named next consumer. Do not split by line count, file count, or one agent per package. Settle a shared interface before two sides implement it independently.

For each substantial step, identify affected packages and public symbols, prerequisites, allowed private choices, test fixture, expected result, and integration point. Keep code, tests, and relevant docs together. Include generated outputs, migration, or target-specific work when the actual consumer needs them. Do not impose routine file names when they do not affect a contract.

## Return

Provide the chosen package/type/ownership design, important alternatives and costs, fixed versus private choices, the implementation order, and the tests that can refute the design. Identify a missing consequential decision without inventing it. Avoid hashes and manifests unless a real release or reproduction need calls for them.

## Sources

[Go specification](https://go.dev/ref/spec), [Effective Go](https://go.dev/doc/effective_go), [Go memory model](https://go.dev/ref/mem), [database transactions](https://go.dev/doc/database/execute-transactions).
