# Types and invariant enforcement

## Named type, not closed enum

**Trigger:** An API accepts a named numeric state or callers can write fields directly.

**Rule:** A named type restricts assignments between types. It does not restrict values to declared constants. Validate the allowed set, and keep transition state private when transitions matter.

**Faulty claim:** `type Mode uint8` plus `const Automatic, Manual` makes all other modes impossible.

**Repair choices:** Accept the named type and reject unknown values; parse into a private representation; or expose operations that hide modes entirely. Choose a useful zero value or a clear error for it. Do not introduce a complex variant framework for two simple states.

[The runnable example](../examples/state.go) uses an exported `Machine` whose zero value is valid and a private state field. `Start` and `Stop` allow only their defined transitions. The test rejects `State(255)` and invalid repeated transitions. It tests typed nil separately: returning a nil `*Failure` as `error` creates a non-nil interface. Return an explicit nil error on success instead.

## Same invariant, more than one boundary

**Trigger:** An agent proposes removing database constraints because application validation exists.

Consider two requests, A and B. A reads “name unused.” B reads the same. A inserts. B inserts. Without a database constraint or another adequate transaction rule, both can succeed. A successful sequential unit test does not exclude this trace.

**Repair:** Keep the database constraint as the final concurrent-write rule. Keep early validation for usability when useful. Translate the known constraint violation to the chosen domain error without parsing arbitrary message text when the driver exposes structured codes. Test two concurrent requests against the actual engine and transaction isolation. Expect one accepted write and a defined conflict; verify the row count and committed data.

The bundled examples do not include a database engine. This trace is analysis, not a claim that a database integration test ran.

## Valid alternatives and false positives

A concrete type with one implementation can be easier to use and test than an interface. A public plugin contract may correctly define its interface at the provider. A small function receiving an `io.Reader` may need no extra test seam. A private helper split across files does not violate package ownership. Retain these valid designs unless a specific change or failure case shows otherwise.
