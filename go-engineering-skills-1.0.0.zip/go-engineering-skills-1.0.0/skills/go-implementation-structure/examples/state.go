// Package state demonstrates a useful zero value and guarded transitions.
package state

import "errors"

type State uint8

const (
	Idle State = iota
	Running
)

var ErrState = errors.New("invalid state or transition")

func ParseState(n uint8) (State, error) {
	s := State(n)
	if s != Idle && s != Running {
		return Idle, ErrState
	}
	return s, nil
}

// Machine's zero value is idle. The caller must serialize access.
type Machine struct{ state State }

func (m *Machine) State() State { return m.state }
func (m *Machine) Start() error {
	if m.state != Idle {
		return ErrState
	}
	m.state = Running
	return nil
}
func (m *Machine) Stop() error {
	if m.state != Running {
		return ErrState
	}
	m.state = Idle
	return nil
}

type Failure struct{}

func (*Failure) Error() string { return "failure" }

// TypedNil is deliberately faulty as a success-return pattern.
func TypedNil() error { var err *Failure; return err }
