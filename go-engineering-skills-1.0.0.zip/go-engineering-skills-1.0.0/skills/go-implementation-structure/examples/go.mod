module example.com/go-skill-examples/go-implementation-structure

go 1.23.0
