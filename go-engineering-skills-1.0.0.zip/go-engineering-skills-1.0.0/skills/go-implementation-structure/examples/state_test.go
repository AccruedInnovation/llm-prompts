package state

import (
	"errors"
	"testing"
)

func TestNamedStateIsNotClosed(t *testing.T) {
	s := State(255)
	if s == Idle || s == Running {
		t.Fatal("unexpected declared state")
	}
	if _, err := ParseState(uint8(s)); !errors.Is(err, ErrState) {
		t.Fatalf("invalid state accepted: %v", err)
	}
	for _, n := range []uint8{0, 1} {
		if _, err := ParseState(n); err != nil {
			t.Fatal(err)
		}
	}
}
func TestZeroValueAndTransitions(t *testing.T) {
	var m Machine
	if m.State() != Idle {
		t.Fatal("zero value must be idle")
	}
	if err := m.Stop(); !errors.Is(err, ErrState) {
		t.Fatal("stop from idle accepted")
	}
	if err := m.Start(); err != nil {
		t.Fatal(err)
	}
	if err := m.Start(); !errors.Is(err, ErrState) {
		t.Fatal("repeated start accepted")
	}
	if m.State() != Running {
		t.Fatal("rejection changed state")
	}
	if err := m.Stop(); err != nil {
		t.Fatal(err)
	}
}
func TestTypedNilError(t *testing.T) {
	if TypedNil() == nil {
		t.Fatal("typed nil should produce a non-nil interface")
	}
	var good error
	if good != nil {
		t.Fatal("explicit nil interface is not nil")
	}
}
