package webexample

import (
	"html/template"
	"net/http"
)

var page = template.Must(template.New("page").Parse(`<!doctype html><html><body><main id="result">{{.}}</main></body></html>`))
var fragment = template.Must(template.New("fragment").Parse(`<main id="result">{{.}}</main>`))

// Render shows response selection. The caller owns request limits and error logging.
func Render(w http.ResponseWriter, r *http.Request) error {
	w.Header().Add("Vary", "HX-Request")
	w.Header().Add("Vary", "HX-History-Restore-Request")
	w.Header().Set("Cache-Control", "private, no-store")
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	selected := page
	if r.Header.Get("HX-Request") == "true" && r.Header.Get("HX-History-Restore-Request") != "true" {
		selected = fragment
	}
	return selected.Execute(w, r.URL.Query().Get("name"))
}
