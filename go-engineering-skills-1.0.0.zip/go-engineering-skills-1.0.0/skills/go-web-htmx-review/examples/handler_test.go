package webexample

import (
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"
)

func TestPageFragmentAndHistory(t *testing.T) {
	for _, tc := range []struct {
		name              string
		hx, history, full bool
	}{
		{"page", false, false, true}, {"fragment", true, false, false}, {"history", true, true, true}, {"history-only", false, true, true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			req := httptest.NewRequest("GET", "/?name=hello", nil)
			if tc.hx {
				req.Header.Set("HX-Request", "true")
			}
			if tc.history {
				req.Header.Set("HX-History-Restore-Request", "true")
			}
			rec := httptest.NewRecorder()
			rec.Header().Set("Vary", "Accept-Encoding")
			if err := Render(rec, req); err != nil {
				t.Fatal(err)
			}
			if strings.HasPrefix(rec.Body.String(), "<!doctype html>") != tc.full {
				t.Fatal(rec.Body.String())
			}
			vary := strings.Join(rec.Header().Values("Vary"), ",")
			for _, key := range []string{"Accept-Encoding", "HX-Request", "HX-History-Restore-Request"} {
				if !strings.Contains(vary, key) {
					t.Fatalf("missing Vary %s: %s", key, vary)
				}
			}
		})
	}
}
func TestEscapingAndPrivateCache(t *testing.T) {
	req := httptest.NewRequest("GET", "/?name="+url.QueryEscape(`<script>alert("x")</script>`), nil)
	rec := httptest.NewRecorder()
	if err := Render(rec, req); err != nil {
		t.Fatal(err)
	}
	body := rec.Body.String()
	if strings.Contains(body, "<script>") || !strings.Contains(body, "&lt;script&gt;") {
		t.Fatal(body)
	}
	if rec.Header().Get("Cache-Control") != "private, no-store" {
		t.Fatal("private cache policy missing")
	}
}
