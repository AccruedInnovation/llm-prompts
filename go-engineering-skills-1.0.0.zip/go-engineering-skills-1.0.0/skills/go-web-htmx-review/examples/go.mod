module example.com/go-skill-examples/go-web-htmx-review

go 1.23.0
