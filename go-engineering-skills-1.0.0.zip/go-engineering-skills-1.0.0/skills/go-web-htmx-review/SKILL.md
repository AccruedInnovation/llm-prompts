---
name: go-web-htmx-review
description: "Review Go applications that already use HTMX, Alpine, and html/template. Check page/fragment contracts, cache/history, swaps, security, and browser behavior; do not impose this stack on other Go projects."
---

# Go HTMX and Server-Rendered UI Review

Apply only to a deliberately selected server-rendered HTMX/Alpine stack. Read its actual version/configuration, routes, templates, response rules, session policy, and tests. JSON endpoints, full pages, and client-side requests are not defects merely because they exist.

## Trace the request and response variant

List full-page routes, fragment routes, HTMX request handling, targets, swaps, OOB updates, stable IDs, events, redirects, and error rendering. Distinguish ordinary navigation, boosted navigation, normal fragment requests, and history restoration after a cache miss. A history miss may need full-page content even when other HX headers are present; check the version's `historyRestoreAsHxRequest` or equivalent settings rather than using one header blindly.

When one URL returns different representations based on `HX-Request`, the cache policy must reflect that variation, typically with `Vary: HX-Request`. Include other actual representation selectors as needed. Authenticated or sensitive pages also need appropriate cache/privacy rules; Vary alone is not privacy protection. Preserve existing Vary values rather than overwriting them.

[The handler examples](examples/handler_test.go) test page, fragment, history restore, escaping, and Vary behavior. They do not execute the browser or prove real cache behavior.

## Define success and failure handling

State what validation errors return and whether the chosen status is swapped by the installed HTMX response-handling configuration. A server returning a correct 422 fragment does not by itself ensure the browser renders it. Avoid changing all errors to 200 solely to hide missing client configuration.

HTMX response headers are not processed as a substitute for browser-followed 3xx redirect handling. Choose the documented `HX-Redirect`, `HX-Location`, or ordinary redirect behavior for the intended navigation and status. Check session expiry and authentication responses so a login page is not accidentally swapped into a small component.

Bound duplicate requests and stale responses. Use request synchronization, disabled controls, version checks, or server idempotency only where they protect the chosen interaction. Disabling a button alone cannot guarantee one server-side effect.

## State, security, and accessibility

Keep domain state, authorization, and validation on the server or the project's actual authoritative owner. Alpine can own transient display state without becoming a second source of permissions or business truth. Templates should compose presentation, not hide important transitions or database operations.

Use `html/template` for contextual escaping; review every trusted HTML/JS/URL cast and any untrusted template source. HX request headers are client-controlled and do not prove authorization or CSRF safety. Check CSRF tokens/origin policy, cookies, CSP, sensitive content in history storage, and cross-origin requests.

Test stable IDs and selectors after swaps, OOB updates, history, focus, keyboard operation, error announcements, and progressive enhancement when promised. Handle stale/disconnected/partial states honestly. Do not make a specific DOM layout mandatory when behavior and accessibility remain correct.

## Evidence and return

Use handler tests for selection, headers, escaping, and fragment shape. Use a real browser and server for navigation/history, actual swaps, status handling, cookies, CSRF, CSP, focus, and accessibility. Browser checks not run remain unproved; do not call a string assertion an end-to-end test.

Report the actual violated stack contract, location, user effect, evidence, and smallest repair. Retain valid non-HTMX routes and intentional client state. Do not redesign the application solely to match a preferred web pattern.

## Sources

[HTMX documentation](https://htmx.org/docs/), [HTMX reference](https://htmx.org/reference/), [HX-Redirect](https://htmx.org/headers/hx-redirect/), [HX-Location](https://htmx.org/headers/hx-location/), [html/template](https://pkg.go.dev/html/template).
