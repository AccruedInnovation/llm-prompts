---
name: go-performance-review
description: "Investigate measured Go CPU, memory, allocation, contention, latency, or throughput problems. Select benchmarks, profiles, and traces by the question; do not recommend speculative optimization."
---

# Go Performance Investigation

Use this for a concrete performance question or a supported resource risk. Do not turn a style review into a performance claim. State the workload, correct result, target, measurement conditions, and current evidence first.

## Find the relevant cost

Trace the actual request or job: queues, processing, allocation, locks, database, network, serialization, and cleanup. Separate latency, throughput, total CPU, live heap, allocation rate, and peak process memory. They need different evidence. A smaller microbenchmark number is not necessarily a better end-to-end result.

| Observation or question | Useful next measurement | Important limit |
| --- | --- | --- |
| High CPU during useful work | CPU profile under representative load | Samples show on-CPU cost, not all waiting time. |
| Growing retained memory | Heap profile with comparable GC/load conditions | Live sampled heap is not all RSS or native memory. |
| Excess allocation and GC work | `-benchmem`, allocation profile, allocation sites | Allocation rate and retained memory are different. |
| Contended shared state | Mutex profile; block profile where needed | Sampling must be enabled; instrumentation can change cost. |
| Bursty latency or scheduling stalls | Execution trace with a bounded workload | A short trace may miss rare events; traces may expose data. |
| High database wait | Pool stats, query timings, query plan and engine metrics | A Go profile alone cannot explain the database engine. |
| Slow startup or I/O | Timed end-to-end test with cold/warm conditions | Cache state, network, and fixture size change the result. |

Use the existing diagnostics setup rather than adding a public `net/http/pprof` endpoint. Profiles and traces can expose secrets; protect access, retention, and transport.

## Build a meaningful benchmark

Fix the correctness expectation independently. Use realistic input shapes and sizes, including skew, empty and boundary cases when relevant. Keep setup outside timed work unless setup is part of the product cost. Prevent unwanted constant folding or dead-code elimination without creating a global data race.

On Go 1.24+, use the documented `for b.Loop()` form. On older versions, use a `b.N` loop with proper timing and result consumption. Do not mix both styles. [The included benchmarks](examples/benchmark_test.go) and [version-guarded B.Loop example](examples/benchmark_go124_test.go) compare equal results; they are test patterns, not evidence for an application speedup.

Collect several comparable samples; use the repository's qualified statistical comparison tool when available. Compare workload, Go version, CPU, concurrency, power/container limits, GC settings, target, flags, CGO, and PGO. Do not present a single noisy result as a regression or a selected sample as representative. Keep correctness tests separate from benchmark numbers.

## Example investigation commands

Run only commands that match the question, in a declared package and allowed output directory. These forms are illustrative, not a mandate to profile the whole repository:

```sh
go test -run '^$' -bench '^BenchmarkEncode$' -benchmem -count=8 ./codec
go test -run '^$' -bench '^BenchmarkEncode$' -cpuprofile=cpu.out ./codec
go test -run '^$' -bench '^BenchmarkEncode$' -memprofile=mem.out ./codec
go tool pprof -top cpu.out
go tool pprof -sample_index=alloc_space -top mem.out
go test -run '^TestLoad$' -trace=trace.out ./service
go tool trace trace.out
```

Inspect the selected test/benchmark count; a command that matches nothing proves nothing. Do not combine multiple package profiles into one output filename and assume it covers all packages. Keep emitted test binaries and profiles outside release content. Use block/mutex sampling deliberately when the question needs it.

## Choose and verify a repair

Prefer algorithmic fixes, fewer round trips, bounded work, or improved ownership when evidence supports them. Preallocate when size is known and cost matters. Pool only with a clear reset and ownership rule; pooling can retain memory and leak prior contents. Do not assume pointers, goroutines, lock-free code, `unsafe`, or generics are faster.

Check error, cancellation, ordering, and memory bounds after optimization. Re-run the original workload and an independent correctness suite. Under load, report distributions and overload behavior, not just averages. Race-enabled runs check executed concurrency paths; their timing is not normal production performance.

PGO input is part of a build. Inspect `default.pgo` and explicit `-pgo` selection; record the profile's origin and workload. Compare PGO/non-PGO only when that is the question. A Go memory limit is not a hard limit on all process memory; native allocations, mappings, and the operating environment need separate treatment.

## Return

State the measured issue, environment and workload, chosen tool, observed cause or unresolved hypothesis, proposed repair, correctness checks, repeated comparison, and remaining uncertainty. Do not claim causation from one profile or a speedup from a benchmark smoke run.

## Sources

[Go diagnostics](https://go.dev/doc/diagnostics), [runtime/pprof](https://pkg.go.dev/runtime/pprof), [runtime/trace](https://pkg.go.dev/runtime/trace), [testing benchmarks](https://pkg.go.dev/testing), [GC guide](https://go.dev/doc/gc-guide), [PGO](https://go.dev/doc/pgo).
