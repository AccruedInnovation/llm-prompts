package perfexample

import (
	"fmt"
	"strconv"
	"testing"
)

var sample = []int64{0, 1, -3, 42, 1024, 9999999}
var sinkString string
var sinkBytes []byte

func TestFormattingAgrees(t *testing.T) {
	for _, n := range sample {
		a := fmt.Sprintf("%d", n)
		b := strconv.AppendInt(nil, n, 10)
		if a != string(b) {
			t.Fatalf("%q != %q", a, b)
		}
	}
}
func BenchmarkSprintf(b *testing.B) {
	var out string
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		out = fmt.Sprintf("%d", sample[i%len(sample)])
	}
	sinkString = out
}
func BenchmarkAppendInt(b *testing.B) {
	var out []byte
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		out = strconv.AppendInt(nil, sample[i%len(sample)], 10)
	}
	sinkBytes = out
}
