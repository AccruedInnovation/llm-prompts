//go:build go1.24

package perfexample

import (
	"strconv"
	"testing"
)

func BenchmarkAppendIntLoop(b *testing.B) {
	i := 0
	var out []byte
	b.ReportAllocs()
	for b.Loop() {
		out = strconv.AppendInt(nil, sample[i%len(sample)], 10)
		i++
	}
	sinkBytes = out
}
