module example.com/go-skill-examples/go-performance-review

go 1.23.0
