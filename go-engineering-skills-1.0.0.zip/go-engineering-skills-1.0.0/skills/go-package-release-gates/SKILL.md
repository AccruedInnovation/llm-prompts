---
name: go-package-release-gates
description: "Prepare or review a Go module or binary release using clean builds, downstream consumers, target checks, and artifact smoke tests. Use for release work, not every local edit; publication requires separate permission."
---

# Go Module and Binary Release Checks

Distinguish a reusable module from a shipped command or service. Read the release promise, supported targets, current source, local changes, and existing release commands. Choose checks that establish that promise. Do not invent byte-reproducibility or signing requirements.

## Public module

Check module/import path, semantic major suffix, tags including submodule conventions, public packages, license notices, generated source, minimum Go, and supported tag/target/CGO variants. Separate `go` requirements from the main-module/workspace `toolchain` suggestion.

In a disposable clean copy, test with workspace leakage removed where appropriate. Inspect all relevant module roots; `./...` from one root need not cover nested modules. Identify local replacements, private proxies, vendor assumptions, and external consumers. Use a downstream compile/behavior fixture for the actual public surface, including methods, errors, wire forms, and examples.

Run module tidy comparisons only in a copy or with the user's edit authority; tidy can change the graph and directives. `go mod verify` checks downloaded module-cache contents, not all source trust or vendor integrity. Inspect vendor data and generation through the project's own checks. A cached test or local replacement is not proof of registry resolution, publication, or offline installation.

## Binary or service

Build the intended artifact from known source and dependencies with the declared Go/C toolchains, target, tags, CGO, linker/build flags, and PGO input. Inspect `default.pgo` and explicit `-pgo`. Consider `go version -m` for embedded build/module details. Choose `-trimpath` and VCS stamping deliberately for privacy, diagnostics, and the release's reproduction needs.

Check the real archive or installation: expected files, executable permissions, runtime assets, configuration, path assumptions, native libraries, and absence of secrets or task caches. Test from a fresh extraction rather than the authoring tree. Run version/help, valid startup, invalid config, signals, graceful and deadline shutdown, exit status, and relevant migration/rollback checks. Do not claim execution on a target from cross-compilation alone.

For services, define what state survives uninstall or rollback. Removing a binary is not a database rollback. Mixed versions and irreversible migrations need their own evidence and authorized plan.

## Final check discipline

Finish source, docs, generation, and cleanup changes before final checks. Check-only qualification should not silently repair the candidate. A later repair invalidates affected results, not necessarily every unrelated check.

Use a final archive checksum when useful for transfer, not a web of mutually hashing manifests. Keep reports separate from the bytes they identify. Do not bundle build caches, test binaries, native toolchains, credentials, or task state unless those are explicit deliverables. Preserve required license notices.

Record unavailable mandatory checks as missing evidence. Optional analyzers remain optional unless project policy requires them; do not install tools or upgrade the entire graph merely to use this skill. Signing, publication, uploads, deployment, and production migration need their own permission.

## Return

State the release subject, actual artifact, supported versus tested configurations, commands and results, downstream/install evidence, compatibility and migration limits, and any remaining release-blocking gap. Passing local release checks is not a claim that publication occurred.

## Sources

[Module release workflow](https://go.dev/doc/modules/release-workflow), [module reference](https://go.dev/ref/mod), [go command](https://pkg.go.dev/cmd/go), [PGO](https://go.dev/doc/pgo).
