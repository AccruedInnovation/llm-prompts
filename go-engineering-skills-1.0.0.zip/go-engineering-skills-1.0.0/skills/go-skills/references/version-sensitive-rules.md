# Version-sensitive Go rules

Use the project's supported versions, not the newest API by default. Record the exact toolchain separately from `go.mod` language requirements, workspace selection, build tags, experiments, and relevant `GODEBUG`. This is a selected compatibility reference, not a complete release history or a declaration of currently supported Go releases.

| Feature | Version boundary | Review rule |
| --- | --- | --- |
| `go` requirement and automatic toolchain selection | Go 1.21 | `go` declares a required minimum. `toolchain` suggests a toolchain for the main module/workspace; a dependency's suggestion is not a downstream minimum and is not an exact upper pin. Inspect `GOTOOLCHAIN` before commands that may download tools. |
| Loop variables | Go 1.22 language semantics | Variables declared by the loop get per-iteration identity. Assignment to an existing variable still reuses that variable. Inspect the package language version and relevant build constraints, not just `go version`. |
| Timer channels and collection | Go 1.23 runtime behavior | New semantics normally apply when the main module declares Go 1.23 or newer. `GODEBUG=asynctimerchan=1` requests old behavior while that setting remains supported. Do not paste old drain/reset recipes into new code or use `len(timer.C)` as a synchronization test. |
| `testing.B.Loop` | Go 1.24 | Use the documented `for b.Loop()` form when supported. Do not mix it with a `b.N` loop. Keep old benchmarks valid for older minimums. |
| `os.Root` | Go 1.24; more methods in Go 1.25 | Use only methods present in the minimum version. Rooted access limits traversal, not authorization, resource consumption, device access, or every filesystem threat. Check platform-specific limits. |
| `testing/synctest` | Experimental Go 1.24; stable Go 1.25 | Stable code uses `synctest.Test(t, func(t *testing.T) { ... })` and `synctest.Wait()`. Old experimental examples use a different API. Do not impose the experiment on older projects. |
| `sync.WaitGroup.Go` | Go 1.25 | Call `wg.Go(f)`, not `go wg.Go(f)`. It handles task counting, not cancellation or error collection; `f` must not panic. If the group is empty, launch before waiting. |

## Loop example

With Go 1.22 or later language semantics:

```go
var values []*int
for i := 0; i < 3; i++ {
    values = append(values, &i) // Separate variables: 0, 1, 2.
}
var j int
for j = 0; j < 3; j++ {
    values = append(values, &j) // All three pointers refer to the same j.
}
```

Do not flag the first loop as the old capture bug. Do flag concurrent mutation of the shared `j` when a goroutine uses it without synchronization. The per-iteration fix does not copy pointers, slices, or maps stored in the loop value.

## Timers

With the Go 1.23 timer-channel semantics, after `Stop` or `Reset` returns the channel does not deliver an old value from before that call. Garbage collection of an unreferenced timer is different from stopping an operation or waking its reader: `Ticker.Stop` does not close `C`. A loop waiting only on that channel can still leak. Under old semantics, one timer owner must coordinate stop/drain/reset with receivers; an unconditional drain can block after another receiver consumed the value. Prefer fresh timers or a single explicit owner when that simplifies a low-volume path.

Do not assume a compatibility flag exists forever. Check the exact Go version's docs for flags outside the tested project range. Also inspect `default.pgo`: PGO selection can change a build without a command-line flag.

## JSON APIs

This collection's runnable decoding examples use `encoding/json`, not `encoding/json/v2`. Do not infer duplicate-name, casing, or null semantics from the name “JSON.” Inspect the imported API and its options. Experimental status and availability may change; verify the selected toolchain before suggesting a new JSON API.

## Sources

[Toolchain selection](https://go.dev/doc/toolchain), [module directives](https://go.dev/ref/mod), [Go 1.22](https://go.dev/doc/go1.22), [Go 1.23](https://go.dev/doc/go1.23), [Go 1.24](https://go.dev/doc/go1.24), [Go 1.25](https://go.dev/doc/go1.25), [sync](https://pkg.go.dev/sync), [timer compatibility note](https://go.dev/wiki/Go123Timer).
