---
name: go-skills
description: "Implement or repair ordinary Go code using clear types, errors, ownership, and focused tests. Start here for Go changes; use a specialist skill only for a concrete deeper concern."
---

# Go Implementation

Use the project's requirements and conventions first. These are defaults, not laws. Read only the reference needed for the current question; do not load every skill or turn a small edit into a broad audit.

## Start with the real build

Read the relevant code, tests, and repository instructions. Identify the module, any parent `go.work`, local replacements, supported Go versions, build tags, target, CGO mode, generators, and normal check commands. Inspect both the requested change and the behavior it must preserve. Do not discard unrelated edits.

When allowed, `go env GOMOD GOWORK GOVERSION GOOS GOARCH CGO_ENABLED GOFLAGS GOTOOLCHAIN` helps reveal the effective context. Go commands can select or download a toolchain; use `GOTOOLCHAIN=local` when automatic downloads are not allowed. Do not run `go env -w`, dependency upgrades, `go generate`, or tool installation as routine inspection.

Consult [version-sensitive rules](references/version-sensitive-rules.md) when advice depends on the language or standard library version. A newer local compiler is not proof that the declared minimum version works.

## Implement the smallest coherent change

1. State the expected behavior, failure behavior, and important invariant before editing.
2. Trace the caller, state owner, effect, and real consumer. Choose a local repair unless the defect requires a wider change.
3. Keep package responsibilities clear and exported surfaces small. Avoid a new `util` package merely to break a dependency cycle.
4. Define interfaces at real substitution or ownership boundaries. Consumers often own them; public extension points may justify provider ownership. Prefer concrete return types unless abstraction is part of the public contract.
5. Add tests that distinguish the required result from a plausible wrong one. Then implement and run the relevant existing checks.
6. Report what changed, what ran, and what remains unproved. Do not rewrite acceptance rules merely to make the result pass.

## Types and ownership

Choose pointer or value receivers by identity, mutation, method sets, aliasing, copy safety, and measured cost—not a size threshold. Never copy used synchronization values. Do not copy a struct that embeds a used mutex through a return, slice append, map assignment, or value receiver.

Define zero-value and nil behavior. A nil interface differs from an interface holding a typed nil pointer. A nil map can be read but cannot accept an assignment; a nil slice supports append; a nil channel blocks send and receive. Use these properties deliberately, not as accidental control flow.

A named type distinguishes concepts but does not validate values. Typed constants do not close an enum. Constructors cannot prevent callers from declaring an exported zero value. Keep representation private where useful, validate external values, and define legal transitions. Use generics only when they remove meaningful duplication without hiding domain rules.

Sending a slice or map through a channel does not deep-copy its contents. Choose copying, exclusive transfer, or synchronized sharing. Make buffer reuse and capacity-sensitive `append` behavior explicit. Sort map-derived output when the contract requires stable order; do not assume every encoder uses map iteration order.

## Errors and effects

Return expected failures as errors. Add useful context at meaningful boundaries, not at every helper. Use `%w` when callers may intentionally inspect the underlying identity with `errors.Is` or `errors.As`. Keep operational detail in logs when exposing it would create an unwanted public contract or leak secrets.

Check errors from writes, flushes, commits, and meaningful closes. A successful write followed by a failed close is not necessarily success. Defer cleanup after acquisition, but close within a loop or before a dependent operation when lifetime or error handling requires it. Define a panic policy at process, worker, HTTP/RPC, and foreign-call boundaries; recovery does not automatically restore valid state.

Cancellation requests stopping; it does not wait or undo effects. Release derived contexts on all exits, including success. Pass context as an explicit first argument for request-scoped operations; keep ordinary domain data out of context values. Join owned goroutines before releasing resources they may still use. Check cancellation before work where useful, but do not claim that an unsynchronized check prevents a concurrent commit.

## Concurrency and boundaries

For each goroutine, identify its owner, bound, stop signal, join, error destination, and cleanup. Define channel send/receive/close ownership and overload behavior. Both buffered and unbuffered channels can be correct. Prefer a mutex for a simple shared invariant; separate atomic fields do not make a multi-field update atomic.

Process bytes returned by a reader before its error. Bound untrusted input and decompressed output. For JSON, choose unknown-field, duplicate-name, trailing-input, case, null, and numeric rules explicitly. For SQL, keep all transaction work on the transaction, check `Rows.Err` and `Commit`, and avoid borrowing another pool connection while holding the only one.

Reuse HTTP clients and transports where appropriate. Close each response body; define bounded consumption and its effect on connection reuse. Set timeout and size policies that fit ordinary requests versus streams. Handler tests do not prove socket, TLS, streaming, or shutdown behavior.

## Select deeper guidance only when needed

| Concern | Optional skill |
| --- | --- |
| New package/type ownership or substantial design | `go-implementation-structure` |
| Exported API, module, error, wire compatibility | `go-api-module-boundary-review` |
| Goroutines, cancellation, synchronization, recovery | `go-correctness-concurrency-review` |
| I/O, JSON, HTTP, SQL, file or process effects | `go-io-boundary-review` |
| Tests, isolation, fuzzing, race checks | `go-test-strategy-review` |
| Measured performance or resource use | `go-performance-review` |
| Security, native boundaries, operations, releases | The focused skill for that concern |

No companion skill is required to use this one. Measure before optimizing. Preserve relevant failing seeds and outputs. A small fix needs a useful test result, not a new manifest or per-file hash system.

## Sources

[Go specification](https://go.dev/ref/spec), [Effective Go](https://go.dev/doc/effective_go), [Go memory model](https://go.dev/ref/mem), and the version reference above. The linked local examples in focused skills illustrate bounded patterns, not mandatory application architecture.
