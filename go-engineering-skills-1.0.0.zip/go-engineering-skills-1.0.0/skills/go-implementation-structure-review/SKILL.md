---
name: go-implementation-structure-review
description: "Check a Go implementation against supplied design decisions, package ownership, public contracts, and lifecycle rules. Separate material divergence from harmless private choices; no special contract format is needed."
---

# Go Structure and Design Conformance Review

Use this for an implementation with a stated design or important ownership boundary. For a general code survey use `comprehensive-analysis-go` when available. Do not invent a missing architecture specification and then report the code for violating it.

## Review method

1. Read the assignment, actual design or requirements, relevant code and tests, and supported module/build context. Identify fixed decisions separately from examples and private choices.
2. Trace each important fixed decision through its owner, public API, state transition or effect, real consumer, and test. Review a stable candidate; edit only when the user asks for repairs.
3. Compare module/import paths, exported types and methods, error identity, interface satisfaction, generated artifacts, wire/storage formats, and target/tag variants when the design fixes them.
4. Compare mutation authority, zero/nil behavior, goroutine lifetime, cancellation and joining, channel closing, resource release, transactions, retries, shutdown, and recovery. Race-free code can still violate lifecycle rules.
5. Reproduce a material mismatch or give a concrete trace. Test the strongest valid reading of the implementation before retaining the finding.
6. After an authorized repair, rerun the relevant tests and recheck affected boundaries. Preserve valid unrelated choices and checks.

## What counts as divergence

| Design and implementation | Assessment |
| --- | --- |
| Design assigns one package ownership of account transitions; handler directly writes public state. | Material when callers can bypass a required transition or create a second state owner. |
| Design permits any private layout; implementation uses two helper files instead of one. | Harmless. Do not report tree differences alone. |
| Design requires shutdown to join workers; code calls `cancel()` and returns. | Material unless another explicit owner performs and guarantees the join. |
| Design says consumers may use `errors.Is`; code replaces `%w` with `%v`. | Check a downstream caller; this can remove the promised identity. |
| No design fixes interface ownership; provider declares a public extension interface. | Not a conformance defect merely because consumer ownership is a common default. |
| Design fixes a path used by a generator or consumer. | That exact path matters; do not excuse it as private layout. |

A new `State` type does not by itself establish valid values, and a constructor does not make an exported zero value impossible. A private field can protect mutation while public methods still need runtime checks. Review actual enforcement rather than counting types or layers.

One canonical definition does not forbid checks at several trust or transaction boundaries. Retain useful request validation and database constraints when they enforce the same meaning for different failure cases.

## Bound review effort

For large changes, review coherent responsibilities and their shared interfaces separately. Keep a short list of inspected files, open questions, and cross-boundary findings. Do not require a manifest, a new graph, or separate reviewer per package. If a supplied design is incomplete, distinguish a missing design decision from an observed implementation defect. Do not call unavailable evidence a pass.

## Return

For each important item, state: requirement/design location; code location; conforms, advisory difference, material difference, or not established; expected versus actual behavior; consequence; evidence; and smallest repair. Keep source/API, behavioral, and operational compatibility separate where needed. Report unreviewed scope and any repair authority still needed. A review result does not authorize a release.
