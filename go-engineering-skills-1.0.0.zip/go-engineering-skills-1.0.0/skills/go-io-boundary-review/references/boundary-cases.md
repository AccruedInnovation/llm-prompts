# Worked boundary cases

## Data and EOF together

**Fault:** Return on `err != nil` before using `buf[:n]`.

**Correct rule:** Process `n` bytes, then interpret EOF or another error. Define whether a non-EOF error with partial output returns that output or discards it. That is an API contract, not a universal choice.

[The tests](../examples/boundary_test.go) include a reader returning `"abc"` and `io.EOF` in the same call. The faulty local comparator loses the bytes; the corrected copy path retains them. They also exercise a short writer and input exactly at versus beyond the size limit.

## A bounded, intentionally narrow JSON contract

[DecodeCreate](../examples/boundary.go) accepts exactly one flat object:

```json
{"name":"sensor-a","count":3}
```

The object requires `name` and `count`, with exact spelling, no duplicates, no unknown fields, no nulls, a nonempty name, and count from 1 through 1000. Fields may arrive in either order. Whitespace after the object is valid; another value or malformed trailing bytes are not. The caller supplies the total byte limit. No effect occurs during decoding.

The decoder reads a bounded byte slice, uses `Decoder.Token` to track field names, and decodes each scalar field into a temporary `RawMessage` before checking it. This makes duplicate and case rules explicit. Token parsing also detects escaped names that decode to the same field name. For a large or nested real schema, prefer an existing adequate parser/validator and define depth/element budgets instead of expanding this example into a general framework.

This contract does not promise canonical JSON bytes, Unicode normalization, rejection of every noncanonical Unicode escape, or exact error precedence among all malformed inputs. Add those requirements only when a consumer needs them. For this example, total size rejection precedes parsing because the input is read first. Field order can affect which malformed-field error appears first. Tests must not invent a stable precedence the contract does not define.

**Test set:** valid object; boundary count; empty name; count zero and overflow; decimal/exponent input for integer count; duplicate literal and escaped name; wrong case; unknown field; missing field; null field; malformed object; trailing whitespace; two values; trailing junk; exact and excess bytes. Check the intended error class and zero returned result on rejection, not merely `err != nil`.

## Transaction escape

Illustrative fragment, not a complete application:

```go
func rename(ctx context.Context, tx *sql.Tx, id int64, name string) error {
    _, err := tx.ExecContext(ctx, "UPDATE users SET name = ? WHERE id = ?", name, id)
    return err
}
```

The placeholders above are driver-specific. With PostgreSQL they would normally be `$1` and `$2`. Do not transplant SQL syntax across drivers without checking it. A version calling `db.ExecContext` uses the pool outside the transaction even if the caller currently owns a transaction.

**Repair:** Pass the transaction explicitly to operations that must share it. Keep `BeginTx`/`Commit`/rollback in one owner. If ordinary and transaction execution share an internal helper, define only the required methods and keep the caller's transaction choice visible.

**Discriminating test:** With a real engine, arrange failure after one write, then inspect persisted state from a separate connection. Neither write should have committed. Also use a bounded context with a single-connection pool to expose accidental extra acquisition; a timeout is a detected failure, not proof that the design can never deadlock. No live engine is bundled here.

## Body limits versus connection reuse

A fixed small JSON response may be fully consumed and closed. An unbounded response from an untrusted peer should be cut off and closed even if that loses reuse. A long-running stream needs a streaming policy rather than `ReadAll`. These are three valid designs with different contracts. Test the one the application actually needs.
