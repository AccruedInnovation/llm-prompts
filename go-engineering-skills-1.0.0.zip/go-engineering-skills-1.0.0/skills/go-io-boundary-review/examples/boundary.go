// Package boundary demonstrates bounded reads and a narrow flat JSON contract.
package boundary

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math"
	"strings"
)

var (
	ErrTooLarge     = errors.New("input too large")
	ErrInvalidLimit = errors.New("invalid byte limit")
	ErrJSON         = errors.New("invalid JSON object")
	ErrField        = errors.New("invalid field")
	ErrDuplicate    = errors.New("duplicate field")
	ErrTrailing     = errors.New("trailing input")
)

func ReadBounded(r io.Reader, limit int64) ([]byte, error) {
	if limit < 0 || limit == math.MaxInt64 {
		return nil, ErrInvalidLimit
	}
	data, err := io.ReadAll(io.LimitReader(r, limit+1))
	if int64(len(data)) > limit {
		return nil, ErrTooLarge
	}
	if err != nil {
		return nil, err
	}
	return data, nil
}

// CopyChunks retains successfully written bytes before a read error.
// It rejects 100 successive zero-progress reads to avoid spinning on a broken reader.
func CopyChunks(w io.Writer, r io.Reader) (int64, error) {
	buf := make([]byte, 1024)
	var total int64
	empty := 0
	for {
		n, readErr := r.Read(buf)
		if n < 0 || n > len(buf) {
			return total, errors.New("invalid reader count")
		}
		if n > 0 {
			empty = 0
			written, writeErr := w.Write(buf[:n])
			if written < 0 || written > n {
				return total, errors.New("invalid writer count")
			}
			total += int64(written)
			if writeErr != nil {
				return total, writeErr
			}
			if written != n {
				return total, io.ErrShortWrite
			}
		} else if readErr == nil {
			empty++
			if empty >= 100 {
				return total, io.ErrNoProgress
			}
		}
		if readErr != nil {
			if readErr == io.EOF {
				return total, nil
			}
			return total, readErr
		}
	}
}

type Create struct {
	Name  string
	Count int
}

func DecodeCreate(r io.Reader, limit int64) (Create, error) {
	data, err := ReadBounded(r, limit)
	if err != nil {
		return Create{}, err
	}
	d := json.NewDecoder(bytes.NewReader(data))
	first, err := d.Token()
	if err != nil || first != json.Delim('{') {
		return Create{}, ErrJSON
	}
	var out Create
	seen := map[string]bool{}
	for d.More() {
		token, err := d.Token()
		if err != nil {
			return Create{}, fmt.Errorf("%w: %v", ErrJSON, err)
		}
		key, ok := token.(string)
		if !ok {
			return Create{}, ErrJSON
		}
		if seen[key] {
			return Create{}, fmt.Errorf("%w: %s", ErrDuplicate, key)
		}
		seen[key] = true
		if key != "name" && key != "count" {
			return Create{}, fmt.Errorf("%w: unknown %s", ErrField, key)
		}
		var raw json.RawMessage
		if err := d.Decode(&raw); err != nil {
			return Create{}, fmt.Errorf("%w: %v", ErrJSON, err)
		}
		if bytes.Equal(bytes.TrimSpace(raw), []byte("null")) {
			return Create{}, fmt.Errorf("%w: null %s", ErrField, key)
		}
		switch key {
		case "name":
			if err := json.Unmarshal(raw, &out.Name); err != nil || strings.TrimSpace(out.Name) == "" {
				return Create{}, fmt.Errorf("%w: name", ErrField)
			}
		case "count":
			if err := json.Unmarshal(raw, &out.Count); err != nil || out.Count < 1 || out.Count > 1000 {
				return Create{}, fmt.Errorf("%w: count", ErrField)
			}
		}
	}
	end, err := d.Token()
	if err != nil || end != json.Delim('}') {
		return Create{}, ErrJSON
	}
	if !seen["name"] || !seen["count"] {
		return Create{}, fmt.Errorf("%w: missing field", ErrField)
	}
	var extra any
	if err := d.Decode(&extra); err != io.EOF {
		return Create{}, ErrTrailing
	}
	return out, nil
}
