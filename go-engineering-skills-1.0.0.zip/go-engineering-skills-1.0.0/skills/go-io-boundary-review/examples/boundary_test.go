package boundary

import (
	"bytes"
	"encoding/json"
	"errors"
	"io"
	"math"
	"strings"
	"testing"
)

type dataAndEOF struct{ done bool }

func (r *dataAndEOF) Read(p []byte) (int, error) {
	if r.done {
		return 0, io.EOF
	}
	r.done = true
	return copy(p, "abc"), io.EOF
}

type shortWriter struct{}

func (shortWriter) Write(p []byte) (int, error) { return len(p) - 1, nil }

type idleReader struct{}

func (idleReader) Read([]byte) (int, error) { return 0, nil }
func TestReadDataBeforeEOF(t *testing.T) {
	var dst bytes.Buffer
	n, err := CopyChunks(&dst, &dataAndEOF{})
	if err != nil || n != 3 || dst.String() != "abc" {
		t.Fatalf("%d %q %v", n, dst.String(), err)
	}
	// A deliberately wrong ordering drops the same data.
	r := &dataAndEOF{}
	buf := make([]byte, 8)
	nread, readErr := r.Read(buf)
	var lost []byte
	if readErr == nil {
		lost = append(lost, buf[:nread]...)
	}
	if len(lost) != 0 {
		t.Fatal("faulty comparator did not expose the intended defect")
	}
}
func TestShortWriteAndNoProgress(t *testing.T) {
	if _, err := CopyChunks(shortWriter{}, strings.NewReader("abc")); !errors.Is(err, io.ErrShortWrite) {
		t.Fatal(err)
	}
	if _, err := CopyChunks(io.Discard, idleReader{}); !errors.Is(err, io.ErrNoProgress) {
		t.Fatal(err)
	}
}
func TestReadBoundaries(t *testing.T) {
	if data, err := ReadBounded(strings.NewReader("abc"), 3); err != nil || string(data) != "abc" {
		t.Fatalf("%q %v", data, err)
	}
	if _, err := ReadBounded(strings.NewReader("abcd"), 3); !errors.Is(err, ErrTooLarge) {
		t.Fatal(err)
	}
	if _, err := ReadBounded(strings.NewReader(""), math.MaxInt64); !errors.Is(err, ErrInvalidLimit) {
		t.Fatal(err)
	}
	if _, err := ReadBounded(strings.NewReader(""), -1); !errors.Is(err, ErrInvalidLimit) {
		t.Fatal(err)
	}
}
func TestNarrowJSONContract(t *testing.T) {
	cases := []struct {
		name, input string
		want        error
	}{
		{"valid", `{"name":"a","count":3}`, nil},
		{"reordered", `{"count":1000,"name":"a"}`, nil},
		{"whitespace", "{\"name\":\"a\",\"count\":1}\n\t ", nil},
		{"empty-name", `{"name":"","count":1}`, ErrField},
		{"blank-name", `{"name":"  ","count":1}`, ErrField},
		{"zero-count", `{"name":"a","count":0}`, ErrField},
		{"large-count", `{"name":"a","count":1001}`, ErrField},
		{"overflow", `{"name":"a","count":999999999999999999999999}`, ErrField},
		{"decimal", `{"name":"a","count":1.0}`, ErrField},
		{"exponent", `{"name":"a","count":1e0}`, ErrField},
		{"duplicate", `{"name":"a","count":1,"count":2}`, ErrDuplicate},
		{"escaped-duplicate", `{"name":"a","count":1,"\u0063ount":2}`, ErrDuplicate},
		{"wrong-case", `{"Name":"a","count":1}`, ErrField},
		{"unknown", `{"name":"a","count":1,"extra":true}`, ErrField},
		{"missing", `{"name":"a"}`, ErrField},
		{"null-name", `{"name":null,"count":1}`, ErrField},
		{"null-count", `{"name":"a","count":null}`, ErrField},
		{"array", `[]`, ErrJSON},
		{"empty-input", ``, ErrJSON},
		{"malformed", `{"name":"a","count":`, ErrJSON},
		{"two-values", `{"name":"a","count":1}{}`, ErrTrailing},
		{"trailing-junk", `{"name":"a","count":1}x`, ErrTrailing},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			got, err := DecodeCreate(strings.NewReader(tc.input), 4096)
			if !errors.Is(err, tc.want) {
				t.Fatalf("got %v; want %v", err, tc.want)
			}
			if err != nil && got != (Create{}) {
				t.Fatalf("partial result leaked: %#v", got)
			}
			if err == nil && (got.Name != "a" || got.Count < 1 || got.Count > 1000) {
				t.Fatalf("wrong result: %#v", got)
			}
		})
	}
}
func TestJSONSizeLimit(t *testing.T) {
	input := `{"name":"a","count":1}`
	if _, err := DecodeCreate(strings.NewReader(input), int64(len(input))); err != nil {
		t.Fatal(err)
	}
	if _, err := DecodeCreate(strings.NewReader(input), int64(len(input)-1)); !errors.Is(err, ErrTooLarge) {
		t.Fatal(err)
	}
}
func TestStandardDecoderPitfalls(t *testing.T) {
	var v struct {
		Count int `json:"count"`
	}
	d := json.NewDecoder(strings.NewReader(`{"count":1,"count":2}{"count":3}`))
	d.DisallowUnknownFields()
	if err := d.Decode(&v); err != nil || v.Count != 2 {
		t.Fatalf("%+v %v", v, err)
	}
	if err := d.Decode(&v); err != nil || v.Count != 3 {
		t.Fatalf("second value was not available: %+v %v", v, err)
	}
	d = json.NewDecoder(strings.NewReader(`9007199254740993`))
	d.UseNumber()
	var value any
	if err := d.Decode(&value); err != nil {
		t.Fatal(err)
	}
	n, ok := value.(json.Number)
	if !ok || n.String() != "9007199254740993" {
		t.Fatal(value)
	}
}
func FuzzDecodeCreate(f *testing.F) {
	for _, s := range []string{`{"name":"a","count":1}`, `{"name":null}`, `[]`, `{"count":1,"count":2}`, ""} {
		f.Add(s)
	}
	f.Fuzz(func(t *testing.T, s string) {
		got, err := DecodeCreate(strings.NewReader(s), 4096)
		if len(s) > 4096 && !errors.Is(err, ErrTooLarge) {
			t.Fatalf("limit not enforced: %v", err)
		}
		if err != nil {
			if got != (Create{}) {
				t.Fatal("partial result on error")
			}
			return
		}
		if strings.TrimSpace(got.Name) == "" || got.Count < 1 || got.Count > 1000 {
			t.Fatalf("invalid accepted value: %#v", got)
		}
	})
}
