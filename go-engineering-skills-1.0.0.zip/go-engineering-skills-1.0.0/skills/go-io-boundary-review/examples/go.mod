module example.com/go-skill-examples/go-io-boundary-review

go 1.23.0
