---
name: go-io-boundary-review
description: "Review or implement Go I/O boundaries: readers, bounded JSON, HTTP bodies, SQL transactions, files, and subprocesses. Use when partial results, input limits, or resource lifetime can change correctness."
---

# Go I/O and Data Boundaries

Start with the actual API, input trust, size/time budget, owner, and permitted effects. Choose the simplest mechanism that enforces those rules. Do not label a parser “strict” or a file write “atomic” without defining the property.

## Readers and writers

Process `n > 0` bytes before handling a read error; `Read` may return data and `io.EOF` together. Do not treat a short read as end-of-stream. Use `io.ReadFull` for a fixed-width record and distinguish clean EOF from a truncated record. Do not spin forever on a broken reader that repeatedly returns `(0, nil)`.

Check bytes written and errors. An `io.Writer` must report an error for a short write; defensive code talking to an imperfect implementation can convert `(n < len(p), nil)` to `io.ErrShortWrite`. Do not retry the whole original buffer after a partial write and duplicate bytes. Check buffered flush and relevant close errors separately.

A limited reader caps consumption; it does not prove the full input fits. For a small bounded document, read at most `limit+1` bytes and reject the extra byte, guarding integer overflow. For streams, use a framed protocol and its limits. Bound both compressed input and decompressed output. Memory bounds do not establish CPU or time bounds.

## Define JSON acceptance

Identify the exact API and options. In `encoding/json`, one successful `Decode` can leave a second value unread. `DisallowUnknownFields` rejects unknown struct fields but does not reject duplicate names or require exact key casing. Decoding arbitrary numbers to `any` normally uses `float64`; `UseNumber` preserves numeric text for later checked conversion.

Choose rules for unknown fields, duplicate names, case matching, trailing data, nesting, null versus missing, nil versus empty, numeric range, invalid text, and semantic relationships. Decode into temporary state, validate, then commit; a failed decode must not partly mutate live domain state. Check request content type and encoding policy when relevant.

Read [boundary cases](references/boundary-cases.md). [The runnable decoder](examples/boundary.go) intentionally accepts one small flat object with exact field names, required non-null fields, integer bounds, no duplicates, and no trailing JSON. It is a narrow example, not a new general JSON framework or a proof of canonical JSON/Unicode validation.

## HTTP client and server

Reuse clients and transports where useful; close each response body. For small bounded responses, reading to EOF and closing helps HTTP/1 connection reuse. Do not drain an unbounded hostile body just to save the connection. For streams, define lifetime, backpressure, cancellation, and maximum resource use instead.

Non-2xx HTTP status is not normally a `Client.Do` error. Handle status explicitly, cap diagnostic bodies, redact secrets, and apply retry rules only to safe operations. Decide redirect and proxy policy; a context deadline does not establish destination trust. Request retries also need replayable bodies and a defined effect model.

Use a body limit before decoding requests. Check actual bytes rather than trusting `Content-Length`. Choose header, request, idle, and client deadlines for the protocol; whole-request timeouts that suit JSON can break long-lived streams. Distinguish ordinary request cancellation from server shutdown.

Handler tests prove response logic. Use a real local server/client for socket cancellation, connection reuse, TLS, streaming, redirects, or body-close behavior. The operations skill covers process shutdown.

## database/sql

A `*sql.DB` is a connection pool, not one transaction or one connection. Begin a transaction with `BeginTx`, defer rollback as a fallback, perform all transaction operations through `*sql.Tx`, and check `Commit`. A helper that uses the parent `*sql.DB` escapes the transaction. Narrow an internal helper interface only when it makes this ownership clearer; it cannot by itself stop a caller passing the wrong owner.

Check query errors, defer `Rows.Close`, handle scan errors, and check `Rows.Err` after iteration. Release rows before another operation that needs the same constrained resource. Choose NULL handling explicitly. `QueryRow` defers errors until `Scan`; distinguish `sql.ErrNoRows` from other failures.

Pool limits can deadlock code that holds one connection and waits for another. Test with the intended driver and engine, including a pool size of one when that exposes ownership errors. Mocks can check calls but do not establish isolation, constraint behavior, rollback durability, or driver cancellation.

A commit error may leave the outcome uncertain depending on driver and failure. Do not rerun the whole transaction automatically. Use the engine's retry rules, idempotency, and reconciliation. External email, file, or network effects are not rolled back by a SQL rollback; use an outbox or another protocol only when that requirement warrants it.

## Files and subprocesses

For replacement writes, consider a temporary file in the destination directory, complete write, permissions, relevant sync/close errors, rename, and cleanup. Define platform and filesystem assumptions. Atomic visibility is not crash durability; directory sync and replacement semantics need target-specific verification. Rooted access and symlink checks address different threats from durability.

Use argument lists with `exec.CommandContext` rather than a shell unless shell syntax is required and inputs are trusted. Define working directory, environment, stdin, bounded stdout/stderr, and exit interpretation. Context cancellation normally targets the direct child; descendant handling is platform-specific. A child that inherited a pipe can keep output collection waiting. Use a supported `WaitDelay` or an explicit process/pipe policy when needed. Always reap owned processes.

## Return

For each boundary, state its accepted input/result, resource owner and bound, concrete failure case, check performed, and missing platform/driver evidence. Report partial effects and uncertain outcomes rather than treating every error as “nothing happened.”

## Sources

[io](https://pkg.go.dev/io), [encoding/json](https://pkg.go.dev/encoding/json), [net/http](https://pkg.go.dev/net/http), [database/sql](https://pkg.go.dev/database/sql), [transaction guide](https://go.dev/doc/database/execute-transactions), [pool management](https://go.dev/doc/database/manage-connections), [os/exec](https://pkg.go.dev/os/exec).
