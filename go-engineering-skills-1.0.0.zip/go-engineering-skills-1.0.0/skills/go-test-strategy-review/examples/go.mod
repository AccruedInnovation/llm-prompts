module example.com/go-skill-examples/go-test-strategy-review

go 1.23.0
