package testpatterns

import (
	"context"
	"errors"
	"os"
	"sync/atomic"
	"testing"
	"time"
)

func TestWorkerErrorReportedByParent(t *testing.T) {
	want := errors.New("expected worker failure")
	ctx, cancel := context.WithCancel(context.Background())
	result := make(chan error, 1)
	done := make(chan struct{})
	t.Cleanup(func() {
		cancel()
		select {
		case <-done:
		case <-time.After(3 * time.Second):
			t.Error("worker did not stop during cleanup")
		}
	})
	go func() {
		defer close(done)
		select {
		case <-ctx.Done():
			result <- ctx.Err()
		default:
			result <- want
		}
	}()
	select {
	case err := <-result:
		if !errors.Is(err, want) {
			t.Fatal(err)
		}
	case <-time.After(3 * time.Second):
		t.Fatal("no result")
	}
	<-done
}
func TestCleanupCoversParallelChildren(t *testing.T) {
	var closed atomic.Bool
	t.Run("group", func(t *testing.T) {
		t.Cleanup(func() { closed.Store(true) })
		for _, name := range []string{"one", "two"} {
			t.Run(name, func(t *testing.T) {
				t.Parallel()
				if closed.Load() {
					t.Fatal("resource closed before child finished")
				}
			})
		}
	})
	if !closed.Load() {
		t.Fatal("cleanup did not run after group")
	}
}
func TestSerialEnvironmentAndDefer(t *testing.T) {
	const key = "GO_SKILLS_EXAMPLE_SETTING"
	before, had := os.LookupEnv(key)
	t.Run("serial", func(t *testing.T) {
		t.Setenv(key, "local")
		if os.Getenv(key) != "local" {
			t.Fatal("setting unavailable")
		}
		closed := false
		func() { defer func() { closed = true }() }()
		if !closed {
			t.Fatal("defer did not run")
		}
	})
	after, has := os.LookupEnv(key)
	if has != had || after != before {
		t.Fatal("environment did not restore")
	}
}

var errName = errors.New("unknown account")
var errAmount = errors.New("amount must be positive")

type ledger struct{ balance, effects int }

func (l *ledger) apply(name string, amount int) error {
	if name != "known" {
		return errName
	}
	if amount <= 0 {
		return errAmount
	}
	l.balance += amount
	l.effects++
	return nil
}
func TestRejectionReachesAmountGuardAndHasNoEffect(t *testing.T) {
	l := ledger{balance: 10}
	if err := l.apply("known", -1); !errors.Is(err, errAmount) {
		t.Fatalf("wrong guard: %v", err)
	}
	if l.balance != 10 || l.effects != 0 {
		t.Fatal("rejected operation changed state")
	}
	if err := l.apply("known", 2); err != nil || l.balance != 12 || l.effects != 1 {
		t.Fatalf("valid operation: %+v %v", l, err)
	}
}
func TestCombinedViolationHasSeparatePrecedence(t *testing.T) {
	l := ledger{}
	if err := l.apply("unknown", -1); !errors.Is(err, errName) {
		t.Fatalf("precedence: %v", err)
	}
	if l.effects != 0 {
		t.Fatal("effect on rejected input")
	}
}
