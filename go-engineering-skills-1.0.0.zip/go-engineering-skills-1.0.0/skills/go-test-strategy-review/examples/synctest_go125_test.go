//go:build go1.25

package testpatterns

import (
	"testing"
	"testing/synctest"
	"time"
)

func TestSynctestTimer(t *testing.T) {
	synctest.Test(t, func(t *testing.T) {
		fired := make(chan struct{})
		go func() { time.Sleep(time.Second); close(fired) }()
		synctest.Wait()
		select {
		case <-fired:
			t.Fatal("timer fired before time advanced")
		default:
		}
		time.Sleep(time.Second)
		synctest.Wait()
		select {
		case <-fired:
		default:
			t.Fatal("timer did not finish")
		}
	})
}
