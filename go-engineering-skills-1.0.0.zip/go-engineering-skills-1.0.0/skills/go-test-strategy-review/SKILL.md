---
name: go-test-strategy-review
description: "Design and review Go tests for meaningful assertions, cleanup, parallel safety, cancellation, fuzzing, and real integration. Use for test changes or weak/flaky evidence; do not treat coverage as a quality score."
---

# Go Test Strategy and Test Correctness

Start from what must be true, a plausible defect, and the cheapest test that distinguishes them. Read the actual Go version, workspace, selected packages, tags, target, CGO mode, and repository check commands. Keep mandatory checks; do not run unrelated tools merely because they are available.

## Choose the right level

Use internal package tests for private behavior and external `package x_test` tests for public use. Use examples for stable caller expectations. Test real database, filesystem, subprocess, or transport behavior when that is the claim. `httptest.ResponseRecorder` is useful for handler logic, while `httptest.Server` or process tests can exercise streams, TLS, connection behavior, cancellation, and shutdown.

A mock can isolate an external service or check call order; it does not prove the real driver or protocol. A downstream module fixture catches assumptions hidden by a workspace. Cross-compilation is not a runtime test. Keep golden outputs independently justified instead of regenerating expected results from a failed candidate as their only basis.

## Make the test itself correct

`t.Fatal`, `FailNow`, and helpers that call them must run in the test goroutine, not a worker goroutine. Send results or errors through a buffered channel and assert in the test goroutine. A worker can use concurrency-safe reporting methods where documented, but it must finish before the test's lifetime ends.

Use `t.Cleanup` for resources needed by parallel subtests: the parent's ordinary defer runs as its function returns, before paused parallel children run. Cleanup follows the test-and-subtest lifetime. Register cleanup promptly, release resources in the right order, and join workers before removing their files or closing their connections.

Do not call `t.Setenv` in a parallel test or below a parallel ancestor. Environment and working directory are process-wide. Make inputs explicit or use a subprocess for conflicting process-global settings. `t.TempDir` isolates paths, not every external process or database. Use unique resource names and ports allocated by the OS rather than guessed fixed ports.

For older language versions, loop-capture fixes may be needed in table-driven parallel tests. Under Go 1.22 semantics, a loop-declared variable already has per-iteration identity; assignment to an existing variable still shares it. Do not add or report old workarounds blindly.

See [tests that can mislead](references/test-correctness.md) and the [runnable examples](examples/testing_test.go).

## Coordinate; do not guess from sleeps

Signal that a worker reached a known state, trigger the transition, wait for its result, then assert. Use a deadline to bound a hung test, not as the only evidence that an event occurred. Check rejection prevented the forbidden effect, not just that some error appeared.

`testing/synctest` is stable from Go 1.25. It controls time and contained goroutines through `synctest.Test`; `synctest.Wait` waits until the other goroutines are durably blocked or finished. A closed or signaled channel can provide an ordinary synchronization point without requiring this package. Network I/O, system calls, and mutex acquisition are not durably blocked operations for virtual-time advancement. A real HTTP test does not become deterministic by wrapping it in synctest. Read [the guarded example](examples/synctest_go125_test.go) only when that API is supported.

Use the race detector for exercised shared access, explicit state/transition checks for logical ordering, and fault injection for recovery. None proves all schedules or every platform. Retain timeout diagnostics and goroutine stacks where they help explain failures.

## Assertions, fuzzing, and properties

Use `errors.Is`/`errors.As` for a promised error identity. Assert exact text only when wording itself is the contract. For rejection, satisfy unrelated preconditions so the intended guard runs, then inspect state and effects. Test combined-invalid cases separately when precedence matters.

Fuzz parsers, decoders, paths, protocols, and other input boundaries with meaningful seeds and independent properties. A round trip can pass when encoder and decoder share a defect; add known vectors or another invariant. Keep each fuzz input isolated, bounded, and free of shared mutable state. Store minimized failures as regression cases. Bound fuzz time, parallelism, disk, memory, and external effects.

Use state-machine, differential, or metamorphic tests when the relation supplies a useful independent expectation. Test partial writes, cancellation, restart, duplicates, empty input, and size boundaries according to actual risk. Mutation testing can check assertion strength for valuable logic; a timeout or tool error is not a killed mutant.

## Cache, repeats, and performance

Use the project's cache policy. `go test -count=1` requests a fresh test execution; it does not disable build caches or prove offline operation. `-shuffle` and repeated runs can expose order/schedule dependence; keep the printed seed. FAIL then PASS remains a flaky sequence, not an unqualified pass.

Coverage shows what executed, not whether assertions were useful. Benchmark correctness first, define data and setup, and collect repeated comparable samples. `B.Loop` requires Go 1.24; use `b.N` for older minimums. Profile only when the question needs it; performance measurements under race instrumentation are not ordinary production latency evidence.

## Return

State assertions and chosen levels; missing, weak, or duplicate tests; exact commands and selected cases; results, skips, seeds, and all retries; remaining integration/platform gaps. For a small edit this can be a short summary. Do not demand a receipt schema, per-file hashes, or model-level review for every test.

## Sources

[testing](https://pkg.go.dev/testing), [subtests](https://go.dev/blog/subtests), [synctest](https://pkg.go.dev/testing/synctest), [testing time](https://go.dev/blog/testing-time), [fuzzing](https://go.dev/doc/security/fuzz), [race detector](https://go.dev/doc/articles/race_detector).
