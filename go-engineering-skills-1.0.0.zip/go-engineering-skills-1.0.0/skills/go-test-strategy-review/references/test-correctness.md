# Tests that can mislead

## Fatal failure in a worker

**Fault:** `go func() { if err := work(); err != nil { t.Fatal(err) } }()` stops that goroutine, not the goroutine waiting for it. A completion send after `t.Fatal` never runs.

**Repair:** Send the error on a one-slot channel; receive and call `t.Fatal` in the test goroutine. Register cancellation/cleanup before starting the work. A buffer lets a worker finish reporting if the test takes an error path before receiving. Still join the worker; the buffer alone does not own its lifetime.

**Test:** Inject an error and prove it reaches the parent. The included test uses an expected sentinel and a deterministic channel. It does not intentionally fail the whole suite just to demonstrate misuse.

## Parallel subtests outlive a parent's defer

**Fault:** Open a server or temp resource, `defer` its close in the parent, and then call `t.Run` with children that call `t.Parallel`. They can start after the parent defer has run.

**Repair:** Register `t.Cleanup` on the parent or put parallel children inside a group `t.Run` that completes before ordinary teardown. Both can be correct. Do not replace every defer in every test; simple non-parallel local lifetime often needs only defer.

**Test:** In a grouped subtest, each child checks the resource is still open. After the group returns, the outer test checks cleanup occurred. The example uses an atomic flag to model lifetime without adding unrelated sockets or sleeps.

## Process-global state

`t.Setenv` restores the prior value after the test, but it does not give concurrent tests separate environments. A serial parent with parallel children still cannot use environment-setting children. Prefer an explicit config argument. A child process is useful when testing actual environment parsing or `os.Exit`; do not put production process termination inside the test process.

The runnable suite checks serial environment use and controlled cleanup. Misuse of `t.Setenv` or `t.Fatal` belongs in isolated expected-failure tests when you need an executed demonstration; do not knowingly introduce hangs into ordinary `go test ./...`.

## Guard reached, effect absent

Suppose an operation rejects unknown names and negative amounts. A negative-amount test using an unknown name can pass at the name guard without testing amount validation. Use a known name, require the amount error, and inspect that the balance and event count did not change. Add another case for simultaneous violations only when error order is part of the contract.

## Controlled time versus external I/O

A Go 1.25+ synctest test can start a goroutine waiting on a timer, wait for it to block, advance virtual time with a sleep inside the test, and wait for completion. It cannot treat arbitrary network or mutex waits as durable blocking. Use a channel or fake reader for a protocol unit test and a separate real transport test for the network claim.

The guarded [synctest test](../examples/synctest_go125_test.go) checks a channel-controlled timer. Older compilers exclude that file; a passing older run does not establish that case.

## False-positive controls

Keep a few valid cases alongside defects: a useful `defer` in a serial test, independent parallel subtests with read-only fixtures, an exact error text assertion for a documented CLI message, and a channel handshake without synctest. A skill that flags these by pattern alone needs correction.
