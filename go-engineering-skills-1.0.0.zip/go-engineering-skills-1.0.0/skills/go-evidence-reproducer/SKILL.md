---
name: go-evidence-reproducer
description: "Reproduce and record Go test, race, fuzz, flaky, benchmark, crash, native, or release failures. Use when results need a reliable rerun; keep evidence proportional and preserve failed attempts."
---

# Go Evidence and Reproduction

Make the result rerunnable. Record enough to identify the code, configuration, inputs, and command that produced it. A short note and a saved failing input often suffice; do not build a manifest system for a routine bug.

## Minimum useful record

State the assertion; relevant source revision plus uncommitted edits or a saved reproduction; selected module/packages; exact Go version and important flags; command and working directory; input/fixture; expected versus actual result; and output or failure artifact. Redact secrets.

Add `GOMOD`, `GOWORK`, replacements, dependency versions, GOOS/GOARCH, CGO, compiler/native libraries, tags, experiments, relevant `GODEBUG`, PGO, and external service versions only where they affect reproduction. A revision alone does not include uncommitted files. A tool exit code alone does not show intended cases ran.

Use hashes at final handoff or for a specific artifact identity need, not while editing every document. Do not hash manifests recursively or repair cascading metadata instead of fixing the defect. Keep logs outside the source they identify; retain original evidence before minimizing it.

## Reproduce and reduce

1. Run the smallest known failing command under the recorded environment, with a bounded timeout and allowed effects.
2. Preserve the first failure, exact inputs, seeds, and diagnostic output before editing.
3. Reduce one dimension at a time: packages, input size, dependencies, concurrency, or external services. Keep a version that still exercises the actual failed property.
4. Add an independent expected result or invariant. A reproduction that merely prints a success flag is not a test.
5. Repair, then run both the reduced regression and relevant broader checks. State when a reduced case no longer covers the original real integration.

A fresh test normally uses `-count=1` when cache reuse would weaken the claim. Keep every retry. A FAIL/PASS sequence remains flaky; do not erase the failure by reporting only the last attempt. A test selection matching zero cases or a timeout is not a pass.

## Preserve evidence by technique

| Technique | Preserve |
| --- | --- |
| Race | Full conflicting and creation stacks, workload, target, build flags, and every attempt. |
| Fuzz/property | Exact failing bytes or values, corpus location, seed, target, budget, and minimized case. |
| Shuffle/repeat | Printed shuffle seed, count, order when relevant, failures and successes. |
| Synctest | Go API version, contained operations, time assumptions, wait/blocked state, and deadlock report. |
| Golden/coverage/mutation | Expected-result basis, selected packages, changed golden diff, missing paths, mutant outcomes including timeouts/tool errors. |
| Benchmark/profile/PGO | Workload, repeated samples, environment, correctness check, profile and its origin. |
| Crash/recovery | Fault point, state before/after, retained data, restart trace, and final reconciliation. |
| Module/native/release | Workspace and replacement state, relevant toolchains and libraries, actual artifact, and consumer/install command. |

## Results and reuse

Use the project's vocabulary while distinguishing passed, failed, not run, unavailable, inconclusive, and flaky. A command failure caused by unavailable infrastructure is different from a failed behavior assertion. Preserve a known candidate failure even if a later run becomes inconclusive.

Reuse prior results only when the changed work cannot affect their subject, inputs, environment, or expected behavior. A relevant code, fixture, dependency, flag, or generator change calls for rechecking. Do not rerun unrelated work merely because a log timestamp changed. State an uncertain impact and use a proportionate broader check.

## Return

Give a copyable reproduction command, expected and actual behavior, relevant environment, saved artifacts, fix and regression evidence, and remaining uncertainty. Report exactly which real platforms, transports, drivers, and code paths ran. Local tests do not prove deployment or independent agent performance.

## Sources

[go test](https://pkg.go.dev/cmd/go#hdr-Test_packages), [race detector](https://go.dev/doc/articles/race_detector), [fuzzing](https://go.dev/doc/security/fuzz), [diagnostics](https://go.dev/doc/diagnostics).
