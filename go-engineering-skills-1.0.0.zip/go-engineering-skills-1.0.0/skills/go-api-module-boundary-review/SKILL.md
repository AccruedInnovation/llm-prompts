---
name: go-api-module-boundary-review
description: "Review Go exported APIs, method sets, errors, module versions, build variants, and wire compatibility. Use for changes visible to callers or downstream modules, not private layout alone."
---

# Go API and Module Compatibility

Read the intended compatibility promise, previous API or behavior, candidate, and real consumers. Review without edits unless repairs are requested. Compare the direction that matters: old callers with the new library, new callers with the old library, mixed wire versions, or persisted data migration.

## Establish the build and consumer context

Inspect module path and major version, `go` and `toolchain`, active `go.work`, local replacements, vendor policy, public packages, build tags, target, and CGO. Include public command, configuration, HTTP/RPC, wire, and persistent contracts when they change.

Separate `go` minimum requirements from toolchain selection. The `go` directive sets the required minimum under modern toolchains and affects language semantics. `toolchain` suggests a toolchain for the main module/workspace; it does not impose the same minimum on consumers of a dependency or pin an upper version. Inspect `GOTOOLCHAIN`, effective `go version`, and the project's minimum-version test. Do not claim a dependency's toolchain suggestion alone raises a downstream requirement.

## Inspect the exported surface

Compare types versus aliases, constants, mutable globals, functions, methods, struct fields and embedding, interfaces, generic constraints, constructors, zero values, lifecycle ordering, and promised errors. Method sets and implicit interface satisfaction can break callers without an explicit implements declaration.

```go
type Reader interface { Read() }
type Buffer struct{}
func (*Buffer) Read() {}
var _ Reader = (*Buffer)(nil) // Valid: pointer method set.
// var _ Reader = Buffer{}    // Invalid: value method set lacks Read.
```

An addressable variable may call a pointer-receiver method through automatic address-taking, but assigning a value to an interface does not apply that rule. A receiver change therefore needs downstream compile checks, not only method-call tests. See [the runnable API checks](examples/api_test.go).

Adding a public interface method can break implementers. Adding an exported struct field can break external unkeyed literals. Removing an unexported implementation detail is usually private, but generated consumers, reflection, or documented behavior may create a real dependency. Inspect actual promises before claiming one.

## Review behavior as well as source compatibility

Define whether nil and empty serialize differently, whether new fields are ignored or rejected, which order is stable, and what defaults mean. Map iteration is unspecified; an encoder may impose its own order. Compare actual wire bytes or decoded semantics according to the contract rather than making a blanket claim about all map serialization.

`fmt.Errorf("lookup: %w", err)` permits callers to inspect the wrapped error. `%v` does not. Preserve or change that identity deliberately, including joined errors. A typed nil pointer returned as `error` is not a nil error. Do not promise driver-specific error types unless callers should depend on them. Use behavioral consumer tests for these properties.

Review generic constraints as accepted type sets and operations, not only pretty signatures. A changed constraint can exclude callers or expose runtime limits. Language typing does not validate numeric states, wire input, runtime comparability of every dynamic value, or transaction behavior.

## Modules and release use

For semantic major v2+, verify the applicable import path and tag relationship. Check modules in subdirectories and repository-specific tag conventions rather than assuming one root module. A dependency's local `replace` is not automatically inherited by its consumer; workspace success can conceal a broken standalone release.

Test a clean source copy with `GOWORK=off` where appropriate and compile an actual downstream fixture using only public APIs. A local replacement in that fixture is useful for source compatibility but does not prove the published module exists or resolves from a registry. Test artifact/module resolution separately when that is the release claim. `go test ./...` from one module does not automatically test nested modules.

Preserve supported tags, OS/architecture, CGO variants, and minimum Go. A missing compiler or driver means that configuration remains untested, not that the candidate failed on it. Inspect generated API source, generator, and output together; do not hand-edit a generated surface and leave the next generation wrong.

## Return

Report source/API, method-set, module/import, minimum Go, build variant, error behavior, wire, persistence, configuration, CLI, HTTP/RPC, and operational compatibility separately when applicable. For each material change, give caller impact, exact evidence, compatible/conditional/incompatible/not established, and migration or versioning needs. An API diff is supporting evidence, not the whole decision.

## Sources

[Method sets](https://go.dev/ref/spec#Method_sets), [toolchains](https://go.dev/doc/toolchain), [module reference](https://go.dev/ref/mod), [module release workflow](https://go.dev/doc/modules/release-workflow), [errors](https://pkg.go.dev/errors), [working with errors](https://go.dev/blog/go1.13-errors).
