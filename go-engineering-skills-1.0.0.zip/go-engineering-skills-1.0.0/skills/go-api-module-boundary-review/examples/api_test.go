package apifixture_test

import (
	"errors"
	api "example.com/go-skill-examples/go-api-module-boundary-review"
	"reflect"
	"testing"
)

func TestMethodSetsFromConsumer(t *testing.T) {
	want := reflect.TypeOf((*api.Reader)(nil)).Elem()
	if reflect.TypeOf(api.Buffer{}).Implements(want) {
		t.Fatal("value unexpectedly implements pointer method")
	}
	if !reflect.TypeOf((*api.Buffer)(nil)).Implements(want) {
		t.Fatal("pointer lost interface")
	}
	var b api.Buffer
	b.Read()
}
func TestPublicErrorIdentity(t *testing.T) {
	if !errors.Is(api.Lookup(), api.ErrMissing) {
		t.Fatal("promised error identity lost")
	}
	if errors.Is(api.HiddenIdentity(), api.ErrMissing) {
		t.Fatal("text formatting unexpectedly unwraps")
	}
}
func TestLoopDeclaredVersusExistingVariable(t *testing.T) {
	var separate []*int
	for i := 0; i < 3; i++ {
		separate = append(separate, &i)
	}
	for i, p := range separate {
		if *p != i {
			t.Fatalf("per-iteration value: %d want %d", *p, i)
		}
	}
	var shared []*int
	var j int
	for j = 0; j < 3; j++ {
		shared = append(shared, &j)
	}
	for _, p := range shared {
		if *p != 3 || p != &j {
			t.Fatal("existing variable not shared")
		}
	}
}
