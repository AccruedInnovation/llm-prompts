package apifixture

import (
	"errors"
	"fmt"
)

type Reader interface{ Read() }
type Buffer struct{}

func (*Buffer) Read() {}

var _ Reader = (*Buffer)(nil)
var ErrMissing = errors.New("record missing")

func Lookup() error { return fmt.Errorf("lookup record: %w", ErrMissing) }

// HiddenIdentity is deliberately different: callers cannot inspect ErrMissing.
func HiddenIdentity() error { return fmt.Errorf("lookup record: %v", ErrMissing) }
