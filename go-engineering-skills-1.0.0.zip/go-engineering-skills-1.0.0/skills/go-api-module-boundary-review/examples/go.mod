module example.com/go-skill-examples/go-api-module-boundary-review

go 1.23.0
