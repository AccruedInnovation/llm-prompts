---
name: go-security-supply-chain-review
description: "Review Go input, filesystem, subprocess, network, module, generator, and secret boundaries. Use for concrete exposure or dependency changes; separate vulnerable-package presence from demonstrated reachability."
---

# Go Security and Supply-Chain Review

Start with the assets, attacker-controlled inputs, trust boundaries, allowed effects, and exact build/dependency context. Review code and tools without installing analyzers or changing dependencies unless authorized. Severity follows reachable consequence, not the presence of a suspicious API name.

## Identify the boundaries

Trace untrusted requests, files, archives, templates, paths, URLs, database values, and configuration to an effect. Include authentication versus authorization, tenant scope, redirect/proxy/DNS behavior, subprocess arguments and environment, and generated/native code. Check logs, errors, profiles, traces, crash files, and binaries for secret exposure.

Apply size, count, nesting, decompression, CPU/time, and concurrency bounds where input can consume resources. Validation must run before the prohibited effect. A rejected parse is not proof that authorization ran. Use a structurally valid unauthorized input with other preconditions satisfied to test that guard.

## Filesystem decisions

Choose protection from the threat model. Lexical checks such as `filepath.IsLocal` can reject unsuitable path strings, but cannot establish containment through a changing filesystem. `EvalSymlinks` followed by a later open permits a check/use race if an attacker can replace components between them.

When supported, `os.OpenRoot` and root-relative methods provide traversal-resistant access. Open the root from a trusted location, retain the root handle for the operation, and avoid converting back to an ordinary joined path for the actual access. Go 1.24 introduced the basic API; later versions added methods. Verify the exact method and platform support before using it.

Rooted access is not a complete sandbox. It does not supply per-file authorization, byte budgets, a content snapshot, or protection against every mount, device, hard-link, or platform-specific threat. Define whether symlinks within the root are allowed. For older versions, use a proven adequate library or a justified narrower deployment assumption; do not invent a string-prefix substitute.

For archives, also handle duplicate/case-colliding names, absolute paths, symlinks, file kinds, count and expanded-size limits, permissions, and partially extracted output. See [filesystem and process cases](references/security-cases.md) and the [version-guarded root test](examples/root_go124_test.go).

## Commands, network, and presentation

Use argument arrays instead of shell evaluation where possible. That prevents shell metacharacter interpretation, not dangerous target-program options; use `--` only where the program supports it and validate the intended operation. Control working directory, environment, inherited handles, output bounds, and process-tree lifetime.

For outbound requests, parse URLs and define allowed schemes/hosts/ports, proxy behavior, redirects, and resolved-address policy when SSRF matters. Validating the original hostname once does not validate later redirects or DNS changes. Recheck each relevant destination, using an adequate transport/dial policy rather than improvised string matching. Do not send credentials to a redirected origin inadvertently.

Use parameterized SQL values; identifiers and SQL syntax need a separate allowlist or builder. Scope each query and mutation to authorized actors/tenants. `html/template` escapes untrusted values for HTML contexts, but casting to trusted template types bypasses protections. Templates themselves must come from the intended trusted source. CSRF and session policy remain separate from escaping.

## Dependencies and build-time effects

Inspect module paths, sums, workspace/local replacements, vendor content, retractions, tools, generators, native libraries, and relevant build flags. A valid module checksum checks downloaded bytes, not benign behavior, licensing, or maintenance quality. Downstream consumers do not inherit every main-module replacement or workspace setting.

Check private-module policy before contacting proxies or checksum services. `GOPRIVATE`, `GONOPROXY`, and `GONOSUMDB` have distinct roles; an intentional corporate proxy can be valid. Do not disable verification globally to silence one private-module problem.

`go generate` can run arbitrary commands and is not part of ordinary `go build`. Inspect generator identity, versions, inputs, network/effects, and output ownership before running it. Review `//go:embed`, linker inputs, CGO flags, release scripts, and CI credentials as part of what can influence the shipped result.

Use an available approved vulnerability scanner when needed. Distinguish package present, vulnerable symbol reachable, runtime exposure, mitigation, and unknown/tool failure. Scanner freshness and call-graph limits matter. Known-vulnerability checks do not replace review of authorization or unsafe behavior. Preserve required licence and release-origin checks without adding an unused attestation system.

## Return

Give concrete attack/failure path, prerequisites, affected data/effect, evidence, severity and confidence, smallest mitigation, and a discriminating regression test. Keep untested exposure separate from a proven exploit. Do not publish, disclose private sources, rotate credentials, or modify remote systems on review authority alone.

## Sources

[Traversal-resistant access](https://go.dev/blog/osroot), [os.Root](https://pkg.go.dev/os#Root), [filepath.IsLocal](https://pkg.go.dev/path/filepath#IsLocal), [os/exec](https://pkg.go.dev/os/exec), [html/template](https://pkg.go.dev/html/template), [module reference](https://go.dev/ref/mod), [govulncheck](https://go.dev/doc/security/vuln/).
