# Filesystem and process cases

## Check then open

**Faulty sequence:** Resolve `uploads/name`, prove it is under `uploads`, then call `os.Open` on the path later. An attacker with directory-write access may replace a component between those operations.

**Repair:** Use a root-relative operation that enforces containment during access, when supported. Alternatively narrow the threat with enforced filesystem permissions or use an established safe API for the target. A trusted fixed path with no attacker-controlled components may need no new root abstraction.

**Test:** Include `../outside`, an absolute path, an in-root file, and an out-of-root symlink. The guarded Go 1.24+ test creates temporary local fixtures and checks both accepted and rejected cases. It tests ordinary traversal and symlink escape on the executed platform; it is not an exhaustive adversarial race or mount-isolation proof. Creating a symlink may require privileges on some systems; report that skip explicitly.

Do not generalize a root-escape rejection into authorization for every file inside the root. A different tenant's file can be inside the same root.

## Argument arrays are not an option policy

`exec.Command("tool", userArgument)` avoids shell parsing of semicolons and substitutions. It still allows `userArgument` to be a dangerous option understood by `tool`. Define whether the input is a file name, pattern, subcommand, or option; validate that role and use the tool's documented end-of-options marker when valid. Some tools have no such marker.

Use a harmless argument-echo fixture to establish the boundary, not a destructive real command. Process cancellation and inherited output pipes need separate tests.

## SSRF without a string-only guarantee

A URL that begins with an allowed-looking prefix can still name a different authority. Parsing resolves syntax, not final network destination. Redirects and DNS can change the destination after initial validation. Decide whether the application may use ambient proxies and what address ranges/routes it permits. A valid public endpoint may legitimately redirect; preserve that behavior when the policy allows it. No SSRF-hardened HTTP client is bundled here.

## Negative tests must reach the target rule

To test file authorization, supply a structurally valid path that reaches the authorization check. To test traversal, use an otherwise valid authorized request and an escaping path. To test decompression limits, use valid compressed data with excessive expanded size, not a corrupt header rejected first. Inspect that no file, command, database change, or outbound call occurred.
