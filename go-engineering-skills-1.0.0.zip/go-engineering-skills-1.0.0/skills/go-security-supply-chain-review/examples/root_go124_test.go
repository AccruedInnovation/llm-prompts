//go:build go1.24

package rootexample

import (
	"io"
	"os"
	"path/filepath"
	"testing"
)

func TestRootAcceptsFileRejectsEscape(t *testing.T) {
	parent := t.TempDir()
	inside := filepath.Join(parent, "inside")
	if err := os.Mkdir(inside, 0700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(inside, "ok"), []byte("ok"), 0600); err != nil {
		t.Fatal(err)
	}
	outside := filepath.Join(parent, "outside")
	if err := os.WriteFile(outside, []byte("secret"), 0600); err != nil {
		t.Fatal(err)
	}
	root, err := os.OpenRoot(inside)
	if err != nil {
		t.Fatal(err)
	}
	defer root.Close()
	f, err := root.Open("ok")
	if err != nil {
		t.Fatal(err)
	}
	data, readErr := io.ReadAll(f)
	closeErr := f.Close()
	if readErr != nil || closeErr != nil || string(data) != "ok" {
		t.Fatalf("%q %v %v", data, readErr, closeErr)
	}
	for _, p := range []string{"../outside", outside} {
		if f, err := root.Open(p); err == nil {
			_ = f.Close()
			t.Fatalf("escape accepted: %q", p)
		}
	}
	t.Run("symlink", func(t *testing.T) {
		if err := os.Symlink(outside, filepath.Join(inside, "link")); err != nil {
			t.Skipf("symlink unavailable: %v", err)
		}
		if f, err := root.Open("link"); err == nil {
			_ = f.Close()
			t.Fatal("symlink escape accepted")
		}
	})
}
