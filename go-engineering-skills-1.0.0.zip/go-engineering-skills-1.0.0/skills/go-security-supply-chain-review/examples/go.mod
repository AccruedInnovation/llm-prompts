module example.com/go-skill-examples/go-security-supply-chain-review

go 1.23.0
