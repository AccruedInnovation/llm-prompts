// Package rootexample contains version-guarded filesystem examples.
// The os.Root test requires Go 1.24 or later and may skip symlinks without permission.
package rootexample
