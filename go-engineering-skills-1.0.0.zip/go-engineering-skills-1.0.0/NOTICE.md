# Source and notices

This collection adapts the fourteen skill files and supporting references supplied in `bbk-profile-go-0.1.0-alpha.3(2).zip`. The user authorized the content improvements and conversion to independent generic skills. The resulting set retains thirteen generic names, removes `bbk-go`, and adds `go-io-boundary-review` and `go-performance-review`.

The supplied archive's [MIT license](LICENSE), including its original copyright notice, remains unchanged. Each skill carries that same notice so copying one complete directory preserves it. The original package also identifies `comprehensive-analysis-go` as adapted from a user-supplied skill; no separate license for that earlier source was supplied. This collection preserves the notice and does not claim any additional rights over an unavailable earlier source.

New explanatory text, helper tools, and demonstration code were authored for this revision. Linked Go, OpenAI, and HTMX documentation informed technical corrections; links appear with the relevant sections. These are supporting references, not copies of vendor documentation. No external Go modules, analyzers, compilers, databases, browsers, agent runtimes, or third-party native libraries are bundled. The tiny C callback fixture is local demonstration code.

Product and project names in technical references identify their interfaces or source history. They do not imply endorsement. Source-project names in license/provenance notices do not impose a BBK runtime or package dependency.
