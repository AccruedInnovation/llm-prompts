#!/usr/bin/env python3
"""Check this collection; optionally run its local Go examples without downloads.

Python 3.10+. The header check validates the deliberately narrow name + JSON-quoted
YAML-description format used here, not arbitrary YAML. Go is optional for content
checks. Reports never hash themselves. Run on a trusted, disposable local copy.
"""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]

def content_checks(root: Path) -> dict:
    errors: list[str] = []
    skills = sorted((root / 'skills').glob('*/SKILL.md'))
    if not skills:
        errors.append('No skills found')
    for path in skills:
        text = path.read_text(encoding='utf-8')
        match = re.match(r'\A---\nname: ([a-z0-9]+(?:-[a-z0-9]+)*)\ndescription: ("[^\n]*")\n---\n\s*# ', text)
        if not match:
            errors.append(f'{path.relative_to(root)}: invalid collection header format')
            continue
        name, quoted = match.groups()
        if name != path.parent.name or len(name) > 64:
            errors.append(f'{name}: name/path mismatch or excessive length')
        try:
            desc = json.loads(quoted)
            if not 1 <= len(desc) <= 1024:
                errors.append(f'{name}: description length')
        except json.JSONDecodeError:
            errors.append(f'{name}: invalid quoted description')
        for doc in path.parent.rglob('*.md'):
            data = doc.read_text(encoding='utf-8')
            if re.search(r'\bBBK\b|alpha\.4|ImplementationStructureContract|ExecutionSlice|profile digest', data, re.I):
                errors.append(f'{doc.relative_to(root)}: project-specific instruction remains')
            for link in re.findall(r'\[[^\]]*\]\(([^)]+)\)', data):
                if re.match(r'[a-zA-Z][a-zA-Z0-9+.-]*:', link) or link.startswith('#'):
                    continue
                target = (doc.parent / link.split('#', 1)[0]).resolve()
                if not target.is_relative_to(path.parent.resolve()):
                    errors.append(f'{doc.relative_to(root)}: link leaves independent skill: {link}')
                elif not target.exists():
                    errors.append(f'{doc.relative_to(root)}: missing link: {link}')
        notice = path.parent / 'LICENSE'
        if not notice.is_file() or notice.read_bytes() != (root / 'LICENSE').read_bytes():
            errors.append(f'{name}: missing or changed upstream license notice')
    return {'status': 'FAIL' if errors else 'PASS', 'skills': len(skills), 'errors': errors}

def run_command(argv: list[str], cwd: Path, env: dict[str, str], root: Path,
                timeout: int = 120) -> dict:
    print('RUN', str(cwd.relative_to(root)), ' '.join(argv), flush=True)
    start = time.monotonic()
    try:
        p = subprocess.run(argv, cwd=cwd, env=env, text=True,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
        code, output = p.returncode, p.stdout
        status = 'PASS' if code == 0 else 'FAIL'
    except subprocess.TimeoutExpired as exc:
        output = exc.stdout or ''
        if isinstance(output, bytes):
            output = output.decode('utf-8', errors='replace')
        code, status = None, 'INCONCLUSIVE'
        output += '\nCommand timeout; this is not a pass.\n'
    events = []
    for line in output.splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(item, dict) and 'Action' in item:
            events.append(item)
    passed = [e['Test'] for e in events if e.get('Action') == 'pass' and 'Test' in e]
    skipped = [e['Test'] for e in events if e.get('Action') == 'skip' and 'Test' in e]
    return {'command': argv, 'cwd': str(cwd.relative_to(root)), 'status': status,
            'exit': code, 'seconds': round(time.monotonic() - start, 3),
            'passed_test_events': passed, 'skipped_test_events': skipped, 'output': output}

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--only', nargs='+', metavar='SKILL', help='Limit Go execution to these skill names; all content is still checked')
    parser.add_argument('--tests', action='store_true', help='Run tests and go vet')
    parser.add_argument('--race', action='store_true', help='Run tests with the race detector')
    parser.add_argument('--native-checks', action='store_true', help='Run checkptr and cgocheck2 on the callback example')
    parser.add_argument('--benchmarks', action='store_true', help='Run short benchmark smoke checks, not a performance study')
    parser.add_argument('--fuzz-seconds', type=int, default=0, help='Run bounded JSON fuzzing (1..60 seconds)')
    parser.add_argument('--report', type=Path, help='Write a JSON result to this explicit path')
    args = parser.parse_args()
    if not 0 <= args.fuzz_seconds <= 60:
        parser.error('--fuzz-seconds must be between 0 and 60')
    available = {p.parent.name for p in ROOT.glob('skills/*/SKILL.md')}
    if args.only and set(args.only) - available:
        parser.error('Unknown skills: ' + ', '.join(sorted(set(args.only) - available)))
    selected_skills = set(args.only or available)
    for requested, required in ((args.native_checks, 'go-unsafe-cgo-assembly-review'),
                                (args.benchmarks, 'go-performance-review'),
                                (args.fuzz_seconds, 'go-io-boundary-review')):
        if requested and required not in selected_skills:
            parser.error('Requested check requires selecting ' + required)
    report = {'content': content_checks(ROOT), 'checks': [], 'excluded_examples': [],
              'requested_go_scope': sorted(selected_skills),
              'requested_checks': {'tests_and_vet': args.tests, 'race': args.race,
                                   'native_checks': args.native_checks, 'benchmark_smoke': args.benchmarks,
                                   'fuzz_seconds': args.fuzz_seconds},
              'limits': ['No Codex-agent efficacy or discovery trial.',
                         'No browser, real database, asynchronous foreign library, or cross-platform runtime qualification.']}
    need_go = args.tests or args.race or args.native_checks or args.benchmarks or args.fuzz_seconds
    if need_go and not shutil.which('go'):
        report['error'] = 'Go is unavailable; requested execution did not run.'
    elif need_go:
        env = dict(os.environ)
        env.update(GOTOOLCHAIN='local', GOWORK='off', GOPROXY='off', GOSUMDB='off',
                   GOFLAGS='', GOEXPERIMENT='', GODEBUG='', GOMAXPROCS='2')
        # Limit execution to the host, rather than inheriting an unintended cross target.
        host = subprocess.check_output(['go', 'env', '-json', 'GOHOSTOS', 'GOHOSTARCH'], env=env, text=True)
        host = json.loads(host)
        env.update(GOOS=host['GOHOSTOS'], GOARCH=host['GOHOSTARCH'])
        report['go_version'] = subprocess.check_output(['go', 'version'], env=env, text=True).strip()
        report['environment'] = {k: env.get(k, '') for k in ('GOTOOLCHAIN','GOWORK','GOPROXY','GOSUMDB','GOFLAGS','GOEXPERIMENT','GODEBUG','GOMAXPROCS','GOOS','GOARCH')}
        report['cgo'] = subprocess.check_output(['go','env','CGO_ENABLED','CC'],env=env,text=True).strip().splitlines()
        for module in sorted(ROOT.glob('skills/*/examples/go.mod')):
            if module.parent.parent.name not in selected_skills:
                continue
            cwd = module.parent
            listing = run_command(['go', 'list', '-json', '.'], cwd, env, ROOT)
            if listing['status'] != 'PASS':
                report['checks'].append(listing)
                continue
            data = json.loads(listing['output'])
            for name in data.get('IgnoredGoFiles', []):
                report['excluded_examples'].append({'path': str((cwd / name).relative_to(ROOT)),
                                                    'status': 'NOT_RUN', 'reason': 'Excluded by the active Go version or build configuration'})
            selected = data.get('TestGoFiles', []) + data.get('XTestGoFiles', [])
            if args.tests or args.race:
                if not selected:
                    report['checks'].append({'cwd': str(cwd.relative_to(ROOT)), 'status': 'NOT_RUN',
                                             'reason': 'No example tests selected; not counted as a passing suite'})
                else:
                    cmd = ['go','test','-json','-count=1','-timeout=20s']
                    if args.race:
                        cmd.append('-race')
                    cmd.append('./...')
                    result = run_command(cmd, cwd, env, ROOT)
                    if result['status'] == 'PASS' and not result['passed_test_events']:
                        result['status'] = 'INCONCLUSIVE'
                        result['reason'] = 'No passing test events discovered'
                    report['checks'].append(result)
                if args.tests:
                    report['checks'].append(run_command(['go','vet','./...'],cwd,env,ROOT))
        if args.native_checks and 'go-unsafe-cgo-assembly-review' in selected_skills:
            cwd = ROOT/'skills/go-unsafe-cgo-assembly-review/examples'
            if report['cgo'][0] != '1':
                report['checks'].append({'cwd': str(cwd.relative_to(ROOT)), 'status': 'NOT_RUN', 'reason': 'CGO disabled'})
            else:
                report['checks'].append(run_command(['go','test','-json','-count=1','-timeout=20s','-gcflags=all=-d=checkptr=2','./...'],cwd,env,ROOT))
                stronger = dict(env, GOEXPERIMENT='cgocheck2')
                result = run_command(['go','test','-json','-count=1','-timeout=20s','./...'],cwd,stronger,ROOT)
                result['extra_environment'] = {'GOEXPERIMENT': 'cgocheck2'}
                report['checks'].append(result)
        if args.benchmarks and 'go-performance-review' in selected_skills:
            report['checks'].append(run_command(['go','test','-run','^$','-bench','.','-benchtime=10x','-count=1','./...'], ROOT/'skills/go-performance-review/examples',env,ROOT))
        if args.fuzz_seconds and 'go-io-boundary-review' in selected_skills:
            report['checks'].append(run_command(['go','test','-run','^$','-fuzz','^FuzzDecodeCreate$',f'-fuzztime={args.fuzz_seconds}s','-parallel=2','-timeout=90s'], ROOT/'skills/go-io-boundary-review/examples',env,ROOT))
    failed = report['content']['status'] != 'PASS' or 'error' in report or any(c['status'] in ('FAIL','INCONCLUSIVE') for c in report['checks'])
    report['status'] = 'FAIL' if failed else ('PASS_WITH_UNRUN_EXAMPLES' if report['excluded_examples'] else 'PASS')
    if args.report:
        args.report.expanduser().parent.mkdir(parents=True, exist_ok=True)
        args.report.expanduser().write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k: report[k] for k in ('status','content','excluded_examples')},indent=2))
    for c in report['checks']:
        print(c['status'], c.get('cwd'), ' '.join(c.get('command',[])), c.get('reason',''))
        if c['status'] in ('FAIL','INCONCLUSIVE'):
            print(c.get('output','')[-6000:])
    if 'error' in report:
        print(report['error'],file=sys.stderr)
    return 1 if failed else 0

if __name__ == '__main__':
    raise SystemExit(main())
