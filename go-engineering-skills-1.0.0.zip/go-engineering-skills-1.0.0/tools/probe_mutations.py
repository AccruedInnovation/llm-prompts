#!/usr/bin/env python3
"""Demonstrate four example tests detecting wrong behavior in disposable copies.

Requires Python 3.10+ and local Go 1.23+. No source skill or project is changed.
This is a small test-sensitivity check, not a Codex efficacy evaluation.
"""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
CASES = [
    ('duplicate-json', 'go-io-boundary-review', 'boundary.go',
     'if seen[key] {', 'if false && seen[key] {',
     '^TestNarrowJSONContract$/^duplicate$'),
    ('trailing-json', 'go-io-boundary-review', 'boundary.go',
     'if err := d.Decode(&extra); err != io.EOF {',
     'if err := d.Decode(&extra); false && err != io.EOF {',
     '^TestNarrowJSONContract$/^trailing-junk$'),
    ('state-transition', 'go-implementation-structure', 'state.go',
     'if m.state != Idle {', 'if false && m.state != Idle {',
     '^TestZeroValueAndTransitions$'),
    ('wrapped-error', 'go-api-module-boundary-review', 'api.go',
     'fmt.Errorf("lookup record: %w", ErrMissing)',
     'fmt.Errorf("lookup record: %v", ErrMissing)',
     '^TestPublicErrorIdentity$'),
]

def check(cwd: Path, selection: str, env: dict) -> dict:
    argv = ['go','test','-json','-count=1','-timeout=10s','-run',selection,'./...']
    p = subprocess.run(argv,cwd=cwd,env=env,text=True,stdout=subprocess.PIPE,
                       stderr=subprocess.STDOUT,timeout=90)
    events = []
    for line in p.stdout.splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(event,dict) and event.get('Test'):
            events.append(event)
    return {'command':argv,'exit':p.returncode,
            'passed':[e['Test'] for e in events if e.get('Action')=='pass'],
            'failed':[e['Test'] for e in events if e.get('Action')=='fail'],
            'output':p.stdout}

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report',type=Path)
    args = parser.parse_args()
    env = dict(os.environ, GOTOOLCHAIN='local', GOWORK='off', GOPROXY='off',
               GOSUMDB='off', GOFLAGS='', GOEXPERIMENT='', GODEBUG='', GOMAXPROCS='2')
    host = json.loads(subprocess.check_output(['go','env','-json','GOHOSTOS','GOHOSTARCH'],env=env,text=True))
    env.update(GOOS=host['GOHOSTOS'],GOARCH=host['GOHOSTARCH'])
    report = {'go_version':subprocess.check_output(['go','version'],env=env,text=True).strip(),
              'scope':'Four disposable example mutations; not agent evaluation', 'cases':[]}
    with tempfile.TemporaryDirectory(prefix='go-skill-mutations-') as temp:
        for name,skill,filename,old,new,selection in CASES:
            cwd=Path(temp)/name
            shutil.copytree(ROOT/'skills'/skill/'examples',cwd)
            baseline=check(cwd,selection,env)
            path=cwd/filename
            text=path.read_text(encoding='utf-8')
            if text.count(old)!=1:
                raise ValueError(f'{name}: mutation target is not unique')
            path.write_text(text.replace(old,new,1),encoding='utf-8')
            altered=check(cwd,selection,env)
            # A compile failure or zero selected tests does not count as detection.
            detected=(baseline['exit']==0 and bool(baseline['passed'])
                      and altered['exit']!=0 and bool(altered['failed']))
            report['cases'].append({'name':name,'source_skill':skill,'file':filename,
                'old':old,'new':new,'baseline':baseline,'mutated':altered,
                'status':'DETECTED' if detected else 'FAIL'})
            print(name,report['cases'][-1]['status'],flush=True)
    report['status']='PASS' if all(c['status']=='DETECTED' for c in report['cases']) else 'FAIL'
    if args.report:
        args.report.parent.mkdir(parents=True,exist_ok=True)
        args.report.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    return 0 if report['status']=='PASS' else 1

if __name__=='__main__':
    raise SystemExit(main())
