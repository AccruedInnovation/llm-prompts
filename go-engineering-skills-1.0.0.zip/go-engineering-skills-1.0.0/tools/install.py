#!/usr/bin/env python3
"""Copy selected local skill directories without overwriting an existing skill."""
from __future__ import annotations
import argparse
import os
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[1]

def install(target: Path, names: list[str] | None = None) -> list[str]:
    sources = {p.name: p for p in sorted((ROOT / 'skills').iterdir())
               if p.is_dir() and (p / 'SKILL.md').is_file()}
    chosen = list(sources) if names is None else list(dict.fromkeys(names))
    unknown = sorted(set(chosen) - sources.keys())
    if unknown:
        raise ValueError('Unknown skills: ' + ', '.join(unknown))
    if not chosen:
        raise ValueError('No skills selected')
    target = target.expanduser().resolve()
    if target == (ROOT / 'skills').resolve() or target.is_relative_to(ROOT / 'skills'):
        raise ValueError('The destination must not be inside the source skills directory')
    if target.exists() and not target.is_dir():
        raise ValueError(f'Not a directory: {target}')
    conflicts = [name for name in chosen if os.path.lexists(target / name)]
    if conflicts:
        raise FileExistsError('No files copied. Existing skill names: ' + ', '.join(conflicts))
    for name in chosen:
        if sources[name].is_symlink() or any(p.is_symlink() for p in sources[name].rglob('*')):
            raise ValueError(f'Source symlink is not supported: {name}')
    target.mkdir(parents=True, exist_ok=True)
    created: list[Path] = []
    try:
        for name in chosen:
            dest = target / name
            # Exclusive creation prevents replacing an existing destination.
            dest.mkdir()
            created.append(dest)
            shutil.copytree(sources[name], dest, dirs_exist_ok=True)
    except Exception:
        for dest in reversed(created):
            shutil.rmtree(dest)
        raise
    return chosen

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target', type=Path, help='Explicit Codex skills directory')
    parser.add_argument('--only', nargs='+', metavar='SKILL', help='Install only these names')
    parser.add_argument('--list', action='store_true', help='List skill names without copying')
    args = parser.parse_args()
    if args.list:
        for p in sorted((ROOT / 'skills').glob('*/SKILL.md')):
            print(p.parent.name)
        return 0
    if args.target is None:
        parser.error('--target is required unless --list is used')
    try:
        names = install(args.target, args.only)
    except (OSError, ValueError) as exc:
        print(f'Install failed: {exc}', file=sys.stderr)
        return 1
    print(f'Installed {len(names)} skills into {args.target.expanduser().resolve()}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
