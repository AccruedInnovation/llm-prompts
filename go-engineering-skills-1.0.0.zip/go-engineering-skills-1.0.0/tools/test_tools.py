"""Local tests for the optional copy helper and collection checks. Python 3.10+."""
from __future__ import annotations
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent

def load(name: str):
    spec = importlib.util.spec_from_file_location(name, HERE / (name + '.py'))
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

installer = load('install')
validator = load('validate')

class ToolTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='go-skill-tools-')
        self.addCleanup(self.temp.cleanup)
        self.home = Path(self.temp.name)
        self.source = self.home / 'source'
        self.target = self.home / 'target'
        self.source.mkdir()
        (self.source / 'LICENSE').write_text('Test license\n', encoding='utf-8')
        for name in ('go-a', 'go-b'):
            directory = self.source / 'skills' / name
            (directory / 'references').mkdir(parents=True)
            (directory / 'references' / 'case.md').write_text('# Case\n', encoding='utf-8')
            (directory / 'SKILL.md').write_text('---\nname: '+name+'\ndescription: '+json.dumps('Use for tests')+'\n---\n\n# Test\n\n[Case](references/case.md)\n', encoding='utf-8')
            shutil.copy2(self.source / 'LICENSE', directory / 'LICENSE')
        self.binding = patch.object(installer, 'ROOT', self.source)
        self.binding.start()
        self.addCleanup(self.binding.stop)

    def test_install_whole_directories(self):
        self.assertEqual(installer.install(self.target), ['go-a', 'go-b'])
        for p in (self.source/'skills').rglob('*'):
            if p.is_file():
                self.assertEqual(p.read_bytes(), (self.target/p.relative_to(self.source/'skills')).read_bytes())

    def test_selected_skill_and_duplicate_request(self):
        self.assertEqual(installer.install(self.target, ['go-b', 'go-b']), ['go-b'])
        self.assertFalse((self.target/'go-a').exists())

    def test_collision_preflights_entire_request(self):
        (self.target/'go-b').mkdir(parents=True)
        keep = self.target/'go-b'/'keep.txt'
        keep.write_text('existing user work', encoding='utf-8')
        with self.assertRaises(FileExistsError):
            installer.install(self.target)
        self.assertEqual(keep.read_text(), 'existing user work')
        self.assertFalse((self.target/'go-a').exists())

    def test_unknown_name_does_not_create_target(self):
        with self.assertRaises(ValueError):
            installer.install(self.target, ['../../outside'])
        self.assertFalse(self.target.exists())

    def test_source_destination_rejected(self):
        with self.assertRaises(ValueError):
            installer.install(self.source/'skills'/'nested')
        self.assertFalse((self.source/'skills'/'nested').exists())

    def test_copy_failure_removes_only_new_destinations(self):
        self.target.mkdir()
        keep = self.target/'unrelated.txt'
        keep.write_text('keep', encoding='utf-8')
        with patch.object(installer.shutil, 'copytree', side_effect=OSError('injected copy failure')):
            with self.assertRaises(OSError):
                installer.install(self.target)
        self.assertFalse((self.target/'go-a').exists())
        self.assertFalse((self.target/'go-b').exists())
        self.assertEqual(keep.read_text(), 'keep')

    def test_source_symlink_rejected(self):
        link = self.source/'skills'/'go-a'/'references'/'alias.md'
        try:
            link.symlink_to('case.md')
        except OSError as exc:
            self.skipTest(f'Cannot create a symlink here: {exc}')
        with self.assertRaises(ValueError):
            installer.install(self.target)
        self.assertFalse(self.target.exists())

    def test_static_valid(self):
        self.assertEqual(validator.content_checks(self.source)['status'], 'PASS')

    def test_static_broken_local_reference(self):
        (self.source/'skills'/'go-a'/'references'/'case.md').unlink()
        self.assertEqual(validator.content_checks(self.source)['status'], 'FAIL')

    def test_static_missing_license(self):
        (self.source/'skills'/'go-a'/'LICENSE').unlink()
        self.assertEqual(validator.content_checks(self.source)['status'], 'FAIL')

    def test_static_invalid_header(self):
        p = self.source/'skills'/'go-a'/'SKILL.md'
        p.write_text(p.read_text().replace('description: "Use for tests"', 'description: bad: YAML'), encoding='utf-8')
        self.assertEqual(validator.content_checks(self.source)['status'], 'FAIL')

    def test_static_external_local_dependency(self):
        p = self.source/'skills'/'go-a'/'SKILL.md'
        p.write_text(p.read_text()+'\n[Other](../go-b/SKILL.md)\n', encoding='utf-8')
        self.assertEqual(validator.content_checks(self.source)['status'], 'FAIL')

if __name__ == '__main__':
    unittest.main()
