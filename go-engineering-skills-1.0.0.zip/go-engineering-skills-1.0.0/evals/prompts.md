# Go skill evaluation prompts

These are prepared cases, not records of executed Codex trials. Use a fresh session and give the agent only a selected prompt and its stated context. Keep the separate answer key out of that session. The user may explicitly select the named skill or test automatic selection. Snippets are review fragments unless a complete runnable example path is named.

Record the model/tool versions, project Go version, supplied skill, answer, actual commands, repairs, and false positives. Judge defect detection, valid alternatives, and proof quality separately. Do not infer an improvement from examples merely compiling.

## E01 — Select and shutdown

Use `go-correctness-concurrency-review`. We promise that once cancellation starts no new job can be accepted. Does this fragment enforce that promise? Give the smallest valid repair choices without inventing a universal queue framework.

```go
select {
case <-ctx.Done():
    return ctx.Err()
case jobs <- job:
    return nil
}
```

## E02 — Cancel and return

Use `go-correctness-concurrency-review`. A function owns a connection, defers closing it, starts a worker that uses it, then returns as soon as its context is canceled. The worker sometimes blocks on a method that does not use context. Review ownership and completion, and propose a test based on events rather than sleeps.

## E03 — Buffer ownership

Use `go-correctness-concurrency-review`. A producer sends `buf[:n]` through a channel and immediately refills `buf`; the consumer reads the received slice later. The channel is buffered. Does buffering protect the data? Give valid repair choices and one race-free demonstration of the aliasing issue.

## E04 — Valid unbuffered handoff

Use `go-correctness-concurrency-review`. A function starts one worker, receives its one integer result on an unbuffered channel, and waits for its separate done channel before returning. The worker always computes locally, sends once, closes done, and accesses no shared mutable data. No cancel/overload requirement exists. Review it without adding requirements.

## E05 — JSON assumptions

Use `go-io-boundary-review`. An endpoint uses `encoding/json.NewDecoder`, calls `DisallowUnknownFields`, and calls `Decode` once into a struct. Its documented contract requires exact field casing, no duplicate names, one value only, required non-null fields, and an input byte bound. Which promises does the current code not establish? Avoid claiming every endpoint needs this particular contract.

## E06 — EOF and size

Use `go-io-boundary-review`. A read loop returns before using the buffer whenever `err != nil`. Elsewhere `io.ReadAll(io.LimitReader(r, 1024))` is claimed to prove the document is at most 1024 bytes. Review both claims, name distinguishing inputs, and preserve valid stream use of limits.

## E07 — Transaction helper

Use `go-io-boundary-review`. A request starts a `sql.Tx`; one helper then calls the parent `*sql.DB.ExecContext`, and a later transaction statement fails. The pool permits one connection. Explain the two distinct hazards and a real-engine test; do not pretend a mock proves persistence behavior.

## E08 — Constants and constructors

Use `go-implementation-structure`. A public `type State uint8` has constants Idle and Running. The author says only those states exist because the constants are typed. A public struct has private fields and a constructor, which the author says prevents every invalid zero value. Assess these claims and propose choices that respect Go's actual guarantees.

## E09 — One invariant, two checks

Use `comprehensive-analysis-go`. An application validates a unique account name before inserting it, and the database has a unique constraint. A review proposes deleting the database constraint because the rule is already enforced once in the application. All inserts can run concurrently. Assess the proposed simplification.

## E10 — Worker failure and parallel cleanup

Use `go-test-strategy-review`. A test worker calls `t.Fatal`; the test goroutine waits for a result it may never receive. A different parent test defers resource cleanup and creates children that call `t.Parallel`. A third parallel test calls `t.Setenv`. Explain each issue, valid repairs, and when ordinary defer remains correct.

## E11 — Toolchain versus minimum

Use `go-api-module-boundary-review`. A library changes only its `toolchain` suggestion to a newer version, while its `go` directive and source API use stay unchanged. A reviewer declares every downstream consumer must now upgrade to that toolchain. Explain what must actually be checked. Do not infer an exact pinned compiler from a toolchain suggestion.

## E12 — Version-sensitive false positive

Use `go-api-module-boundary-review`. The module declares Go 1.23. Compare pointers captured by `for i := 0; i < 3; i++` with pointers captured by `var i int; for i = 0; i < 3; i++`. Is the old loop-variable warning valid for both? Does the answer deep-copy objects pointed to by a loop value?

## E13 — Graceful shutdown

Use `go-operational-readiness-review`. A main function launches `srv.Shutdown` in a goroutine using the request context it just canceled, then returns after `ListenAndServe` reports `http.ErrServerClosed`. It also has WebSocket connections and a queue worker. Review its completion claim and propose separate tests for normal drain and grace expiry.

## E14 — Native handle lifetime

Use `go-unsafe-cgo-assembly-review`. A foreign library retains a `cgo.Handle` integer. Unregister stops new submissions but may return while a callback is still active. Close deletes the handle immediately. The author adds `runtime.KeepAlive` and says the lifetime is safe. Explain the missing guarantee and why a synchronous callback fixture alone would not prove this API safe.

## E15 — Rooted paths

Use `go-security-supply-chain-review`. A server resolves symlinks, checks a path prefix, then opens the path. An attacker can replace directory entries. Compare this with a fixed private configuration path whose parents the attacker cannot alter. Discuss a suitable rooted-access option for Go 1.24+, its limits, and what a platform test can prove.

## E16 — Performance and HTMX claims

Use only the focused skills needed. A benchmark loop was optimized away, but its single best run is cited as a service latency improvement. Separately, one URL returns a full page or HTMX fragment based on a request header, and a shared cache keys only on URL. Name the useful evidence for each claim and the conditional repair. Do not prescribe browser changes or PGO merely because a benchmark exists.

## E17 — Small, valid local change

Use `go-skills`. A private parser fix preserves public behavior except for the requested bug. Two focused regression cases distinguish the defect; existing affected tests pass. No dependency, lifecycle, security, public API, or release promise changes. What should the handoff contain? Do not require a new interface, manifest, hashing system, or full release audit without a named need.
